import js from '@eslint/js';
import tseslint from 'typescript-eslint';
import jsxA11y from 'eslint-plugin-jsx-a11y';
import prettier from 'eslint-config-prettier';

export default tseslint.config(
  {
    ignores: [
      '**/node_modules/**',
      '**/dist/**',
      '**/.next/**',
      '**/coverage/**',
      '**/next-env.d.ts',
    ],
  },

  js.configs.recommended,
  ...tseslint.configs.recommended,

  // Autorise `const { champExclu, ...reste } = valeurs` sans lire `champExclu` : c'est la
  // façon habituelle d'omettre un champ avant un envoi à l'API (voir `send` dans les
  // formulaires d'inscription), pas une variable oubliée.
  {
    rules: {
      '@typescript-eslint/no-unused-vars': ['error', { ignoreRestSiblings: true }],
    },
  },

  // Accessibilité : les règles jsx-a11y couvrent une partie du RGAA 4.1
  // (alternatives textuelles, labels, rôles ARIA) directement à la frappe.
  {
    files: ['apps/web/**/*.tsx'],
    ...jsxA11y.flatConfigs.recommended,
  },

  // Les tests manipulent des doubles : on y tolère `any`.
  {
    files: ['**/*.spec.ts', '**/*.e2e-spec.ts'],
    rules: {
      '@typescript-eslint/no-explicit-any': 'off',
      '@typescript-eslint/no-unsafe-argument': 'off',
    },
  },

  prettier,
);
