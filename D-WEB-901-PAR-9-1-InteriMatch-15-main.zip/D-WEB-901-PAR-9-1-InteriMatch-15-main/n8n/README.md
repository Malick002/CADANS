# Workflows n8n

Trois workflows importables. Deux sont déclenchés par l'API via les webhooks qu'elle appelle
déjà (`apps/api/src/n8n/n8n.service.ts`), le troisième se réveille tout seul.

| Fichier | Déclencheur | Ce qu'il fait |
| --- | --- | --- |
| `match-notification.json` | Webhook, `notifyMatch` — un **nouveau** match apparaît | Email à l'intérimaire : la mission et son score |
| `mission-pourvue.json` | Webhook, `notifyMissionPourvue` — une mission passe à `POURVUE` | **Deux emails distincts** : à l'intérimaire et à l'entreprise, chacun avec le lien vers **son** contrat à signer sur CADANS |
| `rappel-debut-mission.json` | **Planification**, tous les jours à 8h **heure de Paris** | Email à l'intérimaire dont une mission démarre **dans 2 jours** |

> Le conteneur est réglé sur `Europe/Paris` (`GENERIC_TIMEZONE` et `TZ` dans
> `docker-compose.yml`). Sans cela n8n raisonne en UTC, et le rappel de 8h partirait à 10h
> l'été, 9h l'hiver.

> ⚠️ **Ces fichiers ne sont pas exécutés par le dépôt.** Ils doivent être **importés dans une
> instance n8n, puis testés dedans**. Tant que les deux premiers ne sont pas importés, activés
> et que leurs URL ne sont pas dans le `.env`, l'API journalise l'appel au lieu de l'envoyer
> (`N8nService`, comportement voulu).

## Envoi : Gmail SMTP

Les trois workflows envoient par **Gmail SMTP**, avec le même expéditeur
`CADANS <interimcadans@gmail.com>`.

**L'identifiant se crée dans n8n, après l'import. Il n'est ni dans ces fichiers, ni ailleurs
dans le dépôt** — les nœuds d'envoi arrivent donc sans identifiant sélectionné, c'est normal.

### Créer le mot de passe d'application Google

Le mot de passe du compte Google **ne fonctionne pas** en SMTP. Il faut un *mot de passe
d'application*, qui se révoque seul sans toucher au compte.

1. Activer la **vérification en deux étapes** sur le compte Google — sans elle, Google ne
   propose pas les mots de passe d'application.
2. Générer un **mot de passe d'application** (16 caractères) depuis la sécurité du compte.
3. Dans n8n : **Credentials → New → SMTP**, puis :

| Champ | Valeur |
| --- | --- |
| User | `interimcadans@gmail.com` |
| Password | le mot de passe d'application, **pas** celui du compte |
| Host | `smtp.gmail.com` |
| Port | `465` |
| SSL/TLS | **activé** |

4. Sur chaque nœud d'envoi des trois workflows, sélectionner cet identifiant.

Le troisième workflow demande en plus un **identifiant PostgreSQL**, créé lui aussi dans n8n
uniquement. Sa requête est un `SELECT` : un rôle en lecture seule suffit, et c'est préférable.

## Import

1. Lancer n8n : **`npm run n8n:up`** (`npm run n8n:down` pour l'arrêter).

   Il est déclaré dans `docker-compose.yml` sous un **profil**, donc `npm run db:up` ne le
   démarre pas — ce script s'appelle « db » et n'a pas à lancer un troisième service.

   Son volume s'appelle `n8n_data` **sans préfixe de projet**, et c'est délibéré : Compose
   l'aurait sinon nommé `<projet>_n8n_data` et créé un volume NEUF. Quiconque avait déjà
   lancé n8n à la main (`docker run … -v n8n_data:…`) retrouve donc ses workflows et ses
   identifiants tels quels.
2. Ouvrir `http://localhost:5678`, puis, pour chaque fichier :
   **Workflows → … (menu) → Import from File**.
3. Créer les identifiants (chapitre ci-dessus) et les sélectionner sur les nœuds concernés.

   ⚠️ **Hôte de la base, pour le workflow de rappel.** Depuis le conteneur n8n, `localhost`
   désigne n8n lui-même, pas votre machine. L'hôte à saisir dans l'identifiant PostgreSQL
   est **`postgres`** — le nom du service Compose — et le port **5432**. (Avec un `docker run`
   isolé, hors du réseau Compose, il fallait `host.docker.internal` : `npm run n8n:up` évite
   ce détour.)
4. **Save**, puis **Active**.
5. Sur les nœuds *Webhook* des deux premiers, relever l'**URL de production** — pas l'URL de
   test, qui n'écoute que pendant un clic sur « Listen for test event ».
6. Coller ces deux URL dans le `.env` de l'API, et la redémarrer :

```dotenv
N8N_MATCH_NOTIFICATION_URL=https://<votre-n8n>/webhook/cadans-match-notification
N8N_MISSION_POURVUE_URL=https://<votre-n8n>/webhook/cadans-mission-pourvue
```

En production, ce sont les mêmes deux variables à définir sur le service Render de l'API. Le
workflow de rappel n'en a pas : il n'est jamais appelé par l'API.

## Tester

### Sans lancer l'API

Ouvrir le workflow, cliquer **Execute workflow**, et coller un corps de requête sur le nœud
Webhook. Les nœuds Code retombent sur la racine du JSON quand `body` est absent, précisément
pour que ce test manuel fonctionne.

Notification de match :

```json
{
  "interimaire": {
    "prenom": "Leïla",
    "nom": "Moreau",
    "email": "interimcadans+cariste@gmail.com"
  },
  "entreprise": { "email": "interimcadans+entreprise@gmail.com" },
  "mission": {
    "titre": "Cariste",
    "entreprise": "Entrepôt du Nord",
    "ville": "Entrepôt du Nord — quai 4",
    "codePostal": "95700",
    "dateDebut": "2026-09-29",
    "remuneration": "13.5 € / h",
    "url": "http://localhost:3000/missions/..."
  },
  "score": 100
}
```

Mission pourvue : même forme, plus `mission.dateFin`. **Aucun contrat n'y figure** — ni en
pièce jointe, ni en base64.

Ce qui compte, c'est `mission.url` : les liens de signature en sont déduits. Le nœud Code
**échoue volontairement** s'il n'y a ni `interimaire.email` ni `entreprise.email` — mieux vaut
une exécution en erreur, visible dans n8n, qu'un envoi silencieux à personne.

### Tester le rappel sans attendre 8h

Le workflow de rappel n'a pas de webhook : on ne peut pas lui envoyer un corps de requête. Il
faut donc que la **base contienne** une mission qui démarre dans exactement deux jours.

1. `npm run db:up`, puis `npm run seed:demo -- --complet`. Le jeu complet crée exactement ça :
   une mission `POURVUE` attribuée à Leïla, qui démarre **dans 2 jours**, quai 2.
2. Dans n8n, ouvrir `rappel-debut-mission.json` et cliquer **Execute workflow**. La
   planification est ignorée en exécution manuelle : la requête part tout de suite.
3. Le nœud Postgres doit renvoyer **une ligne**, et l'email partir vers
   `interimcadans+cariste@gmail.com`.

Pour vérifier la requête sans n8n :

```bash
docker exec cadans_postgres psql -U cadans -d cadans -c "
SELECT p.label, m.site_label, to_char(m.start_date,'DD/MM/YYYY'), u.email
FROM missions m
JOIN postes p ON p.code = m.poste_code
JOIN workers w ON w.id = m.assigned_worker_id
JOIN users u ON u.id = w.user_id
WHERE m.status = 'POURVUE' AND m.start_date = CURRENT_DATE + 2;"
```

Zéro ligne signifie qu'aucune mission ne démarre dans deux jours — relancer le seed, dont les
dates sont relatives au jour où il tourne.

### De bout en bout, avec l'API

1. `npm run db:up` puis `npm run seed:demo -- --complet`.
2. Renseigner les deux `N8N_*_URL` dans le `.env`, relancer `npm run dev`.
3. **Match** : se connecter en `interimcadans+cariste@gmail.com` et ouvrir
   `/interimaire/matches`. Rien ne part au tout premier calcul — l'API compare au dernier
   calcul journalisé en Mongo et ne notifie que les matchs nouveaux, pour éviter une rafale à
   l'inscription. Publier une nouvelle mission correspondante, puis recharger : l'email part.
4. **Mission pourvue** : en `interimcadans+entreprise@gmail.com`, passer une mission à
   `POURVUE` en désignant l'intérimaire retenu. Les contrats sont générés, puis le webhook est
   appelé. **Deux emails** arrivent, un par destinataire, chacun portant le lien de son propre
   espace — et non le même message à deux adresses.

Les trois comptes de démonstration utilisent le **sous-adressage Gmail** (`+suffixe`) : ils
sont distincts pour l'application, mais tous les emails arrivent dans **la même boîte**.

Si rien n'arrive, l'API le dit dans sa console : `Webhook n8n « … » désactivé (URL absente)`,
`… a répondu 4xx` ou `… injoignable`. Ces appels ne font jamais échouer l'action principale.

## Notes de lecture

**Le contrat n'est plus joint : on envoie un lien vers la signature.** Un PDF en pièce jointe
ne peut pas être signé, et il circule ensuite hors de toute trace — là où la signature
conserve qui, quand, d'où, et sur quelle empreinte de document. Le nœud *Base64 vers fichier*
a donc disparu de `mission-pourvue.json`, et avec lui la pièce jointe.

**Un élément par destinataire.** Le nœud Code rend un tableau de deux éléments ; le nœud
d'envoi s'exécute **une fois par élément**. C'est ce qui permet d'envoyer deux messages
différents — l'intérimaire reçoit le lien de `/interimaire/contrats`, l'entreprise celui de
`/entreprise/contrats`. Un envoi groupé mettrait les deux adresses dans le même « À », et
l'entreprise lirait le lien de l'intérimaire. Comme le JSON est conservé d'un nœud à l'autre,
l'envoi lit directement `$json.destinataire`, `$json.sujet` et `$json.texte`.

**L'adresse du site est déduite de `mission.url`**, en coupant sur `/missions/`. C'est le seul
moyen de ne pas toucher à l'API, qui ne connaît pas les chemins des espaces connectés. Piège
vérifié en exerçant le code : `split` rend le tableau entier quand le séparateur est absent,
donc sans test de longueur une URL de forme inattendue produisait
`https://…/offre/1/interimaire/contrats` — un lien mort qui a l'air valide. Le repli est
désormais l'URL de la mission elle-même.

**La charge utile ne porte plus le contrat.** `contrat_pdf_base64` a été retiré de l'API
(`MissionPourvuePayload`) le 23/09 : envoyer un PDF entier sur un webhook qui n'en fait rien
coûtait pour rien, et faisait transiter l'état civil du salarié à chaque mission pourvue. Un
test unitaire vérifie que le corps envoyé ne contient que `interimaire`, `entreprise` et
`mission`.

**Le rappel est en lecture seule.** Son nœud Postgres exécute un `SELECT`, jamais d'écriture.
Il sélectionne les missions `POURVUE` dont `start_date` vaut exactement `CURRENT_DATE + 2`, et
joint `workers` puis `users` par `assigned_worker_id` pour obtenir le nom et l'adresse de
l'intérimaire retenu.

**L'API n'échoue jamais si n8n est absent.** `N8nService` journalise et n'élève rien :
notifier est un aval de l'action principale (matching calculé, mission mise à jour), jamais
une condition de sa réussite. Une instance n8n arrêtée le jour de la soutenance ne doit pas
empêcher de pourvoir une mission.
