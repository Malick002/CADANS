# Livrables du point de cadrage

Rendu du **mardi 15 septembre 2026 (J3)**, correspondant au point de cadrage go/nogo de J2.

## Contenu

| Fichier | Contenu |
| --- | --- |
| `dossier_de_cadrage_CADANS.pdf` | Étude de marché, périmètre du POC, synthèse du chiffrage, planning, stack technique, liste des livrables |
| `chiffrage_CADANS.xlsx` | Chiffrage détaillé : 52 sous-tâches, 31,5 jours-homme, dépendances, priorités d'arbitrage, suivi du réel vs estimé |
| Tableau Miro | Roadmap fonctionnelle et backlog — vues Tableau, Planning et Kanban |

**Tableau Miro :** https://miro.com/app/board/uXjVHml3NSU=/?share_link_id=371414406445

## Où vit quoi

Le **chiffrage n'est tenu qu'à un seul endroit**, le fichier `chiffrage_CADANS.xlsx`. Le
tableau par module du dossier de cadrage en est une synthèse, et le backlog Miro sert au
pilotage quotidien. Toute modification décidée dans Miro doit être reportée dans le fichier
Excel, sinon l'écart entre le temps réel et l'estimé présenté en soutenance serait calculé
sur une base fausse.

Dans le fichier Excel, **seule la colonne « Réel (j) » de l'onglet Chiffrage détaillé est à
saisir** — elle est sur fond jaune. Tout le reste est calculé.

## Révision depuis le go/nogo

Le chiffrage présenté à J2 portait sur 48 sous-tâches et 29 jours-homme. Il a été décliné
plus finement et complété de quatre lignes manquantes : maquettes des écrans clés, chaîne de
déploiement continu, dockerisation de l'environnement de développement, et réserve
d'intégration et de reprise de bugs. Il est donc passé à **52 sous-tâches et 31,5
jours-homme**.

## Jalons restants

| Jalon | Date | Objet |
| --- | --- | --- |
| J8 | mar. 22/09 | Gel du périmètre produit : ce qui n'est pas fait bascule en coupe |
| J10 | jeu. 24/09 | Livraison du dépôt, du rapport de coverage et du chiffrage réel |
| J11 | ven. 25/09 | Soutenance orale et démo live |
