# Parcours entreprise

Ce que vit une entreprise utilisatrice de son inscription à la première mission pourvue, écran
par écran, avec ce que chaque écran appelle et les effets qui ne se voient pas. Symétrique de
[`parcours-interimaire.md`](parcours-interimaire.md). État au 23/09/2026.

## Le parcours

| # | Étape | Écran | Ce que l'écran appelle |
| --- | --- | --- | --- |
| 1 | Inscription | `/inscription?profil=entreprise` | `POST /auth/register/company` : raison sociale, SIRET (clé de Luhn vérifiée), code NAF, contact, adresse, téléphone. La session s'ouvre, l'entreprise arrive sur `/entreprise/missions` |
| 2 | Coordonnées | `/entreprise/parametres` | `PUT /companies/me`, `PUT /account/me/email`, `PUT /account/me/password` |
| 3 | Publier une mission | `/entreprise/missions/nouvelle` | `POST /missions`, ou `POST /missions/prefill` puis `POST /missions` depuis une offre France Travail |
| 4 | Suivre ses missions | `/entreprise/missions` | `GET /missions` : Ouverte, Pourvue, Terminée, avec le nombre de candidatures |
| 5 | Lire les candidatures | `/entreprise/candidatures` | `GET /missions/:id/candidatures` : score ventilé, habilitations « vérifié » ou « déclaré », compétences déclarées |
| 6 | Retenir un candidat | même écran | `PATCH /missions/:id/status` avec `POURVUE` et l'intérimaire choisi |
| 7 | Signer le contrat de mise à disposition | `/entreprise/contrats` puis `/entreprise/contrats/:id/signer` | `GET /contrats`, `GET /contrats/:id/document`, `POST /contrats/:id/signer` |
| 8 | Joindre des documents | `/entreprise/missions/:id/annexes` | `POST /missions/:id/annexes`, `DELETE /annexes/:id` |
| 9 | Clore | `/entreprise/missions` | `PATCH /missions/:id/status` avec `TERMINEE` |

## Écran par écran

### Publier une mission

Le poste se choisit dans le référentiel ROME, jamais en texte libre : c'est ce qui rend le
matching possible. Choisir un poste **pré-remplit les habilitations exigées** avec la
suggestion du référentiel, que l'entreprise ajuste ; c'est cette liste, sur la mission, que le
filtrage bloquant lit. Le formulaire demande aussi dates, créneau, lieu (libellé du site et
code postal), taux horaire, motif de recours (accroissement temporaire, remplacement, saisonnier,
usage) et, pour un remplacement, le nom et la qualification de la personne remplacée : ce sont
les mentions que le contrat de mise à disposition doit porter.

Seconde entrée, si les identifiants France Travail sont renseignés : **partir d'une offre**,
en collant son adresse ou son identifiant. Le formulaire est prérempli avec ce que l'offre
donne vraiment, et un bilan dit ce qui a été repris, ce qui reste à saisir et ce qui est à
vérifier (une rémunération mensuelle convertie en taux horaire, par exemple). Détail :
[`referentiel-matching.md`](referentiel-matching.md), « Préremplir une mission ».

Dès la publication, la mission est visible sur `/missions` (page publique, indexable) et
remonte dans les matches des intérimaires habilités. Si un match est **nouveau** pour un
intérimaire, l'API appelle le workflow n8n `match-notification` : il reçoit un email.

### Lire les candidatures

Chaque candidature porte le **score que l'intérimaire a vu**, avec sa ventilation (compétences
sur 60, zone sur 40), ses habilitations avec leur statut de vérification par un agent
(« vérifié » ou « déclaré »), et ses compétences déclarées. L'entreprise ne reçoit ni email, ni
téléphone, ni document : nom, prénom, commune, habilitations et compétences suffisent pour
décider, et l'intérimaire reste un salarié de CADANS.

### Retenir un candidat, et ce que ça déclenche

Retenir un candidat passe la mission à **Pourvue**. Trois effets ne se voient pas à l'écran :

1. **Les deux contrats sont générés** par l'API, en tâche de fond, chiffrés au repos. Le contrat
   de mise à disposition (CADANS ↔ entreprise) part tout de suite. Le contrat de mission
   (CADANS ↔ intérimaire) n'est généré que si l'intérimaire a rempli ses informations
   d'embauche ; sinon il l'est dès qu'il les complète. CADANS signe les deux à la génération.
2. **Le workflow n8n `mission-pourvue` est appelé** : deux emails, un à l'intérimaire, un à
   l'entreprise, chacun avec le lien vers **son** contrat à signer. Si n8n n'est pas joignable,
   l'API journalise l'appel et rien n'échoue.
3. La mission **sort du sitemap** et sa page publique porte `noindex`, mais reste servie : une
   URL déjà partagée ne doit pas disparaître. Toute nouvelle candidature est refusée (`409`).

### Signer

Depuis `/entreprise/contrats` : aperçu du PDF, nom complet du contact tapé, case d'acceptation.
Le nom est comparé à celui du compte, aux accents, à la casse et aux espaces près. La preuve
conservée dit qui, quoi, quand, d'où et **sur quel document** (empreinte SHA-256). Un contrat
signé est figé : il ne se régénère plus.

**« Mission prête à démarrer » n'est pas « mon contrat est signé »** : la mission n'est prête
que lorsque **les deux contrats** portent leurs deux signatures. L'entreprise peut avoir signé
le sien pendant que l'intérimaire n'a pas encore rempli ses informations d'embauche.

Signature électronique **simple** au sens eIDAS, sans certificat qualifié : ce que ça vaut et
ce qu'il faudrait pour aller plus loin, [`contrats.md`](contrats.md) et
[`perspectives.md`](perspectives.md).

### Joindre des documents

Plan d'accès, consignes de sécurité, fiche de poste : des PDF de 5 Mo au plus, chiffrés au
repos, visibles de l'entreprise et de **l'intérimaire retenu** seulement, jamais des candidats.
**Une annexe n'est plus supprimable dès qu'un contrat de la mission est signé** (`409`) : elle
fait partie de ce sur quoi l'intérimaire s'est engagé.

### Deux jours avant le début

Le workflow n8n `rappel-debut-mission` lit PostgreSQL chaque matin à 8h, heure de Paris, et
envoie un rappel à l'intérimaire dont une mission démarre dans deux jours. Rien n'est envoyé à
l'entreprise.

## Ce que ce document ne couvre pas

- **Rien ne se passe à la fin d'une mission** : pas de bilan, pas de libération automatique de
  l'intérimaire, pas de facturation. Le circuit financier et ses limites sont dans
  [`perspectives.md`](perspectives.md), « Flux financier ».
- **Modifier une mission pourvue** : `PUT /missions/:id` existe, mais un contrat signé porte
  les mentions de la mission au moment de la signature et ne se régénère pas.
