# Espace agent : habilitations, annuaire, missions et contrats

L'espace `/admin` est celui de l'**agent CADANS**, le troisième rôle. Sa raison d'être est la
vérification des habilitations ; il donne aussi, depuis le 23/09/2026, une vue transverse sur
les comptes, les missions et les contrats.

## Vérification des habilitations

Une agence d'intérim engage sa responsabilité sur les habilitations de ceux qu'elle place.
CADANS ne se contente donc pas d'une déclaration : l'intérimaire dépose un **justificatif par
CACES**, et un **agent CADANS** l'examine.

## Le rôle agent

Troisième rôle, `ADMIN`, **sans inscription publique** : le DTO d'inscription ne propose que
`COMPANY` et `WORKER`. Un compte agent se crée par `seed:demo`, ou à la main en base.

`AdminController` porte `@Roles(Role.ADMIN)` **sur la classe** — toute route ajoutée ensuite
est protégée sans qu'on ait à y penser. Un intérimaire ou une entreprise reçoit **403**, un
visiteur sans session **401** ; vingt-deux tests fonctionnels le vérifient sur les routes des
justificatifs, route par route et rôle par rôle.

## Le justificatif

Déposé depuis `/interimaire/profil` : **PDF, JPEG ou PNG, 5 Mo maximum**. Le type est vérifié
**par les octets du fichier**, jamais par son extension ni par le type annoncé par le
navigateur, tous deux falsifiables (`apps/api/src/sensitive-documents/file-type.ts`).

Le document est **chiffré au repos** (AES-256-GCM, `ENCRYPTION_KEY`) avec un contexte propre à
l'intérimaire et au type d'habilitation, et **stocké en base** — l'offre gratuite de Render n'a
pas de disque persistant, un fichier écrit sur le disque disparaîtrait au redéploiement.

## Les quatre statuts

| Statut | Quand |
| --- | --- |
| `NON_VERIFIE` | Habilitation déclarée sans justificatif |
| `EN_ATTENTE` | Un justificatif vient d'être déposé |
| `VERIFIE` | Un agent a examiné la pièce et l'a acceptée |
| `REFUSE` | Un agent l'a rejetée, **avec un motif obligatoire** que l'intérimaire lit sur son profil |

**Redéposer un fichier remet le statut à `EN_ATTENTE`** et efface le motif : le document validé
la semaine dernière n'est plus celui qui est en base.

## Ce que le matching en fait : rien

**Le statut de vérification n'entre pas dans le matching.** Une habilitation vaut par sa
présence et sa date d'expiration, comme avant. En faire un filtre priverait l'intérimaire de
missions tant qu'un agent n'a pas cliqué — le délai de traitement deviendrait une sanction.

Le statut est une **information affichée** : badge « CACES vérifié » sur le profil, et mention
« vérifié » ou « déclaré » sur chaque habilitation dans `/entreprise/candidatures`. L'entreprise
voit ainsi ce qui a été contrôlé, sans jamais recevoir le document.

## Confidentialité

Le justificatif n'a **aucune URL publique**. Il est servi en flux par
`GET /admin/justificatifs/:id/document`, derrière le rôle agent, déchiffré à la volée, avec
`Cache-Control: no-store` et `X-Content-Type-Options: nosniff`. Sur l'écran des
justificatifs, l'agent voit le nom et la commune de l'intérimaire, une vérification d'identité
professionnelle ne pouvant pas être anonyme. Son email et son téléphone sont sur sa fiche de
l'annuaire (ci-dessous) : CADANS est son employeur et doit pouvoir le joindre. Décision du
23/09/2026, annoncée dans la politique de confidentialité (« Destinataires »).

## Registre des décisions d'habilitation

Chaque validation et chaque refus écrit une ligne dans `certification_decisions` :
**habilitation, type de CACES, intérimaire, décision, motif, agent, date**. La décision
courante reste sur `Certification` (`verificationStatus`, `verifiedAt`, `verifiedByUserId`) —
le registre ne la remplace pas, il garde ce qu'elle écrasait.

**Pourquoi il existe.** Sans lui, une validation suivie d'un refus effaçait la première : on
savait qu'il y avait eu un refus, plus qui avait validé ni quand. Sur un contrôle
d'habilitation professionnelle — ce qui conditionne l'accès d'un intérimaire à un chariot
élévateur — c'est la trace qui compte autant que la décision.

**Il survit à la suppression de l'habilitation.** La clé étrangère est en `onDelete: SetNull`,
pas `Cascade` : supprimer son CACES retire l'habilitation du profil et des écrans, mais laisse
le registre intact. *Un registre que la personne contrôlée peut effacer ne vaut rien comme
registre.*

Pour qu'une ligne détachée reste lisible, deux colonnes sont **recopiées à l'écriture** :

| Colonne | Pourquoi dénormalisée |
| --- | --- |
| `certification_type` | Sans elle, une ligne orpheline dirait « quelqu'un a refusé quelque chose » |
| `worker_id` | **Identifiant nu, sans clé étrangère.** Une clé en cascade ferait disparaître le registre avec l'intérimaire ; une clé `SetNull` le rendrait anonyme |

Ces deux colonnes **figent l'état au moment de la décision** : elles ne suivent pas
l'original. C'est le comportement attendu d'un registre.

**Ce qu'il ne contient pas** : ni le document, ni le numéro de certificat, ni aucune donnée
d'identité en clair. Un identifiant d'intérimaire, un type d'habilitation, une décision, un
motif et une date.

**Durée de conservation : cinq ans** après la décision, alignée sur celle des contrats —
c'est la même prescription contractuelle qui la justifie. Annoncée dans la politique de
confidentialité.

## Annuaire, missions et contrats

Quatre écrans en lecture seule, ajoutés le 23/09/2026 (PR 56), sur le même principe que les
justificatifs : une liste triée, une fiche derrière. Les six compteurs du tableau de bord
`/admin` mènent chacun à la liste correspondante, filtrée sur le même statut.

| Écran | Liste | Fiche | Jamais exposé |
| --- | --- | --- | --- |
| `/admin/interimaires` | nom, prénom, ville, code postal, date d'inscription | + email, téléphone, créneaux acceptés, compétences déclarées, habilitations (type, expiration, statut de vérification) | NIR, IBAN, pièce d'identité, numéro de certificat, justificatif |
| `/admin/entreprises` | raison sociale, SIRET, ville | + code NAF, contact, email, téléphone, adresse, missions publiées | — |
| `/admin/missions[?statut=]` | poste, entreprise, statut, dates | + site, code postal, créneau, taux horaire, intérimaire retenu, nombre de candidatures, état des deux contrats | — |
| `/admin/contrats[?statut=A_SIGNER\|TOUS]` | type, entreprise, intérimaire, date de génération, signé ou non | + les deux signatures attendues (partie, nom tapé, date) | le PDF, l'adresse IP, le navigateur, l'empreinte |

Rien de chiffré n'est déchiffré pour ces écrans : ni pièce d'identité, ni informations
d'embauche, ni document de contrat. L'agent constate **qui** a signé et **quand**, pas les
éléments de preuve technique d'une contestation.

**Limite assumée** : ces huit routes n'ont que des tests unitaires sur leurs services, aucun
test fonctionnel. Leur protection repose sur le `@Roles(ADMIN)` de classe, vérifié par les
tests des routes de justificatifs. Le coverage global reste au-dessus du seuil de 95 %.
