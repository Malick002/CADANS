# Limites assumées et perspectives

État au 23/09/2026. Ce document dit ce que CADANS **ne fait pas**, et pourquoi c'est un choix
plutôt qu'un oubli. À tenir tel quel en soutenance.

Il s'appelait `perspectives-matching.md` jusqu'au 23/09 : son périmètre a dépassé le matching
le jour où les contrats et les annexes ont apporté leurs propres limites.

## Matching

### Le calcul aujourd'hui

Deux filtres bloquants, dans cet ordre, **avant** tout scoring :

1. **Le créneau.** Un créneau non accepté écarte la mission. Aucun créneau déclaré = aucune
   préférence, donc aucun filtrage : l'onboarding est différable et ne doit jamais vider la
   liste.
2. **Les habilitations.** Un profil sans le CACES exigé ne remonte jamais, quel que soit son
   score. La mission est comptée dans `masqueesFauteHabilitation`, jamais renvoyée.

Puis un score sur 100, ventilé et exposé dans `MatchView.detail` :

| Critère | Poids | Valeurs |
| --- | --- | --- |
| Recouvrement de compétences | **60** | proportion des compétences exigées que le profil déclare |
| Zone | **40** | même département **1** · département voisin **0,5** · sinon **0** |

### Limite 1 — la zone ne connaît que l'Île-de-France

`DEPARTMENTS_NEIGHBORS` couvre **huit départements** : 75, 77, 78, 91, 92, 93, 94, 95. Chacun
est une clé et liste tous ses voisins franciliens. La table est symétrique, et un test le
vérifie — une table asymétrique fonctionnerait quand même, la fonction testant les deux sens,
mais elle serait fausse à la lecture et piégerait le prochain qui l'étendrait.

**Hors de ces huit départements, la fonction rend 0.** Le Nord et le Pas-de-Calais sont
voisins dans la réalité, pas ici. Un intérimaire lyonnais ne verra jamais une mission iséroise
remonter au titre du voisinage — elle remontera, mais avec 0 point de zone, comme avant.

Les départements limitrophes non franciliens (Eure 27, Eure-et-Loir 28, Oise 60) sont
**volontairement absents**, alors qu'ils touchent le 78 et le 95. Les inclure ferait croire à
une couverture nationale partielle, impossible à raisonner : une mission dans l'Oise scorerait
0,5 vue depuis le 95, et 0 vue depuis le 60 lui-même, faute d'entrée pour le 60.

**Pourquoi ce périmètre.** Le jeu de démonstration, les missions et l'étude de marché sont
franciliens. Une table de 101 départements se saisit vite et se vérifie lentement : chaque
paire doit être exacte et symétrique, et une erreur y est invisible.

#### Extension nationale

Deux voies, par coût croissant.

**a. Compléter la table aux 101 départements.** Aucune migration, aucune dépendance : c'est
une constante de code. Le vrai coût est la vérification — environ 230 paires d'adjacence. À
générer depuis une source ouverte (contours IGN/INSEE) plutôt qu'à la main, et à verrouiller
par le test de symétrie déjà écrit.

**b. Passer à une distance réelle en kilomètres.** Strictement meilleur : « voisin » est un
mauvais proxy, deux communes voisines de part et d'autre d'une frontière départementale sont
plus proches que deux communes opposées d'un même département.

Ce que ça demande :

- **Une migration sur `Mission`** pour y ajouter `latitude` et `longitude`. Elle n'en a pas ;
  `Worker` les a déjà, vides, ajoutées en prévision de ce jour.
- **Le géocodage à la saisie**, via l'[API Adresse (BAN)](https://api-adresse.data.gouv.fr)
  de data.gouv.fr : gratuite, sans clé, gouvernementale. Une recherche rend d'un coup le code
  postal, la commune, le code INSEE, le département (champ `context`) et les coordonnées.
- **Un champ de saisie semi-automatique conforme RGAA** sur trois formulaires (inscription
  intérimaire, inscription entreprise, création de mission). C'est la vraie difficulté :
  `role="combobox"`, `aria-expanded`, `aria-activedescendant`, navigation aux flèches, Échap,
  annonce du nombre de résultats. Bâclé, il dégrade l'accessibilité d'un parcours critique.

### Limite 2 — toutes les compétences pèsent le même poids

Le recouvrement est un simple rapport d'ensembles : **« savoir être ponctuel » compte autant
que « conduire un chariot à mât rétractable »**.

Or l'import ROME remplit déjà deux informations que le calcul ignore :

- **`RomeCompetence.principale`** — 41 compétences principales contre 177 secondaires ;
- **`Competence.type`** — 79 `COMPETENCE_DETAILLEE`, 75 `SAVOIR`, 5 `MACRO_SAVOIR_ETRE`,
  5 `MACRO_SAVOIR_FAIRE`.

Les pondérer ne demande **aucune migration, aucune donnée nouvelle, aucune dépendance** : tout
est en base. C'est la piste d'amélioration au meilleur rapport coût/effet, et elle renforce un
critère du sujet — les données France Travail alimentant un critère de matching.

### Piste écartée — la lettre RIASEC

Les fiches ROME portent un code **RIASEC** (R, I, A, S, E, C), au niveau du métier et de
certaines compétences. Mesuré sur les trois fiches du dépôt :

| Fiche | `riasecMajeur` du métier | Compétences portant une lettre |
| --- | --- | --- |
| N1101 Cariste | **R** | 8 sur 70 |
| N1103 Préparateur de commandes | **R** | 10 sur 63 |
| N1105 Manutentionnaire | **R** | 8 sur 44 |

**Les trois métiers ont la même lettre**, et la logistique d'entrepôt est tout notre
périmètre. Un critère identique sur 100 % des offres ne classe rien. Au niveau des
compétences, seules ~14 % en portent une, avec la même répartition partout.

Écartée sur preuve, donc — pas par manque de temps.

### Limite 3 — l'intérimaire n'a pas de statut « en mission »

`Mission.assignedWorkerId` dit quelle mission un intérimaire a obtenue. Rien ne dit
l'inverse : **le profil ignore qu'il est en mission**. Trois conséquences, toutes visibles.

#### a. Le matching propose des missions qui se chevauchent

`getMatchesForWorker` ne lit que le statut des missions, jamais l'occupation de la personne.
Leïla, retenue du 24/09 au 08/10, continue de voir remonter des missions qui démarrent le
29/09 — et peut y postuler. La candidature est acceptée : rien ne la refuse.

Ce n'est pas une faute de calcul mais **une donnée manquante**. Il faudrait :

- lire les missions déjà attribuées à l'intérimaire (`assignedWorkerId`, statut `POURVUE`) au
  début du calcul, comme on lit déjà ses candidatures pour `applied` ;
- **écarter** celles dont la période chevauche — `start ≤ autre.end ET end ≥ autre.start` ;
- décider si c'est un **filtre bloquant** (comme les CACES) ou un simple malus de score. Le
  filtre bloquant se défend mieux : proposer une mission qu'on ne peut pas accepter fait
  perdre son temps au candidat, exactement l'argument qui justifie déjà le filtre CACES.

Aucune migration : `Mission.assignedWorkerId`, `startDate` et `endDate` existent tous. C'est
une requête de plus et une règle de chevauchement — le coût est celui des tests.

#### b. L'entreprise ne voit pas la disponibilité d'un candidat

`/entreprise/candidatures` affiche nom, zone et habilitations valides. Elle ne dit pas que le
candidat est déjà pris sur la période. Le bloc `CandidatView` pourrait porter un booléen
« disponible sur la période de la mission » — une information dérivée, pas une donnée
personnelle de plus, donc sans incidence sur la minimisation.

#### c. Rien ne se passe à la fin d'une mission

Le workflow `rappel-debut-mission.json` montre qu'un déclencheur planifié suffit à couvrir ce
genre de besoin, sans rien changer à l'API. Le pendant naturel : **une notification de fin de
mission**, envoyée le dernier jour ou le lendemain, qui remercie l'intérimaire et lui propose
**les prochaines missions disponibles** — celles qui matchent son profil et démarrent après la
date de fin.

Ce quatrième workflow se construirait sur le même moule que le troisième : planification,
`SELECT` sur les missions `POURVUE` dont `end_date` vaut `CURRENT_DATE - 1`, puis un second
`SELECT` sur les missions `OUVERTE` à venir dans son département ou un département voisin.

**La limite** : ce second SELECT rejouerait en SQL une partie des règles de matching
(habilitations, créneau, zone) déjà écrites en TypeScript, avec la garantie que les deux
divergent. La bonne version exposerait une **route API** rendant les matchs d'un intérimaire
donné, que n8n appellerait — mais elle demanderait une authentification machine à machine,
absente du POC. À trancher avant de l'écrire, pas pendant.

### Limite 4 — pas de seuil

Aucun score plancher : toutes les missions non écartées par les filtres bloquants remontent,
triées par score décroissant puis par date de début (ordre déterministe). À arbitrer si le
volume d'offres augmente — sur un POC à quelques missions, masquer des résultats ferait plus
de mal que de bien.

## Habilitations

### Ce qui est fait : l'expiration se voit

Le matching écarte déjà les habilitations expirées (`validCertificationTypes`), et les
candidatures ne les listent pas à l'entreprise — les afficher laisserait croire le candidat
couvert. Ce qui manquait était l'inverse : **rien ne le disait à l'intéressé**.

Un cariste dont le CACES avait expiré la veille ne voyait plus aucune mission, et son profil
lui affichait toujours « CACES vérifié » avec une date d'expiration présentée comme n'importe
quelle autre. Il ne pouvait pas comprendre, donc pas corriger.

**La règle de validité a été corrigée au passage** : une habilitation est valide **jusqu'à
la fin de son jour d'expiration**. La comparaison portait sur l'instant, or une colonne
`@db.Date` revient à minuit UTC — une carte marquée « 23/09 » était donc écartée le 23/09 au
matin, et son titulaire perdait un jour. La comparaison porte maintenant sur le jour, **en
heure de Paris** : CADANS est une plateforme française, et nos missions du matin commencent
à 6 h — une règle écrite en UTC laissait une habilitation valide deux heures après minuit
heure française, et le décalage change entre l'été et l'hiver.

`certificationValide` (API) et `estExpiree` (site) portent **le même test de bord, aux mêmes
instants** : minuit heure de Paris vaut 22:00 UTC en septembre et 23:00 UTC en janvier. Faute
de paquet partagé dans ce monorepo (`workspaces: apps/*`), ce sont ces deux tests jumeaux qui
empêchent les règles de diverger — modifier l'une sans l'autre casse un test.

Depuis le 23/09/2026, une habilitation expirée porte un badge **« Expirée »** — mot écrit en
toutes lettres et contour tireté, la distinction ne repose pas sur la couleur — et un bloc qui
dit la conséquence (« les missions exigeant ce CACES ne vous sont plus proposées ») et
l'action (redéposer le justificatif à jour). L'écran agent signale lui aussi un justificatif
qui arrive déjà expiré, pour qu'il ne soit pas validé pour rien.

### Limite — personne n'est prévenu avant l'échéance

L'intérimaire découvre l'expiration **s'il retourne sur son profil**. Rien ne l'y ramène : pas
d'email, pas de relance. En pratique, il la découvrira en constatant que ses missions ont
disparu — c'est-à-dire trop tard, et après une période pendant laquelle il n'était proposé
nulle part.

**La réponse, non construite : un cinquième workflow n8n, planifié, à J-30.** Il se bâtirait
sur le moule exact de `rappel-debut-mission.json`, qui a déjà prouvé qu'un déclencheur
planifié suffit sans rien changer à l'API :

1. déclencheur planifié quotidien ;
2. `SELECT` sur les certifications dont `expires_at` vaut `CURRENT_DATE + 30`, jointes à
   l'intérimaire et à son compte pour l'adresse email ;
3. envoi par Gmail SMTP, comme les autres automatisations, avec le lien vers le profil.

**Coût** : un fichier de workflow, aucune migration, aucune route d'API. La requête ne rend
que ce dont l'email a besoin — type d'habilitation, date, prénom, adresse.

**Pourquoi pas maintenant** : le périmètre est gelé au 22/09, et l'affichage ci-dessus couvre
le cas où l'intérimaire cherche à comprendre. La relance couvre le cas où il ne cherche pas —
plus utile, mais ce n'est plus un correctif, c'est une fonctionnalité.

**À décider avec elle** : une seule relance à J-30, ou une seconde à J-7 ? Et que faire d'une
habilitation déjà expirée depuis longtemps — relancer indéfiniment serait du harcèlement.

## Sessions

### Le choix : des sessions sans état, et une fenêtre d'une heure

La session est un **JWT HS256 signé à la main** (`apps/api/src/auth/token.service.ts`), posé
dans un cookie `httpOnly`. `SessionGuard` est **synchrone** : il vérifie la signature et la
date d'expiration, et rien d'autre. **Il ne lit jamais la base.** L'identité de l'appelant
sort du contenu du jeton.

La conséquence est directe et il faut l'assumer telle quelle : **l'API ne sait pas révoquer
un jeton déjà émis.** Changer son mot de passe ne ferme pas les sessions ouvertes ; supprimer
un compte non plus. La durée de vie du jeton *est* la fenêtre pendant laquelle un jeton volé
reste utilisable.

Elle était de 8 h. Elle est passée à **1 h le 23/09/2026** : même mécanique, même code, mais
une fenêtre divisée par huit, pour le seul prix d'une reconnexion en cours de journée. C'est
la seule chose qui coûtait zéro et qui réduisait vraiment le risque.

**Le contexte du choix : un POC de 11 jours.** Les trois options ci-dessous ont été comparées
le 23/09 sur le code réel, pas en principe.

### Option 1 — sans état, tel quel *(retenu pour le POC)*

| | |
| --- | --- |
| **Coût** | Nul. C'est l'existant. |
| **Apporte** | Aucune requête en base pour authentifier : le guard reste synchrone, l'API tient sur une petite instance et une base gratuite. |
| **Ne couvre pas** | La révocation. Fenêtre d'exposition = **1 h**. |

### Option 2 — `tokenVersion` en base *(écarté)*

Une colonne `tokenVersion` sur `User`, incrémentée à chaque changement de mot de passe,
recopiée dans le jeton à l'émission et **comparée à la valeur en base à chaque vérification**.

| | |
| --- | --- |
| **Coût** | 7 fichiers de production, une migration, 2 fichiers de tests à reprendre (`token.service.spec.ts`, `guards.spec.ts`) et 3 à 4 cas fonctionnels à écrire. Techniquement modeste. |
| **Apporte** | Révocation **immédiate** : le jeton meurt à la seconde où le mot de passe change. |
| **Pourquoi écarté** | **Une lecture en base par requête authentifiée.** C'est exactement ce que l'architecture sans état évite : le guard devient asynchrone, et chaque appel paie un aller-retour vers Neon. On paie le prix d'une session avec état sans en avoir les bénéfices — ni déconnexion à distance, ni liste des appareils connectés, ni expiration par inactivité. |

Une variante à moitié prix a été envisagée : ne vérifier la version **que sur les routes
sensibles** (module `account`, documents chiffrés). Elle réduit le coût mais laisse les
autres routes ouvertes, et il faudrait tenir cette asymétrie en soutenance. Écartée aussi.

### Option 3 — accès court + rafraîchissement révocable *(l'évolution retenue)*

La solution de production, et celle vers laquelle il faudrait aller si CADANS dépassait le POC :

- un **jeton d'accès très court** (5 à 15 min), sans état, vérifié comme aujourd'hui — le
  chemin chaud ne touche donc toujours pas la base ;
- un **jeton de rafraîchissement** de longue durée, **stocké en base** (empreinte seulement,
  comme les jetons de réinitialisation le sont déjà) et donc **révocable** ;
- **rotation** : chaque rafraîchissement consomme le jeton et en émet un nouveau ;
- **détection de réutilisation** : un jeton de rafraîchissement déjà consommé qui se
  représente signale un vol, et **toute la famille de jetons de cette session est révoquée**.

| | |
| --- | --- |
| **Coût** | Le plus élevé des trois : une table, deux routes, la rotation, la détection de réutilisation, la gestion de la course quand deux onglets rafraîchissent en même temps, et le tout côté navigateur aussi. |
| **Apporte** | Révocation réelle, sessions longues sans reconnexion, déconnexion à distance, détection de vol — le tout **sans lecture en base sur le chemin chaud**, contrairement à l'option 2. |
| **Pourquoi pas maintenant** | Ce n'est pas du travail de deux jours, et le faire à la hâte avant la soutenance produirait une révocation à moitié juste — pire qu'une absence de révocation assumée et documentée. |

### Ce qu'il faut tenir en soutenance

Les sessions sont sans état par choix, pas par oubli. La limite — pas de révocation — est
connue, écrite dans le code (`token.service.ts`, `password-reset.service.ts`,
`account.service.ts`) et bornée à une heure. La suite est l'option 3, pas l'option 2 : ajouter
une lecture en base au guard reviendrait à payer le coût d'une session avec état en n'en
gardant aucun avantage.

## Contrats et signature

### Limite 1 — le numéro de sécurité sociale est masqué au contrat de mission

Un contrat de mission réel le porte en entier. Le raisonnement complet — régime propre du NIR,
surface d'exposition d'un PDF téléchargé et transmis — et les trois arbitrages qu'il faudrait
rendre pour lever la limite sont dans **`docs/contrat-mentions-obligatoires.md`**. Il n'est pas
répété ici : un même argument tenu à deux endroits finit par diverger.

### Limite 2 — la signature est « simple », pas « avancée »

Au sens du règlement eIDAS (art. 3.10), et le document le dit lui-même sur sa page de
signatures. Elle ne bénéficie donc **pas** de la présomption de fiabilité de l'article 26, et
se conteste.

Passer à une signature **avancée** demanderait les quatre conditions de l'article 26 : lien
univoque au signataire, identification du signataire, moyen de création sous son contrôle
exclusif, et détection de toute modification ultérieure. Les deux premières se rapprochent avec
un compte et un envoi de code à usage unique ; les deux dernières supposent un **prestataire de
service de confiance** — c'est un contrat et un budget, pas une fonctionnalité. Hors de portée
d'un POC de onze jours, et le document ne prétend pas le contraire.

**Ce qui se ferait à moindre coût**, et qui n'a pas été fait : un code à usage unique envoyé
par email avant de valider la signature. Ça ne rend pas la signature avancée, mais ça remplace
« qui est connecté sur ce compte » par « qui a accès à cette boîte mail au moment de signer ».
Le module `mail` existe déjà, il n'y aurait ni dépendance ni migration.

### Limite 3 — six mentions obligatoires manquent encore aux contrats

Motif du recours mis à part (ajouté le 23/09), il manque : poste à risques particuliers,
équipements de protection individuelle, primes et accessoires de salaire, horaire réel — seul
le créneau est connu —, clause de variation du terme, et durée de la période d'essai. Le détail
de ce qu'il faudrait stocker pour chacune est dans `docs/contrat-mentions-obligatoires.md`.

**Les documents le disent eux-mêmes**, en toutes lettres et sur chaque exemplaire. C'est le
seul choix défendable en attendant : un contrat qui aurait l'air complet sans l'être ferait
bien pire effet qu'un contrat qui énonce ses trous.

### Limite 4 — rien ne se passe à la fin d'un contrat

`Contract.completedAt` dit quand les deux parties ont signé. Aucune échéance n'est posée après :
ni relance si une partie ne signe pas, ni archivage au terme de la mission, ni purge au bout des
cinq ans annoncés par la politique de confidentialité.

La relance est la plus simple et la plus utile : un quatrième workflow n8n planifié, sur le
moule de `rappel-debut-mission.json`, qui sélectionne les contrats sans `completed_at` dont la
mission démarre bientôt. Requête en lecture seule, aucune règle métier rejouée en SQL — c'est
précisément ce qui rend ce workflow-là sans danger, contrairement à la notification de fin de
mission décrite plus haut.

## Flux financier

**La question tombera en soutenance** : « l'entreprise vous paie, et vous payez l'intérimaire ?
C'est dans le produit ? » Voici la réponse, et pourquoi la frontière est là.

### Le circuit, qui n'est pas un choix de produit

CADANS est une **entreprise de travail temporaire**, donc **l'employeur** de l'intérimaire.
Le circuit de l'argent en découle mécaniquement :

```
Entreprise utilisatrice ──facture──► CADANS ──salaire──► Intérimaire
```

- CADANS verse un **salaire** à l'intérimaire : bulletin de paie, cotisations sociales,
  **indemnité de fin de mission** (10 % de la rémunération brute totale) et **indemnité
  compensatrice de congés payés** (10 % également).
- CADANS **facture** à l'entreprise utilisatrice une prestation de mise à disposition.
- L'écart est la marge, exprimée par un **coefficient de facturation** — de l'ordre de 1,8 à
  2,2 fois le taux horaire dans la logistique. Il couvre les cotisations patronales, les deux
  indemnités ci-dessus, et le service.

**L'entreprise utilisatrice ne paie jamais l'intérimaire directement.** Si elle le faisait, ce
ne serait plus du travail temporaire mais du **prêt de main-d'œuvre illicite** (art. L. 8241-1
du Code du travail). C'est la même raison qui impose les deux contrats plutôt qu'un seul.

### Ce que le produit porte déjà

Deux points de raccordement existent, et ils ne sont pas là par hasard.

**Le taux horaire de la mission** (`Mission.hourlyRate`) est la **rémunération de référence du
salarié**, et il figure au contrat de mise à disposition avec sa double fonction écrite noir
sur blanc :

> « Montant servant de base à la rémunération du salarié intérimaire (art. L. 1251-43 6°) **et
> à la facturation de la mise à disposition**. »

C'est donc l'assiette des deux côtés du circuit : le salaire s'en déduit directement, la
facture s'en déduit par le coefficient.

**L'IBAN de l'intérimaire** est collecté, **chiffré au repos** (AES-256-GCM, contexte lié à
l'intérimaire) et n'est **jamais** rendu en clair — l'API n'en renvoie que les quatre derniers
caractères, et l'entreprise utilisatrice n'y a aucun accès.

#### Minimisation (RGPD) : pourquoi l'IBAN est là

Il est collecté parce que **CADANS est l'employeur et qu'un salaire se verse sur un compte** :
c'est une donnée du **dossier d'embauche**, au même titre que l'état civil ou le NIR — pas une
donnée conservée « en prévision » d'une fonctionnalité de paiement à venir. Trois faits le
montrent :

1. **Elle n'est due qu'à partir du moment où l'intérimaire est retenu sur une mission**
   (`InformationsEmbaucheView.requis`, calculé par l'API depuis le nombre de missions
   obtenues). Tant que personne ne l'a retenu, le formulaire n'est pas réclamé.
2. **Elle est chiffrée au repos** et n'apparaît en clair nulle part — ni en réponse HTTP, ni
   dans un cache de navigateur, ni sur une capture d'écran de démonstration.
3. **Elle n'est pas imprimée sur les contrats.** Elle sert à établir la relation de travail,
   pas à alimenter un document.

À noter, pour être exact : l'IBAN **ne figure pas parmi les mentions obligatoires** du contrat
de mission. Ce qui conditionne la génération du contrat, c'est la **complétude du dossier
d'embauche**, dont il fait partie — les huit champs sont exigés ensemble.

### La frontière, et pourquoi elle est là

**Ni la paie ni l'encaissement ne sont dans le produit.** Il n'existe aucun modèle de facture,
aucun coefficient, aucune marge, aucun moyen de paiement — vérifié : zéro occurrence dans
`schema.prisma`, et zéro dans `chiffrage_CADANS.xlsx`.

**Ce n'est pas un oubli, et voici les trois raisons, par ordre de poids.**

**1. La paie n'est pas une fonctionnalité, c'est un métier régulé.** Il faudrait produire des
bulletins conformes, déclarer en **DSN** mensuelle, calculer et reverser les **cotisations**
URSSAF, appliquer les taux de la branche, gérer l'**IFM** et l'**ICP**, et s'affilier à la
**caisse de congés payés du travail temporaire** — une obligation propre au secteur. Une agence
utilise un logiciel de paie dédié ou un cabinet. Le construire dépasse un POC ; le construire
*mal* serait pire que ne pas le construire, parce qu'un bulletin faux est une faute.

**2. Encaisser de l'argent est un autre produit.** Il faudrait un **prestataire de paiement**
agréé, la conformité **DSP2** (authentification forte), la gestion des impayés, des relances et
des avoirs. Rien de tout cela ne se traite en marge d'un POC.

**3. Le périmètre est un POC de 11 jours**, gelé au 22/09, et le flux financier n'y a jamais
figuré.

### Ce qu'il faudrait pour la franchir

Par coût croissant. Les deux premières étapes sont modestes ; la troisième est un projet.

**a. Le coefficient et la facturation théorique.** Une colonne `coefficientFacturation` sur
`Mission` (ou un taux par entreprise cliente), et le montant facturable se calcule :
`heures × taux × coefficient`. Aucune dépendance, aucun paiement — de quoi éditer un
récapitulatif mensuel par entreprise. **C'est l'étape au meilleur rapport coût/effet**, et
celle qui rendrait l'onglet « Facturation » légitime.

**b. La facture comme document.** Un modèle `Facture` (entreprise, période, lignes de mission,
montants HT/TVA/TTC, numérotation **séquentielle et sans trou** — exigence fiscale), et une
génération PDF sur le moule de `ContractPdfService`, qui existe déjà. Toujours aucun paiement :
une facture est d'abord un document.

**c. La paie et l'encaissement.** À **externaliser**, pas à construire. Le raccordement se fait
par les deux données déjà en place : les contrats signés donnent les heures et le taux, l'IBAN
donne le compte. Un logiciel de paie reprend l'un, un prestataire de paiement l'autre.

### Ce qu'il faut tenir en soutenance

CADANS couvre la **mise en relation et le contractuel** : matching, contrats, signature,
traçabilité. Le flux financier s'y **raccorde** par deux points déjà construits — le taux
horaire, qui est l'assiette des deux côtés, et l'IBAN chiffré. La frontière est **choisie et
argumentée**, pas subie : une facturation à moitié faite se défendrait moins bien qu'une
absence assumée dont on sait dire exactement ce qu'elle coûterait à combler.

## Annexes de mission

### Limite 1 — pas de renommage, et une suppression bornée

Une annexe se dépose et se retire, **tant qu'aucun contrat de la mission n'est signé**. Passé
ce point, elle est figée : les consignes de sécurité d'un site font partie de ce sur quoi
l'intérimaire s'est engagé, les retirer changerait le dossier sans laisser de trace.

Ce qui manque : **le renommage**. Un nom mal saisi oblige à retirer puis redéposer, ce qui est
impossible une fois un contrat signé. Une colonne, une route `PATCH`, aucune migration de
donnée — mais le périmètre était gelé.

### Limite 2 — aucune trace de qui a déposé quoi

`mission_attachments` porte la mission, pas l'utilisateur. Sur un compte entreprise partagé par
plusieurs personnes — le cas normal —, personne ne peut dire qui a joint un document ni quand
il a été retiré. Une colonne `uploaded_by_user_id` et une table d'événements suffiraient ; c'est
la même question que la traçabilité des décisions d'un agent CADANS, déjà résolue pour les
justificatifs d'habilitation (`verified_by_user_id`).

### Limite 3 — le PDF est accepté sur sa signature binaire, pas sur son contenu

`%PDF-` en tête de fichier, 5 Mo maximum, et c'est tout. Aucun antivirus, aucune analyse du
contenu, aucun aplatissement du JavaScript qu'un PDF peut embarquer. Le document est servi avec
`Content-Disposition: inline`, `X-Content-Type-Options: nosniff` et `Cache-Control: no-store`,
et le visualiseur du navigateur l'ouvre dans un bac à sable — c'est la protection réelle, et
elle n'est pas la nôtre.

Sur une plateforme exploitée, l'analyse antivirus à l'envoi serait un prérequis, pas une
option. Ici le dépôt est réservé aux entreprises inscrites et le document n'est lisible que par
l'intérimaire retenu : la surface est étroite, mais elle n'est pas nulle.
