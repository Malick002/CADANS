# Parcours intérimaire

Ce que vit un intérimaire de son inscription à sa première mission, écran par écran, avec ce
que chaque écran appelle et les effets qui ne se voient pas. Conçu le 18/09/2026, mis à jour
sur l'état réel du 23/09/2026. Symétrique de [`parcours-entreprise.md`](parcours-entreprise.md).

## Trois principes

**1. Compléter son profil n'est jamais bloquant.** On s'inscrit avec le minimum (email, mot de
passe, nom, ville et code postal), la session s'ouvre, et le profil se complète dans l'ordre
qu'on veut, depuis une seule page. Un intérimaire qui s'inscrit sur son téléphone n'a pas son
scan de CACES sous la main : lui barrer la route à ce moment-là, c'est le perdre. Le matching
se charge d'écarter de lui-même un profil qui n'a pas ce qu'une mission exige.

**2. L'ordre suit la valeur pour le matching, la friction en dernier.** Habilitations →
compétences → créneaux font exister le profil dans le matching. Les informations d'embauche
(état civil, adresse, NIR, IBAN) ne sont nécessaires qu'au moment du contrat : elles ferment la
marche, et l'écran des contrats dit quand elles manquent.

**3. Un profil incomplet voit tout, et apprend ce qui lui manque.** Les missions sont
publiques, rendues côté serveur. Sur `/interimaire/matches`, celles qu'il ne peut pas tenir sont
comptées, pas cachées : « 4 missions supplémentaires exigent une habilitation absente de votre
profil (CACES R489-3). Ajoutez-la pour les voir apparaître. » Sur la page d'une mission, le
bouton « Postuler » s'affiche, et c'est l'**API qui refuse** en disant précisément quoi (`409`,
message affiché sous le bouton).

## Dire ce que le CACES débloque, sans mentir

Le filtrage bloquant du matching n'exclut pas « les profils sans CACES » : il exclut un profil
**des missions qui exigent une habilitation qu'il n'a pas**. Or toutes n'en exigent pas : la
fiche ROME du manutentionnaire n'en cite aucune, celle du préparateur dit « selon l'offre ».
*« Sans CACES vous ne serez jamais proposé »* serait donc faux, et un manutentionnaire le
prendrait mal. Le message juste :

> Sans habilitation, vous ne verrez que les missions qui n'en exigent pas. Ajoutez vos CACES
> pour être proposé sur toutes celles que vous pouvez tenir.

Sur `/interimaire/matches`, il prend la forme d'un compteur qui nomme les habilitations
manquantes, et le lien mène au profil. Sans aucun match, l'écran renvoie aussi vers les
compétences et les créneaux.

## Le parcours

| # | Étape | Écran | Ce que l'écran appelle |
| --- | --- | --- | --- |
| 1 | Inscription | `/inscription` (profil intérimaire par défaut) | `POST /auth/register/worker` : email, mot de passe, nom, prénom, **ville et code postal**. Session ouverte, arrivée sur `/interimaire/matches` |
| 2 | Habilitations | `/interimaire/profil`, bloc « Habilitations » | `PUT /workers/me/certifications/:type` : type de CACES, date d'expiration, justificatif (PDF, JPEG ou PNG, 5 Mo) ; `DELETE …/:type` |
| 3 | Compétences et créneaux | `/interimaire/profil`, bloc « Profil de matching » | `GET /referentiel/competences[?rome=]`, `PUT /workers/me/profil-matching` : compétences cochées parmi les 38 principales, créneaux acceptés (matin, après-midi, nuit, journée) |
| 4 | Matches | `/interimaire/matches` | `GET /matches` : missions ouvertes compatibles, score ventilé, missions masquées faute d'habilitation |
| 5 | Missions et candidature | `/missions` puis `/missions/:id` | `GET /missions/ouvertes`, `GET /missions/:id`, `POST /missions/:id/candidatures` |
| 6 | Suivi | `/interimaire/mes-missions` | `GET /workers/me/candidatures` : statut de chaque candidature |
| 7 | Informations d'embauche | `/interimaire/informations-embauche` | `PUT /workers/me/informations-embauche` : état civil, adresse, NIR et IBAN, chiffrés |
| 8 | Contrat de mission | `/interimaire/contrats` puis `/interimaire/contrats/:id/signer` | `GET /contrats`, `GET /contrats/:id/document`, `POST /contrats/:id/signer` |
| 9 | Documents de la mission | `/interimaire/contrats` (annexes) | `GET /workers/me/annexes`, `GET /annexes/:id/document` |
| — | Coordonnées et identifiants | `/interimaire/parametres` | `PUT /workers/me/identite`, `PUT /account/me/email`, `PUT /account/me/password` |

**Pièce d'identité : pas d'écran.** La route `PUT /workers/me/identity-document` existe, chiffre
et stocke le fichier, mais aucune page ne l'appelle. À assumer comme une coupe : le contrat de
mission se génère sur les informations d'embauche, pas sur la pièce.

## Écran par écran

### Après l'inscription

La session est ouverte par l'API et l'intérimaire arrive sur ses matches, vides : l'écran dit
combien de missions exigent une habilitation qu'il n'a pas, et renvoie vers le profil.

### Habilitations

Chaque CACES déclaré porte une date d'expiration et un justificatif. Le type et la date sont en
clair en base (le matching les lit), le numéro et le fichier sont chiffrés. Un justificatif
déposé passe **en attente de vérification** par un agent CADANS ; son statut (en attente,
vérifié, refusé avec motif) s'affiche sur le profil, et une habilitation **expirée** est
signalée par deux badges. Le statut de vérification n'entre pas dans le matching : seules la
présence et la validité dans le temps comptent ([`espace-agent.md`](espace-agent.md)).

### Compétences et créneaux

Les 38 compétences principales du référentiel, filtrables par métier (cariste, préparateur,
manutentionnaire), et les créneaux acceptés. Les compétences pèsent 60 % du score ; le créneau
est un filtre bloquant, avant même les habilitations. Un profil sans créneau déclaré est
considéré ouvert à tous. Il n'y a pas de dates de disponibilité : un intérimaire qui consulte
la plateforme est considéré disponible.

### Matches

Une carte par mission compatible, score en tête avec sa ventilation (compétences, zone), et le
compteur des missions masquées. La zone vaut 100 % dans le même département, 50 % dans un
département voisin d'Île-de-France, 0 sinon. Au premier calcul, rien n'est notifié ; ensuite,
chaque **nouveau** match déclenche un email via n8n.

### Missions et candidature

Liste publique, un `h1`, une URL par mission. La candidature est refusée par l'API si une
habilitation manque ou si la mission est déjà pourvue, avec le message affiché sous le bouton.
Une fois retenu par l'entreprise, l'intérimaire reçoit un email (n8n) avec le lien vers son
contrat, et un rappel deux jours avant le début de la mission.

### Informations d'embauche et contrat

Le contrat de mission ne se génère qu'une fois les informations d'embauche complètes ; l'écran
des contrats le dit et renvoie vers le formulaire. Le contrat se signe en tapant son nom
complet ; le PDF final, avec sa page de signatures, remplace le brouillon. Les annexes déposées
par l'entreprise (plan d'accès, consignes) sont lisibles dès qu'on est retenu, contrat signé ou
non. Ce que vaut la signature : [`contrats.md`](contrats.md).

## Ce que ce document ne couvre pas

- **Rien ne se passe à la fin d'une mission**, et un intérimaire n'a pas de statut « en
  mission » : [`perspectives.md`](perspectives.md), « Matching », limite 3.
- **Personne n'est prévenu avant l'expiration d'une habilitation** : même document,
  « Habilitations ».
