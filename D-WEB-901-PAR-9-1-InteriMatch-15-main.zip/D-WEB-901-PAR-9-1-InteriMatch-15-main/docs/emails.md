# Emails : deux expéditeurs, deux usages

Ne pas les confondre — c'est la question que le jury posera.

| | Expéditeur | Ce qu'il envoie | Où vit l'identifiant |
| --- | --- | --- | --- |
| **API** | **Resend**, API HTTP | Transactionnel : réinitialisation de mot de passe | `RESEND_API_KEY` et `MAIL_FROM`, dans l'environnement de l'API |
| **n8n** | **Gmail SMTP** | Automatisations : notification de match, mission pourvue (**lien vers le contrat à signer**, plus de pièce jointe), rappel 2 jours avant le début | Identifiant n8n, **jamais dans le dépôt** |

**Côté API — Resend.** `apps/api/src/mail` appelle l'API HTTP avec le `fetch` natif de Node :
aucune dépendance ajoutée, et changer de fournisseur ne touche que ce dossier. Sans
`RESEND_API_KEY` ni `MAIL_FROM`, l'API démarre quand même et **journalise** le message au lieu
de l'envoyer — on développe sans compte fournisseur, le lien de réinitialisation reste lisible
dans la console.

**Côté n8n — Gmail SMTP.** L'identifiant est créé **dans n8n uniquement**, jamais dans le
dépôt ni dans un fichier de workflow : compte Gmail avec vérification en deux étapes activée
et **mot de passe d'application** dédié — pas le mot de passe du compte, qui ne fonctionne
d'ailleurs pas en SMTP. Un mot de passe d'application se révoque seul, sans toucher au compte.
`smtp.gmail.com`, port `465`, SSL. Marche à suivre complète : `n8n/README.md`.

## Pourquoi deux fournisseurs, et pas un seul

**Le mode test de Resend ne délivre qu'à une adresse.** Sans domaine vérifié, l'expéditeur de
bac à sable `onboarding@resend.dev` n'envoie **qu'à l'adresse du compte Resend lui-même** ;
toute autre destination est refusée. Vérifier un domaine suppose d'en posséder un et d'y poser
des enregistrements DNS — hors périmètre d'un POC de onze jours.

C'est suffisant pour la réinitialisation de mot de passe, qu'on démontre sur le compte de
l'équipe. Ça ne l'est pas pour les automatisations, qui écrivent à un intérimaire **et** à une
entreprise, deux adresses différentes. D'où Gmail SMTP côté n8n.

C'est aussi pourquoi `seed:demo` utilise le **sous-adressage Gmail** : `interimcadans+cariste@`,
`interimcadans+entreprise@`, `interimcadans+interimaire@`. Trois comptes distincts pour
l'application, une seule boîte à surveiller pendant la démonstration.
