# API : comptes, sessions, routes et données sensibles

Comment l'API se protège et comment s'en servir, pour le site comme pour un nouveau module
du back. Toutes les routes sont préfixées par `http://localhost:3001` en local. Le détail
métier de chaque module est dans les autres documents de `docs/` (voir l'index du README).

## Vue d'ensemble

```
Inscription / connexion ──► cookie de session httpOnly `cadans_session` (JWT, 1 h)
        │
        ▼
Chaque requête ──► SessionGuard : session valide ?  sinon 401
                 └► RolesGuard   : bon rôle ?        sinon 403
        │
        ▼
Pièces d'identité, habilitations ──► chiffrées AES-256-GCM avant d'être écrites en base
```

Trois rôles, portés par le champ `role` : **`COMPANY`** (entreprise), **`WORKER`**
(intérimaire) et **`ADMIN`** (agent CADANS, sans inscription publique, voir
[`espace-agent.md`](espace-agent.md)). Un compte `COMPANY` ou `WORKER` a exactement un profil,
`company` ou `worker`, l'autre vaut `null` ; un compte `ADMIN` n'en a aucun.

## Routes d'authentification

| Méthode et route | Accès | Corps (JSON) | Réponse |
| --- | --- | --- | --- |
| `POST /auth/register/company` | public | `email`, `password`, `legalName`, `siret`, `nafCode`, `contactFirstName`, `contactLastName`, `addressLine`, `postalCode`, `city`, `phone` (facultatif) | `201` + compte, **session ouverte** |
| `POST /auth/register/worker` | public | `email`, `password`, `firstName`, `lastName`, `postalCode`, `city`, `phone` (facultatif) | `201` + compte, **session ouverte** |
| `POST /auth/login` | public | `email`, `password` | `200` + compte, session ouverte |
| `GET /auth/me` | connecté | — | `200` + compte de la session |
| `POST /auth/logout` | public | — | `204`, cookie effacé |
| `POST /auth/password-reset/request` | public | `email` | `204` **quoi qu'il arrive**, adresse inconnue comprise : la réponse ne révèle pas quelles adresses ont un compte. Le lien part par email (Resend), ou dans la console de l'API si `RESEND_API_KEY` est vide |
| `POST /auth/password-reset/confirm` | public | `token`, `password` | `204`. `400` avec le même message si le lien est inconnu, déjà utilisé ou expiré. La session n'est pas ouverte |

Exemple de compte renvoyé (le hash du mot de passe n'est **jamais** renvoyé) :

```json
{
  "id": "8bd646b8-69fe-45fe-8a7b-178efea4967c",
  "email": "samir@example.fr",
  "role": "WORKER",
  "createdAt": "2026-09-17T08:30:08.183Z",
  "updatedAt": "2026-09-17T08:30:08.183Z",
  "company": null,
  "worker": {
    "id": "8e165339-7c39-4a50-88df-a37e4d976cba",
    "userId": "8bd646b8-69fe-45fe-8a7b-178efea4967c",
    "firstName": "Samir",
    "lastName": "Diallo",
    "phone": null,
    "postalCode": "69007",
    "city": "Lyon",
    "createdAt": "2026-09-17T08:30:08.183Z",
    "updatedAt": "2026-09-17T08:30:08.183Z"
  }
}
```

**Règles de validation** (l'API renvoie `400` avec la liste des messages en français dans `message`) :

| Champ | Règle |
| --- | --- |
| `email` | Email valide. Espaces retirés et mis en minuscules : `Samir@Example.FR` = `samir@example.fr`. |
| `password` (inscription) | **12 caractères minimum**, avec une minuscule, une majuscule, un chiffre et un caractère spécial (recommandation CNIL). |
| `password` (connexion) | Aucune règle de complexité, pour ne pas révéler la politique. |
| `siret` | 14 chiffres dont la clé de contrôle (Luhn) est juste. Les espaces sont acceptés : `732 829 320 00074`. |
| `nafCode` | Format `52.10B`. **Non bloquant** : une entreprise hors entreposage peut s'inscrire. |
| `postalCode` | 5 chiffres, gardé en texte (`01000` conserve son zéro). |
| `phone` | Numéro français, `06 12 34 56 78` ou `+33 6 12 34 56 78`. |
| Champ inconnu | Refusé. Un client ne peut pas choisir son `role`. |

**Codes d'erreur à gérer dans les formulaires :**

| Code | Quand | `message` |
| --- | --- | --- |
| `400` | Champ invalide | Tableau de messages, un par règle non respectée |
| `401` | Mauvais identifiants | `Email ou mot de passe incorrect` (identique si l'email n'existe pas, volontairement) |
| `401` | Pas de session, ou session expirée | `Authentification requise` |
| `403` | Mauvais type de compte | `Cette action n'est pas autorisée pour votre type de compte` |
| `409` | Email déjà utilisé | `Un compte existe déjà avec cette adresse email` |
| `409` | SIRET déjà inscrit | `Une entreprise est déjà inscrite avec ce SIRET` |

## Toutes les routes

Inventaire au 23/09/2026, relevé dans les contrôleurs de `apps/api/src`. « connecté » = tout
rôle avec une session ; sinon le rôle exigé, `403` pour les autres, `401` sans session.

**Compte et profils**

| Route | Accès | Effet |
| --- | --- | --- |
| `GET /account/me` | connecté | identifiants de connexion du compte |
| `PUT /account/me/email` · `PUT /account/me/password` | connecté | changement d'email ou de mot de passe, mot de passe actuel exigé |
| `GET /companies/me` · `PUT /companies/me` | `COMPANY` | coordonnées de l'entreprise |
| `GET /workers/me/identite` · `PUT …` | `WORKER` | nom, prénom, téléphone, ville, code postal |
| `GET /workers/me/profil-matching` · `PUT …` | `WORKER` | compétences déclarées et créneaux acceptés |
| `GET /workers/me/informations-embauche` · `PUT …` | `WORKER` | état civil, adresse, NIR et IBAN (chiffrés), nécessaires au contrat de mission |
| `PUT` / `GET` `/workers/me/identity-document`, `GET …/file` | `WORKER` | pièce d'identité chiffrée (voir plus bas) |
| `GET /workers/me/certifications`, `PUT` / `DELETE` `…/:type`, `GET …/:type/document` | `WORKER` | habilitations et justificatifs chiffrés (voir plus bas) |

**Référentiel, missions, candidatures, matching**

| Route | Accès | Effet |
| --- | --- | --- |
| `GET /referentiel/postes` · `GET /referentiel/competences[?rome=]` | public | postes exposés et compétences principales (cache 1 h) |
| `GET /missions/ouvertes` · `GET /missions/:id` | public | pages publiques ; une mission pourvue reste servie (`200`) |
| `GET /missions/prefill/disponibilite` | public | l'entrée « depuis une offre France Travail » est-elle proposable ? |
| `POST /missions/prefill` | `COMPANY` | préremplissage depuis une offre France Travail |
| `POST /missions` · `GET /missions` · `PUT /missions/:id` | `COMPANY` | ses propres missions |
| `PATCH /missions/:id/status` | `COMPANY` | `OUVERTE` → `POURVUE` (exige `workerId` : génère les contrats, appelle n8n) → `TERMINEE` |
| `POST /missions/:missionId/candidatures` | `WORKER` | postuler ; `409` si l'habilitation manque ou si la mission est pourvue |
| `GET /workers/me/candidatures` | `WORKER` | ses candidatures |
| `GET /missions/:missionId/candidatures` | `COMPANY` | candidatures reçues, avec score ventilé et habilitations |
| `GET /matches` | `WORKER` | missions ouvertes compatibles, triées par score, plus le nombre de missions masquées faute d'habilitation |

**Contrats et annexes** : voir [`contrats.md`](contrats.md), « Les routes ».

**Espace agent** (`ADMIN`, `@Roles` posé sur la classe) : `GET /admin/tableau-de-bord`,
`GET /admin/justificatifs[?statut=]`, `GET /admin/justificatifs/:id/document`,
`POST /admin/justificatifs/:id/valider`, `POST …/refuser`, puis `GET /admin/interimaires[/:id]`,
`GET /admin/entreprises[/:id]`, `GET /admin/missions[/:id][?statut=]`,
`GET /admin/contrats[/:id][?statut=]`. Détail dans [`espace-agent.md`](espace-agent.md).

**Santé** : `GET /health`, public, toujours `200`, corps `{ status, postgres, mongo, uptimeSeconds }`.

## Référentiel métier (lecture)

Deux routes **publiques, en lecture seule** : le référentiel est une donnée ouverte (ROME 4.0,
licence Etalab) sans rien d'utilisateur, et les pages publiques rendues côté serveur doivent
pouvoir le lire sans session. Il est alimenté par `npm run import:rome` (voir
[`referentiel-matching.md`](referentiel-matching.md)).

| Route | Pour qui | Renvoie |
| --- | --- | --- |
| `GET /referentiel/postes` | Le formulaire de mission (entreprise) | Les postes **exposés** et actifs, triés par code ROME puis appellation principale en tête : `code`, `label`, `classification`, `rome {code, label}`, `habilitationsSuggerees` (types de `CertificationType`, pré-remplissage de l'exigence de la mission) |
| `GET /referentiel/competences` | Le profil intérimaire | Les compétences **principales** actives, sans les savoir-être, dédoublonnées et triées par libellé : `code`, `label`, `type`, `romeCodes`. `?rome=N1101` restreint à un métier ; un code mal formé répond `400`. |

Ce qu'un ré-import a désactivé n'est plus proposé mais reste en base : un profil ou une
mission qui y fait référence continue de se lire.

**Cache d'une heure** (`Cache-Control: public, max-age=3600`) sur les deux routes : le
référentiel ne change qu'au ré-import, il n'y a aucune raison de resservir les mêmes 26 postes
à chaque affichage de formulaire. C'est l'une des pratiques d'éco-conception (RGESN) du
projet. Contrepartie assumée : un ré-import met jusqu'à une heure à être visible par un
client qui avait déjà la liste.

## Côté front (Next.js)

La session est un **cookie httpOnly** posé par l'API : le JavaScript de la page ne peut ni le
lire, ni le stocker, ni l'envoyer lui-même. **Il n'y a aucun jeton à gérer.** Deux situations,
deux mécanismes :

- **Dans le navigateur** (composant client, formulaire), le navigateur joint le cookie de
  lui-même à condition que l'appel porte `credentials: 'include'`. Sans cette option, l'API
  répond `401` alors que l'utilisateur vient de se connecter.
- **Dans un composant serveur** (page, layout, `generateMetadata`), le serveur Next.js n'a pas
  les cookies du navigateur : il faut relire celui de la requête entrante et le transmettre à
  la main dans l'en-tête `Cookie`.

Le site encapsule les deux dans `apps/web/src/lib`, et c'est par là qu'il faut passer :

| Helper | Fichier | Usage |
| --- | --- | --- |
| `postJson`, `putJson`, `patchJson`, `getJson` | `lib/api.ts` | appels depuis le navigateur, `credentials: 'include'` posé, erreurs normalisées en `ApiError { status, messages }` (`status` vaut `0` si l'API ne répond pas) |
| `getSessionAccount()` | `lib/session.ts` | compte de la session dans un composant serveur, ou `null` : à la page de rediriger |
| `serverGet(path, query?)` | `lib/session.ts` | `GET` authentifié depuis un composant serveur, lève une erreur si la réponse n'est pas `2xx` |
| `serverGetOrRedirect(path, query?)` | `lib/session.ts` | idem, mais redirige vers `/connexion` en cas d'échec : à préférer dans une page protégée, dont le layout et la page démarrent leurs requêtes en parallèle |

```ts
// Composant client : connexion, puis envoi d'un formulaire.
import { ApiError, postJson, putJson } from '../lib/api';

try {
  await postJson('/auth/login', { email, password });
  await putJson('/workers/me/profil-matching', { competences, shifts });
} catch (error) {
  if (error instanceof ApiError) {
    setMessages(error.messages); // string[] : une ligne par règle non respectée sur un 400
  }
}
```

```ts
// Composant serveur : page protégée.
import { serverGetOrRedirect } from '../../lib/session';

export default async function Page() {
  const matches = await serverGetOrRedirect<MatchesView>('/matches');
  // …
}
```

**Envoyer un fichier** (justificatif de CACES, annexe) : `FormData` et `fetch` direct avec
`credentials: 'include'`, **sans** fixer `Content-Type` à la main, le navigateur ajoute la
frontière multipart. Voir `components/profil/Habilitations.tsx`.

## Côté back : protéger une nouvelle route

**Toute route est protégée par défaut** : sans rien ajouter, elle exige une session. Trois
décorateurs, dans `apps/api/src/auth/decorators.ts`, suffisent pour tout le reste :

| Décorateur | Effet |
| --- | --- |
| `@Public()` | Route accessible sans session (pages publiques, `/health`…) |
| `@Roles(Role.COMPANY)` | Réservée à un ou plusieurs rôles, `403` pour les autres |
| `@CurrentUser()` | Injecte l'utilisateur connecté : `{ id, role }` |

Exemple pour le module missions :

```ts
import { Body, Controller, Get, Post } from '@nestjs/common';
import { Role } from '@prisma/client';
import { CurrentUser, Public, Roles } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';

@Controller('missions')
export class MissionsController {
  // Liste publique des annonces (pages SEO).
  @Public()
  @Get()
  findAll() { … }

  // Seule une entreprise crée une mission, pour elle-même.
  @Roles(Role.COMPANY)
  @Post()
  create(@CurrentUser() user: SessionUser, @Body() dto: CreateMissionDto) {
    return this.missions.create(user.id, dto);
  }
}
```

> **Règle de sécurité : l'identité vient toujours de `@CurrentUser()`, jamais d'un paramètre
> d'URL ou du corps de la requête.** Une route `/workers/me/…` ou un `companyId` lu dans la
> session empêche un utilisateur d'agir sur le compte d'un autre.

`user.id` est l'identifiant du **compte** (`User`). Pour obtenir le profil :
`prisma.company.findUnique({ where: { userId: user.id } })` (ou `prisma.worker`).

**Tester une route protégée** : les tests fonctionnels n'ont pas besoin de PostgreSQL. Voir
`apps/api/test/session.e2e-spec.ts` : on inscrit un compte, on récupère son cookie, puis on
l'envoie avec `.set('Cookie', cookie)`. Le stockage en mémoire est dans `apps/api/test/`.

## Données sensibles chiffrées

Pièces d'identité et habilitations sont **chiffrées par l'API avant d'être écrites en base**
(AES-256-GCM, clé `ENCRYPTION_KEY`) : un accès direct à PostgreSQL, à Prisma Studio ou à une
sauvegarde ne montre que des octets illisibles. Chaque valeur chiffrée est liée à son
intérimaire : recopiée sur la ligne d'un autre, elle ne se déchiffre plus.

| Donnée | En base | Pourquoi |
| --- | --- | --- |
| Type d'habilitation (`CACES_R489_3`…) | **en clair** | Filtrage bloquant du matching |
| Date d'expiration | **en clair** | Écarter une habilitation périmée |
| Numéro du certificat | chiffré | Donnée personnelle |
| Scan du certificat | chiffré | Donnée personnelle |
| Pièce d'identité (fichier) | chiffré | Donnée personnelle |

Routes, **réservées aux intérimaires connectés** (`403` pour une entreprise) :

| Méthode et route | Corps (multipart) | Réponse |
| --- | --- | --- |
| `PUT /workers/me/identity-document` | `type` (`CNI`, `PASSEPORT`, `TITRE_SEJOUR`), `file` | `200` + métadonnées. Remplace la pièce précédente. |
| `GET /workers/me/identity-document` | — | `200` + métadonnées, `404` si aucune |
| `GET /workers/me/identity-document/file` | — | Le fichier déchiffré |
| `GET /workers/me/certifications` | — | `200` + liste, numéro déchiffré inclus |
| `PUT /workers/me/certifications/:type` | `expiresAt` (`AAAA-MM-JJ`, facultatif), `number` (facultatif), `file` (facultatif) | `200` + habilitation. Crée ou met à jour ; **sans nouveau `file`, le scan existant est conservé**. |
| `GET /workers/me/certifications/:type/document` | — | Le scan déchiffré, `404` si aucun |
| `DELETE /workers/me/certifications/:type` | — | `204` |

Types d'habilitation acceptés dans `:type` : `CACES_R489_1A`, `CACES_R489_1B`,
`CACES_R489_2A`, `CACES_R489_2B`, `CACES_R489_3` à `CACES_R489_7`, `CACES_R485_1`,
`CACES_R485_2`, `HABILITATION_ELECTRIQUE`.

**Fichiers acceptés : PDF, JPEG ou PNG, 5 Mo maximum.** Le format est vérifié sur le contenu
réel du fichier, pas sur son extension : un `.pdf` qui n'en est pas un est refusé (`415`).
Au-delà de 5 Mo : `413`.

**Pour le matching** : type et date sont lisibles directement avec Prisma, sans déchiffrer.

```ts
// Intérimaires ayant un CACES R489 catégorie 3 valide le jour de la mission.
prisma.worker.findMany({
  where: {
    certifications: {
      some: {
        type: 'CACES_R489_3',
        OR: [{ expiresAt: null }, { expiresAt: { gte: missionDate } }],
      },
    },
  },
});
```

**Ajouter une nouvelle donnée chiffrée** : colonne `Bytes` suffixée `Encrypted` dans
`schema.prisma`, puis `EncryptionService` (module global, injectable partout) :

```ts
const encrypted = this.encryption.encryptText(valeur, `mon-usage:${workerId}`);
const valeur = this.encryption.decryptText(ligne.monChampEncrypted, `mon-usage:${workerId}`);
```

Le second argument (le contexte) doit être **identique** au chiffrement et au déchiffrement.

## Tester à la main avec curl

```bash
# Inscription : -c enregistre le cookie de session dans un fichier
curl -c /tmp/session -H 'Content-Type: application/json' \
  http://localhost:3001/auth/register/worker \
  -d '{"email":"test@example.fr","password":"Preparateur!42x","firstName":"Test","lastName":"Test","postalCode":"69007","city":"Lyon"}'

# Requêtes authentifiées : -b renvoie le cookie
curl -b /tmp/session http://localhost:3001/auth/me
curl -b /tmp/session -X PUT http://localhost:3001/workers/me/certifications/CACES_R489_3 \
  -F expiresAt=2030-06-30 -F number=R489-3-000123 -F 'file=@caces.pdf;type=application/pdf'
curl -b /tmp/session -o copie.pdf http://localhost:3001/workers/me/certifications/CACES_R489_3/document
```

## Sécurité en résumé (pour la soutenance)

| Exigence | Mise en œuvre |
| --- | --- |
| Mots de passe | Hachés avec **argon2id** (sel inclus), paramètres OWASP m = 19 Mio, t = 2, p = 1, jamais stockés ni renvoyés en clair |
| Authentification « à la main » | **JWT HS256 codé avec `node:crypto`**, sans librairie : signature en temps constant, en-tête figé (refus de `alg: none`), expiration 1 h. Les **primitives cryptographiques** viennent de librairies éprouvées (`argon2`, `node:crypto`) : on ne réimplémente pas un algorithme de hachage ou de chiffrement. La **logique d'authentification** (émission et vérification des sessions, cookie, gardes, rôles) est entièrement la nôtre. |
| Vol de session par XSS | Cookie **httpOnly**, illisible par le JavaScript |
| CSRF | Cookie `SameSite` + refus des écritures dont l'en-tête `Origin` n'est pas `WEB_URL` |
| CORS | Une seule origine autorisée : `WEB_URL` |
| Énumération des comptes | **À la connexion** : même message et même temps de réponse pour un email inconnu et un mauvais mot de passe. **À l'inscription**, un email déjà utilisé est signalé (409) : compromis assumé, sans quoi l'utilisateur ne comprendrait pas pourquoi son inscription échoue. |
| Permissions | Routes protégées par défaut, rôles vérifiés sur chaque route |
| Chiffrement au repos | **AES-256-GCM** (intégrité incluse) sur pièces d'identité et habilitations |
| Chiffrement en transit | HTTPS (Render), cookie `Secure` et en-tête **HSTS** en production |
| Fichiers malveillants | Format vérifié sur le contenu, 5 Mo max, jamais écrits sur le disque ; téléchargement forcé, sans cache, avec `X-Content-Type-Options: nosniff` |
| Secrets d'exemple | Les valeurs de `.env.example`, publiques, sont refusées au démarrage en production |
