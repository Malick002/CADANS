# Déploiement

**Rien n'est déployé à ce jour** (23/09/2026). Ce chapitre prépare le terrain : la configuration est dans
le dépôt, les actions manuelles sont listées, et aucune n'a été exécutée.

Le blueprint **`render.yaml`** décrit les deux services web Node. Site et API sur Render,
PostgreSQL chez Neon, MongoDB chez Atlas (décision du 18/09/2026, voir « Hébergement :
Render plutôt que Vercel » dans le README).

## Ce que fait le blueprint

| Service | Build | Démarrage |
| --- | --- | --- |
| `cadans-api` | `npm ci && npm run prisma:generate:prod -w apps/api && npm run build -w apps/api` | `npm run prisma:deploy -w apps/api && npm run start -w apps/api` |
| `cadans-web` | `npm ci && npm run build:prod -w apps/web` | `npm run start:prod -w apps/web` |

Quatre scripts **`:prod`** ont été ajoutés exprès. Les scripts habituels passent par
`dotenv-cli` et cherchent un `.env` à la racine, **qui n'existe pas sur l'hébergeur** : là,
les variables sont déjà dans l'environnement du processus. Les deux commandes de build
ci-dessus ont été rejouées localement sans `.env`, elles passent.

**Les migrations s'appliquent au démarrage**, par `prisma migrate deploy` — et non
`migrate dev`, qui peut créer une migration ou proposer de réinitialiser la base. Si une
migration échoue, le service ne démarre pas : mieux vaut ça qu'une API en ligne sur un
schéma incohérent.

**`/health` est la sonde Render.** Elle répond **toujours 200**, même bases coupées : son
corps porte l'état (`{"status":"down","postgres":"up","mongo":"down"}`). Elle dit donc que le
processus vit, pas que tout va bien — c'est exactement ce qu'attend un health check.

## Variables d'environnement, service par service

`sync: false` dans `render.yaml` signifie **valeur à saisir à la main** dans le tableau de
bord : Render les demande au moment d'appliquer le blueprint. Rien de secret n'est écrit
dans le dépôt.

### `cadans-api`

| Variable | Origine | Sans elle |
| --- | --- | --- |
| `DATABASE_URL` | Neon, chaîne de connexion avec `?sslmode=require` | L'API ne démarre pas |
| `MONGO_URL` | MongoDB Atlas, `mongodb+srv://…` | `/health` renvoie `mongo: down` ; le journal de matching est perdu, le reste fonctionne |
| `MONGO_DB` | `cadans` (posée par le blueprint) | Repli sur `cadans`, donc sans effet |
| `JWT_SECRET` | **généré par Render**, 32 caractères minimum | L'API refuse de démarrer |
| `ENCRYPTION_KEY` | `openssl rand -base64 32` — **32 octets encodés en base64** | L'API refuse de démarrer |
| `WEB_URL` | URL du site, `https://…`, **sans `/` final** | CORS et contrôle CSRF retombent sur `http://localhost:3000` : le site en ligne ne peut plus appeler l'API |
| `RESEND_API_KEY` | compte Resend de l'équipe | L'API démarre, mais **journalise** les emails au lieu de les envoyer |
| `MAIL_FROM` | expéditeur sur un domaine vérifié chez Resend | idem |
| `N8N_MATCH_NOTIFICATION_URL` | URL de production du webhook (voir `n8n/README.md`) | L'appel est journalisé, jamais envoyé |
| `N8N_MISSION_POURVUE_URL` | idem | idem |
| `FRANCE_TRAVAIL_CLIENT_ID` | portail France Travail (application souscrite aux API **ROME 4.0** et **Offres d'emploi v2**) | Deux conséquences : `npm run import:rome -- --fetch` échoue — le seed figé du dépôt reste utilisable — **et** l'entrée « Partir d'une offre France Travail » disparaît de l'écran de création de mission. Le formulaire vierge, lui, fonctionne entièrement |
| `FRANCE_TRAVAIL_CLIENT_SECRET` | idem | idem |
| `NODE_ENV=production` | posée par le blueprint | Cookie en `SameSite=Lax` et sans `Secure` : **la session ne traverse pas les deux domaines** |
| `PORT` | **injectée par Render**, ne pas la définir | — |

### `cadans-web`

| Variable | Origine | Sans elle |
| --- | --- | --- |
| `NEXT_PUBLIC_API_URL` | URL de l'API, `https://…`, sans `/` final | Les appels navigateur échouent avec un message explicite (`lib/api.ts`) |
| `WEB_URL` | URL du site | `sitemap.xml` et `robots.txt` pointent sur `http://localhost:3000` |
| `NODE_ENV=production` | posée par le blueprint | — |

⚠️ **`NEXT_PUBLIC_API_URL` est lue AU BUILD** et inlinée dans le JavaScript envoyé au
navigateur. La modifier impose de **relancer un déploiement**, pas seulement un redémarrage.

⚠️ **n8n n'est pas déployé.** L'instance tourne sur le poste de chacun (`n8n/README.md`) :
une API sur Render ne peut donc pas atteindre `http://localhost:5678`. Laisser
`N8N_MATCH_NOTIFICATION_URL` et `N8N_MISSION_POURVUE_URL` **vides** côté Render — l'API
journalise alors l'appel au lieu de l'envoyer, sans rien casser. La démonstration des
automatisations se fait en local, API et n8n sur la même machine.

⚠️ **À vérifier avant la soutenance** : sans `FRANCE_TRAVAIL_CLIENT_ID` et
`FRANCE_TRAVAIL_CLIENT_SECRET` sur `cadans-api`, l'écran de création de mission n'affiche
qu'une seule entrée, et le préremplissage depuis une offre — une des démonstrations de
l'exigence « les données France Travail alimentent une fonctionnalité visible » — n'est pas
montrable. Rien ne casse, mais il n'y a aucun message : l'entrée est simplement absente.

## La session doit traverser deux domaines

Le site et l'API sont sur deux hôtes différents, et `onrender.com` figure sur la *Public
Suffix List* : `cadans-web.onrender.com` et `cadans-api.onrender.com` sont donc **deux sites
distincts** pour le navigateur, pas deux sous-domaines d'un même site. Un cookie de session
en `SameSite=Lax` ne serait jamais envoyé.

Le code le gère déjà, et c'est `NODE_ENV=production` qui l'active
(`apps/api/src/auth/session-cookie.ts`) :

- **`SameSite=None`**, sans quoi le navigateur n'envoie pas le cookie sur une requête
  déclenchée par l'autre domaine ;
- **`Secure`**, qu'impose `SameSite=None` — donc HTTPS obligatoire, ce que Render fournit ;
- **`httpOnly`**, pour que le JavaScript de la page ne puisse pas lire la session ;
- côté client, **`credentials: 'include'`** sur chaque appel (`apps/web/src/lib/api.ts`).

`SameSite=None` retire la protection CSRF que `Lax` offrait gratuitement. Elle est remplacée
par un **contrôle d'origine explicite** : `SessionGuard` refuse toute méthode non sûre dont
l'en-tête `Origin` ne vaut pas `WEB_URL`, et `enableCors` n'autorise que cette origine. D'où
l'exigence d'une valeur **exacte** : `https://cadans-web.onrender.com`, sans `/` final.

## Check-list des actions manuelles

Aucune n'a été faite. Dans cet ordre — l'API a besoin de l'URL du site, et le site de celle
de l'API.

**1. Neon (PostgreSQL)**

- [ ] Créer un projet, région Europe (Francfort) pour rester près des services Render.
- [ ] Copier la chaîne de connexion **pooled**, vérifier qu'elle contient `?sslmode=require`.

**2. MongoDB Atlas**

- [ ] Créer un cluster gratuit **M0**, même région.
- [ ] Créer un utilisateur de base, puis autoriser l'accès réseau. Render n'annonce pas
      d'adresses IP fixes sur l'offre gratuite : `0.0.0.0/0` est la seule option praticable.
      **À dire au jury comme une limite assumée de l'offre gratuite**, pas comme un oubli.
- [ ] Copier l'URL `mongodb+srv://…`.

**3. Accès GitHub — depuis un miroir privé**

Installer l'application GitHub de Render sur l'organisation Epitech exige un **droit de
propriétaire de l'organisation**, que personne dans l'équipe n'a. Décision du 23/09/2026 : le
déploiement se fait depuis un **miroir privé du dépôt sur un compte GitHub personnel**, que
Render peut lire. **Le dépôt de l'organisation reste la référence** : le miroir ne reçoit que
des pousses de `main`, jamais de commit direct.

- [ ] Créer le dépôt privé miroir, puis `git push --mirror` (ou `git push <miroir> main`)
      depuis un clone à jour.
- [ ] Installer l'application GitHub de Render sur ce compte personnel, limitée à ce dépôt.
- [ ] Après chaque fusion sur `main` de l'organisation, repousser `main` vers le miroir :
      c'est ce push qui déclenche le redéploiement Render.

**4. Render**

- [ ] **Blueprints → New Blueprint Instance**, pointer sur ce dépôt : `render.yaml` crée les
      deux services.
- [ ] Renseigner les variables demandées (tableaux ci-dessus).
- [ ] Générer la clé de chiffrement : `openssl rand -base64 32`. **La conserver ailleurs que
      sur Render** — la perdre rend définitivement illisibles les pièces d'identité et
      habilitations déjà enregistrées.
- [ ] Vérifier que le `JWT_SECRET` généré fait bien **32 caractères ou plus**.
- [ ] Premier déploiement des deux services, puis **relever les deux URL**.
- [ ] Renseigner `WEB_URL` sur l'API, `NEXT_PUBLIC_API_URL` et `WEB_URL` sur le site.
- [ ] **Redéployer le site** (et pas seulement le redémarrer) : `NEXT_PUBLIC_API_URL` est
      inlinée au build.

**5. Données**

- [ ] Les migrations partent seules au démarrage de l'API. Vérifier dans le journal.
- [ ] Importer le référentiel ROME : `npm run import:rome` depuis un shell Render, ou en
      local avec le `DATABASE_URL` de Neon. Sans lui, **aucun poste n'est proposable** et la
      création de mission échoue.
- [ ] Jeu de démonstration : `npm run seed:demo -- --complet`. ⚠️ Il crée des comptes dont
      **le mot de passe est public** — à ne lancer que si la démonstration l'exige, et à
      assumer devant le jury.

**6. n8n**

- [ ] Importer les **trois** workflows de `n8n/`, créer l'**identifiant Gmail SMTP** dans n8n
      (mot de passe d'application, jamais le mot de passe du compte) et l'**identifiant
      PostgreSQL** du workflow de rappel (rôle en lecture seule), activer les workflows,
      relever les **URL de production** des deux webhooks.
- [ ] Les coller dans `N8N_MATCH_NOTIFICATION_URL` et `N8N_MISSION_POURVUE_URL` sur l'API.
- [ ] Détail complet : `n8n/README.md`.

**7. Le jour de la soutenance**

- [ ] Sur l'offre gratuite, **un service s'endort après 15 minutes** sans visite et met
      environ une minute à se réveiller. **Ouvrir le site ET `/health` une dizaine de
      minutes avant de passer.**
- [ ] Vérifier que `/health` renvoie `"status":"up"` sur les deux bases.
- [ ] Les 750 heures gratuites mensuelles sont partagées par tout le compte : deux services
      allumés en continu tiennent jusqu'à la soutenance, pas beaucoup plus.

## Intégration continue

Le workflow `.github/workflows/ci.yml` rejoue les six vérifications sur chaque pull request,
avec un vrai PostgreSQL et un vrai MongoDB, et publie le rapport de coverage.

### ⚠️ La CI ne s'exécute pas actuellement

Le dépôt est **privé** et appartient à l'organisation Epitech, dont le **quota GitHub
Actions est épuisé** :

```
The job was not started because an Actions budget is preventing further use.
```

Les jobs ne démarrent pas. Ce n'est pas un problème de code, et aucun membre de l'équipe
n'a les droits d'administration pour le corriger.

**En attendant, `npm run verify` remplace la CI** et doit être lancé avant chaque push. Le
workflow est conservé tel quel : il repartira automatiquement dès que le budget sera
rétabli, et il est écrit pour consommer le minimum de minutes ce jour-là.
