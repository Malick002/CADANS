# Les deux contrats — mentions obligatoires

Comparaison entre le PDF produit par `apps/api/src/contracts/contract-pdf.service.ts` et les
mentions qu'exige le Code du travail. Établi le 22/09/2026.

Textes consultés sur Légifrance, pas cités de mémoire :

- [Article L. 1251-16](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006901267) —
  contenu du **contrat de mission** (entreprise de travail temporaire ↔ salarié intérimaire) ;
- [Article L. 1251-43](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000006901299) —
  contenu du **contrat de mise à disposition** (ETT ↔ entreprise utilisatrice), dont le
  L. 1251-16 1° impose la reproduction intégrale dans le contrat de mission.

## Le positionnement a changé le 22/09 — et ça change le contrat

**CADANS est désormais une entreprise de travail temporaire**, donc l'employeur de
l'intérimaire. Tout ce document était écrit sous l'hypothèse inverse. Ce qui suit est la
nouvelle lecture.

### Ce qui devient faux, et doit disparaître du PDF

L'avertissement en tête de document — « *CADANS n'est pas une entreprise de travail
temporaire : ce document ne vaut pas contrat de mission* » — **s'inverse**. C'était l'argument
central de la version précédente ; il n'a plus lieu d'être, et un test verrouille aujourd'hui
sa présence : il faudra le retourner, pas le supprimer sans le remplacer.

De même, la mention que la caisse de retraite complémentaire et l'organisme de prévoyance
« n'ont pas d'objet, faute d'ETT » (L. 1251-16 6°) : **ils ont un objet maintenant**. Ce
n'était pas une impossibilité de principe, c'est devenu une donnée manquante.

### Ce qui manque et n'existait pas comme manque avant

**CADANS n'est pas partie au contrat qu'elle génère.** Le PDF actuel ne nomme que deux
parties : l'entreprise utilisatrice et l'intérimaire. L'employeur est absent du document qui
l'engage. Il faut y ajouter un bloc d'identité de l'agence — dénomination, forme juridique,
SIRET, siège, et le nom du signataire pour CADANS.

Ces valeurs ne sont pas des données utilisateur : ce sont des **constantes de l'entreprise**,
à poser une fois (constantes de code ou variables d'environnement), pas à saisir par écran.
Elles restent **à fournir** — les inventer produirait un document qui a l'air authentique et
ne l'est pas.

| Donnée de l'agence | Où elle sert |
| --- | --- |
| Dénomination, forme juridique, capital | En-tête des deux contrats, mentions légales |
| SIRET, RCS | Identification de la partie |
| Adresse du siège | Identification de la partie |
| Caisse de retraite complémentaire | L. 1251-16 6° |
| Organisme de prévoyance | L. 1251-16 6° |
| Garantie financière (organisme, montant) | Condition d'exercice, art. L. 1251-49 |
| Nom et qualité du signataire | Bloc de signature « Pour CADANS » |

### Ce qui devient structurellement différent

**Un document ne suffit plus, il en faut deux.** Le PDF actuel s'appelle « contrat de
mission » et mélange les deux natures : il nomme l'entreprise utilisatrice comme partie, ce
qui relève du contrat de **mise à disposition**, tout en s'intitulant contrat de **mission**.

- **Contrat de mission** (L. 1251-16) : CADANS ↔ **intérimaire**. L'entreprise utilisatrice y
  apparaît, mais comme lieu d'exécution, pas comme partie signataire.
- **Contrat de mise à disposition** (L. 1251-43) : CADANS ↔ **entreprise utilisatrice**.
  L'intérimaire y est nommé, mais ne le signe pas.

Le contenu se recoupe largement — le L. 1251-16 1° impose de reproduire dans le contrat de
mission toutes les clauses du contrat de mise à disposition — donc le générateur actuel est
une **bonne base commune**. Ce sont l'en-tête, les parties et le bloc de signature qui
diffèrent.

### Ce qui ne change pas

Les manques listés plus bas restent des manques, ni plus ni moins : motif du recours, poste à
risques particuliers, équipements de protection individuelle, primes et accessoires, période
d'essai, horaire réel. La clause de rapatriement (L. 1251-16 5°) reste sans objet, le
périmètre étant la France métropolitaine.

## Ce que le PDF porte désormais

| Mention | Article | Source de la donnée |
|---|---|---|
| Identité de l'entreprise utilisatrice (raison sociale, SIRET, adresse) | — | `Company.legalName`, `siret`, `addressLine`, `postalCode`, `city` |
| **Identité de CADANS, employeur** | — | **manquante** — constantes à poser, voir ci-dessus |
| Identité de l'intérimaire, commune de domicile | — | `Worker.firstName`, `lastName`, `city`, `postalCode` |
| Qualification professionnelle | L. 1251-43 4°, L. 1251-16 2° | `Poste.label` (référentiel ROME) |
| Lieu de la mission | L. 1251-43 4° | `Mission.siteLabel` + `postalCode` |
| Horaire | L. 1251-43 4° | `Mission.shift`, libellé indicatif (voir réserve plus bas) |
| Terme de la mission | L. 1251-43 2° | `Mission.startDate`, `endDate` |
| Caractéristiques du poste | L. 1251-43 4° | `Mission.description` (texte libre, facultatif) |
| Habilitations exigées | L. 1251-43 4° | `MissionHabilitation.type` |
| Montant de la rémunération | L. 1251-43 6° | `Mission.hourlyRate` |
| Indemnité de fin de mission (10 %) | L. 1251-16 3°, L. 1251-32 | mention fixe, aucune donnée requise |
| Liberté d'embauche à l'issue de la mission | L. 1251-16 7° | mention fixe, aucune donnée requise |

**Réserve sur l'horaire.** `Mission.shift` est un créneau (`MATIN`, `APRES_MIDI`, `NUIT`,
`JOURNEE`), pas un horaire. Les heures affichées (« Matin (6h – 14h) ») sont **indicatives**,
comme le dit déjà `apps/web/src/lib/shifts.ts`. C'est la meilleure approximation disponible ;
ce n'est pas l'horaire au sens de l'article.

## Ce qui manque, et la donnée qu'il faudrait ajouter

Rien n'a été inventé pour combler ces trous. Chaque ligne indique ce qu'il faudrait stocker.

### Manques qui se comblent avec un champ de plus sur `Mission`

| Mention manquante | Article | Donnée à ajouter |
|---|---|---|
| **Motif du recours** (accroissement temporaire d'activité, remplacement, emploi saisonnier…), et pour un remplacement le nom et la qualification du remplacé | L. 1251-43 1° | `Mission.motifRecours` (enum) + `Mission.remplaceNom` / `remplaceQualification` (nullables) |
| **Caractère à risques particuliers** du poste (liste de l'art. L. 4154-2) | L. 1251-43 4° | `Mission.posteARisques` (booléen) — la description libre ne suffit pas, c'est une case qui déclenche une formation renforcée à la sécurité |
| **Équipements de protection individuelle** et qui les fournit | L. 1251-43 5° | `Mission.equipementsProtection` (liste ou texte) + `Mission.epiFournisPar` |
| **Primes et accessoires de salaire** que percevrait un salarié équivalent de l'entreprise utilisatrice | L. 1251-43 6° | `Mission.primes` (liste libellé + montant) |
| **Horaire réel** (et non le créneau) | L. 1251-43 4° | `Mission.heureDebut` / `heureFin`, ou une table d'horaires par jour |
| **Clause de variation du terme** (« souplesse »), le cas échéant | L. 1251-43 3° | `Mission.variationTermeJours` (nullable) — facultative au sens du texte |

### Manques qui supposent une entité qui n'existe pas dans le modèle

| Mention manquante | Article | Ce qu'il faudrait |
|---|---|---|
| **Durée de la période d'essai** | L. 1251-16 4° | Un champ sur la mission, mais son barème légal dépend de la durée du contrat (art. L. 1251-14) : c'est une règle à implémenter, pas seulement une colonne |
| **Caisse de retraite complémentaire et organisme de prévoyance** | L. 1251-16 6° | Deux constantes de l'agence, à fournir. Depuis le 22/09 la mention a un objet : CADANS est l'ETT |
| **Clause de rapatriement** hors métropole | L. 1251-16 5° | Sans objet : le périmètre du POC est l'entrepôt en France métropolitaine |

## État au 23/09/2026 — les deux documents sont générés

Ce qui suit remplace la « décision proposée » du 22/09 pour tout ce qui a été fait depuis.

### Ce qui est en place

- **Deux générateurs**, un par document, dans `apps/api/src/contracts/contract-pdf.service.ts` :
  contrat de mission (L. 1251-16) et contrat de mise à disposition (L. 1251-43). Le corps
  « mission » et le corps « rémunération » sont écrits par **le même code** — le L. 1251-16 1°
  impose de reproduire dans le contrat de mission les clauses du contrat de mise à
  disposition, deux copies divergeraient.
- **Génération à la mise à POURVUE**, stockage **chiffré** (AES-256-GCM) dans la table
  `contracts`, avec l'**empreinte SHA-256 du PDF en clair** — c'est elle qui identifiera le
  document signé (b2). Le chiffré, lui, change à chaque écriture (IV aléatoire).
- **Le contrat de mission attend les informations d'embauche.** Sans elles il n'est pas
  généré, la mise à disposition part quand même, et l'intérimaire lit sur
  `/interimaire/contrats` ce qui manque, avec le lien vers le formulaire. Il est généré
  automatiquement dès qu'il complète celui-ci.
- **Identité de l'agence complétée** (`cadans-identity.ts`) : organisme de prévoyance et
  garantie financière (L. 1251-49) ne sont plus des emplacements vides. **Ce sont des valeurs
  fictives, signalées comme telles dans le fichier**, et chaque page des deux documents porte
  désormais la mention « Document généré dans le cadre d'un projet pédagogique. Les données
  d'identité de l'agence sont fictives. »
- **Qualité du signataire de l'entreprise utilisatrice** : champ `Company.signatoryRole`,
  nullable. Quand il est vide, le générateur écrit « Représentant légal » — vrai de quiconque
  engage une société, là où un titre inventé affirmerait une fonction qu'on ne connaît pas.
- **Motif du recours** (L. 1251-43 1°) : enum `MotifRecours` sur `Mission`, quatre valeurs,
  obligatoire au formulaire de création. Un remplacement exige en plus le nom et la
  qualification du salarié remplacé, et ces deux champs sont remis à null dès que le motif
  change — sinon le contrat garderait le nom d'un salarié qui n'y a plus sa place.

### Qui reçoit quoi, et pourquoi

| Document | Parties | Qui peut l'ouvrir |
| --- | --- | --- |
| Contrat de mission | CADANS ↔ intérimaire | l'**intérimaire retenu** seulement |
| Contrat de mise à disposition | CADANS ↔ entreprise utilisatrice | l'**entreprise** seulement |

L'entreprise n'accède **jamais** au contrat de mission : elle n'y est pas partie, et il porte
l'état civil du salarié. Ce n'est pas une restriction d'affichage mais la règle de la route —
avec l'identifiant exact, elle reçoit **404** (et non 403 : un 403 confirmerait qu'un contrat
porte cet identifiant).

Le contrat de mise à disposition ne porte du salarié que **prénom, nom et commune**. Ni date
de naissance, ni adresse, ni numéro de sécurité sociale : l'entreprise a besoin de savoir qui
elle accueille, pas d'où il vient (RGPD art. 5.1.c). Un test le vérifie sur le texte réellement
dessiné dans le PDF, pas sur les données d'entrée.

### Choix assumé — le NIR est masqué sur le contrat de mission

Un contrat de mission réel porte le numéro de sécurité sociale **entier**. Ici, seuls ses
quatre derniers chiffres y figurent, et le document le dit — plutôt que de laisser croire à
une troncature accidentelle :

> Le numéro de sécurité sociale est volontairement masqué sur ce document : seuls ses quatre
> derniers chiffres y figurent. Le numéro complet est conservé chiffré par l'employeur et
> n'est restitué par aucune interface.

**Décision du 23/09 : on garde le masquage.** Deux raisons, et elles ne disent pas la même
chose.

**1. Le NIR n'est pas un identifiant comme un autre.** Son usage est encadré au-delà du
RGPD : le décret n° 2019-341 du 19 avril 2019 réserve les traitements du NIR à des finalités
limitativement énumérées, et l'article 30 de la loi Informatique et Libertés lui donne un
régime propre. Une entreprise de travail temporaire a bien un motif de le traiter — DPAE,
DSN, bulletin de paie — mais ce motif porte sur **le traitement**, pas sur chaque support où
le numéro pourrait être recopié. Le faire figurer en entier dans un PDF ne découle pas de
l'autorisation de le traiter.

**2. Un PDF n'a pas la surface d'exposition d'une ligne en base.** La colonne
`hiring_infos.nir_encrypted` est chiffrée au repos, liée à son intérimaire par le contexte
AES-GCM, et n'est lue que par le code qui en a besoin. Un contrat, lui, est **stocké,
téléchargé, ouvert dans un navigateur, mis en cache par un lecteur PDF, imprimé, transféré par
email**. Chacune de ces étapes est une copie en clair que plus personne ne contrôle. Le
chiffrement au repos protège la base ; il ne protège pas un fichier qu'on a rendu à son
destinataire.

La règle du projet — **l'API ne restitue jamais ce numéro en clair** — s'applique donc aussi
ici : un PDF servi par une route HTTP est une sortie de l'API, pas une exception.

**Ce que ça coûte, et comment lever la limite.** En l'état, le document ne peut pas servir de
contrat de mission opposable : la mention manque. La levée ne demande aucune migration — la
donnée est en base, `ContractsService` la déchiffre déjà pour la masquer. Il faudrait :

- **décider que le contrat de mission fait exception à la règle**, explicitement, dans
  `docs/` et pas seulement en commentaire de code ;
- **restreindre le document complet** à sa seule partie signataire, ce que fait déjà la route
  (l'entreprise reçoit 404), et retirer la mention de masquage qui deviendrait fausse ;
- **arbitrer le cas du contrat signé** (b2) : une fois le PDF final produit et transmis, il
  circule hors de la plateforme. C'est là que le masquage prend le plus de sens, et là qu'il
  gêne le plus.

Tant que ce n'est pas tranché, un document trop discret se rattrape ; un numéro de sécurité
sociale qui a circulé, non.

### Approximation qui reste — la qualification

**La qualification portée aux deux documents est celle du POSTE, pas celle du SALARIÉ.**

Le générateur écrit l'intitulé ROME de la mission (« Cariste ») à deux endroits que la loi
distingue pourtant :

- **L. 1251-43 4°** — la qualification professionnelle **exigée** par l'entreprise
  utilisatrice. Ici, c'est exact : c'est bien le poste à pourvoir.
- **L. 1251-16 2°** — la qualification **du salarié**. Ici, c'est une approximation : rien ne
  dit que la qualification de l'intérimaire est celle du poste qu'on lui confie. Un cariste
  titulaire d'un CACES R489-5 affecté à de la préparation de commandes verra écrit
  « préparateur de commandes », ce qui n'est pas sa qualification.

**Pourquoi ce n'est pas corrigé.** Le profil intérimaire ne porte aucune qualification : il
porte des compétences (déclaratives, issues du référentiel ROME) et des habilitations
(justifiées, datées, vérifiées). Aucune des deux n'est une qualification professionnelle au
sens du Code du travail.

**Correction en perspective**, par coût croissant :

1. **Un champ libre `Worker.qualification`**, saisi à l'onboarding ou aux informations
   d'embauche. Coût réel : une colonne, un champ, sa validation en double. Défaut : du texte
   libre à l'endroit où les deux autres parties attendent un vocabulaire contrôlé, et rien ne
   garantit qu'il soit à jour.
2. **Une qualification choisie dans le référentiel ROME**, comme le poste d'une mission —
   même vocabulaire des deux côtés, donc comparable, et le matching pourrait s'en servir.
   C'est la bonne version. Coût : un sélecteur de plus au profil, et la question de ce qu'on
   fait des profils existants qui n'en ont pas.
3. **Une qualification par niveau conventionnel** (coefficient de la convention collective du
   travail temporaire). C'est ce qu'un vrai contrat porte. Hors de portée d'un POC : il
   faudrait la grille, et quelqu'un pour la tenir.

En attendant, les deux documents écrivent la même chaîne aux deux endroits, et ce document
dit que c'en est une seule.

### Signature — ce qu'elle vaut, et ce qu'elle ne vaut pas

**Signature électronique simple** au sens du règlement eIDAS (UE n° 910/2014), art. 3.10.
Elle ne repose sur aucun certificat qualifié, donc **la présomption de fiabilité de
l'article 26 ne s'applique pas**. Le document le dit lui-même, sur sa page de signatures :
laisser croire l'inverse serait la seule faute grave possible ici.

Sa valeur probante tient au faisceau d'éléments conservés ensemble, et chacun répond à une
question qu'un juge poserait :

| Élément | Question |
| --- | --- |
| `userId` | qui, du point de vue du compte |
| `typedName` | ce qui a été **tapé** — c'est lui qui distingue une signature d'un clic |
| `signedAt` | quand, à la milliseconde |
| `ip`, `userAgent` | d'où |
| `documentSha256` | **sur quoi** — sans elle, la signature pourrait porter sur n'importe quelle version |

**CADANS signe automatiquement à la génération.** C'est elle qui établit les documents ; faire
cliquer un agent sur un PDF produit par la machine n'ajouterait aucune garantie. Chaque
document porte donc exactement deux signatures : CADANS et sa contrepartie.

**Le document signé est figé, et pas seulement à l'écran.** La régénération est refusée dès
qu'une contrepartie a signé (`ContractsService.estFige`). Régénérer produirait d'autres octets
— pdf-lib horodate ses fichiers — donc une autre empreinte, et la signature conservée ne
porterait plus sur rien. Le gel porte sur un **document**, pas sur la mission : le second
contrat de la même mission continue de se régénérer tant qu'il n'est pas signé.

**La page de signatures est ajoutée au document existant**, jamais régénérée avec lui. C'est la
seule façon correcte : la signature porte sur l'empreinte du document tel qu'il a été lu.

**« Mission prête à démarrer » n'est pas « document signé ».** Les deux états sont distincts et
affichés distinctement : un document est signé quand ses deux parties l'ont signé ; la mission
n'est prête que lorsque **les deux contrats** le sont. Annoncer le démarrage à l'entreprise
pendant que l'intérimaire n'a pas signé le sien serait faux.

**Limite assumée.** Une signature simple se conteste. Passer à une signature **avancée** (art.
26) demanderait un lien univoque au signataire, un moyen sous son contrôle exclusif et la
détection de toute modification ultérieure — donc un prestataire de service de confiance. Hors
de portée d'un POC, et le document ne prétend pas le contraire.

## Décision du 22/09, conservée pour le reste

Les constantes d'identité de l'agence **ont été fournies** (valeurs fictives assumées, voir
plus haut), et le motif du recours **a été ajouté** au modèle — c'était la première mention de
l'article, et son absence se voyait.

Pour le reste, **ne rien ajouter au modèle avant la soutenance**. Les six champs manquants sur
`Mission` ne sont dans aucune ligne du chiffrage, et chacun signifie un champ de plus au
formulaire de création, sa validation en double, et une migration sur le fichier partagé.

Les deux documents porteront donc ce que les données permettent, et diront ce qu'ils ne
couvrent pas — ce qui est plus défendable qu'un contrat qui aurait l'air complet sans l'être.
