# Contrats, signature et annexes

Ce que l'API génère à la mise à `POURVUE`, comment chaque partie signe, et ce que l'entreprise
peut joindre à une mission. Les mentions obligatoires et ce qui manque encore aux documents :
[`contrat-mentions-obligatoires.md`](contrat-mentions-obligatoires.md). Les limites de la
signature simple : [`perspectives.md`](perspectives.md), « Contrats et signature ».

## Deux contrats, pas un

Le travail temporaire impose **deux** documents, qui n'ont ni les mêmes parties ni le même
contenu. Les confondre était le défaut du générateur unique d'avant le 23/09.

| Document | Article | Parties | Qui peut l'ouvrir |
| --- | --- | --- | --- |
| **Contrat de mission** | L. 1251-16 | CADANS ↔ **intérimaire** | l'intérimaire retenu, lui seul |
| **Contrat de mise à disposition** | L. 1251-43 | CADANS ↔ **entreprise utilisatrice** | l'entreprise, elle seule |

L'entreprise n'accède **jamais** au contrat de mission : elle n'y est pas partie, et il porte
l'état civil du salarié. Ce n'est pas une restriction d'affichage mais la règle de la route —
avec l'identifiant exact, elle reçoit **404** (et non 403 : un 403 confirmerait qu'un contrat
porte cet identifiant).

Le L. 1251-16 1° impose de reproduire dans le contrat de mission les clauses du contrat de
mise à disposition : les blocs « mission » et « rémunération » sont donc écrits par **le même
code**, dans `apps/api/src/contracts/contract-pdf.service.ts`. Deux copies divergeraient au
premier réglage.

## Quand ils sont générés

À la mise à `POURVUE`, en tâche de fond — ni la génération ni l'appel à n8n ne doivent
retarder ou faire échouer la réponse HTTP à l'entreprise.

Le **contrat de mise à disposition part toujours**. Le **contrat de mission attend les
informations d'embauche** de l'intérimaire (état civil, adresse, NIR, IBAN) : sans elles il
n'est pas généré, et l'intérimaire lit sur `/interimaire/contrats` ce qui manque, avec le lien
vers le formulaire. Il est généré automatiquement dès qu'il le complète — sans ce rattrapage,
un intérimaire retenu avant d'avoir rempli le formulaire n'aurait jamais son contrat.

Chaque PDF est **chiffré au repos** (AES-256-GCM, contexte lié à la mission et au type) et
stocké avec l'**empreinte SHA-256 du document en clair**. C'est elle qui identifie ce sur quoi
porte la signature : le chiffré change à chaque écriture (IV aléatoire), il ne pourrait pas
servir de référence.

## La signature

**CADANS signe à la génération.** C'est elle qui établit les documents ; faire cliquer un agent
sur un PDF produit par la machine n'ajouterait aucune garantie. Chaque document porte donc
exactement **deux** signatures : CADANS et sa contrepartie.

Chaque partie signe **son** document depuis son espace : aperçu du PDF dans la page, nom
complet tapé, case d'acceptation, confirmation. Le nom est comparé à celui du compte, mais
**aux accents, à la casse et aux espaces près** — exiger la frappe exacte d'un nom accentué
ferait du consentement une épreuve de saisie, ne rien comparer ferait du champ une case à
cocher déguisée.

Ce qui est conservé en preuve, et pourquoi chaque élément compte :

| Élément | Question à laquelle il répond |
| --- | --- |
| `userId` | qui, du point de vue du compte |
| `typedName` | ce qui a été **tapé** — c'est lui qui distingue une signature d'un clic |
| `signedAt` | quand, à la milliseconde |
| `ip`, `userAgent` | d'où |
| `documentSha256` | **sur quoi** — sans elle, la signature pourrait porter sur n'importe quelle version |

> `trust proxy` est activé en production (`main.ts`) : sans lui, derrière le répartiteur de
> l'hébergeur, l'adresse conservée serait celle du proxy. Une preuve fausse est pire qu'une
> preuve absente — d'où aussi une colonne nullable. En local le réglage reste désactivé :
> faire confiance à `X-Forwarded-For` sur un serveur joignable directement laisserait
> n'importe qui choisir l'adresse écrite dans la preuve.

Après les deux signatures, le **PDF final** est produit : le document d'origine **augmenté**
d'une page de signatures, jamais régénéré avec elle — pdf-lib horodate ses fichiers, un
document régénéré à l'identique n'aurait pas la même empreinte et la signature ne porterait
plus sur rien. Ce document final remplace le brouillon à la lecture, et son nom de fichier le
dit (`-signe.pdf`).

**Un contrat signé est figé**, et pas seulement à l'écran : la régénération est **refusée** dès
qu'une contrepartie a signé. Le gel porte sur un document, pas sur la mission — le second
contrat de la même mission continue de se régénérer tant qu'il n'est pas signé.

Enfin, **« mission prête à démarrer » n'est pas « document signé »** : un document est signé
quand ses deux parties l'ont signé, la mission n'est prête que lorsque **les deux contrats** le
sont. Annoncer le démarrage à l'entreprise pendant que l'intérimaire n'a rien signé serait faux.

## Ce que vaut la signature

**Signature électronique simple** au sens du règlement eIDAS (UE n° 910/2014, art. 3.10). Elle
ne repose sur aucun certificat qualifié, donc **la présomption de fiabilité de l'article 26 ne
s'applique pas**. Le document le dit lui-même sur sa page de signatures : laisser croire
l'inverse serait la seule faute grave possible ici. Ce qu'il faudrait pour passer à une
signature avancée est dans `docs/perspectives.md`.

## Les annexes

L'entreprise joint des **PDF** à une mission — plan d'accès, consignes de sécurité du site,
fiche de poste détaillée : ce que le contrat ne porte pas et que l'intérimaire doit avoir avant
d'arriver.

- **5 Mo maximum**, PDF uniquement, type détecté sur les **octets** du fichier et jamais sur
  celui annoncé par le navigateur, qui est falsifiable.
- **Chiffrées au repos**, comme les justificatifs d'habilitation : un plan de site nomme des
  zones, des horaires et parfois des personnes.
- **Visibles de l'entreprise et de l'intérimaire retenu.** Pas des candidats : tant qu'une
  personne n'est pas retenue, les consignes d'un site où elle n'ira peut-être jamais ne la
  concernent pas.
- **Indépendantes des contrats** : un intérimaire retenu dont le contrat de mission attend
  encore ses informations d'embauche n'a aucun contrat à l'écran, et doit pourtant recevoir le
  plan d'accès. C'est `GET /workers/me/annexes` qui les sert.
- **Retirables par l'entreprise tant qu'aucun contrat de la mission n'est signé**, avec une
  confirmation dans la page. Passé ce point : **409**. Une annexe n'est pas un brouillon — les
  consignes font partie de ce sur quoi l'intérimaire s'est engagé en signant, les retirer
  changerait le dossier sans laisser de trace. L'intérimaire, lui, ne supprime jamais : les
  annexes ne sont pas à lui, il les reçoit.

## Les routes

| Route | Qui | Ce qu'elle fait |
| --- | --- | --- |
| `GET /contrats` | intérimaire, entreprise | ses propres contrats — le document dépend de qui on est, pas de l'URL |
| `GET /contrats/:id/document` | la partie destinataire | PDF déchiffré à la volée, `no-store`, `nosniff`, `inline` |
| `POST /contrats/:id/signer` | la partie destinataire | nom complet + case d'acceptation ; 409 si déjà signé |
| `POST /missions/:id/annexes` | entreprise propriétaire | dépôt d'un PDF (`multipart/form-data`) |
| `GET /missions/:id/annexes` | entreprise ou intérimaire retenu | liste |
| `DELETE /annexes/:id` | entreprise propriétaire | 409 si un contrat de la mission est signé |
| `GET /annexes/:id/document` | entreprise ou intérimaire retenu | PDF déchiffré à la volée |
| `GET /workers/me/annexes` | intérimaire | toutes les annexes de ses missions retenues |

Les identités d'agence (dénomination, SIRET, prévoyance, garantie financière, signataire)
vivent à **un seul endroit** : `apps/api/src/contracts/cadans-identity.ts`. Elles sont
**fictives et signalées comme telles**, et chaque page de chaque document porte la mention
« Document généré dans le cadre d'un projet pédagogique ».
