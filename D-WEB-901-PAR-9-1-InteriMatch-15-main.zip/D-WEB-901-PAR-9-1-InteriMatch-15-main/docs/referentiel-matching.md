# Référentiel métier et matching

Comment les données France Travail entrent dans le produit, et comment le matching s'en sert.
Conçu le 18/09/2026 sur les données réelles (réponses des API lues, volumes mesurés),
implémenté depuis : le référentiel est importé par `npm run import:rome`, le schéma est dans
`apps/api/prisma/schema.prisma`, le matching dans `apps/api/src/matching`.

## Le problème qu'il résout

Si une entreprise saisit son intitulé de poste en texte libre et un intérimaire ses
compétences de même, le matching compare des chaînes de caractères. « Cariste », « CARISTE »,
« Cariste (H/F) » et « Cariste/préparateur » deviennent quatre métiers différents, et le
score ne veut plus rien dire.

La parade est un **vocabulaire contrôlé** : entreprises et intérimaires choisissent dans une
même liste, construite une fois à partir des données publiques de France Travail. C'est ce
qui transforme le matching en comparaison d'identifiants plutôt que de texte — et c'est aussi
la réponse à l'exigence du sujet, qui demande que les données France Travail alimentent une
fonctionnalité visible plutôt qu'un affichage brut.

## La source et son périmètre

Trois codes ROME, choisis pour couvrir l'intérim d'entrepôt et rien d'autre :

| Code | Libellé France Travail | Métiers visés |
| --- | --- | --- |
| **N1101** | Conduite d'engins de déplacement des charges | Cariste |
| **N1103** | Magasinage et préparation de commandes | Préparateur de commandes, magasinier |
| **N1105** | Manutention manuelle de charges | Manutentionnaire |

Le périmètre est une **liste fermée, écrite dans la configuration de la CLI d'import**. En
ajouter un plus tard ne coûte qu'une ligne. `N1303` (intervention technique d'exploitation
logistique) a été **écarté** : métier de technicien d'exploitation orienté transport, or le
transport routier est hors périmètre.

Les données viennent des **API ROME 4.0** de France Travail (accès libre, licence Etalab), pas
des offres d'emploi : la taxonomie y est déjà curée, avec des codes stables. Ce que la
reconnaissance du 18/09 a mesuré :

| | N1101 | N1103 | N1105 | Total |
| --- | --- | --- | --- | --- |
| Appellations (postes) | 18 | 3 | 18 | **39** |
| Compétences mobilisées | 70 | 63 | 44 | 139 distinctes |
| Compétences principales — liste **séparée**, non incluse dans la précédente | 14 | 13 | 14 | 38 distinctes, **164 au total** |
| CACES dans un champ structuré | non | non | non | — |

**Le référentiel entier tient en trois appels d'API.** Il n'y a ni pagination, ni reprise
sur interruption, ni nettoyage à prévoir : les appellations arrivent dédoublonnées, chacune
avec son code et une classification `PRINCIPALE` / `SYNONYME`. La ligne « nettoyage /
reformatage » du chiffrage se réduit à la curation ci-dessous.

**Curation : le code ROME ne garantit pas « entrepôt uniquement ».** N1101 contient
*Conducteur de nacelle* et *Conducteur de chariot élévateur de l'armée* ; N1105 contient
*Bagagiste manutentionnaire* et *Manutentionnaire caleur sur chantier de ferroutage*. La
liste des appellations **exposées** est donc fermée elle aussi, et vit dans le fichier de
seed, pas dans le code :

| Code | Exposées | Écartées (hors entrepôt) |
| --- | --- | --- |
| N1101 | Cariste · Cariste d'entrepôt · Cariste en préparation logistique · Cariste manutentionnaire · Cariste réceptionnaire · Cariste chargeur-déchargeur · Cariste pointeur · Cariste agent de magasinage · Agent de quai cariste · Conducteur d'engins de manutention (2 libellés) | nacelle, armée, livraison ferroviaire, bobinier, tractoriste, secteur industrie |
| N1103 | les trois appellations | — |
| N1105 | Manutentionnaire · charges lourdes · déchargeur · chargeur · chargeur-déchargeur · expéditeur · réceptionnaire-pointeur · réceptionnaire-vérificateur · agent de quai manutentionnaire · agent de quai réceptionnaire · employé logistique de réception · manœuvre | messagerie, porteur en transport, ferroutage, produits carnés, bagagiste, transport logistique |

## La chaîne

```mermaid
graph LR
  ROME["Code ROME<br/>N1101 · N1103 · N1105"] --> POSTE["Poste<br/>appellation exposée"]
  ROME --> COMP["Compétence<br/>38 principales"]
  POSTE -. suggère .-> HAB["Habilitation<br/>CACES, électrique"]
  MISSION["Mission<br/>entreprise"] -- choisit --> POSTE
  MISSION == exige ==> HAB
  PROFIL["Profil intérimaire"] -- déclare --> COMP
  PROFIL -- téléverse --> HAB
```

Deux choses que les données imposent, contre l'intuition de départ :

- **Les compétences sont rattachées au code ROME, pas à chaque poste.** Les 18 appellations
  de N1101 partagent les mêmes 70 compétences ; chacune n'a en propre que 2 à 9
  « compétences clés » avec une fréquence. Le lien est donc `Rome ↔ Compétence`, et un
  poste ne porte que son code ROME.
- **L'habilitation exigée appartient à la mission, pas au poste.** La fiche N1103 le dit
  textuellement : *« CACES R318, R490 ou R489 1B à 6 selon l'offre d'emploi »*. Le même
  poste « Cariste » demande le R489-3 dans un entrepôt et le R489-5 dans un autre. Le
  référentiel fournit une **suggestion par défaut** par poste ; **l'entreprise fixe
  l'exigence réelle sur chaque mission**, pré-remplie par la suggestion ; le filtrage
  bloquant lit la mission.

Parmi les 164 compétences, cinq sont des *savoir-être* (« faire preuve de rigueur »),
inexploitables pour un matching. L'intérimaire ne se voit proposer que les **38 principales**
(types `COMPETENCE-DETAILLEE`, `SAVOIR`, `MACRO-SAVOIR-FAIRE`).

## Ce qui est importé, ce qui est saisi à la main

| Donnée | Origine |
| --- | --- |
| Codes ROME et leurs libellés | Importé |
| Appellations rattachées à un ROME | Importé, puis **curé** (liste fermée ci-dessus) |
| Compétences rattachées à un ROME, avec le drapeau « principale » | Importé |
| **Suggestion poste → habilitation** | **Saisi à la main** |
| **Habilitation exigée par une mission** | **Choisie par l'entreprise**, pré-remplie par la suggestion |

La suggestion mérite d'être assumée en soutenance plutôt que découverte : **le mot CACES
n'apparaît dans les fiches ROME que dans un paragraphe en texte libre** (`accesEmploi`), le
champ `emploiReglemente` vaut `false` sur les 39 appellations, et aucune clé de certification
n'existe. Cette table de correspondance est donc de l'expertise métier encodée par l'équipe,
là où la donnée publique s'arrête. Une vingtaine de lignes.

## Ré-import : deux règles qui évitent de casser les profils

La CLI d'import est une commande d'équipe, pas une fonctionnalité du site. Elle sera relancée
— pour rafraîchir, ou pour élargir le périmètre. Or un intérimaire a pu cocher des
compétences entre-temps.

1. **La clé d'une entrée est son code France Travail**, jamais un identifiant généré par nous.
   Un ré-import qui redistribuerait des identifiants rendrait orphelins tous les choix déjà
   enregistrés.
2. **L'import met à jour ou insère ; il n'efface jamais.** Une entrée disparue de la source
   passe à `active = false` : elle n'est plus proposée, mais la ligne du profil ou de la
   mission qui la référence est conservée et continue de se lire.

Sans ces deux règles, le deuxième import vide silencieusement les profils. Ce qui n'est **pas**
fait : le message prévu sur le profil pour signaler une compétence retirée. L'intérimaire ne
voit pas la différence ; c'est une limite, pas un risque, puisque rien n'est effacé.

## Le matching

`GET /matches` calcule, pour l'intérimaire connecté, la liste des missions **ouvertes** qu'il
peut tenir, triées par score. Le même calcul de score sert à l'entreprise sur
`/entreprise/candidatures` : elle voit le chiffre que l'intérimaire a vu.

**Étape 1 — filtrage bloquant.** Deux tests, dans cet ordre, et une mission qui échoue à l'un
ne remonte jamais, quel que soit son score :

1. le **créneau** de la mission figure parmi ceux que l'intérimaire accepte (matin,
   après-midi, nuit, journée) ; un profil sans créneau déclaré est considéré ouvert à tous ;
2. l'intérimaire possède **toutes les habilitations exigées par la mission**, et aucune n'est
   **expirée** (`Certification.expiresAt`, valide jusqu'à la fin du jour d'expiration, heure
   de Paris).

Il n'y a **pas de fenêtre de dates** : un intérimaire qui consulte la plateforme est considéré
disponible (décision produit du 21/09/2026). Les colonnes `availableFrom` et `availableUntil`
existent dans le schéma mais ne sont ni saisies ni lues.

Les missions écartées par le second test sont **comptées, pas cachées** : la réponse porte le
nombre de missions masquées et les habilitations qui les débloqueraient, ce qui alimente
l'incitation « Ajoutez vos CACES » sur `/interimaire/matches`. Une mission écartée par le
créneau n'est pas comptée, l'ordre des tests le garantit.

**Étape 2 — scoring sur ce qui reste**, sur 100 :

| Composante | Poids | Calcul |
| --- | --- | --- |
| Compétences | 60 | part des compétences requises par la mission que l'intérimaire a déclarées ; une mission sans compétence requise vaut 100 % sur cette composante |
| Zone | 40 | même département que la mission = 100 %, département **voisin en Île-de-France** = 50 %, sinon 0 % |

La table de voisinage ne couvre que les huit départements franciliens, volontairement : hors
Île-de-France, la composante zone vaut 0 sauf même département. Les colonnes `latitude` et
`longitude` existent, vides, pour un futur calcul en kilomètres. Limites et extension
nationale : [`perspectives.md`](perspectives.md), « Matching ».

**La même règle dans les deux sens.** Le matching *pousse* (classement, notification n8n) :
un intérimaire sans l'habilitation exigée n'y apparaît jamais. Mais l'intérimaire *navigue*
aussi, sur les pages publiques de missions rendues côté serveur pour le SEO, et peut tomber
sur une mission qu'il ne couvre pas. La page reste servie et le bouton « Postuler » s'affiche ;
c'est l'**API qui refuse la candidature** (`409`) avec le message qui dit ce qui manque, et le
bouton l'affiche. La vraie protection est là, pas dans la disparition de la page.

**Ce que CADANS vérifie.** Une habilitation « présente » est une déclaration avec une date
d'expiration, et un justificatif déposé par l'intérimaire, chiffré, qu'un **agent CADANS**
examine ([`espace-agent.md`](espace-agent.md)). Le statut de cette vérification **n'entre pas
dans le matching** : en faire un filtre priverait l'intérimaire de missions tant qu'un agent
n'a pas cliqué. Il est affiché à l'entreprise (« vérifié » ou « déclaré ») sur chaque
candidature.

**Compétences déclarées contre habilitations vérifiées.** Les compétences sont déclaratives :
elles **scorent**. Les habilitations sont justifiées par un document et une date d'expiration :
elles **filtrent**. Une compétence ne doit jamais pouvoir tenir lieu d'habilitation, sans quoi
il suffirait de cocher « conduite de chariot élévateur » pour ressortir sur une mission
exigeant le R489-3.

**Journal.** Chaque calcul est écrit dans la collection MongoDB `matching_logs` (intérimaire,
missions retenues, scores, date). Il sert à la notification n8n : le service compare le calcul
courant au dernier journalisé et n'appelle le webhook `match-notification` que pour les
matchs **nouveaux**, jamais au tout premier calcul. C'est la seule donnée en Mongo à ce jour.

## Tranché, et ce qui reste ouvert

Ces points ne touchent aucune table : ce sont des constantes du code de matching,
modifiables jusqu'au dernier jour.

| Point | État |
| --- | --- |
| **Poids** | Tranché : **60 % de recouvrement de compétences, 40 % de zone**. Constantes `POIDS_COMPETENCES` et `POIDS_ZONE`. La ventilation est exposée dans `MatchView.detail` et affichée sous le pourcentage, sur `/interimaire/matches`. |
| **Déclencheur** | Tranché : la notification part **quand un nouveau match apparaît** pour un intérimaire, indépendamment des candidatures. Le service compare le calcul courant au dernier calcul journalisé en Mongo, et **ne notifie rien au tout premier** — sans quoi une inscription déclencherait une rafale. |
| Seuil | **Ouvert.** Aucun score plancher : toutes les missions non écartées par le filtrage bloquant remontent, triées par score décroissant. À arbitrer si le volume d'offres augmente. |

## Préremplir une mission depuis une offre France Travail

Seconde utilisation des données France Travail dans l'application, après le référentiel ROME.
Sur `/entreprise/missions/nouvelle`, deux entrées : **Formulaire vierge** (par défaut,
inchangé) et **Partir d'une offre France Travail**, où l'entreprise colle l'adresse d'une
offre ou son identifiant.

**Ce qu'une offre alimente réellement**, mesuré le 23/09/2026 sur 15 offres d'intérim des
trois codes ROME du périmètre :

| Champ | Source | Fiabilité |
| --- | --- | --- |
| `posteCode` | `romeCode` + `appellationlibelle` | L'offre ne donne **pas** le code appellation : correspondance par libellé parmi les postes exposés du ROME, sinon repli sur l'appellation PRINCIPALE |
| `postalCode` | `lieuTravail.codePostal` | Bon |
| `siteLabel` | `lieuTravail.libelle` (« 57 - Sarrebourg ») | Une localité, pas un site. **Jamais `entreprise.nom`** : c'est l'agence recruteuse, pas le client |
| `hourlyRate` | `salaire.libelle` + `dureeTravailLibelle` | Horaire repris tel quel ; **mensuel et annuel convertis** sur la durée hebdomadaire de l'offre, et signalés comme estimés (voir ci-dessous) |
| `shift` | `dureeTravailLibelle` | « Travail en journée » / « de nuit » seulement. Un 2x8 ne correspond à aucun de nos quatre créneaux |
| `description` | `description` | Reprise après **caviardage** (voir ci-dessous) |
| `startDate`, `endDate`, `motifRecours`, habilitations, compétences | — | **Jamais préremplis.** L'offre donne une durée (« Intérim - 3 Mois »), pas deux dates ; le motif est une qualification juridique absente de l'offre ; les CACES n'y sont dans aucun champ structuré |

### Rémunération : convertie, jamais maquillée

`salaire.libelle` est un texte libre. **Formes relevées le 23/09/2026 sur 450 offres**
d'intérim des trois codes ROME :

| Forme | Offres | Traitement |
| --- | --- | --- |
| `Horaire de N Euros` | 220 | Repris tel quel |
| `Horaire de N Euros à N Euros` | 141 | **Borne basse**, signalée |
| `Annuel de N Euros à N Euros` | 33 | Converti : `N ÷ 12 ÷ 151,67` |
| (aucun salaire) | 24 | Champ vide, aucune mention |
| `Mensuel de N Euros [à N Euros]` | 26 | Converti : `N ÷ 151,67` |
| l'une des précédentes + complément libre (« - 13ème mois + prime de panier ») | 6 | Salaire de base converti, complément visible dans le libellé brut affiché |

Une offre sur huit exprime donc son salaire au mois ou à l'année. Les laisser de côté vidait
le champ le plus regardé du formulaire.

**La base de conversion vient de l'offre elle-même** : `base mensuelle = durée hebdomadaire ×
52 ÷ 12`, lue dans `dureeTravailLibelle`. Convertir une mission à 38 h sur 35 h surestimerait
le taux horaire de 8 % — sur 2 206 € mensuels, 14,55 € au lieu de 13,40 €, et c'est ce taux-là
qui figure au contrat de mission.

**Formes de `dureeTravailLibelle`**, première ligne, mêmes 450 offres :

| Forme | Offres | Remarque |
| --- | --- | --- |
| `35H/semaine` | 434 | dont 405 réellement à 35 h |
| `Temps partiel - 24H/semaine` | 13 | de 3 h à 28 h |
| `38H45/semaine` | 3 | heures **et** minutes → 38,75 h |

Aucune des 450 offres n'était sans durée. Le troisième cas est le piège : lu naïvement,
« 38H45 » donne 38 h (acceptable) ou 3 845 h (catastrophique).

**Repli sur 35 h** quand la durée est illisible ou hors de la plage plausible (20 à 48 h).
En dessous, le salaire mensuel affiché d'un temps très partiel — « Temps partiel - 3H/semaine »
existe dans l'échantillon — est rarement cohérent ; au-dessus, la durée maximale légale est
dépassée. Dans les deux cas, mieux vaut une base conventionnelle qu'un taux aberrant.

La base retenue **reste une estimation** : elle suppose que le salaire annoncé correspond à
la durée annoncée. Le taux converti n'est donc jamais présenté comme une donnée de l'offre :

- le champ porte une mention **lisible sans interaction** (pas une infobulle) qui cite le
  libellé de l'offre, le montant d'origine, **la base réellement utilisée et d'où elle vient**
  (« base 38 h/semaine, celle de l'offre » / « base 35 h/semaine, l'offre n'en précisant
  aucune ») et le mot « à vérifier » ;
- le bilan sort la rémunération de « repris de l'offre » pour la placer en **« à vérifier »** —
  la laisser dans la première liste ferait dire à l'annonce un taux horaire qu'elle n'énonce
  nulle part ;
- une **fourchette** donne toujours sa borne basse, et le dit. Proposer le haut gonflerait une
  rémunération contractuelle ;
- un **format non reconnu** (ou un montant qui dépasserait `Decimal(5,2)`) laisse le champ
  vide, avec le libellé brut affiché à titre indicatif.

Contrôle de vraisemblance : `Annuel de 22405 €` à 35 h donne 12,31 €/h, soit le SMIC — la
base de conversion n'est pas absurde.

L'écran affiche donc, en tête du formulaire, **ce qui a été repris et ce qui reste à saisir**.
Sans ce bilan, un formulaire à moitié rempli se relit mal et la mission partirait sans les
deux mentions que l'article L. 1251-43 impose au contrat.

**Provenance, et rien de plus.** Le bandeau dit « Prérempli depuis l'offre France Travail
n° X », nomme l'offre, renvoie à la fiche d'origine et précise que CADANS n'en est pas
l'auteur. Seule la référence de l'offre est stockée (`Mission.sourceOffreId`) : aucun
employeur d'origine, aucune coordonnée. Les blocs `contact`, `agence` et `entreprise` de la
réponse **ne sont pas déclarés dans le type** — ils ne peuvent donc pas être lus par
inadvertance. La description, elle, est caviardée avant d'arriver au formulaire (adresses
électroniques, numéros de téléphone, URL), et le champ porte l'étiquette « texte repris de
l'offre France Travail, à relire et adapter ».

> **Piège vérifié, à ne pas redécouvrir : une offre inconnue ou expirée répond `204 No
> Content`, pas `404`.** `response.ok` vaut `true` sur un 204 : un client naïf préremplit
> alors un formulaire vide sans rien signaler. Les autres codes relevés le 23/09/2026 :
> `400` pour un identifiant mal formé (message explicite), `200` pour une offre en ligne.
> L'identifiant fait **sept caractères alphanumériques** sur les 150 offres échantillonnées.

**Aucun échec ne bloque.** Identifiant non reconnu (400), offre expirée (404), quota atteint
(429), API indisponible (503) : chacun rend un message qui dit quoi faire, et l'écran revient
au formulaire vierge — déjà affiché en dessous — en conservant la saisie pour permettre de
corriger une faute de frappe. Sans les identifiants France Travail, l'entrée est **masquée**,
pas désactivée (`GET /missions/prefill/disponibilite`).
