# Charte graphique CADANS

Refonte du 21/09/2026. **Identité monochrome anthracite** : plus aucun accent coloré.

Ce document décrit l'intention. La source d'autorité reste
[`apps/web/src/app/globals.css`](../apps/web/src/app/globals.css) : tous les jetons y sont
définis, et **aucune couleur, aucun rayon, aucune taille de texte n'est écrit en dur
ailleurs**. Si les deux divergent, c'est le CSS qui a raison et ce fichier qui est en retard.

Tous les ratios cités ici ont été **calculés** avec la formule de luminance relative des
WCAG 2, pas estimés à l'œil.

## Identité visuelle

Anthracite sur blanc, et rien d'autre. La hiérarchie est portée par la **typographie** (une
serif de titrage face à une sans-serif d'interface), par les **aplats** (encre pleine pour
l'action principale, gris très clairs pour les surfaces en creux) et par l'**espace**, jamais
par une couleur d'accent.

Une seule couleur échappe au monochrome : le rouge `--c-danger`, réservé à ce qui bloque —
habilitation CACES manquante, erreur de formulaire.

## Palette

Dix jetons, pas un de plus. Colonne « contraste » : sur le fond blanc `--c-bg`.

| Jeton | Hex | Usage | Contraste sur blanc |
| --- | --- | --- | --- |
| `--c-ink` | `#14181D` | texte, titres, CTA principal, logo | **17,82:1** |
| `--c-ink-hover` | `#2C333C` | survol du CTA principal | **12,76:1** |
| `--c-muted` | `#6F6F6F` | paragraphes, libellés secondaires | **5,02:1** |
| `--c-subtle` | `#8A929C` | décoratif seul, **jamais de texte** | 3,15:1 |
| `--c-border-strong` | `#929292` | bordure d'un contrôle de saisie, **jamais de texte** | 3,11:1 |
| `--c-soft` | `#E4E7EB` | bouton secondaire, fond de badge | — |
| `--c-divider` | `#E9E9E9` | filet, séparateur | — |
| `--c-surface` | `#F4F5F7` | surface en creux | — |
| `--c-bg` | `#FFFFFF` | fond | — |
| `--c-danger` | `#B42318` | CACES manquant, erreur de formulaire | **6,57:1** |

Quelques alias de commodité existent dans le CSS (`--c-focus`, `--c-line`, `--c-hint`,
`--c-blocked`) : ce sont des **noms d'usage renvoyant à un jeton existant**, jamais une
couleur de plus. Un écran utilise le nom qui décrit son intention, et changer une couleur ne
se fait qu'à un seul endroit.

### Le piège à connaître

**`--c-muted` sur `--c-soft` tombe à 4,05:1**, sous le seuil de 4,5:1. C'est la combinaison
qui vient naturellement sous les doigts — un texte secondaire dans un badge — et c'est la
seule qui échoue.

| Texte | sur `--c-bg` | sur `--c-surface` | sur `--c-soft` |
| --- | --- | --- | --- |
| `--c-ink` | 17,82:1 | 16,34:1 | 14,37:1 |
| `--c-muted` | 5,02:1 | 4,61:1 | **4,05:1 ❌** |
| `--c-danger` | 6,57:1 | 6,03:1 | — |

**Règle : sur un fond `soft`, le texte est en `--c-ink`.** `--c-muted` ne tient que sur blanc
et sur `--c-surface`, où il garde 4,61:1.

### Blanc sur encre

Le bouton principal, le statut « Ouverte », la barre latérale du tableau de bord et le
bandeau du contrat PDF posent du blanc sur l'encre : **17,82:1**, et **12,76:1** au survol sur
`--c-ink-hover`.

## Statuts de mission

Le libellé est **toujours écrit en toutes lettres**. L'information n'est jamais portée par la
seule couleur ni par la seule pastille (RGAA 4.1), et ça vaut en particulier pour le filtrage
bloquant sur les habilitations.

| Statut | Fond | Texte | Contraste |
| --- | --- | --- | --- |
| Ouverte | `--c-ink` | blanc | 17,82:1 |
| Pourvue | `--c-soft` | `--c-ink` | 14,37:1 |
| Terminée | `--c-surface` | `--c-muted` | 4,61:1 |

« Terminée » est le seul endroit où `--c-muted` sert de texte sur autre chose que du blanc.
C'est volontaire et c'est la seule combinaison qui passe : une mission terminée est une
information atténuée, et `surface` est le seul fond qui laisse à `muted` sa marge.

## Typographie

Trois familles, **auto-hébergées** dans
[`apps/web/src/fonts`](../apps/web/src/fonts) via `next/font/local` :
**65 Ko à elles trois**, sous-ensemble latin uniquement (il couvre tout le français, œ et Œ
compris, ainsi que l'euro), licences jointes à côté des fichiers.

**Aucune requête vers Google**, ni au chargement ni au build. Deux raisons, toutes deux
défendables en soutenance : rien ne part vers un tiers quand un visiteur ouvre une page
(RGPD), et trois requêtes de moins par visite (RGESN). Accessoirement, un déploiement Render
ne peut pas échouer sur un domaine externe injoignable.

| Famille | Jeton | Rôle |
| --- | --- | --- |
| **Crimson Text** 400 | `--police-titre` | Titres |
| **DM Sans** 400/500/700 | `--police` | Texte courant, interface, liens, logotype |
| **Roboto Mono** 400 | `--police-mono` | Sur-titres, codes CACES, scores, dates |

### Échelle

| Jeton | Taille | Usage |
| --- | --- | --- |
| `--t-display` | 56 → 160 px | Titre du hero, en `clamp()` |
| `--t-h1` | 40 → 60 px | Titre de page |
| `--t-h2` | 28 → 40 px | Titre de section |
| `--t-h3` | 18 px | Titre de carte |
| `--t-corps` | 15 px / 1,4 | Texte courant |
| `--t-ui` | 14 px gras | Boutons, liens, libellés de champ |
| `--t-mono` | 12 px | Libellés en chasse fixe |

**Titres** : interlignage 0,95 (`--lh-titre`), approche −3 % (`--ls-titre`). À ces corps,
l'approche par défaut fait flotter les mots et l'interligne normal creuse des trous.

**DM Sans est un fichier variable** : une seule requête couvre 400, 500 et 700, là où trois
fichiers statiques pèseraient plus lourd à eux seuls.

**Roboto Mono aligne les chiffres en colonne**, ce qu'aucune graisse de DM Sans ne fait. C'est
la seule raison de sa présence : scores de matching, ventilations, codes CACES et dates se
comparent d'une carte à l'autre.

### Où la serif a le droit d'apparaître

Crimson Text est **réservée aux titres de page**. Dans un espace connecté, les titres de
cartes et de sections sont en DM Sans gras — une serif y ferait décoratif.

Une seule entorse, assumée : les **trois compteurs** en tête de `/entreprise/missions`. Ces
nombres sont le résumé de la page, ils tiennent le rôle d'un titre.

## Logo

**Il n'existe plus aucun fichier SVG.** Le logotype est un composant :
[`apps/web/src/components/Logo.tsx`](../apps/web/src/components/Logo.tsx).

Le symbole est un SVG **inline** en `fill="currentColor"`. Une seule source sert donc sur fond
clair comme sur fond foncé, la couleur venant du CSS environnant — plus de version claire et
de version sombre à maintenir en parallèle, et une requête réseau de moins.

Le mot « CADANS » est composé à côté, en **DM Sans Medium (500)**, approche +0,01 em,
interlignage 1.

### Règle de calage du logotype

Les deux proportions sont fixées par la charte et exprimées en **`em`**, jamais en pixels :
le rapport tient ainsi à n'importe quelle taille.

| Grandeur | Valeur | Constante |
| --- | --- | --- |
| Hauteur du symbole | **0,93 × la taille de police du mot** | `RATIO_SYMBOLE` |
| Espacement symbole ↔ mot | **0,3 × cette même taille** | `RATIO_ESPACEMENT` |

**C'est la hauteur qui pilote, la largeur suit** (`width: auto`) : le symbole est plus large
que haut, et c'est sa hauteur que la charte rapporte à la taille de police.

La propriété `taille` du composant est la taille de police du mot, **en rem** (1,25 par
défaut). Tout le reste en découle.

> **Piège vérifié, à ne pas réintroduire.** Le `viewBox` est resserré sur le tracé
> (`5.77 14.3 52.49 35.44`). Celui du fichier d'origine (`0 0 64 64`) laissait **45 % de vide
> autour**, si bien que le symbole rendu ne faisait que 0,52 em au lieu des 0,93 attendus.
> Reprendre le viewBox d'origine casserait silencieusement le calage.

### Variantes et accessibilité

- **Logotype complet** (défaut) : symbole + mot. Le SVG est `aria-hidden` — le mot « CADANS »
  est déjà lu à l'écran, l'annoncer une seconde fois serait redondant. C'est le **lien
  parent** qui porte le nom accessible : `aria-label="CADANS, retour à l'accueil"`.
- **`symboleSeul`** : barres latérales étroites, favicon. Là encore, c'est au lien parent de
  porter `aria-label="CADANS"` — sans quoi le logo n'a plus de nom du tout.

## Mise en page

| Jeton | Valeur |
| --- | --- |
| `--largeur` | 1200 px |
| `--marge` | 40 px, 16 px sous 375 px |
| `--section` | 80 px entre deux sections |

Points de rupture : **1280 / 800 / 375**. Les marges suivent, la colonne ne bouge pas.

### Rayons

`--radius-sm` 8 px · `--radius` 12 px · `--radius-lg` 16 px (cartes) · `--radius-xl` 24 px ·
`--radius-full` 999 px (boutons pilule, badges).

### Élévation

Trois niveaux, pas plus : `--ombre-1`, `--ombre-2`, `--ombre-3`. **Teintées d'anthracite et
non de noir** — une ombre grise neutre sur ces surfaces donne un gris sale.

## Composants

Des classes de `globals.css`, **aucune librairie de composants** :

`.bouton` (pilule) · `.champ__saisie` (Input et Select) · `.carte` (filet `divider`,
rayon 16 px) · `.badge` · `.tableau` · `.toast` · `.etat-vide`.

**`.bouton--principal`** : fond `ink`, texte blanc ; survol `ink-hover`.
**`.bouton--secondaire`** : fond `soft`, texte `ink` ; survol fond `ink`, texte blanc.

Le libellé d'un bouton n'est **jamais souligné** : la forme dit déjà qu'il est cliquable. Les
liens, eux, le sont toujours — le soulignement porte l'information de lien, jamais la seule
couleur (RGAA 10.6), d'autant qu'ici le lien est de la même encre que le texte.

## Mode contraste renforcé

`@media (prefers-contrast: more)` — la **préférence déclarée dans le système
d'exploitation**, pas un bouton dans la page.

**Ce n'est pas un rattrapage de conformité.** Le rendu par défaut passe déjà tous les seuils
du RGAA 4.1. Présenter ce mode comme « la version accessible » laisserait entendre que
l'autre ne l'est pas — ce serait faux, et vérifiable en trente secondes avec les tableaux
ci-dessus. C'est un **confort** pour qui a besoin de plus que le minimum.

Il redéfinit **quatre jetons, et rien d'autre** :

| Jeton | Par défaut | En contraste renforcé | Gain |
| --- | --- | --- | --- |
| `--c-muted` | `#6F6F6F` | `--c-ink` | 5,02 → 17,82:1 |
| `--c-divider` | `#E9E9E9` | `#767676` | 1,21 → **4,54:1** |
| `--c-border-strong` | `#929292` | `--c-ink` | 3,11 → 17,82:1 |
| `--c-subtle` | `#8A929C` | `--c-ink` | 3,15 → 17,82:1 |

**Aucune règle CSS n'est dupliquée** : seules les valeurs des jetons changent. Les deux modes
ne peuvent donc pas diverger — c'est ce qui rend la variante quasi gratuite à maintenir.

`--c-divider` monte bien au-delà des 3:1 exigés : un filet à peine visible est exactement ce
que ce mode doit corriger. `--c-subtle` ne porte aucune information aujourd'hui ; il est
relevé au cas où il viendrait à en porter, plutôt que de rester muet ce jour-là.

### Pourquoi la préférence système plutôt qu'un bouton

- Aucun réglage à trouver dans l'interface, sur un site qu'on découvre.
- Aucun choix à mémoriser, donc **aucun stockage ni cookie**.
- Le réglage suit l'utilisateur d'un site à l'autre : il l'a fait une fois, pour tout.

Un sélecteur dans la page reste possible plus tard ; il viendrait **en plus** de la préférence
système, jamais à la place.

## Contraintes non négociables

### RGAA 4.1

- **≥ 4,5:1** pour le texte, **≥ 3:1** pour les composants d'interface.
- **Focus visible** : contour de 2 px en `--c-focus` (l'encre), décalé de 2 px. Il ne doit
  jamais être supprimé.
- Navigation clavier complète, un `label` par champ, **un seul `h1` par page**, `alt` sur les
  images.
- **Jamais d'information portée par la seule couleur.** Chaque statut de mission est écrit en
  toutes lettres, chaque bandeau porte son message en texte.

### Les filets décoratifs sont volontairement sous 3:1

`--c-divider` autour des cartes tient **1,21:1**, et le séparateur de la barre latérale
(blanc à 15 % sur l'encre, soit `#373B3F`) **1,57:1**.

**Ce n'est pas un oubli, et l'argument est à tenir tel quel en soutenance.** Le critère
1.4.11 des WCAG vise « l'information visuelle nécessaire pour identifier un composant ou un
état ». Le contour d'une carte n'identifie rien : c'est son contenu qui le fait. Les bordures
qui, elles, portent un composant — champs de saisie, menus déroulants — utilisent
`--c-border-strong` et sont au-dessus du seuil, vérifiées. Les assombrir toutes donnerait un
rendu de maquette filaire.

### RGESN

- `next/image` pour toute image bitmap, format WebP, chargement différé.
- Icônes importées à l'unité, jamais une librairie entière.
- Polices auto-hébergées, un seul sous-ensemble (voir « Typographie »).
- **À ce jour le projet n'a aucune image bitmap** : le logotype est du code, les icônes sont
  des SVG inline.

## Pourquoi pas de pastilles de couleur dans ce document

GitHub n'affiche un aperçu des codes hexadécimaux que dans les issues, les pull requests et
les discussions, pas dans les fichiers Markdown du dépôt. Des images générées par un service
externe (du type shields.io) le permettraient, mais au prix d'appels réseau supplémentaires,
contraires aux pratiques d'écoconception défendues par ailleurs. Le tableau reste en texte.
