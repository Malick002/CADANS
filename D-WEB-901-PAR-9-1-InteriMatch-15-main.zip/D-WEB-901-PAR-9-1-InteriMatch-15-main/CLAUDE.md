# CADANS

**Agence d'intérim en ligne**, spécialisée en **logistique d'entrepôt**. CADANS est une
**entreprise de travail temporaire** : elle est **l'employeur de l'intérimaire**, le met à
disposition d'entreprises clientes, et signe les deux contrats que la loi impose — contrat de
mission avec l'intérimaire, contrat de mise à disposition avec l'entreprise utilisatrice.

**Ce n'est pas une place de marché ni un simple intermédiaire.** La nuance change tout : elle
fait de CADANS une partie aux contrats, le responsable du traitement des données, et le
destinataire des obligations du Code du travail sur le travail temporaire.

Projet Epitech D-WEB-901, POC de 11 jours, soutenance le **vendredi 25 septembre 2026**.

Le contexte complet est dans `docs/cadrage/` : étude de marché, périmètre, chiffrage, planning.
**Ne recopie pas ce contenu ici**, lis-le sur place quand tu en as besoin.

## Avancement au 23/09/2026, soir (J9 sur 11)

Repère daté, à recouper avec le Miro et `chiffrage_CADANS.xlsx`, qui font foi.

- **Sur `main`** : le socle complet (bases, comptes, sessions, chiffrement, réinitialisation
  du mot de passe, référentiel ROME) ; le profil intérimaire (habilitations avec justificatif,
  compétences, créneaux, informations d'embauche avec NIR et IBAN chiffrés) ; les missions
  (CRUD, statuts, pages publiques, préremplissage depuis une offre France Travail) ; le
  matching (filtrage CACES bloquant, score ventilé, journal en Mongo) ; les candidatures ;
  l'espace agent `ADMIN` complet (justificatifs, registre des décisions, tableau de bord,
  annuaire, missions, contrats) ; les deux contrats PDF chiffrés et leur signature avec
  preuve ; les annexes de mission ; les trois workflows n8n ; le design system ; le SEO des
  pages publiques ; le lint d'accessibilité dans `verify` ; le coverage fusionné unitaires +
  fonctionnels, **seuil 95 % des lignes tenu**.
- **Pas fait, et assumé** : le déploiement (voir « Déploiement ») ; la **pièce d'identité n'a
  pas d'écran**, seule la route API existe ; la page tendances marché, sortie du périmètre le
  22/09 : l'exigence « données France Travail visibles » est couverte par le préremplissage de
  mission, à dire tel quel au jury ; le cache Mongo des offres France Travail et la recherche
  full-text (Mongo ne porte que `matching_logs`) ; un audit RGAA écrit page par page ; aucun
  test fonctionnel sur les huit routes d'annuaire, missions et contrats de l'espace agent.
- **À faire avant le J10** : saisir la colonne « Réel (j) » de `chiffrage_CADANS.xlsx`, vide
  à ce jour, c'est un livrable.
- `npm run verify` passe sur `main`. Les chiffres exacts (tests, coverage) sortent des
  commandes, pas de ce fichier.

## Stack imposée

Next.js + TypeScript · Nest.js + TypeScript · PostgreSQL + Prisma · MongoDB · Jest + Supertest ·
Commander.js · n8n · Docker · Render (site **et** API) + Neon + MongoDB Atlas · GitHub Actions.

**Vercel a été abandonné le 18/09/2026** (décision d'équipe) : son offre gratuite refuse les
dépôts privés appartenant à une organisation GitHub, ce qui est le cas de ce dépôt. Le site
Next.js est donc hébergé sur Render, en service web Node, à côté de l'API.

Pas de changement de stack sans en discuter : chaque choix est justifié devant le jury.

## Contraintes du sujet à ne jamais enfreindre

- **TypeScript partout**, frontend et backend. Mode strict.
- **Deux bases, deux usages.** PostgreSQL porte le relationnel et le contractuel (comptes,
  profils, habilitations, missions, contrats). MongoDB porte le non transactionnel : logs de
  matching, cache des offres France Travail, recherche full-text. Ne déplace rien de l'un à
  l'autre sans demander.
- **L'authentification classique s'implémente à la main** (hash, sessions ou tokens). En
  revanche **ne redéveloppe jamais OAuth** : librairie ou service existant si on en propose une.
- **Chiffrement des données sensibles** (habilitations, pièces d'identité) au repos et en transit.
- **Les données France Travail doivent alimenter une fonctionnalité visible** (fiche de poste
  enrichie, tendances marché, critère de matching). Un affichage brut de l'API ne compte pas.
- **Tests unitaires ET fonctionnels** sur les parcours critiques : inscription, création de
  mission, matching. Le coverage doit être généré et livré.
- **Pages publiques rendues côté serveur.** Un seul `h1` par page, meta title et description,
  URLs lisibles, sitemap. Si une page d'annonce passe en rendu client, l'argument SEO tombe.
- **Accessibilité RGAA 4.1** de base : contrastes, textes alternatifs, navigation clavier,
  structure sémantique. **RGESN** : au moins deux pratiques appliquées et documentées.
- **Notifications : email uniquement.** Pas de SMS, pas de LinkedIn. Le webhook Discord
  cité au cadrage n'était qu'un exemple de canal, pas une obligation : l'équipe assume
  l'email, pour la réinitialisation de mot de passe comme pour les workflows n8n.
- **Deux expéditeurs, deux usages — ne pas les confondre.**
  - **Resend** pour les emails **transactionnels de l'API** (mot de passe oublié). Envoi par
    `apps/api/src/mail`, API HTTP appelée avec le `fetch` natif de Node, aucune dépendance
    ajoutée. Variables : `RESEND_API_KEY` et `MAIL_FROM`.
  - **Gmail SMTP, dans n8n**, pour les **automatisations** (notification de match, mission
    pourvue). L'identifiant vit **dans n8n uniquement**, jamais dans le dépôt : compte Gmail
    avec vérification en deux étapes et **mot de passe d'application**, pas le mot de passe
    du compte.
  - **Limite du mode test de Resend** : sans domaine vérifié, l'expéditeur de bac à sable
    `onboarding@resend.dev` ne délivre **qu'à l'adresse du compte Resend lui-même**. Toute
    autre destination est refusée. C'est la raison pour laquelle les automatisations passent
    par Gmail SMTP et non par Resend, et pourquoi les comptes de `seed:demo` sont en
    sous-adressage `interimcadans+…@gmail.com`.

## Design system

Les valeurs (jetons, échelle typographique, logotype, mode contraste renforcé) sont dans
`docs/charte-graphique.md` et font foi dans `apps/web/src/app/globals.css`. Ce qui suit est
ce dont l'oubli crée un bug ou une non-conformité :

- **Aucune couleur, aucun rayon, aucune taille de texte en dur** hors de `globals.css` : tout
  passe par les jetons `--c-*`, `--t-*`, `--police*`. Pas de librairie de composants : `.bouton`,
  `.champ__saisie`, `.carte`, `.badge`, `.tableau`, `.toast`, `.etat-vide`.
- **Contrastes RGAA 4.1** : ≥ 4,5:1 pour le texte, ≥ 3:1 pour les composants. `--c-subtle` et
  `--c-border-strong` ne portent **jamais de texte**. Piège mesuré : `--c-muted` sur `--c-soft`
  tombe à 4,05:1, donc sur un fond `soft` le texte est en `--c-ink`.
- **Un statut n'est jamais porté par la seule couleur** : le libellé est écrit en toutes
  lettres (Ouverte, Pourvue, Terminée, Vérifié, Refusé…).
- **Les filets décoratifs sont volontairement sous 3:1** (`--c-divider` autour des cartes) :
  le contour d'une carte n'identifie rien, c'est son contenu qui le fait. Les bordures qui
  portent un composant (champs, menus) sont au-dessus du seuil. Ne pas les assombrir, et
  tenir l'argument tel quel en soutenance.
- **Mode `prefers-contrast: more`** : préférence système, pas un bouton ; il ne redéfinit que
  quatre jetons, aucune règle n'est dupliquée. Ne pas ajouter de règle spécifique à ce mode.
- Focus visible (contour 2 px ink), navigation clavier, un `label` par champ, un seul `h1`
  par page, `alt` sur les images. **RGESN** : `next/image` pour toute image bitmap, polices
  auto-hébergées (aucune requête vers Google), icônes importées à l'unité.

## Décisions produit déjà prises

- Périmètre : entrepôt uniquement. Le transport routier et la manutention portuaire sont
  hors périmètre.
- Le matching applique un **filtrage bloquant sur les certifications obligatoires** (CACES)
  avant tout scoring. Un profil sans l'habilitation requise ne remonte jamais, quel que soit
  son score.
- **Trois workflows n8n**, et aucun ne génère de contrat — c'est l'API qui les produit et les
  chiffre. Détail, import et test : `n8n/README.md`.
  - `match-notification` — webhook appelé par `notifyMatch` : email à l'intérimaire quand un
    **nouveau** match apparaît.
  - `mission-pourvue` — webhook appelé par `notifyMissionPourvue` : **deux** emails, à
    l'intérimaire et à l'entreprise, chacun avec le lien vers **son** contrat à signer.
  - `rappel-debut-mission` — **planifié** (8h), lit PostgreSQL directement, sans passer par
    l'API : rappel à l'intérimaire dont une mission démarre dans deux jours.
- **n8n n'est pas déployé.** Chacun le lance sur son poste : **`npm run n8n:up`**, déclaré
  dans `docker-compose.yml` sous un **profil**, donc `npm run db:up` ne le démarre pas. Les
  **identifiants** (Gmail SMTP, PostgreSQL) se créent dans n8n et ne sont jamais dans le
  dépôt : c'est pour cela que les fichiers exportés arrivent sans identifiant sélectionné.
  Dans l'identifiant PostgreSQL, l'hôte est **`postgres`**, pas `localhost` — depuis le
  conteneur, `localhost` désigne n8n lui-même.
- L'intérimaire renseigne **ville et code postal dès l'inscription**, modifiables ensuite dans
  son profil. Ils servent au critère « zone » du matching.
- **Trois rôles** : `COMPANY`, `WORKER` et `ADMIN`. `ADMIN` est l'agent CADANS : il vérifie
  les justificatifs de CACES et consulte, en lecture seule, l'annuaire des comptes, les
  missions et les contrats (espace `/admin`, `AdminController` protégé par un `@Roles` de
  classe, `docs/espace-agent.md`). Sans inscription publique : créé par `seed:demo`, ou à la
  main en base. Il **voit l'email et le téléphone** de l'intérimaire (CADANS est l'employeur,
  décision du 23/09), mais jamais NIR, IBAN, pièce d'identité ni PDF de contrat. Il n'écrit
  rien d'autre que les décisions sur les justificatifs : pas de gestion des comptes ni des
  missions.
- **Parcours** : `docs/parcours-interimaire.md` et `docs/parcours-entreprise.md`. Le profil
  intérimaire se complète dans l'ordre qu'on veut, rien n'est bloquant : habilitations avec
  justificatif, compétences, créneaux, puis informations d'embauche au moment du contrat. Un
  profil incomplet voit les missions ; c'est l'API qui refuse la candidature en disant ce qui
  manque. **La pièce d'identité n'a pas d'écran** : route API seulement.

## Règles de travail

- **Le périmètre est gelé au 22/09.** N'ajoute aucune fonctionnalité qui ne soit pas dans le
  backlog. Si tu penses qu'il en manque une, dis-le, ne la code pas.
- **En cas d'arbitrage**, la priorité de chaque tâche est dans `chiffrage_CADANS.xlsx`. On
  coupe les lignes en priorité Faible en premier.
- `docs/cadrage/chiffrage_CADANS.xlsx` **fait foi** pour le chiffrage. Ne le modifie pas sans
  qu'on te le demande explicitement.
- Signale toute nouvelle dépendance avant de l'installer.
- Commits en français, format `type(scope): description` (`feat`, `fix`, `docs`, `test`,
  `chore`). Exemple : `feat(matching): filtrage bloquant sur les CACES`.

## Git

- **Ne développe jamais sur `main`.** Si tu t'y trouves, crée une branche avant toute
  modification. `main` ne reçoit que des merges de pull requests.
- Branche par tâche, nommée `type/module-description` : `feat/matching-scoring-caces`,
  `fix/auth-refresh-token`, `docs/cadrage`.
- Une pull request par tâche du backlog, pas une PR fourre-tout. Elle doit passer
  `npm run verify` (format, lint, typecheck, tests unitaires et e2e, build) avant merge : la
  CI GitHub Actions ne s'exécute pas, le quota de l'organisation Epitech est épuisé.
  Garde `.github/workflows/ci.yml` tel quel.
- **Ne merge pas toi-même une PR** et ne force push jamais, ni sur `main` ni sur la branche
  d'un autre.
- `prisma/schema.prisma` (`apps/api/prisma/schema.prisma`) est tenu par Khadija et Massilia.
  N'y touche pas sans le dire : c'est le fichier sur lequel tout le monde entre en conflit.
- **L'outillage de Claude Code refuse `gh pr merge`** : Prépare
  tout (branche, commits, PR, vérifications) et donne-lui les commandes de fusion.
- **PR empilées** (une branche partant d'une autre) : fusionner dans l'ordre et en
  `gh pr merge --merge`, jamais `--squash`, qui réécrirait les commits repris par les
  suivantes. Si GitHub annonce un conflit alors que `git merge` local n'en trouve aucun, son
  calcul est périmé : fusionner `main` dans la branche et pousser suffit à le rafraîchir.

## Équipe

| Membre | Périmètre principal sur `main` |
| --- | --- |
| Kemil | socle, design system et écrans, référentiel et matching, espace agent (justificatifs, registre), contrats et annexes, n8n, déploiement, documentation |
| Cheikh | inscription, appel n8n et premier PDF de contrat, annuaire, missions et contrats de l'espace agent |
| Khadija | CRUD missions, profil de matching et moteur initial, candidatures, tableaux de bord |
| Massilia | socle auth, chiffrement, politique de confidentialité, page « Qui sommes-nous », navigation |
| Mohamed | zone du matching par département |

`apps/api/prisma/schema.prisma` est tenu par Khadija et Massilia (voir « Git »).

## Commandes

Détail, installation et dépannage dans le README. Node 22 (`.nvmrc`), Docker Desktop lancé.

```bash
npm run db:up                  # PostgreSQL + MongoDB (Docker)
npm run n8n:up                 # n8n en local, profil Compose à part (n8n/README.md)
npm run dev                    # API :3001 + site :3000
npm run verify                 # à passer avant chaque push
npm run test:cov               # tests unitaires + fonctionnels, coverage fusionné, seuil 95 % des lignes
npm run test:e2e               # tests fonctionnels
npm run prisma:migrate         # applique les migrations, régénère le client
npm run prisma:migrate -- --name <nom>   # crée une migration
npm run import:rome            # référentiel ROME depuis prisma/seed/rome (--fetch : rafraîchit depuis France Travail)
npm run seed:demo -- --complet # trois comptes de démonstration, quatre missions, un profil rempli (README)
```

- **Prisma et Next.js uniquement via `npm run`, jamais `npx prisma` ni `npx next`** : le
  `.env` est à la racine, et ni la CLI Prisma ni Next.js ne l'y cherchent. Les scripts passent
  par `dotenv-cli` (`DATABASE_URL` et `NEXT_PUBLIC_API_URL` sinon introuvables).
- `GET http://localhost:3001/health` donne l'état des deux bases.
- **`npm run verify` casse le watcher de l'API de dev.** `verify` lance `nest build`, qui
  réécrit `dist/` pendant que `nest start --watch` s'en sert : l'API continue de répondre,
  mais sur du code périmé — sans erreur, sans message. Symptôme : une route ajoutée répond
  404, ou une réponse n'a pas les champs qu'on vient d'ajouter. **Redémarrer `npm run dev`
  après chaque `verify`** avant toute vérification au navigateur.
- **`.env` : `JWT_SECRET` (32 caractères minimum) et `ENCRYPTION_KEY` sont obligatoires**,
  sinon l'API refuse de démarrer. Les valeurs d'exemple de `.env.example` sont refusées quand
  `NODE_ENV=production`.
- `apps/web/next-env.d.ts` est réécrit par Next.js selon la dernière commande lancée (`dev` ou
  `build`). Les deux variantes fonctionnent : ne pas le commiter pour rien.

## Pièges rencontrés, à ne pas redécouvrir

- **Versions des dépendances figées volontairement** sur les dernières majeures *stables*, pas
  les dernières tout court : Nest 11 (la 12 est ESM pur), Prisma 6, TypeScript 5.9, ESLint 9,
  driver MongoDB 6 (la 7.6 ne se connecte pas sous Jest). Tableau et justification dans le
  README. Vérifier une version avant de l'installer, `latest` peut être une release candidate.
- **La validation existe en double** : `apps/api/src/auth/dto/` fait autorité,
  `apps/web/src/lib/validation.ts` la reproduit pour afficher l'erreur sous le bon champ.
  Toute règle modifiée côté API doit l'être côté site.
- **Aucune limite de tentatives de connexion** n'est implémentée (hors backlog). argon2 est
  réglé sur les paramètres OWASP m = 19 Mio, t = 2, p = 1 pour limiter la mémoire consommée.
- **Les sessions sont SANS ÉTAT, et le restent** (décision du 23/09/2026). `SessionGuard` est
  volontairement **synchrone** : il ne lit jamais la base, il ne fait que vérifier la
  signature du JWT. L'API ne sait donc pas révoquer un jeton déjà émis — un changement de mot
  de passe ne ferme pas les sessions en cours. La parade retenue est la **durée de vie courte :
  1 h** (`SESSION_TTL_SECONDS`, `apps/api/src/auth/token.service.ts`, source unique dont le
  `maxAge` du cookie découle). Ne pas ajouter de `tokenVersion` ni de lecture en base dans le
  guard sans en discuter : cela annulerait l'intérêt du sans-état. Les trois options étudiées
  et l'évolution retenue sont dans `docs/perspectives.md`, « Sessions ».

## Déploiement

Rien n'est déployé à ce jour. Le blueprint `render.yaml`, les variables par service et la
check-list sont dans `docs/deploiement.md`. Ce qui conditionne ce que tu conseilles :

- **Site et API sur Render**, PostgreSQL sur Neon, MongoDB sur Atlas (décision du 18/09).
  Vercel est abandonné : son offre gratuite refuse les dépôts privés d'organisation.
- **Le déploiement se fera depuis un miroir privé du dépôt sur un compte GitHub personnel**
  (décision du 23/09) : installer l'application GitHub de Render sur l'organisation Epitech
  demande un droit de propriétaire que l'équipe n'a pas. **Le dépôt de l'organisation reste la
  référence** ; le miroir ne reçoit que des pousses de `main`.
- **n8n n'est pas déployé** et ne le sera pas pour la soutenance : tant qu'il tourne sur un
  poste, les deux variables `N8N_*_URL` restent **vides** côté Render, l'API journalise
  l'appel au lieu de l'envoyer. La démonstration des automatisations se fait en local.
- Sur l'offre gratuite de Render, un service **s'endort après 15 minutes** : ouvrir le site et
  `/health` avant la démo.
- `.github/workflows/ci.yml` reste dans le dépôt tel quel ; `npm run verify` tient lieu de CI.

## Documentation

Un document par sujet dans `docs/`, indexés dans le README (« Documentation »). Avant de
documenter quelque chose, chercher où il vit déjà : le README ne porte que l'installation, les
commandes et la procédure de test ; ce fichier ne porte que les règles et les décisions.
