# CADANS

> Le bon profil, à l'heure, demain matin.

**Agence d'intérim en ligne** spécialisée en **logistique d'entrepôt** : préparation de
commandes, conduite de chariots (cariste), manutention, gestion de stock et de quai.

CADANS est une **entreprise de travail temporaire**. Elle est **l'employeur de l'intérimaire**
et le met à disposition d'entreprises clientes — ce n'est ni une place de marché, ni un
intermédiaire. Elle est donc partie aux deux contrats qu'impose le Code du travail : le
**contrat de mission** avec l'intérimaire (art. L. 1251-16) et le **contrat de mise à
disposition** avec l'entreprise utilisatrice (art. L. 1251-43).

POC de 11 jours, du vendredi 11 au vendredi 25 septembre 2026.

## Proposition de valeur

Une agence d'intérim classique fait patienter : un chargé de recrutement rappelle, puis
cherche dans son vivier. CADANS fait le même métier — elle embauche l'intérimaire, l'assure,
établit ses contrats — mais le rapprochement est **automatisé** : dès qu'une entreprise publie
une mission, les profils habilités et disponibles à proximité remontent classés.

L'intérimaire, lui, a un employeur unique et des missions proches de chez lui, adaptées à ses
habilitations et à ses créneaux.

## Équipe

| Membre | Ce qui est sur `main` |
| --- | --- |
| Kemil | Socle du monorepo, design system et écrans (site public, espaces intérimaire, entreprise et agent), référentiel ROME et matching, vérification des habilitations et registre des décisions, contrats, signature et annexes, informations d'embauche, workflows n8n, blueprint Render, documentation |
| Cheikh | Page d'inscription unique et ses composants, appel des webhooks n8n et première génération du contrat PDF, habillage du PDF, annuaire, missions et contrats de l'espace agent |
| Khadija | CRUD missions côté entreprise, profil de matching et première version du moteur, candidatures et pages publiques de missions, tableaux de bord entreprise et intérimaire, paramètres entreprise |
| Massilia | Socle de l'authentification (modèles de comptes, inscription et connexion argon2, sessions et permissions), chiffrement des pièces d'identité et habilitations, guide API, politique de confidentialité et son acceptation, page « Qui sommes-nous », barre de navigation |
| Mohamed | Critère de zone du matching par département, saisie du code postal à l'inscription |

La répartition a évolué par rapport au cadrage initial. Le détail du temps passé par tâche est
dans le chiffrage réel, colonne « Réel (j) » de `docs/cadrage/chiffrage_CADANS.xlsx`.

## Stack

| Couche | Choix |
| --- | --- |
| Frontend | Next.js + TypeScript |
| Backend | Nest.js + TypeScript |
| Base relationnelle | PostgreSQL + Prisma |
| Base non relationnelle | MongoDB |
| Tests | Jest + Supertest (coverage généré) |
| CLI | Commander.js |
| Automatisation nocode | n8n |
| Notifications | Email — Resend pour l'API (transactionnel), Gmail SMTP dans n8n pour les automatisations |
| Environnement de dev | Docker |
| Hébergement | Render (site **et** API), Neon (PostgreSQL), MongoDB Atlas |
| CI / CD | GitHub Actions (workflow livré, à l'arrêt : quota épuisé) + déploiement automatique par Render |

### Versions des dépendances

**Nous avons volontairement figé les dépendances sur les dernières versions stables, et non
sur les dernières versions tout court : sur un projet de 11 jours à cinq, le coût d'une
version trop récente se paie en heures de blocage.**

Au moment de la mise en place du socle, npm proposait par défaut plusieurs versions majeures
toutes récentes, qui cassaient le projet ou n'étaient pas finalisées :

| Dépendance | Version proposée par défaut | Problème constaté | Version retenue |
| --- | --- | --- | --- |
| Nest.js | 12 | Modules au format ESM uniquement : erreur de compilation sur chaque import | 11 |
| Prisma | 8.0.0-rc | Version candidate, pas une version finale, et incompatible avec son propre client | 6 |
| TypeScript | 6 | Rejette des options de configuration encore utilisées par Nest.js | 5.9 |
| ESLint | 10 | Pas encore supporté par le plugin d'accessibilité `eslint-plugin-jsx-a11y` | 9 |
| Driver MongoDB | 7.6 | Connexion impossible sous Jest, donc tests fonctionnels non fiables | 6.21 |

Chaque version reste modifiable. Une montée de version se fait dans une branche dédiée, et
`npm run verify` doit passer avant le merge.

### Hébergement : Render plutôt que Vercel

Le dossier de cadrage prévoyait le site sur Vercel et l'API sur Render. **L'offre gratuite de
Vercel refuse les dépôts privés appartenant à une organisation GitHub**, ce qui est le cas de
ce dépôt : « You cannot deploy to a Hobby team from a private repository in a GitHub
organization » (documentation Vercel). Le site et l'API sont donc hébergés **tous les deux sur
Render**, décision prise en équipe le 18/09/2026. Un seul hébergeur, une seule configuration.

Le déploiement continu est assuré par Render, branché directement sur le dépôt GitHub : il ne
consomme pas de minutes GitHub Actions, dont le quota de l'organisation est épuisé.

## Livrables de cadrage

Tout est dans [`docs/cadrage/`](docs/cadrage/) : dossier de cadrage, chiffrage détaillé et
lien vers le tableau Miro.

## Identité visuelle

Identité **monochrome anthracite**, contrastes conformes au RGAA 4.1. Palette, échelle
typographique, logotype et règle de calage : [`docs/charte-graphique.md`](docs/charte-graphique.md).
Les jetons font foi dans [`apps/web/src/app/globals.css`](apps/web/src/app/globals.css).

## Parcours utilisateur

Écran par écran, avec ce que chaque écran appelle et les effets qui ne se voient pas :
[`docs/parcours-interimaire.md`](docs/parcours-interimaire.md) et
[`docs/parcours-entreprise.md`](docs/parcours-entreprise.md).

## Documentation

Ce README couvre l'installation, les commandes et la vérification. Le reste est dans `docs/`,
un document par sujet.

| Document | Contenu |
| --- | --- |
| [`docs/api.md`](docs/api.md) | Sessions, rôles, inventaire des routes, validation, côté front et côté back, données sensibles chiffrées, sécurité en résumé |
| [`docs/referentiel-matching.md`](docs/referentiel-matching.md) | Référentiel ROME (source, curation, ré-import), règles du matching, préremplissage d'une mission depuis une offre France Travail |
| [`docs/espace-agent.md`](docs/espace-agent.md) | Vérification des justificatifs de CACES, registre des décisions, annuaire, missions et contrats vus par l'agent |
| [`docs/contrats.md`](docs/contrats.md) | Les deux contrats, leur génération, la signature et sa preuve, les annexes |
| [`docs/contrat-mentions-obligatoires.md`](docs/contrat-mentions-obligatoires.md) | Ce que les PDF portent au regard du Code du travail, et ce qui manque |
| [`docs/emails.md`](docs/emails.md) | Resend pour l'API, Gmail SMTP dans n8n : qui envoie quoi, et pourquoi deux |
| [`n8n/README.md`](n8n/README.md) | Les trois workflows : lancement, import, identifiants, test |
| [`docs/deploiement.md`](docs/deploiement.md) | Blueprint Render, variables par service, check-list, intégration continue |
| [`docs/charte-graphique.md`](docs/charte-graphique.md) | Palette, typographie, logotype, mode contraste renforcé |
| [`docs/perspectives.md`](docs/perspectives.md) | Limites assumées et pistes d'évolution, module par module |
| [`docs/cadrage/`](docs/cadrage/) | Dossier de cadrage, chiffrage, lien vers le Miro |
| [`CLAUDE.md`](CLAUDE.md) | Règles de travail et décisions produit, pour l'équipe comme pour l'assistant |

## Installation et lancement

### Prérequis

**Git**, **Node.js 22 LTS** (via fnm) et **Docker Desktop**, à installer une seule fois.

#### macOS

```bash
brew install fnm                       # gestionnaire de versions de Node
brew install --cask docker-desktop     # demande le mot de passe administrateur
```

Puis ajouter cette ligne à la fin de `~/.zshrc` et rouvrir le terminal :

```bash
eval "$(fnm env --use-on-cd --shell zsh)"
```

#### Windows

Dans un terminal **PowerShell** :

```powershell
winget install Git.Git                 # inclut Git Bash, nécessaire au hook pre-push
winget install Schniz.fnm              # gestionnaire de versions de Node
winget install Docker.DockerDesktop    # demande les droits administrateur
```

Docker Desktop s'appuie sur **WSL 2** : au premier lancement, accepter son installation et
redémarrer si Windows le demande. La virtualisation doit être activée dans le BIOS ; Docker
Desktop affiche un message explicite si ce n'est pas le cas.

Ensuite, ouvrir le profil PowerShell :

```powershell
notepad $PROFILE     # si le fichier n'existe pas, accepter sa création
```

Y ajouter cette ligne, enregistrer, puis rouvrir le terminal :

```powershell
fnm env --use-on-cd --shell powershell | Out-String | Invoke-Expression
```

Rien à régler pour les fins de ligne : le fichier `.gitattributes` du dépôt impose le
format Unix à tout le monde. Sans lui, Git pour Windows convertirait les fichiers au format
Windows et `npm run verify` échouerait sur la vérification du format.

#### Tous systèmes

Le dépôt contient un `.nvmrc` : en entrant dans le dossier, fnm bascule
automatiquement sur Node 22. Vérifier avec `node -v`.

> **Tout le monde doit être sur Node 22.** Node 23 et 25 sont des versions impaires,
> donc expérimentales : plusieurs dépendances du projet les refusent explicitement.

> **Ne pas installer PostgreSQL ni MongoDB.** Docker les fournit : les deux bases sont
> téléchargées et lancées automatiquement par `npm run db:up`. Aucun autre installeur,
> aucune interface graphique n'est nécessaire.

### Première installation du projet

À faire une seule fois, après avoir installé les prérequis ci-dessus.

```bash
git clone https://github.com/EpitechMscProPromo2027/D-WEB-901-PAR-9-1-InteriMatch-15.git
cd D-WEB-901-PAR-9-1-InteriMatch-15

npm install                  # installe les deux applications (workspaces npm)
cp .env.example .env         # crée les variables d'environnement locales (voir ci-dessous)
npm run db:up                # télécharge et démarre PostgreSQL + MongoDB
npm run prisma:migrate       # crée les tables et génère le client Prisma
npm run import:rome          # charge le référentiel métier ROME (fichiers du dépôt, sans réseau)
npm run seed:demo            # crée les trois comptes de démonstration (voir ci-dessous)
```

Sous Windows, `cp` fonctionne dans PowerShell. Dans l'invite de commandes classique
(`cmd`), utiliser `copy .env.example .env`.

Le premier `npm run db:up` télécharge environ 1,5 Go d'images Docker. Les suivants sont
instantanés.

### Variables d'environnement

Le `.env` copié depuis `.env.example` fonctionne tel quel en local. Les variables ci-dessous
sont celles de l'authentification et du chiffrement : **l'API refuse de démarrer** si les deux
premières sont absentes ou invalides.

| Variable | Rôle | En local | En production (Render) |
| --- | --- | --- | --- |
| `JWT_SECRET` | Signature des sessions | Valeur de `.env.example` | Générée, **32 caractères minimum** : `openssl rand -base64 48`. La valeur de `.env.example` est **refusée** en production. |
| `ENCRYPTION_KEY` | Clé AES-256 des pièces d'identité et habilitations | Valeur de `.env.example` | Générée : `openssl rand -base64 32`. **Ne jamais la perdre ni la changer** : les documents déjà chiffrés deviendraient illisibles. La valeur de `.env.example` est **refusée** en production. |
| `WEB_URL` | Seul site autorisé à appeler l'API avec une session (CORS, CSRF) | `http://localhost:3000` | URL Render du site, sans `/` final |
| `NODE_ENV` | Active le cookie `Secure` et l'en-tête HSTS | non défini | `production` |

> Un `.env` créé avant l'arrivée de ces variables ne les contient pas : recopier les lignes
> manquantes depuis `.env.example`.

### Prisma : toujours passer par `npm run`

> **Ne jamais lancer `npx prisma …` directement.** Utiliser les commandes `npm run prisma:…`.

Le fichier `.env` est à la racine du projet, pour être partagé par l'API, Docker Compose
et le site. Or l'outil Prisma, lancé depuis `apps/api`, ne cherche le `.env` que dans ce
dossier : un `npx prisma migrate dev` direct échoue avec
`Environment variable not found: DATABASE_URL`. Les commandes `npm run prisma:…` chargent
le `.env` racine avant de lancer Prisma (outil `dotenv-cli`), sous macOS comme sous Windows.

| Commande | Effet |
| --- | --- |
| `npm run prisma:migrate` | Applique les migrations en attente et régénère le client. **À lancer après chaque `git pull` qui modifie le schéma.** |
| `npm run prisma:migrate -- --name ajout_missions` | Crée une nouvelle migration après avoir modifié `schema.prisma` |
| `npm run prisma:generate` | Régénère seulement le client Prisma |
| `npm run prisma:studio` | Ouvre une interface web pour consulter les données PostgreSQL |

Le `--` transmet les options à Prisma. En CI et en production, `DATABASE_URL` est fournie
directement par l'environnement : le fichier `.env` n'y est pas nécessaire.


### Au quotidien

Ces deux commandes suffisent. **Docker Desktop doit être lancé** : icône baleine dans la
barre de menus sur macOS, dans la zone de notification de la barre des tâches sur Windows.

```bash
npm run db:up                # démarre les bases (rien à faire si déjà lancées)
npm run dev                  # API sur :3001, site sur :3000
```

`Ctrl+C` arrête les deux applications. Les bases continuent de tourner ; pour les arrêter :

```bash
npm run db:down              # les données sont conservées
```

### Vérifier que tout fonctionne

Ouvrir [http://localhost:3001/health](http://localhost:3001/health). La réponse doit être :

```json
{ "status": "up", "postgres": "up", "mongo": "up", "uptimeSeconds": 12 }
```

Et [http://localhost:3000](http://localhost:3000) doit afficher la page d'accueil.

### Avant chaque push

```bash
npm run verify
```

Cette commande enchaîne les six vérifications : format, lint, types, tests unitaires, tests
fonctionnels, build. **Elle doit passer avant tout push** : la CI GitHub Actions ne tourne
pas, le quota de l'organisation est épuisé (voir [`docs/deploiement.md`](docs/deploiement.md)).

Pour l'automatiser, une fois par personne :

```bash
git config core.hooksPath .githooks     # lance verify avant chaque git push
```

### Coverage : ce que mesure `npm run test:cov`

Les tests de l'API sont répartis en deux projets Jest, déclarés dans `apps/api/package.json`
et configurés dans `apps/api/test/jest-unit.json` et `jest-e2e.json` :

| Projet | Fichiers | Ce qu'il exerce |
| --- | --- | --- |
| `unitaires` | `src/**/*.spec.ts` | services, gardes, DTO de validation, utilitaires, en isolation |
| `fonctionnels` | `test/*.e2e-spec.ts` | l'application Nest entière par HTTP (Supertest) : contrôleurs, pipes, gardes, DTO |

`npm run test:cov` lance **les deux** et fusionne leur coverage en un seul rapport, dans
`apps/api/coverage/`. Mesurer les seuls tests unitaires donnerait un chiffre faux par
construction : les contrôleurs et les DTO n'y apparaissent qu'à 0 % alors que chaque route est
exercée par les tests fonctionnels.

**Seuil : 95 % des lignes**, imposé par `coverageThreshold` : la commande échoue en dessous.
Le seuil ne porte que sur les lignes ; les branches et les fonctions sont mesurées et
livrées telles quelles, sans test écrit pour gonfler le chiffre.

**Exclu du calcul, et pourquoi** : `src/cli/` (`import-rome.ts`, `seed-demo.ts`). Ce sont
deux scripts d'exploitation qui exigent une base réelle et n'ont pas de logique métier
propre : l'import ROME délègue à `RomeImportService`, testé à 100 % par
`rome-import.service.spec.ts`, et le jeu de démonstration n'est qu'une suite d'écritures
Prisma. Sont aussi exclus, comme avant, `main.ts` et les fichiers `*.module.ts`, qui ne font
qu'assembler.

### Commandes utiles

| Commande | Effet |
| --- | --- |
| `npm run dev` | Lance l'API et le site en parallèle |
| `npm run verify` | **Les 6 vérifications. À lancer avant chaque push.** |
| `npm run build` | Build de production des deux applications |
| `npm run lint` | ESLint sur tout le dépôt |
| `npm run format` | Reformate le code avec Prettier |
| `npm run typecheck` | Vérifie les types TypeScript |
| `npm run test` | Tests unitaires |
| `npm run test:e2e` | Tests fonctionnels (Supertest) |
| `npm run test:cov` | Tests unitaires **et** fonctionnels, avec le rapport de coverage fusionné (voir ci-dessus) |
| `npm run db:up` / `npm run db:down` | Démarre / arrête les bases |
| `npm run n8n:up` / `npm run n8n:down` | Démarre / arrête n8n en local (profil Compose à part, voir [`n8n/README.md`](n8n/README.md)) |
| `npm run prisma:generate` | Régénère le client Prisma après modification du schéma |
| `npm run import:rome` | Importe le référentiel métier ROME depuis `apps/api/prisma/seed/rome` (`-- --fetch` : rafraîchit d'abord les fichiers depuis France Travail, identifiants requis ; `-- --dry-run` : lit sans écrire) |
| `npm run seed:demo` | Crée les trois comptes de démonstration partagés par l'équipe (idempotent) ; `-- --complet` ajoute missions et profil rempli |

### Comptes de démonstration

`npm run seed:demo` crée trois comptes, pour que tout le monde démontre le produit avec le
même jeu de données plutôt qu'avec des comptes créés à la main, chacun les siens.

| Rôle | Adresse | Mot de passe |
|---|---|---|
| Entreprise — *Entrepôt du Nord*, Roissy-en-France (95) | `interimcadans+entreprise@gmail.com` | `DemoCadans#2026` |
| Intérimaire — *Samir Diallo*, Roissy-en-France (95) | `interimcadans+interimaire@gmail.com` | `DemoCadans#2026` |
| **Agent CADANS** — vérifie les justificatifs, espace `/admin` | `admin@cadans.fr` | `DemoCadans#2026` |

La commande est **idempotente** : la relancer remet le mot de passe à sa valeur connue sans
créer de doublon, et sans écraser les profils déjà remplis pendant une démo.

Les adresses utilisent le **sous-adressage Gmail** (`+suffixe`) : les trois comptes restent
distincts pour l'application — l'unicité porte sur la chaîne entière — mais les emails des
workflows n8n arrivent tous dans **la même boîte**. C'est ce qui rend les automatisations
démontrables sans posséder de domaine vérifié.

> **Ces identifiants sont publics.** La commande refuse de s'exécuter quand `NODE_ENV` vaut
> `production` : un compte dont le mot de passe est écrit dans le dépôt ne doit jamais
> exister sur une base déployée. `--force` lève le garde-fou, à n'utiliser qu'en
> connaissance de cause.

Les comptes de démonstration sont volontairement en **95700** : l'intérimaire et l'entreprise sont dans
le même département, donc le critère de zone du matching remonte à son maximum. Le profil
intérimaire est créé vide — créneaux, compétences et CACES restent à saisir, c'est le
parcours qu'on montre.

#### Jeu complet : `npm run seed:demo -- --complet`

Ajoute de quoi montrer le matching **sans rien saisir** : quatre missions ouvertes publiées
par Entrepôt du Nord, avec des CACES variés, et un troisième compte au profil déjà rempli.

| Rôle | Adresse | Profil |
|---|---|---|
| Intérimaire — *Leïla Moreau*, 95700 | `interimcadans+cariste@gmail.com` | CACES R489-3 **vérifié** et R489-1B **en attente de vérification**, créneaux matin / après-midi / journée, trois compétences |

Résultat sur `/interimaire/matches`, vérifié :

- **connectée en `interimcadans+cariste@gmail.com`** : 2 matches (Cariste **100 %**, Préparation de commandes
  **70 %**), 1 mission masquée faute du CACES R489-5, 1 écartée par le créneau de nuit.
  Les deux règles du matching sont donc visibles sur un même écran.
- **connectée en `interimcadans+interimaire@gmail.com`** (profil vide) : 0 match et **4 missions masquées**,
  ce qui affiche l'incitation « ajoutez vos CACES pour les voir apparaître ». C'est le
  parcours d'onboarding, de bout en bout.

Le mode complet **remet à plat les missions de l'entreprise de démonstration** à chaque
exécution — sinon relancer la commande empilerait les mêmes offres. Aucune autre entreprise
n'est touchée. Le compte `interimcadans+interimaire@gmail.com` garde son profil vide dans les deux modes.

### En cas de problème

| Symptôme | Cause et solution |
| --- | --- |
| `/health` répond `"postgres": "down"` ou `"mongo": "down"` | Docker Desktop n'est pas lancé, ou `npm run db:up` n'a pas été exécuté. L'API démarre quand même, c'est voulu : le travail sur le frontend n'est pas bloqué. |
| `Cannot find module '@prisma/client'` | Lancer `npm run prisma:generate`. À refaire après chaque modification de `schema.prisma`. |
| `Environment variable not found: DATABASE_URL` | Prisma a été lancé avec `npx prisma …` au lieu de `npm run prisma:…`, ou le fichier `.env` manque à la racine (`cp .env.example .env`). |
| `P1001: Can't reach database server at localhost:5432` | Docker Desktop n'est pas lancé, ou `npm run db:up` n'a pas été exécuté. |
| `EBADENGINE` à l'installation | Mauvaise version de Node. Vérifier `node -v` → doit afficher `v22.x`. Sinon `fnm use 22`. |
| `port is already allocated` sur 5432 ou 27017 | Une autre instance de base tourne déjà. `npm run db:down` puis `npm run db:up`. |
| `EADDRINUSE` sur 3000 ou 3001 | Un `npm run dev` tourne déjà dans un autre terminal. |
| La commande `npm` semble ignorer `.nvmrc` | La ligne fnm manque dans `~/.zshrc` (macOS) ou dans `$PROFILE` (Windows), ou le terminal n'a pas été rouvert. |
| Windows : `fnm` n'est pas reconnu, ou PowerShell refuse de charger le profil (`running scripts is disabled`) | Autoriser les scripts locaux, une fois : `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, puis rouvrir le terminal. |
| Windows : `npm run verify` échoue au format sur des fichiers qu'on n'a pas modifiés | Dépôt cloné avant l'ajout du `.gitattributes` : les fichiers sur le disque ont gardé les fins de ligne Windows. Pousser ou mettre de côté son travail en cours, puis re-cloner le dépôt. |
| Windows : Docker Desktop ne démarre pas, message sur WSL ou la virtualisation | Lancer `wsl --update` dans PowerShell en administrateur, redémarrer. Si la virtualisation est désactivée, l'activer dans le BIOS. |
| Windows : le hook `pre-push` ne se lance pas | Git doit avoir été installé avec Git Bash (`winget install Git.Git`), qui fournit `sh`. |
| L'API s'arrête au démarrage : `JWT_SECRET absente ou trop courte` ou `ENCRYPTION_KEY absente ou invalide` | Le `.env` date d'avant ces variables. Recopier les lignes manquantes depuis `.env.example`. |
| Le front reçoit `401 Authentification requise` alors que l'utilisateur vient de se connecter | L'appel `fetch` n'a pas `credentials: 'include'` : le cookie de session n'est pas envoyé. Voir [`docs/api.md`](docs/api.md), « Côté front ». |
| `403 Origine de la requête non autorisée` | Le site n'est pas servi depuis `WEB_URL` (autre port, `127.0.0.1` au lieu de `localhost`…). Aligner `WEB_URL` dans le `.env`. |
| `The table "certifications" does not exist` ou erreur Prisma sur une colonne | Des migrations ont été ajoutées : `npm run prisma:migrate`. |

## Procédure de test manuel

Ce que chacun peut dérouler sur son poste pour vérifier le produit de bout en bout, avant la
soutenance ou après une intégration. Les tests automatisés (`npm run verify`) couvrent l'API ;
cette procédure couvre ce qu'ils ne voient pas : les écrans, les emails, les PDF.

### Préparation, une fois

```bash
npm run db:up
npm run prisma:migrate
npm run import:rome
npm run seed:demo -- --complet
npm run dev
curl http://localhost:3001/health      # postgres et mongo doivent répondre "up"
```

Comptes (mot de passe commun `DemoCadans#2026`, voir [Comptes de démonstration](#comptes-de-démonstration)) :
`interimcadans+entreprise@gmail.com`, `interimcadans+interimaire@gmail.com` (profil vide),
`interimcadans+cariste@gmail.com` (profil rempli), `admin@cadans.fr` (agent).

> **Si `npm run verify` a tourné pendant que `npm run dev` était lancé, relancer `npm run dev`
> avant de tester** : le build de `verify` réécrit `dist/` sous les pieds du watcher, qui sert
> alors du code périmé sans le dire (voir CLAUDE.md, « Commandes »).

### Les onze parcours, dans l'ordre

1. **Inscription et connexion.** `/inscription` : créer un intérimaire avec une adresse neuve.
   Se déconnecter, se reconnecter sur `/connexion`. Essayer un mauvais mot de passe : le message
   doit être le même que pour une adresse inconnue.
2. **Mot de passe oublié.** `/mot-de-passe-oublie` avec l'adresse créée. `RESEND_API_KEY` étant
   vide en local, le lien s'affiche dans la console de l'API. L'ouvrir, choisir un nouveau mot de
   passe, se reconnecter avec.
3. **Onboarding intérimaire**, connecté en `+interimaire`. `/interimaire/profil` : déclarer
   un CACES avec sa date d'expiration et déposer son justificatif (PDF, JPEG ou PNG), cocher
   des compétences et des créneaux. `/interimaire/matches` doit afficher 0 match et 4 missions
   masquées, avec l'incitation à ajouter ses CACES. La pièce d'identité n'a **pas d'écran** :
   seule la route API existe (étape 8).
4. **Matching**, connecté en `+cariste`. `/interimaire/matches` doit afficher Cariste 100 % et
   Préparation de commandes 70 %, 1 mission masquée faute du CACES R489-5 et 1 écartée par le
   créneau de nuit. Ouvrir une mission depuis `/missions`, postuler, la retrouver dans
   `/interimaire/mes-missions`.
5. **Entreprise**, connectée en `+entreprise`. `/entreprise/missions/nouvelle` : créer une
   mission. `/entreprise/candidatures` : retenir Leïla. La mission passe **Pourvue** et le
   contrat de mise à disposition apparaît dans `/entreprise/contrats` : le signer en tapant le
   nom du contact. Déposer une annexe PDF dans `/entreprise/missions/[id]/annexes`.
6. **Contrat de mission**, connecté en `+cariste`. `/interimaire/informations-embauche` :
   saisir NIR et IBAN. Le contrat de mission ne se génère qu'à partir de là. Le signer dans
   `/interimaire/contrats`, puis télécharger le PDF final : son nom se termine par `-signe.pdf`
   et il porte la page de signatures.
7. **Agent**, connecté en `admin@cadans.fr`. `/admin` : ouvrir les justificatifs, en valider
   un, en refuser un avec un motif, vérifier l'historique des décisions. Ouvrir
   `/admin/interimaires`, `/admin/entreprises`, `/admin/missions` et `/admin/contrats` : une
   liste, une fiche derrière, et chaque compteur du tableau de bord mène à la liste filtrée.
   Vérifier qu'un autre rôle est renvoyé hors de `/admin`.
8. **API en direct.** La section « Tester à la main avec curl » de
   [`docs/api.md`](docs/api.md) fonctionne telle quelle, y compris le dépôt et la relecture
   d'un justificatif chiffré, et le dépôt d'une pièce d'identité sur
   `PUT /workers/me/identity-document`.
9. **SEO.** `curl -s localhost:3000/missions | grep -c '<h1'` doit répondre `1`. Ouvrir
   `/sitemap.xml` et `/robots.txt`. La fiche d'une mission pourvue reste servie mais porte
   `noindex` (afficher le code source de la page).
10. **Accessibilité.** Parcourir une page au clavier avec Tab : le contour de focus doit être
    visible sur chaque élément. Activer « Augmenter le contraste » dans les réglages système et
    recharger : les gris passent à l'encre.
11. **n8n.** Suivre [`n8n/README.md`](n8n/README.md), section « Tester » : les deux variables
    `N8N_*_URL` doivent être renseignées dans le `.env`, l'instance n8n lancée et les trois
    workflows importés. Sans cela, l'API journalise l'appel au lieu de l'envoyer, sans erreur.

À l'étape 5, l'entrée « depuis une offre France Travail » du formulaire n'apparaît que si
`FRANCE_TRAVAIL_CLIENT_ID` et `FRANCE_TRAVAIL_CLIENT_SECRET` sont renseignés dans le `.env` :
sans eux, seule la saisie à la main est proposée, et le reste du parcours ne change pas.

## Arborescence

```
.
├── apps/
│   ├── api/                # Nest.js — API, bases de données, tests
│   │   ├── prisma/         # schéma PostgreSQL (tenu par Khadija et Massilia), migrations, seed ROME
│   │   ├── src/
│   │   │   ├── account/    # identifiants de connexion (email, mot de passe)
│   │   │   ├── admin/      # espace agent : justificatifs, registre, annuaire, missions, contrats
│   │   │   ├── attachments/  # annexes PDF d'une mission, chiffrées
│   │   │   ├── auth/       # inscription, connexion, sessions JWT, @Public / @Roles / @CurrentUser
│   │   │   ├── candidatures/  # postuler, « mes candidatures », candidatures reçues
│   │   │   ├── cli/        # Commander.js — import ROME, jeu de démonstration
│   │   │   ├── companies/  # coordonnées de l'entreprise
│   │   │   ├── contracts/  # les deux contrats en PDF (pdf-lib), stockage chiffré et signature
│   │   │   ├── encryption/ # chiffrement AES-256-GCM des données sensibles
│   │   │   ├── health/     # GET /health — état des deux bases
│   │   │   ├── mail/       # envoi transactionnel (API HTTP de Resend)
│   │   │   ├── matching/   # filtrage bloquant CACES, score et sa ventilation, journal Mongo
│   │   │   ├── missions/   # CRUD missions, statuts, préremplissage France Travail
│   │   │   ├── mongo/      # connexion MongoDB (non transactionnel)
│   │   │   ├── n8n/        # appel des deux webhooks d'automatisation
│   │   │   ├── prisma/     # connexion PostgreSQL (relationnel, contractuel)
│   │   │   ├── referentiel/  # postes et compétences ROME, client France Travail
│   │   │   ├── sensitive-documents/  # pièces d'identité et justificatifs, chiffrés
│   │   │   └── worker-profile/  # identité, profil de matching, informations d'embauche
│   │   └── test/           # tests fonctionnels (Supertest), doublures en mémoire, configs Jest
│   └── web/                # Next.js — pages publiques rendues côté serveur, espaces connectés
│       └── src/
│           ├── app/        # routes ; (site) = public, entreprise/, interimaire/, admin/ ; globals.css = design system
│           ├── components/ # logotype, en-tête, formulaires, composants par espace
│           ├── lib/        # api.ts et session.ts (appels à l'API), validation, libellés
│           └── fonts/      # trois familles auto-hébergées + licences
├── docs/                   # un document par sujet (voir « Documentation »)
│   └── cadrage/            # livrables du point de cadrage
├── n8n/                    # trois workflows importables + leur mode d'emploi
├── render.yaml             # blueprint Render : API et site, variables par service
├── .github/workflows/      # CI : lint, types, tests, coverage, build (à l'arrêt, quota épuisé)
├── .githooks/              # hook pre-push optionnel (lance npm run verify)
├── .gitattributes          # fins de ligne Unix imposées (indispensable sous Windows)
├── docker-compose.yml      # PostgreSQL + MongoDB en local, n8n sous profil
├── .nvmrc                  # version de Node imposée au projet (22)
└── README.md
```
