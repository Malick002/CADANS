import { MatchNotificationPayload, MissionPourvuePayload, N8nService } from './n8n.service';

const matchPayload: MatchNotificationPayload = {
  interimaire: { prenom: 'Camille', nom: 'Martin', email: 'camille.martin@exemple.fr' },
  entreprise: { email: 'contact@entrepot-nord.fr' },
  mission: {
    titre: 'Cariste CACES 3',
    entreprise: 'Entrepôt du Nord',
    ville: 'Lille',
    codePostal: '59000',
    dateDebut: '2026-10-01',
    remuneration: '13,50 € / h',
    url: 'https://cadans.example/missions/mission-1',
  },
  score: 87,
};

const pourvuePayload: MissionPourvuePayload = {
  interimaire: { prenom: 'Camille', nom: 'Martin', email: 'camille.martin@exemple.fr' },
  entreprise: { email: 'contact@entrepot-nord.fr' },
  mission: {
    titre: 'Cariste CACES 3',
    ville: 'Lille',
    codePostal: '59000',
    dateDebut: '2026-10-01',
    dateFin: '2026-10-31',
    remuneration: '13,50 € / h',
    url: 'https://cadans.example/missions/mission-1',
  },
};

describe('N8nService', () => {
  const env = process.env;
  let fetchMock: jest.Mock;

  beforeEach(() => {
    process.env = { ...env };
    fetchMock = jest.fn().mockResolvedValue(new Response(null, { status: 200 }));
    global.fetch = fetchMock as unknown as typeof fetch;
  });

  afterAll(() => {
    process.env = env;
  });

  describe('sans URL configurée', () => {
    it("n'appelle pas n8n et se contente de journaliser", async () => {
      delete process.env.N8N_MATCH_NOTIFICATION_URL;
      delete process.env.N8N_MISSION_POURVUE_URL;

      await new N8nService().notifyMatch(matchPayload);

      expect(fetchMock).not.toHaveBeenCalled();
    });
  });

  describe('avec URL configurée', () => {
    beforeEach(() => {
      process.env.N8N_MATCH_NOTIFICATION_URL = 'https://interim.app.n8n.cloud/webhook/match';
      process.env.N8N_MISSION_POURVUE_URL = 'https://interim.app.n8n.cloud/webhook/pourvue';
    });

    it('poste le payload de match sur son URL dédiée', async () => {
      await new N8nService().notifyMatch(matchPayload);

      expect(fetchMock).toHaveBeenCalledTimes(1);
      const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
      expect(url).toBe('https://interim.app.n8n.cloud/webhook/match');
      expect(init.method).toBe('POST');
      expect(JSON.parse(String(init.body))).toEqual(matchPayload);
    });

    it('poste le payload de mission pourvue sur son URL dédiée', async () => {
      await new N8nService().notifyMissionPourvue(pourvuePayload);

      expect(fetchMock).toHaveBeenCalledTimes(1);
      const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
      expect(url).toBe('https://interim.app.n8n.cloud/webhook/pourvue');
      expect(JSON.parse(String(init.body))).toEqual(pourvuePayload);
    });

    // Un envoi raté ne doit jamais faire échouer l'action principale (mission mise à jour,
    // matching calculé) : ces notifications ne sont qu'un aval.
    it('ne lève pas quand n8n refuse la requête', async () => {
      fetchMock.mockResolvedValue(new Response('erreur', { status: 500 }));

      await expect(new N8nService().notifyMatch(matchPayload)).resolves.toBeUndefined();
    });

    it('ne lève pas quand le réseau échoue', async () => {
      fetchMock.mockRejectedValue(new Error('ECONNREFUSED'));

      await expect(new N8nService().notifyMissionPourvue(pourvuePayload)).resolves.toBeUndefined();
    });
  });
});

// Le contrat ne part plus en pièce jointe : chacun reçoit un lien vers le sien, à signer sur
// CADANS. Ce test garde la porte fermée — réintroduire le PDF ferait transiter l'état civil du
// salarié sur un webhook à chaque mission pourvue, pour un document qui ne peut pas y être signé.
describe('N8nService — charge utile « mission pourvue »', () => {
  it('n’envoie aucun contrat en pièce jointe', async () => {
    const env = process.env;
    process.env = { ...env, N8N_MISSION_POURVUE_URL: 'https://n8n.example/webhook/pourvue' };
    const fetchMock = jest.fn().mockResolvedValue(new Response(null, { status: 200 }));
    global.fetch = fetchMock as unknown as typeof fetch;

    await new N8nService().notifyMissionPourvue(pourvuePayload);

    const corps = JSON.parse(String(fetchMock.mock.calls[0][1].body)) as Record<string, unknown>;
    expect(Object.keys(corps)).toEqual(['interimaire', 'entreprise', 'mission']);
    expect(JSON.stringify(corps)).not.toContain('JVBER');
    // L'URL de la mission, en revanche, est indispensable : le workflow en déduit l'adresse
    // du site pour construire les liens de signature.
    expect((corps.mission as { url: string }).url).toContain('/missions/');

    process.env = env;
  });
});
