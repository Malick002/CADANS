import { Injectable, Logger } from '@nestjs/common';

export interface MatchNotificationPayload {
  interimaire: { prenom: string; nom: string; email: string };
  entreprise: { email: string };
  mission: {
    titre: string;
    entreprise: string;
    ville: string;
    codePostal: string;
    dateDebut: string;
    remuneration: string;
    url: string;
  };
  score: number;
}

export interface MissionPourvuePayload {
  interimaire: { prenom: string; nom: string; email: string };
  entreprise: { email: string };
  mission: {
    titre: string;
    ville: string;
    codePostal: string;
    dateDebut: string;
    dateFin: string;
    remuneration: string;
    // C'est d'elle que le workflow déduit l'adresse du site pour construire les liens de
    // signature : elle n'est pas décorative.
    url: string;
  };
}

// Le contrat ne part PLUS en pièce jointe. Le workflow envoie à chacun un lien vers son
// contrat à signer sur CADANS — un PDF joint ne peut pas être signé, et il circule ensuite
// hors de toute trace. Envoyer quand même le document entier sur un webhook qui n'en fait
// rien, c'était transporter des données personnelles pour rien : l'état civil du salarié et
// son numéro de sécurité sociale masqué traversaient le réseau à chaque mission pourvue.

/**
 * Appel des deux workflows n8n à webhook (n8n/README.md ; le troisième, le rappel, est
 * planifié dans n8n et n'appelle pas l'API), par requête
 * HTTP avec le fetch natif de Node : aucune dépendance ajoutée, comme apps/api/src/mail.
 *
 * Tant que l'URL du webhook n'est pas renseignée, l'appel est journalisé au lieu d'être
 * envoyé — l'équipe travaille en local sans workflow n8n actif. Un envoi raté ne lève
 * jamais : ces notifications sont un aval de l'action principale (mission mise à jour,
 * matching calculé), jamais une condition de sa réussite.
 */
@Injectable()
export class N8nService {
  private readonly logger = new Logger(N8nService.name);
  private readonly matchNotificationUrl = process.env.N8N_MATCH_NOTIFICATION_URL?.trim() ?? '';
  private readonly missionPourvueUrl = process.env.N8N_MISSION_POURVUE_URL?.trim() ?? '';

  async notifyMatch(payload: MatchNotificationPayload): Promise<void> {
    await this.post(this.matchNotificationUrl, payload, 'match-notification');
  }

  async notifyMissionPourvue(payload: MissionPourvuePayload): Promise<void> {
    await this.post(this.missionPourvueUrl, payload, 'mission-pourvue');
  }

  private async post(url: string, body: unknown, label: string): Promise<void> {
    if (!url) {
      this.logger.warn(`Webhook n8n « ${label} » désactivé (URL absente de l'environnement).`);
      return;
    }

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!response.ok) {
        this.logger.warn(`Webhook n8n « ${label} » a répondu ${response.status}`);
      }
    } catch (error) {
      this.logger.warn(`Webhook n8n « ${label} » injoignable : ${(error as Error).message}`);
    }
  }
}
