import { Logger } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { NextFunction, Request, Response } from 'express';
import { AppModule } from './app.module';
import { configureApp } from './app.setup';
import { allowedWebOrigin } from './auth/session-cookie';

async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);

  // Validation systématique des payloads entrants (voir app.setup.ts).
  configureApp(app);

  // `trust proxy` : sans lui, derrière le répartiteur de l'hébergeur, `request.ip` vaut
  // l'adresse du proxy et non celle du client. Ça n'a pas d'importance pour la plupart des
  // routes ; ça en a pour la preuve de signature d'un contrat, qui conserve cette adresse.
  // Une preuve fausse est pire qu'une preuve absente.
  //
  // Activé en production seulement : en local il n'y a pas de proxy, et faire confiance à
  // `X-Forwarded-For` sur un serveur joignable directement laisserait n'importe qui choisir
  // l'adresse qui sera écrite dans la preuve.
  if (process.env.NODE_ENV === 'production') {
    // `getHttpAdapter()` et non `app.set` : INestApplication n'expose pas les réglages
    // d'Express, c'est l'adaptateur qui les porte.
    app.getHttpAdapter().getInstance().set('trust proxy', 1);
  }

  // Chiffrement en transit : en production, Render sert l'API et le site en HTTPS. HSTS
  // interdit ensuite au navigateur de revenir en HTTP clair vers l'API.
  if (process.env.NODE_ENV === 'production') {
    app.use((_request: Request, response: Response, next: NextFunction) => {
      response.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
      next();
    });
  }

  // Avec une session en cookie, l'origine doit être explicite : `origin: true` autoriserait
  // n'importe quel site à appeler l'API avec la session de l'utilisateur et à lire la réponse.
  app.enableCors({ origin: allowedWebOrigin(), credentials: true });

  // `PORT` d'abord : Render (comme la plupart des hébergeurs) impose le port à l'application
  // et coupe le service si elle écoute ailleurs. `API_PORT` reste pour le poste de travail,
  // où 3001 doit rester stable puisque NEXT_PUBLIC_API_URL le vise en dur.
  const port = Number(process.env.PORT ?? process.env.API_PORT ?? 3001);
  await app.listen(port);
  Logger.log(`API CADANS démarrée sur le port ${port}`, 'Bootstrap');
}

void bootstrap();
