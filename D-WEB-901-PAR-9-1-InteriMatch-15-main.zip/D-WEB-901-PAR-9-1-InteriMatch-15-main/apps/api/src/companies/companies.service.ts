import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateCompanyProfileDto } from './dto/update-company-profile.dto';

export interface CompanyProfileView {
  legalName: string;
  siret: string;
  nafCode: string;
  contactFirstName: string;
  contactLastName: string;
  phone: string | null;
  addressLine: string;
  postalCode: string;
  city: string;
}

const SELECT = {
  legalName: true,
  siret: true,
  nafCode: true,
  contactFirstName: true,
  contactLastName: true,
  phone: true,
  addressLine: true,
  postalCode: true,
  city: true,
} as const;

@Injectable()
export class CompaniesService {
  constructor(private readonly prisma: PrismaService) {}

  async getProfile(userId: string): Promise<CompanyProfileView> {
    const company = await this.prisma.company.findUnique({ where: { userId }, select: SELECT });
    if (!company) {
      throw new NotFoundException('Profil entreprise introuvable');
    }
    return company;
  }

  async updateProfile(userId: string, dto: UpdateCompanyProfileDto): Promise<CompanyProfileView> {
    const company = await this.prisma.company.findUnique({
      where: { userId },
      select: { id: true },
    });
    if (!company) {
      throw new NotFoundException('Profil entreprise introuvable');
    }

    return this.prisma.company.update({
      where: { id: company.id },
      data: {
        legalName: dto.legalName,
        contactFirstName: dto.contactFirstName,
        contactLastName: dto.contactLastName,
        phone: dto.phone ?? null,
        addressLine: dto.addressLine,
        postalCode: dto.postalCode,
        city: dto.city,
      },
      select: SELECT,
    });
  }
}
