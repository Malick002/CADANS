import { NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CompaniesService } from './companies.service';
import { UpdateCompanyProfileDto } from './dto/update-company-profile.dto';

const profile = {
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  phone: null,
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

const dto: UpdateCompanyProfileDto = {
  legalName: 'Entrepôt du Nord (renommé)',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  phone: '0612345678',
  addressLine: '14 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

describe('CompaniesService', () => {
  let prisma: { company: { findUnique: jest.Mock; update: jest.Mock } };
  let service: CompaniesService;

  beforeEach(() => {
    prisma = {
      company: {
        findUnique: jest.fn().mockResolvedValue(profile),
        update: jest.fn().mockResolvedValue({ ...profile, ...dto }),
      },
    };
    service = new CompaniesService(prisma as unknown as PrismaService);
  });

  it("renvoie le profil de l'entreprise connectée", async () => {
    const view = await service.getProfile('user-1');

    expect(prisma.company.findUnique).toHaveBeenCalledWith(
      expect.objectContaining({ where: { userId: 'user-1' } }),
    );
    expect(view).toEqual(profile);
  });

  it('refuse un compte sans profil entreprise', async () => {
    prisma.company.findUnique.mockResolvedValueOnce(null);

    await expect(service.getProfile('user-1')).rejects.toThrow(NotFoundException);
  });

  it('met à jour les coordonnées, jamais le SIRET ni le code NAF', async () => {
    prisma.company.findUnique.mockResolvedValueOnce({ id: 'company-1' });

    await service.updateProfile('user-1', dto);

    const { data } = prisma.company.update.mock.calls[0][0];
    expect(data).toEqual({
      legalName: dto.legalName,
      contactFirstName: dto.contactFirstName,
      contactLastName: dto.contactLastName,
      phone: dto.phone,
      addressLine: dto.addressLine,
      postalCode: dto.postalCode,
      city: dto.city,
    });
    expect(data).not.toHaveProperty('siret');
    expect(data).not.toHaveProperty('nafCode');
  });

  it('refuse la mise à jour pour un compte sans profil entreprise', async () => {
    prisma.company.findUnique.mockResolvedValueOnce(null);

    await expect(service.updateProfile('user-1', dto)).rejects.toThrow(NotFoundException);
    expect(prisma.company.update).not.toHaveBeenCalled();
  });
});
