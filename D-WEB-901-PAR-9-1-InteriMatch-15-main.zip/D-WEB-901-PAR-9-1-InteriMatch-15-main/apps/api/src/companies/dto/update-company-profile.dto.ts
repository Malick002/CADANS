import { IsNotEmpty, IsOptional, IsString, Matches, MaxLength } from 'class-validator';
import { PHONE_PATTERN, POSTAL_CODE_PATTERN, StripSpaces, Trim } from '../../auth/dto/validation';

// SIRET et code NAF n'y figurent pas : identité légale de l'entreprise, non modifiable depuis
// ce formulaire (à la différence des coordonnées, qui peuvent changer).
export class UpdateCompanyProfileDto {
  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  legalName: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  contactFirstName: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  contactLastName: string;

  @IsOptional()
  @StripSpaces()
  @Matches(PHONE_PATTERN, { message: "Le numéro de téléphone n'est pas valide" })
  phone?: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  addressLine: string;

  @Trim()
  @Matches(POSTAL_CODE_PATTERN, { message: 'Le code postal doit comporter 5 chiffres' })
  postalCode: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  city: string;
}
