import { Body, Controller, Get, Put } from '@nestjs/common';
import { Role } from '@prisma/client';
import { CurrentUser, Roles } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import { CompaniesService, CompanyProfileView } from './companies.service';
import { UpdateCompanyProfileDto } from './dto/update-company-profile.dto';

@Roles(Role.COMPANY)
@Controller('companies/me')
export class CompaniesController {
  constructor(private readonly companies: CompaniesService) {}

  @Get()
  get(@CurrentUser() user: SessionUser): Promise<CompanyProfileView> {
    return this.companies.getProfile(user.id);
  }

  @Put()
  update(
    @CurrentUser() user: SessionUser,
    @Body() dto: UpdateCompanyProfileDto,
  ): Promise<CompanyProfileView> {
    return this.companies.updateProfile(user.id, dto);
  }
}
