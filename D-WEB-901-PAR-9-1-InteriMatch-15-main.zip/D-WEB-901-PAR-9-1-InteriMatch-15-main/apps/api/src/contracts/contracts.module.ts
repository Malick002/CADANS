import { Module } from '@nestjs/common';
import { ContractPdfService } from './contract-pdf.service';
import { ContractsController } from './contracts.controller';
import { ContractsService } from './contracts.service';

@Module({
  controllers: [ContractsController],
  providers: [ContractPdfService, ContractsService],
  exports: [ContractPdfService, ContractsService],
})
export class ContractsModule {}
