import { ContractType } from '@prisma/client';
import { PDFArray, PDFDocument, PDFRawStream, decodePDFRawStream } from 'pdf-lib';
import {
  ContratData,
  ContractPdfService,
  InformationsEmbaucheManquantesError,
} from './contract-pdf.service';

const entreprise = {
  nom: 'Entrepôt du Nord',
  siret: '73282932000074',
  adresse: '12 rue des Docks, 95700 Roissy-en-France',
  signataireNom: 'Nadia Benali',
  signataireQualite: 'Responsable d’exploitation',
};

const interimaire = {
  prenom: 'Camille',
  nom: 'Martin',
  ville: 'Roissy-en-France',
  codePostal: '95700',
};

const etatCivil = {
  dateNaissance: '1988-03-17',
  lieuNaissance: 'Dakar',
  paysNaissance: 'Sénégal',
  nationalite: 'Française',
  adresse: '14 avenue de la Gare, 95700 Roissy-en-France',
  nirMasque: '•••••••••••3456',
};

const mission = {
  titre: 'Cariste',
  motifRecours: 'Accroissement temporaire d’activité',
  remplaceNom: null,
  remplaceQualification: null,
  lieu: 'Entrepôt du Nord — quai 4',
  codePostal: '95700',
  horaire: 'Matin (6h – 14h)',
  dateDebut: '2026-10-01',
  dateFin: '2026-10-31',
  remuneration: '13,50 € / h',
  habilitations: ['CACES R489-3'],
  caracteristiques: 'Chargement et déchargement au quai, gerbage en allée étroite.',
};

const contratDeMission: ContratData = {
  type: ContractType.MISSION,
  entreprise,
  interimaire,
  etatCivil,
  mission,
};

const miseADisposition: ContratData = {
  type: ContractType.MISE_A_DISPOSITION,
  entreprise,
  interimaire,
  etatCivil: null,
  mission,
};

/**
 * Texte réellement dessiné dans le PDF.
 *
 * Deux obstacles, tous deux vérifiés plutôt que supposés : pdf-lib range les objets dans des
 * flux compressés en Flate, donc chercher le texte dans les octets bruts ne trouve rien ; et
 * dans le flux de contenu, chaque chaîne est écrite en hexadécimal (`<48656C6C6F> Tj`), pas
 * en clair. On relit donc le document, on décode les flux de contenu de chaque page, puis les
 * chaînes hexadécimales. Les polices standard encodent en WinAnsi, que `latin1` relit sans
 * perte pour les caractères de la charte.
 */
async function texteDuPdf(base64: string): Promise<string> {
  const doc = await PDFDocument.load(Buffer.from(base64, 'base64'));
  const morceaux: string[] = [];

  for (const page of doc.getPages()) {
    const contenu = page.node.Contents();
    const references = contenu instanceof PDFArray ? contenu.asArray() : [contenu];

    for (const reference of references) {
      const flux = doc.context.lookup(reference);
      if (!(flux instanceof PDFRawStream)) {
        continue;
      }
      const instructions = Buffer.from(decodePDFRawStream(flux).decode()).toString('latin1');
      for (const [, hexadecimal] of instructions.matchAll(/<([0-9A-Fa-f]+)>\s*Tj/g)) {
        morceaux.push(winAnsi(Buffer.from(hexadecimal, 'hex')));
      }
    }
  }
  // Recollé par des espaces et non par des sauts de ligne : le service replie les phrases
  // longues, une mention légale peut donc s'étaler sur deux lignes du PDF.
  return morceaux.join(' ').replace(/\s+/g, ' ');
}

// WinAnsi (CP1252) place la ponctuation typographique dans la plage 0x80-0x9F, que `latin1`
// rend comme des caractères de contrôle invisibles. Sans cette table, « L’embauche » se
// relirait « Lembauche » et le test croirait à une apostrophe perdue.
const CP1252: Record<number, string> = {
  0x80: '€',
  0x85: '…',
  0x91: '‘',
  0x92: '’',
  0x93: '“',
  0x94: '”',
  // Ajouté avec le NIR masqué : le point médian du masque est 0x95 en CP1252, et `latin1`
  // le rendrait invisible — le test ne verrait alors aucun masque là où il y en a un.
  0x95: '•',
  0x96: '–',
  0x97: '—',
};

function winAnsi(octets: Buffer): string {
  return [...octets].map((octet) => CP1252[octet] ?? String.fromCharCode(octet)).join('');
}

async function fluxDe(donnees: ContratData = contratDeMission): Promise<string> {
  return texteDuPdf(await new ContractPdfService().generate(donnees));
}

describe('ContractPdfService — les deux documents', () => {
  it('produit un PDF valide, en base64', async () => {
    for (const donnees of [contratDeMission, miseADisposition]) {
      const bytes = Buffer.from(await new ContractPdfService().generate(donnees), 'base64');

      expect(bytes.subarray(0, 5).toString('latin1')).toBe('%PDF-');
      expect((await PDFDocument.load(bytes)).getPageCount()).toBeGreaterThanOrEqual(1);
    }
  });

  // Le L. 1251-16 1° impose de reproduire dans le contrat de mission les clauses du contrat
  // de mise à disposition : ce bloc doit donc être identique sur les deux documents. C'est
  // la raison pour laquelle un seul morceau de code l'écrit, et ce test le verrouille.
  it('porte les mêmes clauses de mission sur les deux documents', async () => {
    const mentions = [
      'Motif du recours : Accroissement temporaire d’activité',
      'Qualification professionnelle : Cariste',
      'Lieu de la mission : Entrepôt du Nord — quai 4 (95700)',
      'Horaire : Matin (6h – 14h)',
      'Terme : du 01/10/2026 au 31/10/2026',
      'Habilitations exigées : CACES R489-3',
    ];

    for (const donnees of [contratDeMission, miseADisposition]) {
      const flux = await fluxDe(donnees);
      for (const mention of mentions) {
        expect(flux).toContain(mention);
      }
    }
  });

  it('nomme CADANS comme employeur et entreprise de travail temporaire, sur les deux', async () => {
    for (const donnees of [contratDeMission, miseADisposition]) {
      const flux = await fluxDe(donnees);

      expect(flux).toContain('entreprise de travail temporaire');
      expect(flux).toContain('est l’employeur de l’intérimaire');
      expect(flux).toContain('Employeur : CADANS SAS');
      expect(flux).toContain('Société par actions simplifiée');
      expect(flux).toContain('12 rue de la Logistique');
      // Le test précédent verrouillait l'inverse (« ce document ne vaut pas contrat de
      // mission »). Le positionnement a changé le 22/09 : la mention est retournée, pas
      // supprimée — un document qui ne dirait plus qui engage qui serait pire.
      expect(flux).not.toContain('ne vaut pas contrat de mission');
    }
  });

  // Mentions de l'article L. 1251-16 6° et condition d'exercice de l'article L. 1251-49.
  // Les valeurs entières, pas seulement les libellés : une troncature silencieuse laisserait
  // croire à une donnée arrêtée là où elle ne l'est pas. C'est arrivé une fois.
  it('porte les organismes sociaux et la garantie financière de l’ETT', async () => {
    const flux = await fluxDe();

    expect(flux).toContain('Retraite complémentaire : Agirc-Arrco');
    expect(flux).toContain('Prévoyance : Malakoff Humanis Prévoyance');
    expect(flux).toContain('Garantie financière souscrite auprès d’un établissement de crédit');
    expect(flux).toContain('150 000 €');
  });

  it('annonce sur chaque document qu’il est pédagogique et ses identifiants fictifs', async () => {
    for (const donnees of [contratDeMission, miseADisposition]) {
      const flux = await fluxDe(donnees);

      expect(flux).toContain('Document généré dans le cadre d’un projet pédagogique');
      expect(flux).toContain('fictifs');
    }
  });

  // La mention pédagogique est écrite sur TOUTES les pages : un document de trois pages dont
  // seule la dernière la porterait laisserait les deux premières circuler sans elle.
  it('répète la mention pédagogique sur chaque page d’un document long', async () => {
    const base64 = await new ContractPdfService().generate({
      ...contratDeMission,
      mission: {
        ...mission,
        caracteristiques: 'Gerbage en allée étroite, port de charges. '.repeat(120),
      },
    });
    const doc = await PDFDocument.load(Buffer.from(base64, 'base64'));
    expect(doc.getPageCount()).toBeGreaterThan(1);

    // Phrase exacte du pied de page, et non « projet pédagogique » : ces deux mots figurent
    // aussi dans le SIRET fictif et dans la mention d'en-tête, le compte serait faux.
    const occurrences =
      (await texteDuPdf(base64)).split('Document généré dans le cadre').length - 1;
    expect(occurrences).toBe(doc.getPageCount());
  });

  it('porte la liberté d’embauche, avec son apostrophe typographique', async () => {
    const flux = await fluxDe();

    expect(flux).toContain('L. 1251-16 7°');
    // « Lembauche » au lieu de « L’embauche » passerait inaperçu sans cette vérification :
    // les polices standard encodent en WinAnsi, pas en UTF-8.
    expect(flux).toContain('L’embauche de l’intérimaire');
  });

  // Ce que les documents ne couvrent pas est écrit SUR eux, pas seulement dans un commentaire
  // de code ou un fichier de documentation que personne ne lira en soutenance.
  it('énonce les mentions qu’il ne couvre pas, faute de donnée', async () => {
    const flux = await fluxDe();

    expect(flux).toContain('Mentions non couvertes par ce document');
    expect(flux).toContain('période d’essai');
    expect(flux).toContain('équipements de protection individuelle');
  });

  it('accepte une mission sans habilitation exigée et sans description', async () => {
    const base64 = await new ContractPdfService().generate({
      ...miseADisposition,
      mission: { ...mission, habilitations: [], caracteristiques: null },
    });

    expect(await texteDuPdf(base64)).toContain('Habilitations exigées : aucune');
  });
});

describe('ContractPdfService — contrat de mission (L. 1251-16)', () => {
  it('s’intitule contrat de mission et cite son article', async () => {
    const flux = await fluxDe();

    expect(flux).toContain('Contrat de mission');
    expect(flux).toContain('l’article L. 1251-16 du Code du travail');
  });

  it('porte l’état civil complet du salarié', async () => {
    const flux = await fluxDe();

    expect(flux).toContain('Salarié intérimaire : Camille Martin');
    expect(flux).toContain('Né(e) le 17/03/1988 à Dakar (Sénégal)');
    expect(flux).toContain('Nationalité : Française');
    expect(flux).toContain('Domicile : 14 avenue de la Gare, 95700 Roissy-en-France');
  });

  // Limite assumée du POC : le numéro n'est pas écrit en entier, et le document dit pourquoi
  // plutôt que de laisser croire à une troncature accidentelle.
  it('n’écrit du numéro de sécurité sociale que sa forme masquée, et l’explique', async () => {
    const flux = await fluxDe();

    expect(flux).toContain('Numéro de sécurité sociale : •••••••••••3456');
    expect(flux).toContain('volontairement masqué');
    expect(flux).not.toContain('•••••••••••3456 ' + '3456');
  });

  it('porte la rémunération et l’indemnité de fin de mission', async () => {
    const flux = await fluxDe();

    expect(flux).toContain('Rémunération : 13,50 € / h');
    expect(flux).toContain('L. 1251-32');
  });

  // L'entreprise utilisatrice n'est PAS partie au contrat de mission : elle y figure comme
  // lieu d'exécution. Confondre les deux était le défaut du document unique d'avant.
  it('présente l’entreprise utilisatrice comme lieu d’exécution, pas comme partie', async () => {
    const flux = await fluxDe();

    expect(flux).toContain('Entreprise d’accueil : Entrepôt du Nord');
    expect(flux).toContain('n’est pas partie au présent contrat');
    expect(flux).not.toContain('Représentée par Nadia Benali');
  });

  it('refuse d’être généré sans les informations d’embauche', async () => {
    await expect(
      new ContractPdfService().generate({ ...contratDeMission, etatCivil: null }),
    ).rejects.toBeInstanceOf(InformationsEmbaucheManquantesError);
  });
});

describe('ContractPdfService — contrat de mise à disposition (L. 1251-43)', () => {
  it('s’intitule contrat de mise à disposition et cite son article', async () => {
    const flux = await fluxDe(miseADisposition);

    expect(flux).toContain('Contrat de mise à disposition');
    expect(flux).toContain('l’article L. 1251-43 du Code du travail');
  });

  it('nomme l’entreprise utilisatrice comme partie et son signataire', async () => {
    const flux = await fluxDe(miseADisposition);

    expect(flux).toContain('Entreprise utilisatrice : Entrepôt du Nord');
    expect(flux).toContain('SIRET 73282932000074');
    expect(flux).toContain('Représentée par Nadia Benali, Responsable d’exploitation');
  });

  // Le champ est nullable en base : le générateur retombe sur « Représentant légal » plutôt
  // que d'inventer un titre qu'il ne connaît pas.
  it('retombe sur une qualité neutre quand le profil n’en porte pas', async () => {
    const flux = await fluxDe({
      ...miseADisposition,
      entreprise: { ...entreprise, signataireQualite: null },
    });

    expect(flux).toContain('Représentée par Nadia Benali, Représentant légal');
    expect(flux).not.toContain('Responsable d’exploitation');
  });

  /**
   * Minimisation (RGPD art. 5.1.c), et c'est le test le plus important du fichier : ce
   * document part chez l'entreprise utilisatrice. Elle a besoin de savoir QUI elle accueille,
   * pas où il est né ni quel est son numéro de sécurité sociale.
   */
  it('ne laisse filtrer aucune donnée d’état civil de l’intérimaire', async () => {
    const flux = await fluxDe(miseADisposition);

    expect(flux).toContain('Camille Martin');
    expect(flux).toContain('Commune de résidence : Roissy-en-France (95700)');

    for (const donnee of ['17/03/1988', 'Dakar', 'Sénégal', '14 avenue de la Gare', '3456']) {
      expect(flux).not.toContain(donnee);
    }
    expect(flux).toContain('ne sont pas communiqués');
  });

  it('porte la rémunération de référence et son article', async () => {
    const flux = await fluxDe(miseADisposition);

    expect(flux).toContain('Rémunération de référence : 13,50 € / h');
    expect(flux).toContain('L. 1251-43 6°');
  });
});

describe('ContractPdfService — motif du recours', () => {
  // Art. L. 1251-43 1° : un remplacement doit nommer le salarié remplacé et sa qualification.
  it('nomme le salarié remplacé quand le motif est un remplacement', async () => {
    const flux = await fluxDe({
      ...miseADisposition,
      mission: {
        ...mission,
        motifRecours: 'Remplacement d’un salarié absent',
        remplaceNom: 'Julien Lefevre',
        remplaceQualification: 'Cariste',
      },
    });

    expect(flux).toContain('Motif du recours : Remplacement d’un salarié absent');
    expect(flux).toContain('Salarié remplacé : Julien Lefevre — Cariste');
  });

  it('n’écrit aucune ligne de remplacement quand le motif est autre', async () => {
    expect(await fluxDe(miseADisposition)).not.toContain('Salarié remplacé');
  });
});
