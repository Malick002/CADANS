import { Equals, IsBoolean, IsNotEmpty, IsString, MaxLength } from 'class-validator';
import { Trim } from '../../auth/dto/validation';

/**
 * Signature d'un contrat. Deux champs, et les deux sont nécessaires.
 *
 * Le **nom tapé** est ce qui distingue une signature d'un clic : il est comparé à celui du
 * compte, et c'est lui qui figurera sur la page de signatures du document final.
 *
 * La **case d'acceptation** est un acte distinct du nom. Elle ne peut pas valoir `false` :
 * `@Equals(true)` et non `@IsBoolean()` seul, sinon un client pourrait poster
 * `{ accepte: false }` et signer quand même — l'API prendrait un refus pour un accord.
 */
export class SignerContratDto {
  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Saisissez votre nom complet pour signer' })
  @MaxLength(200)
  nomComplet: string;

  @IsBoolean()
  @Equals(true, { message: 'Vous devez accepter le contrat pour le signer' })
  accepte: boolean;
}
