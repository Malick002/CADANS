/**
 * Identité de CADANS en tant qu'**entreprise de travail temporaire**, employeur de
 * l'intérimaire et partie aux deux contrats que la loi impose.
 *
 * ⚠️ **TOUTES CES VALEURS SONT FICTIVES.** CADANS est un projet pédagogique
 * (Epitech D-WEB-901) et la société n'est pas immatriculée. Elles sont à remplacer par les valeurs
 * réelles avant toute exploitation, et il n'y a **qu'un seul endroit** à modifier : ce
 * fichier.
 *
 * Le SIRET et le RCS sont volontairement des suites de zéros plutôt que des numéros
 * plausibles : un identifiant inventé mais bien formé est **vérifiable** au registre du
 * commerce, et s'y révéler faux fait bien pire effet qu'un numéro manifestement neutre.
 *
 * Ce fichier fait autorité. `apps/web/src/app/(site)/mentions-legales/page.tsx` en est un
 * miroir — le site ne peut pas importer depuis l'API, même convention assumée que pour la
 * validation (`apps/web/src/lib/validation.ts`) et les libellés d'habilitation. Toute
 * modification ici doit y être répercutée.
 */
export const CADANS = {
  denomination: 'CADANS SAS',
  formeJuridique: 'Société par actions simplifiée au capital de 10 000 €',
  siret: '000 000 000 00000 (fictif — projet pédagogique)',
  rcs: 'Pontoise B 000 000 000 (fictif)',
  adresse: '12 rue de la Logistique, 95700 Roissy-en-France',

  // Mentions exigées au contrat de mission par l'article L. 1251-16 6° : la caisse de
  // retraite complémentaire et l'organisme de prévoyance dont relève l'ETT. Agirc-Arrco est
  // le régime unique de retraite complémentaire des salariés du privé, il ne dépend d'aucun
  // choix d'entreprise. L'organisme de prévoyance, lui, résulte d'un contrat souscrit :
  // **valeur fictive, projet pédagogique** — un organisme réel du secteur, choisi pour que
  // le document soit lisible, pas parce qu'un contrat existerait.
  retraiteComplementaire: 'Agirc-Arrco',
  prevoyance: 'Malakoff Humanis Prévoyance',

  // Condition d'exercice d'une entreprise de travail temporaire (art. L. 1251-49) : elle
  // doit justifier d'une garantie financière qui assure le paiement des salaires en cas de
  // défaillance. **Valeur fictive, projet pédagogique** — le montant réel est révisé chaque
  // année et dépend du chiffre d'affaires.
  garantieFinanciere:
    'Garantie financière souscrite auprès d’un établissement de crédit — montant : 150 000 € (valeur fictive)',

  // Bloc « Pour CADANS » des contrats signés.
  signataireNom: 'Kemil Saadouni',
  signataireQualite: 'Président',
} as const;

/**
 * Qualité du signataire de l'entreprise utilisatrice, quand son profil ne la renseigne pas
 * (`Company.signatoryRole` est nullable — les comptes créés avant ce champ n'en ont pas).
 *
 * « Représentant légal » et non un titre plausible comme « Responsable d'exploitation » :
 * c'est vrai de quiconque engage une société, quel que soit son titre réel, là où un titre
 * inventé affirmerait gratuitement une fonction qu'on ne connaît pas.
 */
export const QUALITE_SIGNATAIRE_PAR_DEFAUT = 'Représentant légal';

/**
 * Phrase portée en tête des documents générés. Elle a été **retournée le 22/09** : la version
 * précédente avertissait que CADANS n'était pas une ETT et que le document ne valait pas
 * contrat. Depuis le changement de positionnement, c'est l'inverse qu'il faut dire — et le
 * rappel que les identifiants sont fictifs reste nécessaire tant que la société n'existe pas.
 */
export const MENTION_EMPLOYEUR =
  `${CADANS.denomination}, entreprise de travail temporaire au sens des articles L. 1251-1 et ` +
  `suivants du Code du travail, est l’employeur de l’intérimaire et le met à disposition de ` +
  `l’entreprise utilisatrice désignée ci-dessous. Projet pédagogique : les identifiants ` +
  `d’entreprise figurant sur ce document sont fictifs.`;

/**
 * Pied de page porté par les deux contrats. La mention en tête (`MENTION_EMPLOYEUR`) dit qui
 * engage qui ; celle-ci dit ce que vaut le document. Les deux sont nécessaires : la première
 * est une clause, la seconde un avertissement, et les fondre ferait perdre l'une ou l'autre.
 */
export const MENTION_PEDAGOGIQUE =
  'Document généré dans le cadre d’un projet pédagogique. Les données d’identité de ' +
  'l’agence sont fictives.';
