import { BadRequestException, ConflictException, NotFoundException } from '@nestjs/common';
import {
  CertificationType,
  ContractType,
  MotifRecours,
  Role,
  Shift,
  SignatureParty,
} from '@prisma/client';
import { createHash } from 'node:crypto';
import { PDFDocument } from 'pdf-lib';
import { EncryptionService } from '../encryption/encryption.service';
import { PrismaService } from '../prisma/prisma.service';
import { ContractPdfService, ContratData } from './contract-pdf.service';
import { ContractsService } from './contracts.service';

const MISSION_ID = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
const WORKER_ID = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';
const NIR = '180127511600128';

function encryption(): EncryptionService {
  process.env.ENCRYPTION_KEY = Buffer.alloc(32, 7).toString('base64');
  return new EncryptionService();
}

function hiringInfo(chiffrement: EncryptionService) {
  return {
    birthDate: new Date('1988-03-17T00:00:00Z'),
    birthPlace: 'Dakar',
    birthCountry: 'Sénégal',
    nationality: 'Française',
    addressLine: '14 avenue de la Gare',
    addressPostalCode: '95700',
    addressCity: 'Roissy-en-France',
    nirEncrypted: chiffrement.encryptText(NIR, `hiring-nir:${WORKER_ID}`),
    ibanEncrypted: chiffrement.encryptText(
      'FR1420041010050500013M02606',
      `hiring-iban:${WORKER_ID}`,
    ),
  };
}

function missionRow(
  chiffrement: EncryptionService,
  options: { embauche?: boolean; status?: string } = {},
) {
  return {
    id: MISSION_ID,
    status: options.status ?? 'POURVUE',
    posteCode: '11679',
    siteLabel: 'Entrepôt du Nord — quai 4',
    postalCode: '95700',
    startDate: new Date('2026-10-01T00:00:00Z'),
    endDate: new Date('2026-10-31T00:00:00Z'),
    shift: Shift.MATIN,
    hourlyRate: { toString: () => '13.5' },
    description: 'Chargement et déchargement au quai.',
    motifRecours: MotifRecours.REMPLACEMENT,
    remplaceNom: 'Julien Lefevre',
    remplaceQualification: 'Cariste',
    poste: { label: 'Cariste' },
    company: {
      legalName: 'Entrepôt du Nord',
      siret: '73282932000074',
      addressLine: '12 rue des Docks',
      postalCode: '95700',
      city: 'Roissy-en-France',
      userId: 'user-entreprise',
      contactFirstName: 'Nadia',
      contactLastName: 'Benali',
      signatoryRole: 'Responsable d’exploitation',
    },
    habilitations: [{ type: CertificationType.CACES_R489_3 }],
    assignedWorker: {
      id: WORKER_ID,
      firstName: 'Camille',
      lastName: 'Martin',
      city: 'Roissy-en-France',
      postalCode: '95700',
      userId: 'user-interimaire',
      hiringInfo: options.embauche === false ? null : hiringInfo(chiffrement),
    },
  };
}

interface Stored {
  id: string;
  missionId: string;
  type: ContractType;
  pdfEncrypted: Uint8Array;
  sha256: string;
  generatedAt: Date;
  finalPdfEncrypted: Uint8Array | null;
  finalSha256: string | null;
  completedAt: Date | null;
}

interface SignatureRow {
  contractId: string;
  party: SignatureParty;
  userId: string | null;
  typedName: string;
  signedAt: Date;
  ip: string | null;
  userAgent: string | null;
  documentSha256: string;
}

/**
 * Doublure de la persistance des contrats et de leurs signatures. Le chiffrement, lui, est
 * réel : c'est le vrai EncryptionService, sans quoi « le PDF est stocké chiffré » ne serait
 * pas vérifié. Le générateur de PDF est doublé sauf mention contraire — les tests de rendu
 * sont dans contract-pdf.service.spec.ts.
 */
function harnais(options: { embauche?: boolean; status?: string; pdfReel?: boolean } = {}) {
  const chiffrement = encryption();
  const rows = new Map<string, Stored>();
  const signatures: SignatureRow[] = [];
  const cle = (missionId: string, type: ContractType) => `${missionId}:${type}`;
  const parId = (id: string) => [...rows.values()].find((row) => row.id === id) ?? null;

  const parties = {
    company: { userId: 'user-entreprise', contactFirstName: 'Nadia', contactLastName: 'Benali' },
    assignedWorker: { userId: 'user-interimaire', firstName: 'Camille', lastName: 'Martin' },
  };

  const avecRelations = (row: Stored) => ({
    ...row,
    signatures: signatures.filter((signature) => signature.contractId === row.id),
    mission: {
      ...parties,
      startDate: new Date('2026-10-01T00:00:00Z'),
      endDate: new Date('2026-10-31T00:00:00Z'),
      poste: { label: 'Cariste' },
      company: { ...parties.company, legalName: 'Entrepôt du Nord' },
      contracts: [...rows.values()].map((autre) => ({
        type: autre.type,
        completedAt: autre.completedAt,
      })),
    },
  });

  const prisma = {
    mission: {
      findUnique: () => Promise.resolve(missionRow(chiffrement, options)),
      findMany: () => Promise.resolve([{ id: MISSION_ID }]),
    },
    contract: {
      upsert: ({
        where,
        create,
      }: {
        where: { missionId_type: { missionId: string; type: ContractType } };
        create: Partial<Stored>;
      }) => {
        const { missionId, type } = where.missionId_type;
        const existant = rows.get(cle(missionId, type));
        const fusion = { ...(existant ?? {}), ...create } as Partial<Stored>;
        const row: Stored = {
          id: cle(missionId, type),
          missionId,
          type,
          pdfEncrypted: fusion.pdfEncrypted!,
          sha256: fusion.sha256!,
          generatedAt: fusion.generatedAt ?? new Date(),
          finalPdfEncrypted: fusion.finalPdfEncrypted ?? null,
          finalSha256: fusion.finalSha256 ?? null,
          completedAt: fusion.completedAt ?? null,
        };
        rows.set(cle(missionId, type), row);
        return Promise.resolve(row);
      },
      update: ({ where, data }: { where: { id: string }; data: Partial<Stored> }) => {
        const row = parId(where.id)!;
        Object.assign(row, data);
        return Promise.resolve(row);
      },
      findUnique: ({
        where,
      }: {
        where: { missionId_type?: { missionId: string; type: ContractType }; id?: string };
      }) => {
        const row = where.missionId_type
          ? (rows.get(cle(where.missionId_type.missionId, where.missionId_type.type)) ?? null)
          : parId(where.id!);
        return Promise.resolve(row ? avecRelations(row) : null);
      },
      findUniqueOrThrow: ({ where }: { where: { id: string } }) =>
        Promise.resolve(avecRelations(parId(where.id)!)),
      findMany: ({ where }: { where: { id?: string; type?: ContractType } }) =>
        Promise.resolve(
          [...rows.values()]
            .filter(
              (row) =>
                (where.id === undefined || row.id === where.id) &&
                (where.type === undefined || row.type === where.type),
            )
            .map(avecRelations),
        ),
    },
    contractSignature: {
      upsert: ({
        where,
        create,
        update,
      }: {
        where: { contractId_party: { contractId: string; party: SignatureParty } };
        create: Omit<SignatureRow, 'userId' | 'signedAt' | 'ip' | 'userAgent'> &
          Partial<SignatureRow>;
        update: Partial<SignatureRow>;
      }) => {
        const { contractId, party } = where.contractId_party;
        const existante = signatures.find(
          (signature) => signature.contractId === contractId && signature.party === party,
        );
        if (existante) {
          Object.assign(existante, update);
          return Promise.resolve(existante);
        }
        const row: SignatureRow = {
          ...create,
          userId: create.userId ?? null,
          signedAt: create.signedAt ?? new Date(),
          ip: create.ip ?? null,
          userAgent: create.userAgent ?? null,
        };
        signatures.push(row);
        return Promise.resolve(row);
      },
      create: ({ data }: { data: SignatureRow }) => {
        const row: SignatureRow = { ...data, signedAt: data.signedAt ?? new Date() };
        signatures.push(row);
        return Promise.resolve(row);
      },
    },
  } as unknown as PrismaService;

  const pdf = new ContractPdfService();
  const generees: ContratData[] = [];
  if (!options.pdfReel) {
    jest.spyOn(pdf, 'generate').mockImplementation((data: ContratData) => {
      generees.push(data);
      return Promise.resolve(Buffer.from(`PDF-${data.type}`).toString('base64'));
    });
    jest
      .spyOn(pdf, 'appendSignaturePage')
      .mockImplementation((original: Buffer) =>
        Promise.resolve(Buffer.concat([original, Buffer.from('-SIGNATURES')])),
      );
  }

  return {
    rows,
    signatures,
    generees,
    chiffrement,
    parId,
    service: new ContractsService(prisma, chiffrement, pdf),
  };
}

describe('ContractsService — génération', () => {
  it('génère et stocke les deux contrats quand tout est complet', async () => {
    const { service, rows, generees } = harnais();

    const resultat = await service.generateForMission(MISSION_ID);

    expect(resultat).toEqual({
      generes: [ContractType.MISE_A_DISPOSITION, ContractType.MISSION],
      contratDeMissionManquant: false,
    });
    expect(rows.size).toBe(2);
    expect(generees.map((d) => d.type)).toEqual([
      ContractType.MISE_A_DISPOSITION,
      ContractType.MISSION,
    ]);
  });

  // Toutes les mentions que les données permettent, vérifiées sur ce qui est PASSÉ au
  // générateur — c'est ici qu'on attrape une donnée oubliée en chemin, pas dans le PDF.
  it('passe au générateur les mentions obligatoires, motif du recours compris', async () => {
    const { service, generees } = harnais();
    await service.generateForMission(MISSION_ID);

    for (const data of generees) {
      expect(data.mission).toMatchObject({
        titre: 'Cariste',
        motifRecours: 'Remplacement d’un salarié absent',
        remplaceNom: 'Julien Lefevre',
        remplaceQualification: 'Cariste',
        lieu: 'Entrepôt du Nord — quai 4',
        codePostal: '95700',
        horaire: 'Matin (6h – 14h)',
        dateDebut: '2026-10-01',
        dateFin: '2026-10-31',
        remuneration: '13.5 € / h',
        habilitations: ['CACES R489-3'],
      });
      expect(data.entreprise).toMatchObject({
        nom: 'Entrepôt du Nord',
        siret: '73282932000074',
        adresse: '12 rue des Docks, 95700 Roissy-en-France',
        signataireNom: 'Nadia Benali',
        signataireQualite: 'Responsable d’exploitation',
      });
    }
  });

  // Le NIR ne doit jamais entrer en clair dans un document, pas même dans celui que
  // l'intérimaire est seul à pouvoir ouvrir : la règle du projet est que l'API ne le rende
  // jamais entier, et un PDF servi par une route HTTP est une sortie de l'API.
  it('ne transmet au contrat de mission que le NIR masqué', async () => {
    const { service, generees } = harnais();
    await service.generateForMission(MISSION_ID);

    const contratDeMission = generees.find((d) => d.type === ContractType.MISSION)!;
    expect(contratDeMission.etatCivil?.nirMasque).toBe('•••••••••••0128');
    expect(JSON.stringify(contratDeMission)).not.toContain(NIR);
  });

  // Minimisation : le document qui part chez l'entreprise utilisatrice ne porte pas l'état
  // civil du salarié. Le générateur n'a même pas la donnée en main.
  it('ne transmet aucun état civil au contrat de mise à disposition', async () => {
    const { service, generees } = harnais();
    await service.generateForMission(MISSION_ID);

    const miseADisposition = generees.find((d) => d.type === ContractType.MISE_A_DISPOSITION)!;
    expect(miseADisposition.etatCivil).toBeNull();
    expect(JSON.stringify(miseADisposition)).not.toContain('Dakar');
  });

  // Exigence de la tâche : le contrat de mission attend les informations d'embauche, la mise
  // à disposition part quand même. Un intérimaire retenu ne doit pas bloquer l'entreprise.
  it('génère la seule mise à disposition quand les informations d’embauche manquent', async () => {
    const { service, rows } = harnais({ embauche: false });

    const resultat = await service.generateForMission(MISSION_ID);

    expect(resultat).toEqual({
      generes: [ContractType.MISE_A_DISPOSITION],
      contratDeMissionManquant: true,
    });
    expect(rows.size).toBe(1);
  });

  it('ne génère rien pour une mission qui n’est pas pourvue', async () => {
    const { service, rows } = harnais({ status: 'OUVERTE' });

    expect(await service.generateForMission(MISSION_ID)).toEqual({
      generes: [],
      contratDeMissionManquant: false,
    });
    expect(rows.size).toBe(0);
  });

  it('remplace le contrat existant au lieu d’en empiler un second', async () => {
    const { service, rows } = harnais();

    await service.generateForMission(MISSION_ID);
    await service.generateForMission(MISSION_ID);

    expect(rows.size).toBe(2);
  });

  it('régénère les contrats de toutes les missions pourvues d’un intérimaire', async () => {
    const { service, rows } = harnais();

    await service.generateForWorker(WORKER_ID);

    expect(rows.size).toBe(2);
  });
});

describe('ContractsService — stockage', () => {
  it('chiffre le PDF et journalise l’empreinte du document en clair', async () => {
    const { service, rows, chiffrement } = harnais();
    await service.generateForMission(MISSION_ID);

    const stocke = [...rows.values()].find((r) => r.type === ContractType.MISSION)!;
    const enClair = Buffer.from('PDF-MISSION');

    expect(Buffer.from(stocke.pdfEncrypted).toString('latin1')).not.toContain('PDF-MISSION');
    // L'empreinte porte sur le PDF en clair : le chiffré change à chaque écriture (IV
    // aléatoire) et ne pourrait servir de référence à une signature.
    expect(stocke.sha256).toBe(createHash('sha256').update(enClair).digest('hex'));
    expect(
      chiffrement.decrypt(stocke.pdfEncrypted, `contract:${MISSION_ID}:MISSION`).toString('latin1'),
    ).toBe('PDF-MISSION');
  });

  // Le contexte lie le chiffré à la mission ET au type : recopier le PDF d'un contrat dans
  // l'autre ligne le rend indéchiffrable au lieu de le révéler.
  it('lie le chiffré à la mission et au type', async () => {
    const { service, rows, chiffrement } = harnais();
    await service.generateForMission(MISSION_ID);

    const stocke = [...rows.values()].find((r) => r.type === ContractType.MISSION)!;
    expect(() =>
      chiffrement.decrypt(stocke.pdfEncrypted, `contract:${MISSION_ID}:MISE_A_DISPOSITION`),
    ).toThrow();
  });
});

describe('ContractsService — qui voit quoi', () => {
  // L'entreprise n'est pas partie au contrat de mission et il porte l'état civil du salarié :
  // elle n'y accède pas, même avec l'identifiant exact. 404 et non 403 — un 403 confirmerait
  // qu'un contrat porte cet identifiant.
  it('refuse à l’entreprise le contrat de mission, et à l’intérimaire la mise à disposition', async () => {
    const { service } = harnais();
    await service.generateForMission(MISSION_ID);

    await expect(
      service.read('user-entreprise', Role.COMPANY, `${MISSION_ID}:MISSION`),
    ).rejects.toBeInstanceOf(NotFoundException);
    await expect(
      service.read('user-interimaire', Role.WORKER, `${MISSION_ID}:MISE_A_DISPOSITION`),
    ).rejects.toBeInstanceOf(NotFoundException);
  });

  it('sert à chacun son document', async () => {
    const { service } = harnais();
    await service.generateForMission(MISSION_ID);

    const cote_interimaire = await service.read(
      'user-interimaire',
      Role.WORKER,
      `${MISSION_ID}:MISSION`,
    );
    expect(cote_interimaire.filename).toBe('contrat-de-mission.pdf');

    const cote_entreprise = await service.read(
      'user-entreprise',
      Role.COMPANY,
      `${MISSION_ID}:MISE_A_DISPOSITION`,
    );
    expect(cote_entreprise.filename).toBe('contrat-de-mise-a-disposition.pdf');
  });

  it('refuse un tiers, quel que soit son rôle', async () => {
    const { service } = harnais();
    await service.generateForMission(MISSION_ID);

    for (const role of [Role.WORKER, Role.COMPANY] as const) {
      await expect(
        service.read('user-inconnu', role, `${MISSION_ID}:MISSION`),
      ).rejects.toBeInstanceOf(NotFoundException);
    }
  });
});

const CONTEXTE = { ip: '203.0.113.7', userAgent: 'Mozilla/5.0 (test)' };
const ID_MISSION = `${MISSION_ID}:MISSION`;
const ID_MISE_A_DISPO = `${MISSION_ID}:MISE_A_DISPOSITION`;

describe('ContractsService — signature', () => {
  // CADANS établit les documents : lui faire cliquer sur un PDF produit par la machine
  // n'ajouterait aucune garantie. Sa signature est donc posée à la génération.
  it('signe automatiquement pour CADANS à la génération, sur l’empreinte du document', async () => {
    const { service, signatures, rows } = harnais();
    await service.generateForMission(MISSION_ID);

    expect(signatures.map((s) => s.party)).toEqual([SignatureParty.CADANS, SignatureParty.CADANS]);
    for (const signature of signatures) {
      expect(signature.typedName).toContain('Président');
      expect(signature.userId).toBeNull();
      expect(signature.documentSha256).toBe(
        [...rows.values()].find((row) => row.id === signature.contractId)!.sha256,
      );
    }
  });

  it('enregistre la preuve complète quand une partie signe', async () => {
    const { service, signatures, rows } = harnais();
    await service.generateForMission(MISSION_ID);

    await service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Camille Martin', CONTEXTE);

    const preuve = signatures.find((s) => s.party === SignatureParty.INTERIMAIRE)!;
    expect(preuve).toMatchObject({
      userId: 'user-interimaire',
      typedName: 'Camille Martin',
      ip: '203.0.113.7',
      userAgent: 'Mozilla/5.0 (test)',
      // Sur QUOI on s'engage : sans cette empreinte, la signature pourrait porter sur
      // n'importe quelle version du document.
      documentSha256: rows.get(`${MISSION_ID}:MISSION`)!.sha256,
    });
    expect(preuve.signedAt).toBeInstanceOf(Date);
  });

  // Le nom tapé est ce qui distingue une signature d'un clic. Il est comparé, mais sans
  // transformer le consentement en épreuve de saisie.
  it('accepte le nom aux accents, à la casse et aux espaces près', async () => {
    const { service } = harnais();
    await service.generateForMission(MISSION_ID);

    await expect(
      service.sign('user-interimaire', Role.WORKER, ID_MISSION, '  camille   MARTIN ', CONTEXTE),
    ).resolves.toBeDefined();
  });

  it('refuse un nom qui n’est pas celui du compte', async () => {
    const { service, signatures } = harnais();
    await service.generateForMission(MISSION_ID);

    await expect(
      service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Jean Dupont', CONTEXTE),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(signatures.some((s) => s.party === SignatureParty.INTERIMAIRE)).toBe(false);
  });

  it('refuse une seconde signature de la même partie, en 409', async () => {
    const { service } = harnais();
    await service.generateForMission(MISSION_ID);
    await service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Camille Martin', CONTEXTE);

    await expect(
      service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Camille Martin', CONTEXTE),
    ).rejects.toBeInstanceOf(ConflictException);
  });

  // On ne signe que son propre document : l'entreprise n'est pas partie au contrat de
  // mission. 404, comme pour la lecture — un 403 confirmerait qu'un contrat porte cet
  // identifiant.
  it('refuse de signer le document de l’autre partie', async () => {
    const { service } = harnais();
    await service.generateForMission(MISSION_ID);

    await expect(
      service.sign('user-entreprise', Role.COMPANY, ID_MISSION, 'Nadia Benali', CONTEXTE),
    ).rejects.toBeInstanceOf(NotFoundException);
    await expect(
      service.sign('user-interimaire', Role.WORKER, ID_MISE_A_DISPO, 'Camille Martin', CONTEXTE),
    ).rejects.toBeInstanceOf(NotFoundException);
  });

  it('produit le PDF final dès que les deux parties ont signé', async () => {
    const { service, parId } = harnais();
    await service.generateForMission(MISSION_ID);

    const avant = parId(ID_MISSION)!;
    expect(avant.completedAt).toBeNull();
    expect(avant.finalPdfEncrypted).toBeNull();

    const vue = await service.sign(
      'user-interimaire',
      Role.WORKER,
      ID_MISSION,
      'Camille Martin',
      CONTEXTE,
    );

    const apres = parId(ID_MISSION)!;
    expect(apres.completedAt).toBeInstanceOf(Date);
    expect(apres.finalPdfEncrypted).not.toBeNull();
    expect(apres.finalSha256).toMatch(/^[0-9a-f]{64}$/);
    expect(vue.signe).toBe(true);
    expect(vue.aSigner).toBe(false);
    // La mise à disposition de la même mission n'est PAS signée : la mission ne peut pas
    // être prête. Confondre les deux états annoncerait un démarrage qui n'a pas lieu d'être.
    expect(vue.missionPrete).toBe(false);
  });

  // Le document final remplace le brouillon à la lecture : personne ne doit pouvoir relire,
  // télécharger ou transmettre une version sans sa page de signatures.
  it('sert le document final une fois signé, et le nomme comme tel', async () => {
    const { service } = harnais();
    await service.generateForMission(MISSION_ID);

    const avant = await service.read('user-interimaire', Role.WORKER, ID_MISSION);
    expect(avant.filename).toBe('contrat-de-mission.pdf');
    expect(avant.content.toString('latin1')).toBe('PDF-MISSION');

    await service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Camille Martin', CONTEXTE);

    const apres = await service.read('user-interimaire', Role.WORKER, ID_MISSION);
    expect(apres.filename).toBe('contrat-de-mission-signe.pdf');
    expect(apres.content.toString('latin1')).toBe('PDF-MISSION-SIGNATURES');
  });

  /**
   * L'exigence « plus aucune modification possible » : elle ne tient pas à un bouton grisé
   * mais au refus de régénérer. Régénérer produirait d'autres octets, donc une autre
   * empreinte, et la signature conservée ne porterait plus sur rien.
   */
  it('refuse de régénérer un contrat signé', async () => {
    const { service, rows } = harnais();
    await service.generateForMission(MISSION_ID);
    await service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Camille Martin', CONTEXTE);

    const fige = { ...rows.get(`${MISSION_ID}:MISSION`)! };
    await service.generateForMission(MISSION_ID);

    const apres = rows.get(`${MISSION_ID}:MISSION`)!;
    expect(apres.sha256).toBe(fige.sha256);
    expect(apres.generatedAt).toEqual(fige.generatedAt);
    expect(apres.completedAt).toEqual(fige.completedAt);
  });

  // Le contrat de mise à disposition de la MÊME mission, lui, n'est pas signé : il doit
  // continuer de se régénérer. Le gel porte sur un document, pas sur la mission.
  it('continue de régénérer le document non signé de la même mission', async () => {
    const { service, rows } = harnais();
    await service.generateForMission(MISSION_ID);
    await service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Camille Martin', CONTEXTE);

    const avant = rows.get(`${MISSION_ID}:MISE_A_DISPOSITION`)!.generatedAt;
    await new Promise((resolve) => setTimeout(resolve, 5));
    await service.generateForMission(MISSION_ID);

    expect(rows.get(`${MISSION_ID}:MISE_A_DISPOSITION`)!.generatedAt).not.toEqual(avant);
  });

  it('n’annonce la mission prête que lorsque les DEUX contrats sont signés', async () => {
    const { service } = harnais();
    await service.generateForMission(MISSION_ID);

    await service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Camille Martin', CONTEXTE);
    expect((await service.listForWorker('user-interimaire'))[0]).toMatchObject({
      signe: true,
      missionPrete: false,
    });

    await service.sign('user-entreprise', Role.COMPANY, ID_MISE_A_DISPO, 'Nadia Benali', CONTEXTE);
    expect((await service.listForWorker('user-interimaire'))[0]).toMatchObject({
      missionPrete: true,
    });
    expect((await service.listForCompany('user-entreprise'))[0]).toMatchObject({
      missionPrete: true,
    });
  });

  // Un seul contrat existe (informations d'embauche manquantes) : même signé, la mission
  // n'est pas prête — il lui manque le contrat de mission.
  it('n’annonce pas la mission prête quand un seul contrat existe', async () => {
    const { service } = harnais({ embauche: false });
    await service.generateForMission(MISSION_ID);

    const vue = await service.sign(
      'user-entreprise',
      Role.COMPANY,
      ID_MISE_A_DISPO,
      'Nadia Benali',
      CONTEXTE,
    );
    expect(vue).toMatchObject({ signe: true, missionPrete: false });
  });

  it('dit à chaque partie si c’est à elle de signer', async () => {
    const { service } = harnais();
    await service.generateForMission(MISSION_ID);

    expect((await service.listForWorker('user-interimaire'))[0]).toMatchObject({
      aSigner: true,
      signe: false,
    });
    expect((await service.listForCompany('user-entreprise'))[0]).toMatchObject({
      aSigner: true,
      signe: false,
    });

    await service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Camille Martin', CONTEXTE);
    expect((await service.listForWorker('user-interimaire'))[0]).toMatchObject({
      aSigner: false,
      signe: true,
    });
  });
});

// Le PDF réel, cette fois : la page de signatures doit vraiment s'ajouter au document sans
// le régénérer, et sans écraser les pages d'origine.
describe('ContractsService — page de signatures sur un vrai PDF', () => {
  it('ajoute une page au document existant, sans toucher aux précédentes', async () => {
    const { service, chiffrement, parId } = harnais({ pdfReel: true });
    await service.generateForMission(MISSION_ID);

    const avant = await PDFDocument.load(
      chiffrement.decrypt(parId(ID_MISSION)!.pdfEncrypted, `contract:${MISSION_ID}:MISSION`),
    );

    await service.sign('user-interimaire', Role.WORKER, ID_MISSION, 'Camille Martin', CONTEXTE);

    const apres = await PDFDocument.load(
      chiffrement.decrypt(
        parId(ID_MISSION)!.finalPdfEncrypted!,
        `contract-final:${MISSION_ID}:MISSION`,
      ),
    );
    expect(apres.getPageCount()).toBe(avant.getPageCount() + 1);
  });
});
