import {
  BadRequestException,
  ConflictException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { ContractType, MissionStatus, Role, SignatureParty } from '@prisma/client';
import { createHash } from 'node:crypto';
import { EncryptionService } from '../encryption/encryption.service';
import { certificationLabel } from '../missions/certification-label';
import { motifRecoursLabel } from '../missions/motif-recours-label';
import { shiftLabel } from '../missions/shift-label';
import { PrismaService } from '../prisma/prisma.service';
import { masquer } from '../worker-profile/identifiants';
import { CADANS } from './cadans-identity';
import { ContractPdfService, ContratData, SignatureApposee } from './contract-pdf.service';

export interface SignatureView {
  party: SignatureParty;
  typedName: string;
  signedAt: Date;
}

export interface ContractView {
  id: string;
  type: ContractType;
  missionId: string;
  missionTitre: string;
  companyName: string;
  generatedAt: Date;
  // Empreinte du document tel qu'il est servi : celle du PDF final une fois signé, celle du
  // brouillon avant. C'est ce que l'écran affiche, et ce sur quoi la signature portera.
  sha256: string;
  signatures: SignatureView[];
  // Vrai quand les deux parties ont signé CE document : il est alors figé.
  signe: boolean;
  // Vrai quand les DEUX contrats de la mission sont signés. C'est autre chose : une mission
  // n'est pas prête à démarrer parce que l'entreprise a signé le sien, mais parce que plus
  // rien ne manque. Le dire à l'entreprise avant que l'intérimaire ait signé le sien serait
  // faux, et c'est exactement le genre de faux qu'on ne rattrape pas en soutenance.
  missionPrete: boolean;
  // Vrai quand c'est au tour du demandeur de signer. Règle métier calculée par l'API et non
  // par l'écran — comme les maxima du score de matching.
  aSigner: boolean;
  // Dates du terme, pour l'écran « prête à démarrer ».
  missionStartDate: string;
  missionEndDate: string;
}

export interface DecryptedContract {
  content: Buffer;
  filename: string;
}

/**
 * Résultat d'une génération. `contratDeMissionManquant` n'est pas une erreur : la mise à
 * disposition part toujours, le contrat de mission attend les informations d'embauche.
 */
export interface GenerationResult {
  generes: ContractType[];
  contratDeMissionManquant: boolean;
}

const NOMS_FICHIER: Record<ContractType, string> = {
  MISSION: 'contrat-de-mission',
  MISE_A_DISPOSITION: 'contrat-de-mise-a-disposition',
};

// Contexte de chiffrement : lié à la mission, au type ET à la variante. Recopier le PDF d'un
// contrat dans l'autre ligne — ou le brouillon dans la colonne du document final — le rend
// indéchiffrable, comme pour les justificatifs.
const contractContext = (missionId: string, type: ContractType): string =>
  `contract:${missionId}:${type}`;
const finalContext = (missionId: string, type: ContractType): string =>
  `contract-final:${missionId}:${type}`;

// Comparaison tolérante du nom saisi : accents, casse et espaces multiples ignorés. Exiger la
// frappe exacte d'un nom accentué transformerait le consentement en épreuve de saisie.
function normaliserNom(valeur: string): string {
  return valeur
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

const MISSION_INCLUDE = {
  poste: { select: { label: true } },
  company: {
    select: {
      legalName: true,
      siret: true,
      addressLine: true,
      postalCode: true,
      city: true,
      userId: true,
      contactFirstName: true,
      contactLastName: true,
      signatoryRole: true,
    },
  },
  habilitations: { select: { type: true } },
  assignedWorker: {
    select: {
      id: true,
      firstName: true,
      lastName: true,
      city: true,
      postalCode: true,
      userId: true,
      hiringInfo: true,
    },
  },
} as const;

/**
 * Génération, stockage et restitution des deux contrats.
 *
 * **Qui voit quoi.** Chaque partie accède à SON document, et à lui seul :
 *
 * - l'intérimaire retenu → le **contrat de mission**, qui porte son état civil ;
 * - l'entreprise utilisatrice → le **contrat de mise à disposition**.
 *
 * L'entreprise ne reçoit donc jamais le contrat de mission : elle n'y est pas partie, et il
 * contient des données qui ne la regardent pas (date de naissance, adresse, NIR masqué). Ce
 * n'est pas une restriction d'affichage mais la règle de la route — un identifiant de contrat
 * deviné ne donne rien de plus. C'est aussi ce qui rendra la signature de b2 lisible : chacun
 * signe le document qu'il est seul à pouvoir ouvrir.
 */
@Injectable()
export class ContractsService {
  private readonly logger = new Logger(ContractsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
    private readonly pdf: ContractPdfService,
  ) {}

  /**
   * Génère les contrats d'une mission pourvue et les stocke. Idempotent : régénérer remplace
   * la ligne existante (contrainte d'unicité `missionId + type`), il n'y a jamais deux
   * versions d'un même contrat en base.
   *
   * Appelée à deux moments, et c'est nécessaire : quand la mission passe POURVUE, et quand
   * l'intérimaire complète ses informations d'embauche. Sans le second appel, un intérimaire
   * retenu avant d'avoir rempli le formulaire n'aurait jamais son contrat de mission.
   */
  async generateForMission(missionId: string): Promise<GenerationResult> {
    const mission = await this.prisma.mission.findUnique({
      where: { id: missionId },
      include: MISSION_INCLUDE,
    });

    if (!mission?.assignedWorker || mission.status !== MissionStatus.POURVUE) {
      return { generes: [], contratDeMissionManquant: false };
    }

    const worker = mission.assignedWorker;
    const commun: Omit<ContratData, 'type' | 'etatCivil'> = {
      entreprise: {
        nom: mission.company.legalName,
        siret: mission.company.siret,
        adresse: `${mission.company.addressLine}, ${mission.company.postalCode} ${mission.company.city}`,
        signataireNom: `${mission.company.contactFirstName} ${mission.company.contactLastName}`,
        signataireQualite: mission.company.signatoryRole,
      },
      interimaire: {
        prenom: worker.firstName,
        nom: worker.lastName,
        ville: worker.city,
        codePostal: worker.postalCode,
      },
      mission: {
        titre: mission.poste.label,
        motifRecours: motifRecoursLabel(mission.motifRecours),
        remplaceNom: mission.remplaceNom,
        remplaceQualification: mission.remplaceQualification,
        lieu: mission.siteLabel,
        codePostal: mission.postalCode,
        horaire: shiftLabel(mission.shift),
        dateDebut: mission.startDate.toISOString().slice(0, 10),
        dateFin: mission.endDate.toISOString().slice(0, 10),
        remuneration: `${mission.hourlyRate.toString()} € / h`,
        habilitations: mission.habilitations.map((h) => certificationLabel(h.type)),
        caracteristiques: mission.description,
      },
    };

    const generes: ContractType[] = [];
    await this.store(missionId, ContractType.MISE_A_DISPOSITION, {
      ...commun,
      type: ContractType.MISE_A_DISPOSITION,
      etatCivil: null,
    });
    generes.push(ContractType.MISE_A_DISPOSITION);

    const info = worker.hiringInfo;
    if (!info) {
      this.logger.log(
        `Contrat de mission différé pour ${missionId} : informations d'embauche incomplètes.`,
      );
      return { generes, contratDeMissionManquant: true };
    }

    await this.store(missionId, ContractType.MISSION, {
      ...commun,
      type: ContractType.MISSION,
      etatCivil: {
        dateNaissance: info.birthDate.toISOString().slice(0, 10),
        lieuNaissance: info.birthPlace,
        paysNaissance: info.birthCountry,
        nationalite: info.nationality,
        adresse: `${info.addressLine}, ${info.addressPostalCode} ${info.addressCity}`,
        // Déchiffré ici pour être aussitôt masqué : la valeur en clair ne quitte pas cette
        // expression, et n'entre jamais dans le PDF.
        nirMasque: masquer(
          this.encryption.decryptText(info.nirEncrypted, `hiring-nir:${worker.id}`),
        ),
      },
    });
    generes.push(ContractType.MISSION);

    return { generes, contratDeMissionManquant: false };
  }

  /**
   * Régénère les contrats de toutes les missions pourvues d'un intérimaire. Appelée quand il
   * complète ses informations d'embauche : c'est le moment où un contrat de mission devient
   * possible, et il peut y avoir plusieurs missions en attente.
   */
  async generateForWorker(workerId: string): Promise<void> {
    const missions = await this.prisma.mission.findMany({
      where: { assignedWorkerId: workerId, status: MissionStatus.POURVUE },
      select: { id: true },
    });

    for (const mission of missions) {
      await this.generateForMission(mission.id);
    }
  }

  /** Contrats de mission de l'intérimaire connecté. */
  async listForWorker(userId: string): Promise<ContractView[]> {
    return this.list(
      { type: ContractType.MISSION, mission: { assignedWorker: { userId } } },
      userId,
      Role.WORKER,
    );
  }

  /** Contrats de mise à disposition des missions de l'entreprise connectée. */
  async listForCompany(userId: string): Promise<ContractView[]> {
    return this.list(
      { type: ContractType.MISE_A_DISPOSITION, mission: { company: { userId } } },
      userId,
      Role.COMPANY,
    );
  }

  /**
   * Document déchiffré, si le demandeur en est bien le destinataire.
   *
   * **404 et non 403** quand le contrat existe mais ne le concerne pas : répondre 403
   * confirmerait qu'un contrat porte cet identifiant, ce qu'un tiers n'a pas à apprendre.
   * C'est le même raisonnement que le cloisonnement des candidatures.
   */
  async read(userId: string, role: Role, contractId: string): Promise<DecryptedContract> {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: {
        mission: {
          select: {
            company: { select: { userId: true } },
            assignedWorker: { select: { userId: true } },
          },
        },
      },
    });

    if (!contract || !this.peutLire(contract, userId, role)) {
      throw new NotFoundException('Contrat introuvable');
    }

    // Le document final remplace le brouillon dès qu'il existe : personne ne doit pouvoir
    // relire, télécharger ou transmettre une version sans sa page de signatures.
    const signe = contract.finalPdfEncrypted !== null;
    return {
      content: signe
        ? this.encryption.decrypt(
            contract.finalPdfEncrypted!,
            finalContext(contract.missionId, contract.type),
          )
        : this.encryption.decrypt(
            contract.pdfEncrypted,
            contractContext(contract.missionId, contract.type),
          ),
      filename: `${NOMS_FICHIER[contract.type]}${signe ? '-signe' : ''}.pdf`,
    };
  }

  /**
   * Signature d'une partie, et production du PDF final quand les deux ont signé.
   *
   * Le nom saisi est comparé au nom attendu — celui du compte — mais de façon **tolérante** :
   * accents, casse et espaces multiples sont ignorés. Exiger la frappe exacte d'un nom
   * accentué sur un clavier quelconque transformerait le consentement en épreuve de saisie ;
   * ne rien comparer du tout ferait du champ une case à cocher déguisée.
   */
  async sign(
    userId: string,
    role: Role,
    contractId: string,
    typedName: string,
    contexte: { ip: string | null; userAgent: string | null },
  ): Promise<ContractView> {
    const contract = await this.prisma.contract.findUnique({
      where: { id: contractId },
      include: {
        signatures: true,
        mission: {
          select: {
            company: { select: { userId: true, contactFirstName: true, contactLastName: true } },
            assignedWorker: { select: { userId: true, firstName: true, lastName: true } },
          },
        },
      },
    });

    if (!contract || !this.peutLire(contract, userId, role)) {
      throw new NotFoundException('Contrat introuvable');
    }

    const party =
      contract.type === ContractType.MISSION
        ? SignatureParty.INTERIMAIRE
        : SignatureParty.ENTREPRISE;

    if (contract.signatures.some((signature) => signature.party === party)) {
      // 409 et non 400 : la demande est bien formée, c'est l'état de la ressource qui la
      // refuse. Même choix que la candidature sur une mission pourvue.
      throw new ConflictException('Ce contrat est déjà signé.');
    }

    const attendu =
      party === SignatureParty.INTERIMAIRE
        ? `${contract.mission.assignedWorker!.firstName} ${contract.mission.assignedWorker!.lastName}`
        : `${contract.mission.company.contactFirstName} ${contract.mission.company.contactLastName}`;

    if (normaliserNom(typedName) !== normaliserNom(attendu)) {
      throw new BadRequestException(
        `Le nom saisi ne correspond pas à celui du compte. Saisissez « ${attendu} ».`,
      );
    }

    await this.prisma.contractSignature.create({
      data: {
        contractId,
        party,
        userId,
        typedName: typedName.trim(),
        ip: contexte.ip,
        userAgent: contexte.userAgent?.slice(0, 500) ?? null,
        // L'empreinte du document TEL QU'IL A ÉTÉ LU : c'est sur lui qu'on s'engage, pas sur
        // une version recalculée après coup.
        documentSha256: contract.sha256,
      },
    });

    await this.finaliser(contractId);
    return (await this.list({ id: contractId }, userId, role))[0];
  }

  /**
   * Produit le PDF final : le document d'origine augmenté d'une page de signatures. Il n'est
   * PAS régénéré — les signatures portent sur l'empreinte du document lu et accepté, et
   * pdf-lib horodate ses fichiers : un document régénéré à l'identique n'aurait pas la même.
   */
  private async finaliser(contractId: string): Promise<void> {
    const contract = await this.prisma.contract.findUniqueOrThrow({
      where: { id: contractId },
      include: { signatures: { orderBy: { signedAt: 'asc' } } },
    });

    if (contract.signatures.length < 2 || contract.completedAt) {
      return;
    }

    const original = this.encryption.decrypt(
      contract.pdfEncrypted,
      contractContext(contract.missionId, contract.type),
    );
    const apposees: SignatureApposee[] = contract.signatures.map((signature) => ({
      party: signature.party,
      typedName: signature.typedName,
      signedAt: signature.signedAt,
      ip: signature.ip,
      userAgent: signature.userAgent,
      documentSha256: signature.documentSha256,
    }));

    const final = await this.pdf.appendSignaturePage(original, apposees);
    await this.prisma.contract.update({
      where: { id: contractId },
      data: {
        finalPdfEncrypted: this.encryption.encrypt(
          final,
          finalContext(contract.missionId, contract.type),
        ),
        finalSha256: createHash('sha256').update(final).digest('hex'),
        completedAt: new Date(),
      },
    });
  }

  private peutLire(
    contract: {
      type: ContractType;
      mission: { company: { userId: string }; assignedWorker: { userId: string } | null };
    },
    userId: string,
    role: Role,
  ): boolean {
    if (role === Role.ADMIN) {
      // Un agent CADANS agit pour l'employeur, partie aux deux contrats.
      return true;
    }
    if (contract.type === ContractType.MISSION) {
      return role === Role.WORKER && contract.mission.assignedWorker?.userId === userId;
    }
    return role === Role.COMPANY && contract.mission.company.userId === userId;
  }

  /**
   * Un contrat que sa contrepartie a signé est **figé**. Le régénérer produirait d'autres
   * octets — donc une autre empreinte — et la signature conservée ne porterait plus sur
   * rien. C'est la garantie que « plus aucune modification n'est possible » n'est pas
   * seulement une phrase à l'écran.
   */
  private async estFige(missionId: string, type: ContractType): Promise<boolean> {
    const contract = await this.prisma.contract.findUnique({
      where: { missionId_type: { missionId, type } },
      select: { signatures: { select: { party: true } } },
    });
    return (contract?.signatures ?? []).some((s) => s.party !== SignatureParty.CADANS);
  }

  private async store(missionId: string, type: ContractType, data: ContratData): Promise<void> {
    if (await this.estFige(missionId, type)) {
      this.logger.log(
        `Contrat ${type} de la mission ${missionId} déjà signé : régénération refusée.`,
      );
      return;
    }
    const base64 = await this.pdf.generate(data);
    const pdf = Buffer.from(base64, 'base64');
    // Empreinte du PDF EN CLAIR : le chiffré change à chaque écriture (IV aléatoire) et ne
    // pourrait pas servir de référence à une signature.
    const sha256 = createHash('sha256').update(pdf).digest('hex');
    const pdfEncrypted = this.encryption.encrypt(pdf, contractContext(missionId, type));

    const contract = await this.prisma.contract.upsert({
      where: { missionId_type: { missionId, type } },
      create: { missionId, type, pdfEncrypted, sha256, generatedAt: new Date() },
      update: { pdfEncrypted, sha256, generatedAt: new Date() },
      select: { id: true },
    });

    // CADANS signe à la génération : c'est elle qui établit le document, et faire cliquer un
    // agent sur un PDF produit par la machine n'ajouterait aucune garantie. La signature est
    // remplacée avec le document — son empreinte doit rester celle de ce qu'elle couvre.
    await this.prisma.contractSignature.upsert({
      where: { contractId_party: { contractId: contract.id, party: SignatureParty.CADANS } },
      create: {
        contractId: contract.id,
        party: SignatureParty.CADANS,
        typedName: `${CADANS.signataireNom}, ${CADANS.signataireQualite}`,
        documentSha256: sha256,
      },
      update: {
        typedName: `${CADANS.signataireNom}, ${CADANS.signataireQualite}`,
        documentSha256: sha256,
        signedAt: new Date(),
      },
    });
  }

  // `userId` n'est pas utilisé pour filtrer — le `where` l'a déjà fait — mais la signature
  // le garde : c'est `sign()` qui appelle cette méthode pour relire le contrat qu'il vient de
  // signer, et le jour où la liste dépendra du demandeur autrement que par son rôle, l'oubli
  // serait silencieux.
  private async list(where: object, _userId: string, role: Role): Promise<ContractView[]> {
    const contracts = await this.prisma.contract.findMany({
      where,
      include: {
        signatures: { orderBy: { signedAt: 'asc' } },
        mission: {
          select: {
            startDate: true,
            endDate: true,
            poste: { select: { label: true } },
            company: { select: { legalName: true } },
            // Les deux contrats de la mission, pour savoir si elle est prête à démarrer. La
            // requête reste unique : un second aller-retour par contrat n'apporterait rien.
            contracts: { select: { type: true, completedAt: true } },
          },
        },
      },
      orderBy: { generatedAt: 'desc' },
    });

    return contracts.map((contract) => {
      const attendue =
        contract.type === ContractType.MISSION
          ? SignatureParty.INTERIMAIRE
          : SignatureParty.ENTREPRISE;
      const deja = contract.signatures.some((signature) => signature.party === attendue);
      const roleAttendu = attendue === SignatureParty.INTERIMAIRE ? Role.WORKER : Role.COMPANY;

      return {
        id: contract.id,
        type: contract.type,
        missionId: contract.missionId,
        missionTitre: contract.mission.poste.label,
        companyName: contract.mission.company.legalName,
        generatedAt: contract.generatedAt,
        // L'empreinte du document SERVI : celle du final une fois signé. Afficher celle du
        // brouillon sous un document signé inviterait à comparer deux choses différentes.
        sha256: contract.finalSha256 ?? contract.sha256,
        signatures: contract.signatures.map((signature) => ({
          party: signature.party,
          typedName: signature.typedName,
          signedAt: signature.signedAt,
        })),
        signe: contract.completedAt !== null,
        // Les DEUX contrats doivent exister et être signés. S'il n'y en a qu'un — parce que
        // le contrat de mission attend encore les informations d'embauche — la mission n'est
        // pas prête, même si ce seul document est signé.
        missionPrete:
          contract.mission.contracts.length === 2 &&
          contract.mission.contracts.every((autre) => autre.completedAt !== null),
        aSigner: !deja && role === roleAttendu,
        missionStartDate: contract.mission.startDate.toISOString().slice(0, 10),
        missionEndDate: contract.mission.endDate.toISOString().slice(0, 10),
      };
    });
  }
}
