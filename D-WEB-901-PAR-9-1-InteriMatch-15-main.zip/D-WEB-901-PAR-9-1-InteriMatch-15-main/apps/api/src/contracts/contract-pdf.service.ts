import { Injectable } from '@nestjs/common';
import { ContractType, SignatureParty } from '@prisma/client';
import { PDFDocument, PDFFont, PDFPage, StandardFonts, rgb } from 'pdf-lib';
import {
  CADANS,
  MENTION_EMPLOYEUR,
  MENTION_PEDAGOGIQUE,
  QUALITE_SIGNATAIRE_PAR_DEFAUT,
} from './cadans-identity';

export interface ContratEntreprise {
  nom: string;
  siret: string;
  adresse: string;
  // Nom et qualité de qui signe pour l'entreprise utilisatrice. La qualité est nullable en
  // base : le générateur retombe sur QUALITE_SIGNATAIRE_PAR_DEFAUT plutôt que d'inventer.
  signataireNom: string;
  signataireQualite: string | null;
}

export interface ContratInterimaire {
  prenom: string;
  nom: string;
  ville: string;
  codePostal: string;
}

/**
 * Informations d'embauche, portées par le SEUL contrat de mission.
 *
 * Elles sont absentes du contrat de mise à disposition, et ce n'est pas un oubli :
 * l'entreprise utilisatrice n'est pas l'employeur, la date de naissance et l'adresse de
 * l'intérimaire ne lui servent à rien pour une mise à disposition (RGPD art. 5.1.c).
 *
 * `nirMasque` : quatre derniers chiffres seulement. Un contrat de mission réel porte le NIR
 * entier ; ici le document est téléchargeable par une route HTTP, et la règle du projet est
 * que l'API ne rende jamais ce numéro en clair. Le choix est assumé et écrit dans
 * docs/contrat-mentions-obligatoires.md — c'est une limite du POC, pas une lecture du droit.
 */
export interface ContratEtatCivil {
  dateNaissance: string;
  lieuNaissance: string;
  paysNaissance: string;
  nationalite: string;
  adresse: string;
  nirMasque: string;
}

export interface ContratMission {
  // Intitulé du poste au référentiel ROME. Il tient lieu de qualification professionnelle
  // exigée (L. 1251-43 4°) comme de qualification du salarié (L. 1251-16 2°), faute d'un
  // champ de qualification propre au profil — approximation documentée.
  titre: string;
  motifRecours: string;
  // Renseignés seulement quand le motif est un remplacement (L. 1251-43 1°).
  remplaceNom: string | null;
  remplaceQualification: string | null;
  // Site d'affectation et code postal : ensemble, ils forment le « lieu de la mission ».
  lieu: string;
  codePostal: string;
  // Libellé du créneau, faute d'horaire précis en base (voir shift-label.ts).
  horaire: string;
  dateDebut: string;
  dateFin: string;
  remuneration: string;
  // Habilitations exigées, en clair (« CACES R489-3 ») : caractéristiques du poste.
  habilitations: string[];
  // Description libre saisie par l'entreprise, seul support des caractéristiques du poste.
  caracteristiques: string | null;
}

export interface ContratData {
  type: ContractType;
  entreprise: ContratEntreprise;
  interimaire: ContratInterimaire;
  // Exigé pour un contrat de mission, ignoré pour une mise à disposition.
  etatCivil: ContratEtatCivil | null;
  mission: ContratMission;
}

/** Une signature apposée, telle qu'elle est rendue sur la page de signatures. */
export interface SignatureApposee {
  party: SignatureParty;
  typedName: string;
  signedAt: Date;
  ip: string | null;
  userAgent: string | null;
  documentSha256: string;
}

export class InformationsEmbaucheManquantesError extends Error {
  constructor() {
    super(
      'Le contrat de mission ne peut pas être établi : les informations d’embauche de ' +
        'l’intérimaire sont incomplètes.',
    );
  }
}

const PAGE_WIDTH = 595.28;
const PAGE_HEIGHT = 841.89; // A4 en points
const MARGIN_X = 56;
const BAND_HEIGHT = 70;
const START_Y = PAGE_HEIGHT - BAND_HEIGHT - 50;
// Relevé pour laisser place au pied de page, qui est écrit APRÈS le corps du document : sans
// cette réserve, la dernière ligne de texte et la mention pédagogique se chevauchaient.
const BAS_DE_PAGE = 84;
const LARGEUR_UTILE = PAGE_WIDTH - 2 * MARGIN_X;

// Jetons de la refonte du 21/09 (docs/charte-graphique.md, et apps/web/src/app/globals.css),
// en RGB 0-1.
const ANTHRACITE = rgb(0.078, 0.094, 0.114); // #14181D — --c-ink, 17,8:1 sur blanc
const MUTED = rgb(0.435, 0.435, 0.435); // #6F6F6F — --c-muted, 5,0:1 sur blanc
const BLANC = rgb(1, 1, 1); // #FFFFFF — --c-bg, 17,8:1 sur l'encre du bandeau

// Mention fixe du Code du travail : toute clause interdisant l'embauche de l'intérimaire par
// l'entreprise utilisatrice à l'issue de la mission est réputée non écrite (L. 1251-43,
// dernier alinéa), et la mention doit figurer au contrat de mission (L. 1251-16 7°).
const MENTION_EMBAUCHE =
  'L’embauche de l’intérimaire par l’entreprise utilisatrice à l’issue de la mission n’est pas ' +
  'interdite (art. L. 1251-16 7° et L. 1251-43 du Code du travail).';

// Taux légal de l'indemnité de fin de mission (art. L. 1251-32). Les modalités de rémunération
// doivent l'inclure (L. 1251-16 3°). Les cas d'exclusion prévus par la loi ne sont pas modélisés.
const MENTION_IFM =
  'Indemnité de fin de mission : 10 % de la rémunération totale brute due au titre de la ' +
  'mission (art. L. 1251-32), hors cas d’exclusion prévus par la loi.';

// Ce que les deux documents ne couvrent pas, dit par eux plutôt que par un commentaire de
// code. La liste est tenue à jour dans docs/contrat-mentions-obligatoires.md.
const MENTION_LACUNES =
  'Mentions non couvertes par ce document, faute de la donnée correspondante : durée de la ' +
  'période d’essai (art. L. 1251-16 4°), équipements de protection individuelle fournis ' +
  '(L. 1251-43 5°), primes et accessoires de salaire d’un salarié équivalent de l’entreprise ' +
  'utilisatrice (L. 1251-43 6°), horaire réel — seul le créneau est connu — et caractère à ' +
  'risques particuliers du poste (L. 1251-43 4°).';

// Le NIR n'est pas écrit en entier, et le document le dit plutôt que de laisser croire à une
// donnée tronquée par accident. Limite du POC, assumée : voir le commentaire de
// ContratEtatCivil et docs/contrat-mentions-obligatoires.md.
const MENTION_NIR_MASQUE =
  'Le numéro de sécurité sociale est volontairement masqué sur ce document : seuls ses ' +
  'quatre derniers chiffres y figurent. Le numéro complet est conservé chiffré par ' +
  'l’employeur et n’est restitué par aucune interface.';

// Libellé de chaque partie sur la page de signatures. « Pour CADANS » et non « CADANS » :
// c'est une personne qui engage la société, et le bloc nomme ensuite laquelle.
const PARTIES: Record<SignatureParty, string> = {
  CADANS: 'Pour l’employeur',
  INTERIMAIRE: 'Le salarié intérimaire',
  ENTREPRISE: 'Pour l’entreprise utilisatrice',
};

// Ce que vaut la signature, écrit sur le document plutôt que sous-entendu. « Simple » au sens
// du règlement eIDAS : pas de certificat qualifié, donc une présomption de fiabilité qui ne
// s'applique pas — ce que le document dit, au lieu de laisser croire le contraire.
const MENTION_SIGNATURE =
  'Signature électronique simple au sens du règlement (UE) n° 910/2014 (eIDAS), art. 3.10. ' +
  'Elle ne repose pas sur un certificat qualifié et ne bénéficie donc pas de la présomption ' +
  'de fiabilité de l’article 26. Sa valeur probante tient aux éléments conservés ci-dessus : ' +
  'identité du compte, nom saisi, horodatage, adresse IP, navigateur, et empreinte SHA-256 ' +
  'du document signé.';

const TITRES: Record<ContractType, string> = {
  MISSION: 'Contrat de mission',
  MISE_A_DISPOSITION: 'Contrat de mise à disposition',
};

const ARTICLES: Record<ContractType, string> = {
  MISSION: 'Établi en application de l’article L. 1251-16 du Code du travail.',
  MISE_A_DISPOSITION: 'Établi en application de l’article L. 1251-43 du Code du travail.',
};

/**
 * Les deux contrats du travail temporaire, en PDF (base64). pdf-lib : pas de navigateur
 * headless, une seule dépendance pure JS.
 *
 * **Deux documents, pas un.** Ils n'ont ni les mêmes parties ni le même contenu :
 *
 * - **Contrat de mission** (L. 1251-16) : CADANS ↔ **intérimaire**. L'entreprise utilisatrice
 *   y figure comme lieu d'exécution, pas comme partie. Il porte l'état civil du salarié.
 * - **Contrat de mise à disposition** (L. 1251-43) : CADANS ↔ **entreprise utilisatrice**.
 *   L'intérimaire y est nommé — prénom, nom, commune — mais rien de plus : ni date de
 *   naissance, ni adresse, ni numéro de sécurité sociale. Il ne le signe pas.
 *
 * Le L. 1251-16 1° impose de reproduire dans le contrat de mission les clauses du contrat de
 * mise à disposition : le corps « mission » et le corps « rémunération » sont donc communs,
 * et c'est volontairement le même code qui les écrit — deux copies divergeraient.
 *
 * Le logo est rendu en texte dans le bandeau, en blanc sur l'encre : c'est la règle de
 * apps/web/src/components/Logo.tsx, dont le symbole est en `currentColor`. pdf-lib n'intègre
 * que des images PNG/JPEG de toute façon, pas de SVG.
 */
@Injectable()
export class ContractPdfService {
  async generate(data: ContratData): Promise<string> {
    if (data.type === ContractType.MISSION && !data.etatCivil) {
      throw new InformationsEmbaucheManquantesError();
    }

    const doc = await PDFDocument.create();
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const bold = await doc.embedFont(StandardFonts.HelveticaBold);
    const plume = new Plume(doc, font, bold);

    plume.titre(TITRES[data.type]);
    plume.petit(ARTICLES[data.type]);
    plume.petit(MENTION_EMPLOYEUR);

    plume.section('Les parties');
    // L'employeur d'abord : c'est lui qui établit le document et qui s'engage.
    plume.cle(`Employeur : ${CADANS.denomination}`);
    plume.valeur(CADANS.formeJuridique);
    plume.valeur(`SIRET ${CADANS.siret} — RCS ${CADANS.rcs}`);
    plume.valeur(`Siège social : ${CADANS.adresse}`);
    plume.valeur(`Retraite complémentaire : ${CADANS.retraiteComplementaire}`);
    plume.valeur(`Prévoyance : ${CADANS.prevoyance}`);
    plume.valeur(CADANS.garantieFinanciere);

    if (data.type === ContractType.MISSION) {
      ecrireSalarie(plume, data.interimaire, data.etatCivil!);
      plume.section('Lieu d’exécution — entreprise utilisatrice');
      plume.petit(
        'L’entreprise utilisatrice n’est pas partie au présent contrat : elle accueille ' +
          'l’intérimaire au titre du contrat de mise à disposition conclu avec l’employeur.',
      );
      ecrireEntreprise(plume, data.entreprise, false);
    } else {
      ecrireEntreprise(plume, data.entreprise, true);
      plume.section('Intérimaire mis à disposition');
      // Minimisation (RGPD art. 5.1.c) : l'entreprise utilisatrice reçoit de quoi identifier
      // la personne qu'elle accueille, pas son état civil complet.
      plume.cle(`${data.interimaire.prenom} ${data.interimaire.nom}`);
      plume.valeur(
        `Commune de résidence : ${data.interimaire.ville} (${data.interimaire.codePostal})`,
      );
      plume.petit(
        'L’intérimaire n’est pas partie au présent contrat et ne le signe pas. Son état ' +
          'civil, son adresse et son numéro de sécurité sociale relèvent du contrat de ' +
          'mission conclu avec l’employeur, et ne sont pas communiqués.',
      );
    }

    ecrireMission(plume, data);
    ecrireRemuneration(plume, data);

    plume.section('Mentions légales');
    plume.valeur(MENTION_EMBAUCHE);
    if (data.type === ContractType.MISSION) {
      plume.valeur(MENTION_NIR_MASQUE);
    }
    plume.valeur(MENTION_LACUNES);

    plume.pied(MENTION_PEDAGOGIQUE);
    return Buffer.from(await doc.save()).toString('base64');
  }

  /**
   * Ajoute la page de signatures au document EXISTANT, sans le régénérer.
   *
   * C'est la seule façon correcte de procéder : les signatures portent sur l'empreinte du
   * document tel qu'il a été lu et accepté. Le régénérer, même à l'identique, produirait
   * d'autres octets — pdf-lib horodate le fichier — et l'empreinte conservée en preuve ne
   * correspondrait plus à rien.
   */
  async appendSignaturePage(pdf: Buffer, signatures: SignatureApposee[]): Promise<Buffer> {
    const doc = await PDFDocument.load(pdf);
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const bold = await doc.embedFont(StandardFonts.HelveticaBold);
    const plume = new Plume(doc, font, bold);

    plume.titre('Signatures');
    plume.petit(
      'Les parties ci-dessous ont accepté le document qui précède. Aucune modification ' +
        'n’est possible après signature : toute évolution demanderait un nouveau document.',
    );

    for (const signature of signatures) {
      plume.section(PARTIES[signature.party]);
      plume.cle(signature.typedName);
      plume.valeur(`Signé le ${dateHeureFr(signature.signedAt)}`);
      plume.valeur(`Adresse IP : ${signature.ip ?? 'non relevée'}`);
      plume.valeur(`Navigateur : ${signature.userAgent ?? 'non relevé'}`);
      plume.valeur(`Empreinte du document signé (SHA-256) : ${signature.documentSha256}`);
    }

    plume.section('Valeur de la signature');
    plume.valeur(MENTION_SIGNATURE);

    // Le pied n'est réécrit que sur les pages ajoutées : celles du document d'origine le
    // portent déjà, et le redessiner par-dessus produirait un texte gras illisible.
    plume.pied(MENTION_PEDAGOGIQUE);
    return Buffer.from(await doc.save());
  }
}

function dateHeureFr(date: Date): string {
  return date.toLocaleString('fr-FR', {
    dateStyle: 'long',
    timeStyle: 'medium',
    timeZone: 'Europe/Paris',
  });
}

function ecrireSalarie(
  plume: Plume,
  interimaire: ContratInterimaire,
  etatCivil: ContratEtatCivil,
): void {
  plume.cle(`Salarié intérimaire : ${interimaire.prenom} ${interimaire.nom}`);
  plume.valeur(
    `Né(e) le ${dateFr(etatCivil.dateNaissance)} à ${etatCivil.lieuNaissance} (${etatCivil.paysNaissance})`,
  );
  plume.valeur(`Nationalité : ${etatCivil.nationalite}`);
  plume.valeur(`Domicile : ${etatCivil.adresse}`);
  plume.valeur(`Numéro de sécurité sociale : ${etatCivil.nirMasque}`);
}

function ecrireEntreprise(plume: Plume, entreprise: ContratEntreprise, partie: boolean): void {
  plume.cle(`${partie ? 'Entreprise utilisatrice' : 'Entreprise d’accueil'} : ${entreprise.nom}`);
  plume.valeur(`SIRET ${entreprise.siret} — ${entreprise.adresse}`);
  if (partie) {
    plume.valeur(
      `Représentée par ${entreprise.signataireNom}, ` +
        `${entreprise.signataireQualite ?? QUALITE_SIGNATAIRE_PAR_DEFAUT}`,
    );
  }
}

// Corps commun aux deux documents : le L. 1251-16 1° impose de reproduire dans le contrat de
// mission les clauses du contrat de mise à disposition. Une seule écriture, donc.
function ecrireMission(plume: Plume, data: ContratData): void {
  const { mission } = data;
  plume.section('La mission');
  plume.cle(`Motif du recours : ${mission.motifRecours}`);
  if (mission.remplaceNom) {
    plume.valeur(
      `Salarié remplacé : ${mission.remplaceNom}` +
        (mission.remplaceQualification ? ` — ${mission.remplaceQualification}` : ''),
    );
  }
  plume.cle(`Qualification professionnelle : ${mission.titre}`);
  plume.valeur(`Lieu de la mission : ${mission.lieu} (${mission.codePostal})`);
  plume.valeur(`Horaire : ${mission.horaire}`);
  plume.valeur(`Terme : du ${dateFr(mission.dateDebut)} au ${dateFr(mission.dateFin)}`);
  plume.valeur(
    `Habilitations exigées : ${mission.habilitations.length > 0 ? mission.habilitations.join(', ') : 'aucune'}`,
  );
  if (mission.caracteristiques) {
    plume.valeur(`Caractéristiques du poste : ${mission.caracteristiques}`);
  }
}

function ecrireRemuneration(plume: Plume, data: ContratData): void {
  plume.section('Rémunération');
  if (data.type === ContractType.MISSION) {
    plume.cle(`Rémunération : ${data.mission.remuneration}`);
    // L. 1251-16 3° : les modalités de rémunération doivent inclure l'indemnité de fin de
    // mission. Elle n'a de sens que sur le contrat qui lie l'employeur au salarié.
    plume.valeur(MENTION_IFM);
    return;
  }
  plume.cle(`Rémunération de référence : ${data.mission.remuneration}`);
  plume.valeur(
    'Montant servant de base à la rémunération du salarié intérimaire (art. L. 1251-43 6°) ' +
      'et à la facturation de la mise à disposition.',
  );
}

// Les dates arrivent en ISO (elles partent telles quelles dans le JSON envoyé à n8n, où
// elles doivent rester lisibles par une machine). Sur un document destiné à être lu, elles
// s'écrivent à la française.
function dateFr(iso: string): string {
  const [annee, mois, jour] = iso.split('-');
  return jour && mois && annee ? `${jour}/${mois}/${annee}` : iso;
}

/**
 * Mise en page du document : curseur vertical, pagination et repli du texte.
 *
 * Extraite en classe parce que les deux contrats partagent exactement la même, et qu'elle
 * était mêlée au contenu dans la version à un seul document — deux copies auraient divergé
 * au premier réglage de marge.
 */
class Plume {
  private page: PDFPage;
  private y = START_Y;
  // Pages écrites par cette instance. Sur un document repris (page de signatures), le pied
  // ne doit être dessiné que sur elles : les autres le portent déjà.
  private readonly pagesEcrites: PDFPage[] = [];

  constructor(
    private readonly doc: PDFDocument,
    private readonly font: PDFFont,
    private readonly bold: PDFFont,
  ) {
    this.page = doc.addPage([PAGE_WIDTH, PAGE_HEIGHT]);
    bandeau(this.page, bold);
    this.pagesEcrites.push(this.page);
  }

  // Une nouvelle page plutôt qu'un texte qui déborde sous la marge : la description est
  // saisie librement par l'entreprise, sa longueur n'est pas bornée.
  private place(hauteur: number): void {
    if (this.y - hauteur >= BAS_DE_PAGE) {
      return;
    }
    this.page = this.doc.addPage([PAGE_WIDTH, PAGE_HEIGHT]);
    bandeau(this.page, this.bold);
    this.pagesEcrites.push(this.page);
    this.y = START_Y;
  }

  private ecrire(texte: string, taille: number, police: PDFFont, couleur = ANTHRACITE): void {
    for (const ligne of couper(texte, taille, police, LARGEUR_UTILE)) {
      this.place(taille + 10);
      this.page.drawText(ligne, {
        x: MARGIN_X,
        y: this.y,
        size: taille,
        font: police,
        color: couleur,
      });
      this.y -= taille + 6;
    }
    this.y -= 4;
  }

  titre(texte: string): void {
    this.ecrire(texte, 20, this.bold);
    this.page.drawRectangle({
      x: MARGIN_X,
      y: this.y + 8,
      width: 60,
      height: 3,
      color: ANTHRACITE,
    });
    this.y -= 14;
  }

  section(texte: string): void {
    this.place(40);
    this.y -= 12;
    this.page.drawText(texte.toUpperCase(), {
      x: MARGIN_X,
      y: this.y,
      size: 9,
      font: this.bold,
      color: MUTED,
    });
    this.y -= 6;
    this.page.drawRectangle({
      x: MARGIN_X,
      y: this.y - 2,
      width: LARGEUR_UTILE,
      height: 1,
      color: MUTED,
    });
    this.y -= 16;
  }

  cle(texte: string): void {
    this.ecrire(texte, 11, this.bold);
  }

  valeur(texte: string): void {
    this.ecrire(texte, 10, this.font, MUTED);
  }

  petit(texte: string): void {
    this.ecrire(texte, 8, this.font, MUTED);
  }

  // Écrit sur toutes les pages écrites par cette instance : un document de trois pages dont
  // seule la dernière porterait l'avertissement laisserait les deux premières circuler sans
  // lui. Sur un document repris, les pages d'origine l'ont déjà — le redessiner dessus
  // donnerait un texte doublé, illisible.
  pied(texte: string): void {
    for (const page of this.pagesEcrites) {
      for (const [index, ligne] of couper(texte, 7, this.font, LARGEUR_UTILE).entries()) {
        page.drawText(ligne, {
          x: MARGIN_X,
          y: 40 - index * 10,
          size: 7,
          font: this.font,
          color: MUTED,
        });
      }
    }
  }
}

function bandeau(page: PDFPage, bold: PDFFont): void {
  page.drawRectangle({
    x: 0,
    y: PAGE_HEIGHT - BAND_HEIGHT,
    width: PAGE_WIDTH,
    height: BAND_HEIGHT,
    color: ANTHRACITE,
  });
  page.drawText('CADANS', {
    x: MARGIN_X,
    y: PAGE_HEIGHT - BAND_HEIGHT / 2 - 8,
    size: 22,
    font: bold,
    color: BLANC,
  });
}

// Découpe aux espaces, à la largeur réelle mesurée dans la police : pdf-lib ne replie pas le
// texte, une ligne trop longue sortirait de la page sans erreur.
function couper(texte: string, taille: number, police: PDFFont, largeur: number): string[] {
  const lignes: string[] = [];
  let courante = '';

  for (const mot of texte.split(/\s+/).filter(Boolean)) {
    const essai = courante ? `${courante} ${mot}` : mot;
    if (police.widthOfTextAtSize(essai, taille) <= largeur || !courante) {
      courante = essai;
      continue;
    }
    lignes.push(courante);
    courante = mot;
  }
  if (courante) {
    lignes.push(courante);
  }
  return lignes.length > 0 ? lignes : [''];
}

export { MENTION_EMBAUCHE, MENTION_IFM, MENTION_LACUNES };
