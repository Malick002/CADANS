import {
  Body,
  Controller,
  ForbiddenException,
  Get,
  Header,
  Param,
  ParseUUIDPipe,
  Post,
  Req,
  StreamableFile,
} from '@nestjs/common';
import { Role } from '@prisma/client';
import { Request } from 'express';
import { CurrentUser } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import { ContractsService, ContractView } from './contracts.service';
import { SignerContratDto } from './dto/signer-contrat.dto';

/**
 * Une seule route de liste pour les deux rôles, et c'est voulu : le contrat qu'on voit
 * dépend de qui on est, pas de l'URL qu'on appelle. Un intérimaire reçoit ses contrats de
 * mission, une entreprise ses contrats de mise à disposition — il n'existe aucune URL par
 * laquelle l'un demanderait les documents de l'autre.
 *
 * Aucun `@Roles` de classe : la route est ouverte à tout utilisateur connecté, et c'est le
 * service qui décide de ce qu'il voit. Un agent CADANS (ADMIN) n'a pas de liste — il agit
 * pour l'employeur, partie aux deux contrats, mais l'espace d'administration ne les expose
 * pas encore.
 */
@Controller('contrats')
export class ContractsController {
  constructor(private readonly contracts: ContractsService) {}

  @Get()
  list(@CurrentUser() user: SessionUser): Promise<ContractView[]> {
    if (user.role === Role.WORKER) {
      return this.contracts.listForWorker(user.id);
    }
    if (user.role === Role.COMPANY) {
      return this.contracts.listForCompany(user.id);
    }
    throw new ForbiddenException("Cette action n'est pas autorisée pour votre type de compte");
  }

  /**
   * Document déchiffré à la volée. `no-store` interdit au navigateur comme aux
   * intermédiaires d'en garder une copie, `nosniff` empêche de le réinterpréter comme du
   * HTML. Même traitement que les justificatifs : il n'existe aucune URL publique.
   *
   * `inline` et non `attachment` : le contrat doit pouvoir être lu à l'écran avant d'être
   * signé (b2), et forcer un téléchargement pour relire un document qu'on va accepter est
   * le meilleur moyen qu'il ne soit pas lu.
   */
  @Get(':id/document')
  @Header('Cache-Control', 'no-store')
  @Header('X-Content-Type-Options', 'nosniff')
  async download(
    @CurrentUser() user: SessionUser,
    @Param('id', ParseUUIDPipe) id: string,
  ): Promise<StreamableFile> {
    const file = await this.contracts.read(user.id, user.role, id);
    return new StreamableFile(file.content, {
      type: 'application/pdf',
      disposition: `inline; filename="${file.filename}"`,
      length: file.content.length,
    });
  }

  /**
   * Signature du contrat par la partie qui en est destinataire.
   *
   * L'adresse IP et l'agent utilisateur sont relevés **ici**, au plus près de la requête, et
   * non reconstitués plus tard : ce sont des éléments de preuve, ils doivent décrire la
   * requête qui a signé.
   *
   * `request.ip` dépend du réglage `trust proxy` d'Express. Derrière l'hébergeur, sans ce
   * réglage, il vaut l'adresse du proxy — une preuve fausse plutôt qu'absente. C'est pourquoi
   * `main.ts` l'active en production, et pourquoi la colonne reste nullable.
   */
  @Post(':id/signer')
  sign(
    @CurrentUser() user: SessionUser,
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: SignerContratDto,
    @Req() request: Request,
  ): Promise<ContractView> {
    return this.contracts.sign(user.id, user.role, id, dto.nomComplet, {
      ip: request.ip ?? null,
      userAgent: request.get('user-agent') ?? null,
    });
  }
}
