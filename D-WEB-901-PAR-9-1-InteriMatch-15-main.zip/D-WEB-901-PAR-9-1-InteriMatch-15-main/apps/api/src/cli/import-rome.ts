import 'reflect-metadata';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { Command } from 'commander';
import { PrismaModule } from '../prisma/prisma.module';
import { ROME_CODES } from '../referentiel/curation';
import { FranceTravailClient } from '../referentiel/france-travail.client';
import { ReferentielModule } from '../referentiel/referentiel.module';
import { RomeFiche } from '../referentiel/rome-fiche';
import { RomeImportService } from '../referentiel/rome-import.service';
import { readSeed, SEED_DIR, writeSeed } from '../referentiel/seed-files';

// Contexte Nest minimal : configuration, PostgreSQL et le module référentiel. Pas de
// serveur HTTP, pas de MongoDB — la CLI n'en a pas besoin.
@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: ['../../.env', '.env'] }),
    PrismaModule,
    ReferentielModule,
  ],
})
class ImportRomeCliModule {}

interface Options {
  fetch: boolean;
  dryRun: boolean;
}

const program = new Command()
  .name('import-rome')
  .description(
    'Importe le référentiel ROME 4.0 (codes, postes, compétences, suggestions d’habilitation) ' +
      `dans PostgreSQL depuis les fichiers de seed. Périmètre : ${ROME_CODES.join(', ')}.`,
  )
  .option(
    '--fetch',
    'rafraîchit d’abord les fichiers de seed depuis l’API France Travail (identifiants requis)',
    false,
  )
  .option('--dry-run', 'lit et valide les fiches sans écrire en base', false)
  .action(async (options: Options) => {
    const app = await NestFactory.createApplicationContext(ImportRomeCliModule, {
      logger: ['warn', 'error'],
    });

    try {
      let fiches: RomeFiche[];
      if (options.fetch) {
        const client = app.get(FranceTravailClient);
        fiches = await client.romeMetiers(ROME_CODES);
        for (const fiche of fiches) {
          console.log(`seed rafraîchi : ${writeSeed(fiche)}`);
        }
      } else {
        fiches = ROME_CODES.map((code) => readSeed(code));
        console.log(`${fiches.length} fiches lues dans ${SEED_DIR}`);
      }

      for (const fiche of fiches) {
        console.log(
          `  ${fiche.code}  ${fiche.libelle} — ${fiche.appellations.length} appellations, ` +
            `${fiche.competencesMobilisees.length} compétences mobilisées + ${fiche.competencesMobiliseesPrincipales.length} principales`,
        );
      }

      if (options.dryRun) {
        console.log('\n--dry-run : rien n’a été écrit en base.');
        return;
      }

      const report = await app.get(RomeImportService).importAll(fiches);
      console.log('\nImport terminé :');
      console.log(`  codes ROME          ${report.romes}`);
      console.log(`  postes              ${report.postes} (dont ${report.postesExposed} exposés)`);
      console.log(
        `  compétences         ${report.competences} liens, ${report.competencesIgnorees} ignorées`,
      );
      console.log(`  suggestions CACES   ${report.suggestions}`);
      console.log(
        `  désactivés          ${report.desactives.romes} ROME, ${report.desactives.postes} postes, ` +
          `${report.desactives.competences} compétences ; ${report.desactives.liensSupprimes} liens supprimés`,
      );
    } finally {
      await app.close();
    }
  });

program.parseAsync(process.argv).catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
