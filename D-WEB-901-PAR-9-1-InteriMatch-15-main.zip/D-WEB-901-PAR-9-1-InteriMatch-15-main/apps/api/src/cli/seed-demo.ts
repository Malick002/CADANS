import 'reflect-metadata';
import { randomUUID } from 'node:crypto';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import {
  CertificationStatus,
  CertificationType,
  ContractType,
  MissionStatus,
  MotifRecours,
  Role,
  Shift,
} from '@prisma/client';
import { Command } from 'commander';
import { AuthModule } from '../auth/auth.module';
import { ContractsModule } from '../contracts/contracts.module';
import { ContractsService } from '../contracts/contracts.service';
import { PasswordService } from '../auth/password.service';
import { EncryptionModule } from '../encryption/encryption.module';
import { EncryptionService } from '../encryption/encryption.service';
import { PrismaModule } from '../prisma/prisma.module';
import { PrismaService } from '../prisma/prisma.service';

// Contexte Nest minimal : configuration, PostgreSQL et le module d'authentification, pour
// hacher les mots de passe avec exactement les mêmes paramètres argon2 que l'inscription,
// et le chiffrement des documents. Pas de serveur HTTP, pas de MongoDB.
@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: ['../../.env', '.env'] }),
    PrismaModule,
    AuthModule,
    // Ajouté avec les justificatifs de démonstration : ils sont chiffrés exactement comme
    // ceux que dépose un intérimaire, avec la clé du .env.
    EncryptionModule,
    // Les missions POURVUE du jeu sont créées directement en base, sans passer par la route
    // qui déclenche d'ordinaire la génération : sans cet appel explicite, aucun contrat
    // n'existerait et les deux écrans « Contrats » seraient vides en soutenance.
    ContractsModule,
  ],
})
class SeedDemoCliModule {}

// Mot de passe unique pour les trois comptes : il est écrit dans le README, autant qu'il soit
// simple à dicter en soutenance. Il respecte les règles de CredentialsDto.
const MOT_DE_PASSE = 'DemoCadans#2026';

// Adresses en sous-adressage Gmail (`+suffixe`) : les trois comptes restent distincts pour
// l'application — l'unicité porte sur la chaîne entière — mais les emails envoyés par les
// workflows n8n arrivent tous dans la même boîte `interimcadans@gmail.com`. C'est ce qui rend
// les automatisations démontrables sans posséder de domaine vérifié.
// Agent CADANS. Aucune inscription publique n'y mène : ce compte n'existe que par le seed.
const ADMIN = { email: 'admin@cadans.fr' };

const ENTREPRISE = {
  email: 'interimcadans+entreprise@gmail.com',
  legalName: 'Entrepôt du Nord',
  // SIRET valide au sens de la clé de Luhn : celui de la Poste, utilisé partout comme
  // exemple public. Un SIRET inventé serait refusé par la validation de l'API.
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  // Qualité du signataire au contrat de mise à disposition (art. L. 1251-43). Sans elle, le
  // générateur retombe sur « Représentant légal » — correct, mais moins parlant en démo.
  signatoryRole: 'Responsable d’exploitation',
  addressLine: '12 rue des Docks',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

const INTERIMAIRE = {
  email: 'interimcadans+interimaire@gmail.com',
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

// --- Jeu de démonstration complet (--complet) -------------------------------
//
// Quatre missions et un second intérimaire dont le profil est déjà rempli. Le jeu est
// construit pour que le matching produise un résultat lisible en soutenance :
//   · mission 1 → match à 100 % (CACES détenu, créneau accepté, même département,
//     les deux compétences souhaitées déclarées) ;
//   · mission 2 → match à 70 % (une compétence sur deux) ;
//   · mission 3 → écartée par le créneau (nuit, non accepté) ;
//   · mission 4 → écartée par le filtrage bloquant, et comptée dans
//     `masqueesFauteHabilitation` : c'est elle qui fait apparaître l'incitation
//     « ajoutez vos CACES » ;
//   · mission 5 → match à 80 % : toutes les compétences sont couvertes, mais elle est en
//     Seine-Saint-Denis, département VOISIN du Val-d'Oise. La zone rapporte alors 20 points
//     sur 40 au lieu de 40. Sans elle, la règle des départements voisins ne se déclenche
//     jamais à l'écran : la seule autre mission hors 95 est de nuit, donc écartée par le
//     créneau avant tout scoring.
// Sans ces deux derniers cas, les deux règles les plus structurantes du produit — filtrage
// bloquant et pondération de zone — ne se voient pas.

const JOUR = 24 * 60 * 60 * 1000;
const dans = (jours: number): Date => new Date(Date.now() + jours * JOUR);

const MISSIONS = [
  {
    posteCode: '11679', // Cariste
    siteLabel: 'Entrepôt du Nord — quai 4',
    motifRecours: MotifRecours.ACCROISSEMENT_TEMPORAIRE,
    postalCode: '95700',
    shift: Shift.MATIN,
    hourlyRate: 13.5,
    description: 'Chargement et déchargement au quai, gerbage en allée étroite.',
    habilitations: [CertificationType.CACES_R489_3],
    competenceCodes: ['400110', '122623'],
  },
  {
    posteCode: '520521', // Agent de préparation de commandes
    siteLabel: 'Entrepôt du Nord — zone picking',
    // Le seul remplacement du jeu : c'est lui qui montre les deux champs supplémentaires,
    // au formulaire comme sur les deux contrats.
    motifRecours: MotifRecours.REMPLACEMENT,
    remplaceNom: 'Julien Lefevre',
    remplaceQualification: 'Préparateur de commandes',
    postalCode: '95700',
    shift: Shift.APRES_MIDI,
    hourlyRate: 12.8,
    description: 'Préparation de commandes au vocal, port de charges jusqu’à 15 kg.',
    habilitations: [CertificationType.CACES_R489_1B],
    competenceCodes: ['300645', '110036'],
  },
  {
    posteCode: '10523', // Agent de manutention de charges lourdes
    siteLabel: 'Entrepôt du Nord — plateforme de nuit',
    motifRecours: MotifRecours.ACCROISSEMENT_TEMPORAIRE,
    postalCode: '93200',
    shift: Shift.NUIT,
    hourlyRate: 13.1,
    description: 'Équipe de nuit, gerbeur accompagnant.',
    habilitations: [CertificationType.CACES_R485_1],
    competenceCodes: ['100016'],
  },
  {
    posteCode: '11684', // Cariste d'entrepôt
    siteLabel: 'Entrepôt du Nord — magasin hauteur',
    motifRecours: MotifRecours.SAISONNIER,
    postalCode: '95700',
    shift: Shift.JOURNEE,
    hourlyRate: 14.2,
    description: 'Chariot à mât rétractable, stockage grande hauteur.',
    habilitations: [CertificationType.CACES_R489_5],
    competenceCodes: ['109996', '103308'],
  },
  // Département voisin (93 ↔ 95), créneau accepté, CACES détenu : tout est couvert sauf la
  // zone. C'est la seule mission du jeu qui isole le critère de zone.
  {
    posteCode: '11679', // Cariste
    siteLabel: 'Entrepôt du Nord — plateforme d’Aulnay',
    motifRecours: MotifRecours.ACCROISSEMENT_TEMPORAIRE,
    postalCode: '93600',
    shift: Shift.MATIN,
    hourlyRate: 13.9,
    description: 'Chargement de semi-remorques, navette entre quais.',
    habilitations: [CertificationType.CACES_R489_3],
    competenceCodes: ['400110', '122623'],
  },
];

const INTERIMAIRE_COMPLET = {
  email: 'interimcadans+cariste@gmail.com',
  firstName: 'Leïla',
  lastName: 'Moreau',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

// Créneaux acceptés et habilitations détenues : volontairement partiels, pour que les
// missions 3 et 4 soient écartées par deux règles différentes.
//
// La journée est acceptée exprès. Le créneau est vérifié AVANT les habilitations : si Leïla
// refusait la journée, la mission 4 serait écartée par le créneau et ne compterait pas dans
// `masqueesFauteHabilitation` — le compteur resterait à zéro et la démonstration du filtrage
// bloquant tomberait à plat. Vérifié : c'était le cas avant cette ligne.
const CRENEAUX_COMPLET = [Shift.MATIN, Shift.APRES_MIDI, Shift.JOURNEE];
// Les deux états de vérification, pour que l'espace d'administration ne soit pas vide et que
// les deux badges se voient sur le profil : un justificatif déjà validé par un agent, et un
// en attente d'examen.
//
// Le document chiffré est un vrai PDF minimal (voir JUSTIFICATIF_PDF) : sans document,
// l'habilitation ne remonterait pas dans la file d'attente, qui n'examine que ce qui a une
// pièce jointe.
const CACES_COMPLET = [
  {
    type: CertificationType.CACES_R489_3,
    expiresAt: dans(720),
    verificationStatus: CertificationStatus.VERIFIE,
  },
  {
    type: CertificationType.CACES_R489_1B,
    expiresAt: dans(900),
    verificationStatus: CertificationStatus.EN_ATTENTE,
  },
];

// PDF valide le plus court possible : une page vide. Il sert de justificatif de démonstration,
// chiffré comme n'importe quel document déposé par un intérimaire.
const JUSTIFICATIF_PDF = Buffer.from(
  '%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n' +
    '2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n' +
    '3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]>>endobj\n' +
    'trailer<</Root 1 0 R>>\n%%EOF\n',
  'latin1',
);
const COMPETENCES_COMPLET = ['400110', '122623', '300645'];

// Informations d'embauche de Leïla, la seule des deux intérimaires à les avoir complétées :
// c'est ce qui rend la démonstration lisible — un profil prêt à contractualiser, un autre qui
// voit le bandeau « informations nécessaires à votre contrat ».
//
// Le NIR est FICTIF mais sa clé est juste (97 − 2900675116001 mod 97 = 71), sinon l'API le
// refuserait — c'est tout l'intérêt de la contrôler. L'IBAN est celui donné en exemple par la
// norme ISO 13616 : son contrôle mod 97 passe, et il n'appartient à aucun compte réel.
const EMBAUCHE_COMPLET = {
  birthDate: new Date('1990-06-14T00:00:00Z'),
  birthPlace: 'Paris',
  birthCountry: 'France',
  nationality: 'Française',
  addressLine: '8 rue des Peupliers',
  addressPostalCode: '95700',
  addressCity: 'Roissy-en-France',
  nir: '290067511600171',
  iban: 'FR1420041010050500013M02606',
};

const program = new Command()
  .name('seed:demo')
  .description(
    'Crée les trois comptes de démonstration (entreprise, intérimaire, agent CADANS) partagés par ' +
      'toute l’équipe. Idempotent : relancer la commande ne crée pas de doublon.',
  )
  .option('--force', 'autorise l’exécution même si NODE_ENV vaut production', false)
  .option(
    '--complet',
    'ajoute quatre missions ouvertes et un second intérimaire au profil déjà rempli, ' +
      'de quoi montrer le matching sans rien saisir',
    false,
  )
  .action(async ({ force, complet }: { force: boolean; complet: boolean }) => {
    // Garde volontairement stricte : ces comptes ont un mot de passe écrit dans un dépôt.
    // Les créer sur une base de production ouvrirait un accès connu de tous.
    if (process.env.NODE_ENV === 'production' && !force) {
      throw new Error(
        'NODE_ENV=production : refus de créer des comptes dont le mot de passe est publié ' +
          'dans le README. Utilisez --force si vous savez ce que vous faites.',
      );
    }

    const app = await NestFactory.createApplicationContext(SeedDemoCliModule, { logger: false });
    try {
      const prisma = app.get(PrismaService);
      const passwordHash = await app.get(PasswordService).hash(MOT_DE_PASSE);

      // Les adresses de démonstration ont changé le 22/09 (passage en sous-adressage Gmail).
      // L'`upsert` ci-dessous porte sur l'email : sur une base où l'ancien compte existe
      // encore, il tenterait de créer une SECONDE entreprise avec le même SIRET, qui est
      // unique — et la commande échouerait. On retire donc d'abord tout compte entreprise qui
      // détient ce SIRET sous une autre adresse. Sans ça, `seed:demo` casse sur chaque poste
      // de l'équipe ayant déjà lancé l'ancienne version.
      await prisma.user.deleteMany({
        where: {
          company: { siret: ENTREPRISE.siret },
          email: { not: ENTREPRISE.email },
        },
      });

      // `upsert` sur l'email : relancer la commande remet le mot de passe à sa valeur connue
      // plutôt que d'échouer sur la contrainte d'unicité. Les profils ne sont créés qu'à la
      // première exécution, pour ne pas écraser des données saisies pendant une démo.
      const entreprise = await prisma.user.upsert({
        where: { email: ENTREPRISE.email },
        update: { passwordHash },
        create: {
          email: ENTREPRISE.email,
          passwordHash,
          role: Role.COMPANY,
          conditionsAcceptedAt: new Date(),
          company: { create: { ...ENTREPRISE, email: undefined } as never },
        },
      });

      const interimaire = await prisma.user.upsert({
        where: { email: INTERIMAIRE.email },
        update: { passwordHash },
        create: {
          email: INTERIMAIRE.email,
          passwordHash,
          role: Role.WORKER,
          conditionsAcceptedAt: new Date(),
          worker: { create: { ...INTERIMAIRE, email: undefined } as never },
        },
      });

      // Agent CADANS : ni profil entreprise ni profil intérimaire, juste un compte et un rôle.
      // C'est le seul moyen d'obtenir un ADMIN — l'inscription publique ne propose que les
      // deux autres rôles, et le DTO les refuse au-delà.
      const admin = await prisma.user.upsert({
        where: { email: ADMIN.email },
        update: { passwordHash, role: Role.ADMIN },
        create: {
          email: ADMIN.email,
          passwordHash,
          role: Role.ADMIN,
          conditionsAcceptedAt: new Date(),
        },
      });

      if (complet) {
        const companyId = (
          await prisma.company.findUniqueOrThrow({
            where: { userId: entreprise.id },
            select: { id: true },
          })
        ).id;

        // Remise à plat des missions de la seule entreprise de démonstration : sans ça,
        // relancer la commande empilerait les mêmes offres. Aucune autre entreprise n'est
        // touchée.
        await prisma.mission.deleteMany({ where: { companyId } });
        // La première mission est retenue : c'est le match à 100 %, celui sur lequel
        // l'intérimaire de démonstration postule (plus bas), pour que l'écran
        // « Candidatures » de l'entreprise ne soit pas vide en soutenance.
        let premiereMissionId = '';
        for (const mission of MISSIONS) {
          const creee = await prisma.mission.create({
            data: {
              companyId,
              posteCode: mission.posteCode,
              siteLabel: mission.siteLabel,
              postalCode: mission.postalCode,
              startDate: dans(7),
              endDate: dans(21),
              shift: mission.shift,
              motifRecours: mission.motifRecours,
              remplaceNom: 'remplaceNom' in mission ? mission.remplaceNom : null,
              remplaceQualification:
                'remplaceQualification' in mission ? mission.remplaceQualification : null,
              hourlyRate: mission.hourlyRate,
              description: mission.description,
              status: MissionStatus.OUVERTE,
              habilitations: { create: mission.habilitations.map((type) => ({ type })) },
              competences: {
                create: mission.competenceCodes.map((competenceCode) => ({ competenceCode })),
              },
            },
            select: { id: true },
          });
          premiereMissionId ||= creee.id;
        }

        const cariste = await prisma.user.upsert({
          where: { email: INTERIMAIRE_COMPLET.email },
          update: { passwordHash },
          create: {
            email: INTERIMAIRE_COMPLET.email,
            passwordHash,
            role: Role.WORKER,
            conditionsAcceptedAt: new Date(),
            worker: { create: { ...INTERIMAIRE_COMPLET, email: undefined } as never },
          },
          include: { worker: { select: { id: true } } },
        });
        const workerId = cariste.worker!.id;

        // Le profil est réécrit en entier à chaque exécution : c'est un jeu de démonstration,
        // il doit être identique d'une machine à l'autre.
        await prisma.worker.update({
          where: { id: workerId },
          data: { shifts: CRENEAUX_COMPLET },
        });
        await prisma.certification.deleteMany({ where: { workerId } });
        // `create` un par un et non `createMany` : chaque justificatif est chiffré avec un
        // contexte qui lui est propre (intérimaire + type), comme le fait l'API.
        const encryption = app.get(EncryptionService);
        for (const caces of CACES_COMPLET) {
          await prisma.certification.create({
            data: {
              workerId,
              ...caces,
              documentEncrypted: encryption.encrypt(
                JUSTIFICATIF_PDF,
                `certification-document:${workerId}:${caces.type}`,
              ),
              documentMimeType: 'application/pdf',
              verifiedAt:
                caces.verificationStatus === CertificationStatus.VERIFIE ? new Date() : null,
            },
          });
        }
        await prisma.workerSkill.deleteMany({ where: { workerId } });
        await prisma.workerSkill.createMany({
          data: COMPETENCES_COMPLET.map((competenceCode) => ({ workerId, competenceCode })),
        });

        // Informations d'embauche de Leïla : chiffrées avec les mêmes contextes que l'API
        // (`hiring-nir:<workerId>` et `hiring-iban:<workerId>`), sans quoi elles seraient
        // indéchiffrables à la lecture.
        const { nir, iban, ...etatCivil } = EMBAUCHE_COMPLET;
        const embauche = {
          ...etatCivil,
          nirEncrypted: encryption.encryptText(nir, `hiring-nir:${workerId}`),
          ibanEncrypted: encryption.encryptText(iban, `hiring-iban:${workerId}`),
        };
        await prisma.hiringInfo.upsert({
          where: { workerId },
          create: { workerId, ...embauche },
          update: embauche,
        });

        // Une candidature sur le match à 100 %. Sans elle, /entreprise/candidatures affiche
        // son état vide et le bloc « candidat » (nom, zone, habilitations valides) ne se
        // démontre pas. Elle ne change ni les scores ni le compteur de missions masquées :
        // elle passe seulement `applied` à vrai sur ce match.
        await prisma.candidature.deleteMany({ where: { workerId } });
        await prisma.candidature.create({
          data: { missionId: premiereMissionId, workerId },
        });

        // Mission POURVUE qui démarre dans DEUX jours, attribuée à Leïla : c'est la seule
        // ligne que remonte le workflow n8n « rappel avant début de mission ». Sans elle, son
        // nœud Postgres renvoie zéro ligne et le workflow ne se teste pas.
        //
        // Elle ne perturbe pas la démonstration du matching : `getMatchesForWorker` ne lit
        // que les missions OUVERTE. Elle est créée à part du tableau MISSIONS, dont toutes
        // les entrées sont ouvertes par construction.
        const missionLeila = await prisma.mission.create({
          data: {
            companyId,
            posteCode: '520521', // Agent de préparation de commandes
            siteLabel: 'Entrepôt du Nord — quai 2',
            postalCode: '95700',
            startDate: dans(2),
            endDate: dans(16),
            shift: Shift.MATIN,
            motifRecours: MotifRecours.ACCROISSEMENT_TEMPORAIRE,
            hourlyRate: 13,
            description: 'Préparation de commandes au vocal, prise de poste à 6h.',
            status: MissionStatus.POURVUE,
            assignedWorkerId: workerId,
          },
          select: { id: true },
        });

        // Samir, retenu lui aussi, mais qui n'a PAS complété ses informations d'embauche :
        // c'est le seul moyen de voir à l'écran le bandeau « informations nécessaires à votre
        // contrat », qui ne s'affiche que dans cet état précis. Sans cette mission, la règle
        // existe et ne se démontre jamais.
        //
        // Elle démarre à J+9 et non à J+2 : le workflow n8n « rappel avant début de mission »
        // ne remonte que les missions qui commencent dans exactement deux jours, et il doit
        // continuer de n'en trouver qu'une seule.
        const samirId = (
          await prisma.worker.findUniqueOrThrow({
            where: { userId: interimaire.id },
            select: { id: true },
          })
        ).id;
        await prisma.hiringInfo.deleteMany({ where: { workerId: samirId } });
        const missionSamir = await prisma.mission.create({
          data: {
            companyId,
            posteCode: '10523', // Agent de manutention de charges lourdes
            siteLabel: 'Entrepôt du Nord — réception',
            postalCode: '95700',
            startDate: dans(9),
            endDate: dans(23),
            shift: Shift.JOURNEE,
            motifRecours: MotifRecours.REMPLACEMENT,
            remplaceNom: 'Amina Cherif',
            remplaceQualification: 'Agent de manutention',
            hourlyRate: 12.9,
            description: 'Réception et contrôle des palettes à quai.',
            status: MissionStatus.POURVUE,
            assignedWorkerId: samirId,
          },
          select: { id: true },
        });

        // Génération des contrats des deux missions pourvues. Elle n'est PAS automatique
        // ici : le seed écrit les missions directement en base, sans passer par la route qui
        // déclenche d'ordinaire la génération. Sans cet appel, les écrans « Contrats »
        // seraient vides en soutenance.
        //
        // Les deux cas de la règle sont couverts par construction : Leïla a ses informations
        // d'embauche, elle obtient ses DEUX contrats ; Samir ne les a pas, seule la mise à
        // disposition de son entreprise est générée.
        const contrats = app.get(ContractsService);
        await contrats.generateForMission(missionLeila.id);
        await contrats.generateForMission(missionSamir.id);

        // Un contrat DÉJÀ SIGNÉ des deux côtés, pour montrer l'état final — page de
        // signatures, document figé, mission « prête à démarrer » — sans avoir à signer deux
        // fois en direct. C'est la mise à disposition de la mission de Samir : l'entreprise
        // signe, CADANS a déjà signé à la génération.
        //
        // Les trois autres restent à signer : ce sont eux qu'on démontre en soutenance, un de
        // chaque côté.
        const miseADispoSamir = await prisma.contract.findUniqueOrThrow({
          where: {
            missionId_type: { missionId: missionSamir.id, type: ContractType.MISE_A_DISPOSITION },
          },
          select: { id: true },
        });
        // Une annexe sur chaque mission pourvue : sans elle, le bloc « Documents joints »
        // n'apparaît nulle part et la partie b3 ne se démontre pas. Le PDF est le même que
        // celui des justificatifs — une page vide suffit, c'est le mécanisme qu'on montre.
        const encryptionAnnexes = app.get(EncryptionService);
        for (const [missionId, nom] of [
          [missionLeila.id, 'Consignes de sécurité du site.pdf'],
          [missionSamir.id, 'Plan d’accès au quai de réception.pdf'],
        ] as const) {
          const annexeId = randomUUID();
          await prisma.missionAttachment.create({
            data: {
              id: annexeId,
              missionId,
              filename: nom,
              mimeType: 'application/pdf',
              sizeBytes: JUSTIFICATIF_PDF.length,
              fileEncrypted: encryptionAnnexes.encrypt(
                JUSTIFICATIF_PDF,
                `mission-attachment:${annexeId}`,
              ),
            },
          });
        }

        await contrats.sign(
          entreprise.id,
          Role.COMPANY,
          miseADispoSamir.id,
          `${ENTREPRISE.contactFirstName} ${ENTREPRISE.contactLastName}`,
          // Adresse de documentation (RFC 5737) et agent explicite : une preuve de
          // démonstration doit se reconnaître comme telle, pas ressembler à une vraie.
          { ip: '203.0.113.10', userAgent: 'CADANS seed:demo' },
        );
      }

      console.log('Comptes de démonstration prêts :');
      console.log(`  entreprise   ${ENTREPRISE.email}   (${entreprise.id})`);
      console.log(`  intérimaire  ${INTERIMAIRE.email}  (${interimaire.id})`);
      console.log(`  agent CADANS ${ADMIN.email}   (${admin.id})`);
      if (complet) {
        console.log(`  intérimaire  ${INTERIMAIRE_COMPLET.email}   (profil déjà rempli)`);
      }
      console.log(`  mot de passe ${MOT_DE_PASSE}`);
      if (complet) {
        console.log(`\n${MISSIONS.length} missions ouvertes publiées par Entrepôt du Nord.`);
        console.log(
          `Pour ${INTERIMAIRE_COMPLET.firstName} : 3 matches, 1 mission écartée faute de CACES, ` +
            '1 écartée par le créneau.',
        );
        console.log(
          'Le match à 80 % est en Seine-Saint-Denis, département voisin du Val-d’Oise : ' +
            'la zone y rapporte 20 points sur 40.',
        );
        console.log(
          'Une mission POURVUE démarre dans 2 jours : elle alimente le workflow n8n ' +
            '« rappel avant début de mission » (voir n8n/README.md).',
        );
        console.log(
          'Habilitations de Leïla : CACES R489-3 vérifié, CACES R489-1B en attente — ' +
            'le second est à examiner dans /admin.',
        );
        console.log(
          `${INTERIMAIRE_COMPLET.firstName} a postulé sur le match à 100 % : ` +
            'la candidature est visible côté entreprise.',
        );
        console.log(
          `Contrats : ${INTERIMAIRE_COMPLET.firstName} a ses deux documents (mission et mise à ` +
            `disposition), ${INTERIMAIRE.firstName} n’a que la mise à disposition côté ` +
            'entreprise — son contrat de mission attend ses informations d’embauche.',
        );
        console.log(
          'Annexes : une par mission pourvue (consignes de sécurité, plan d’accès), chiffrées ' +
            'et visibles du seul intérimaire retenu.',
        );
        console.log(
          'Signatures : CADANS a signé les 3 contrats à la génération. Celui de la mission de ' +
            `${INTERIMAIRE.firstName} est déjà signé par l’entreprise, donc définitif — les ` +
            'deux autres restent à signer, un de chaque côté.',
        );
        console.log(
          `Informations d’embauche : ${INTERIMAIRE_COMPLET.firstName} les a complétées, ` +
            `${INTERIMAIRE.firstName} non — il est retenu sur une mission et voit donc le ` +
            'bandeau « informations nécessaires à votre contrat ».',
        );
      }
      console.log(
        '\nCes identifiants sont publics : ne jamais lancer cette commande en production.',
      );
    } finally {
      await app.close();
    }
  });

program.parseAsync(process.argv).catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
