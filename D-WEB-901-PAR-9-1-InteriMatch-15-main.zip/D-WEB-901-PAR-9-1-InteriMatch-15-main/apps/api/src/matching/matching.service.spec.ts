import { NotFoundException } from '@nestjs/common';
import { CertificationType, Shift } from '@prisma/client';
import { MongoService } from '../mongo/mongo.service';
import { N8nService } from '../n8n/n8n.service';
import { PrismaService } from '../prisma/prisma.service';
import {
  MatchingService,
  certificationValide,
  departmentMatchRate,
  scoreCandidat,
  validCertificationTypes,
} from './matching.service';

// Les notifications de nouveau match partent en tâche de fond (`void`) : il faut laisser
// la microtask queue se vider avant de vérifier qu'elles ont bien eu lieu.
const flushPromises = () => new Promise((resolve) => setImmediate(resolve));

const baseWorker = {
  id: 'worker-1',
  firstName: 'Camille',
  lastName: 'Martin',
  postalCode: '95700',
  shifts: [Shift.MATIN],
  skills: [{ competenceCode: 'C1' }],
  certifications: [{ type: CertificationType.CACES_R489_3, expiresAt: null }],
  user: { email: 'camille.martin@exemple.fr' },
  candidatures: [] as { missionId: string }[],
};

function mission(overrides: Record<string, unknown> = {}) {
  return {
    id: 'mission-1',
    siteLabel: 'LogiNord - Roissy (95)',
    postalCode: '95700',
    startDate: new Date('2026-09-18'),
    endDate: new Date('2026-09-22'),
    shift: Shift.MATIN,
    hourlyRate: { toString: () => '13.5' },
    status: 'OUVERTE',
    poste: { label: 'Cariste' },
    company: { legalName: 'LogiNord SAS', user: { email: 'rh@loginord.fr' } },
    habilitations: [{ type: CertificationType.CACES_R489_3 }],
    competences: [{ competenceCode: 'C1' }, { competenceCode: 'C2' }],
    ...overrides,
  };
}

describe('MatchingService', () => {
  let prisma: {
    worker: { findUnique: jest.Mock };
    mission: { findMany: jest.Mock; findUnique: jest.Mock };
  };
  let mongo: { getDb: jest.Mock };
  let insertOne: jest.Mock;
  let findLogs: jest.Mock;
  let n8n: { notifyMatch: jest.Mock };
  let service: MatchingService;

  // Chaîne .find().sort().limit().toArray(), utilisée pour retrouver les matchs déjà notifiés
  // au calcul précédent. Vide par défaut : la plupart des tests ne portent pas sur l'historique.
  function mockFindLogs(previousLogs: Record<string, unknown>[] = []): jest.Mock {
    return jest.fn(() => ({
      sort: () => ({
        limit: () => ({
          toArray: () => Promise.resolve(previousLogs),
        }),
      }),
    }));
  }

  beforeEach(() => {
    prisma = {
      worker: { findUnique: jest.fn().mockResolvedValue(baseWorker) },
      mission: {
        findMany: jest.fn().mockResolvedValue([mission()]),
        findUnique: jest.fn().mockResolvedValue({ habilitations: mission().habilitations }),
      },
    };
    insertOne = jest.fn().mockResolvedValue(undefined);
    findLogs = mockFindLogs();
    mongo = { getDb: jest.fn(() => ({ collection: () => ({ insertOne, find: findLogs }) })) };
    n8n = { notifyMatch: jest.fn().mockResolvedValue(undefined) };
    service = new MatchingService(
      prisma as unknown as PrismaService,
      mongo as unknown as MongoService,
      n8n as unknown as N8nService,
    );
  });

  it('score une mission couverte par le profil (compétences + zone)', async () => {
    const { matches, masqueesFauteHabilitation } = await service.getMatchesForWorker('user-1');

    expect(matches).toHaveLength(1);
    expect(matches[0]).toMatchObject({
      missionId: 'mission-1',
      posteLabel: 'Cariste',
      companyName: 'LogiNord SAS',
      // 1 compétence sur 2 partagée (50 %) * 60 + même département (100 %) * 40 = 70
      score: 70,
    });
    expect(masqueesFauteHabilitation).toEqual({ missions: 0, certifications: [] });
  });

  describe('ventilation du score', () => {
    it('détaille les 70 points en 30 de compétences et 40 de zone', async () => {
      const { matches } = await service.getMatchesForWorker('user-1');

      expect(matches[0].detail).toEqual({
        competences: { points: 30, max: 60 },
        zone: { points: 40, max: 40 },
      });
    });

    it('met la zone à zéro hors du département, sans toucher aux compétences', async () => {
      prisma.mission.findMany.mockResolvedValueOnce([mission({ postalCode: '69007' })]);

      const [match] = (await service.getMatchesForWorker('user-1')).matches;

      expect(match.detail).toEqual({
        competences: { points: 30, max: 60 },
        zone: { points: 0, max: 40 },
      });
      expect(match.score).toBe(30);
    });

    // Une mission qui n'exige aucune compétence donne le maximum : rien à ne pas couvrir.
    // C'est la règle déjà en place (`overlap = 1`), le détail ne fait que la rendre lisible.
    it('accorde tous les points de compétences à une mission qui n’en exige aucune', async () => {
      prisma.mission.findMany.mockResolvedValueOnce([mission({ competences: [] })]);

      const [match] = (await service.getMatchesForWorker('user-1')).matches;

      expect(match.detail.competences).toEqual({ points: 60, max: 60 });
      expect(match.score).toBe(100);
    });

    // Le point qui compte : exposer le détail ne doit pas déplacer le total d'un seul point.
    // Vérifié sur des taux de recouvrement qui tombent mal (1/3, 1/7, 1/8, 7/8), avec et
    // sans la zone, en recalculant la valeur attendue par la formule d'origine.
    it('garde un total strictement égal à la formule d’origine, et égal à la somme des parties', async () => {
      // Le profil de référence est en 95700. Les trois codes postaux couvrent les trois
      // valeurs possibles de zone : même département (1), voisin francilien (0,5) et
      // lointain (0). Le cas 0,5 est celui qui pouvait faire diverger les arrondis.
      const zones: [string, number][] = [
        ['95700', 1],
        ['93200', 0.5],
        ['69007', 0],
      ];
      const cas = [1, 2, 3, 6, 7, 8, 16];
      for (const nombreDeCompetences of cas) {
        for (const declarees of [0, 1]) {
          for (const [postalCode, zone] of zones) {
            const competences = Array.from({ length: nombreDeCompetences }, (_, i) => ({
              competenceCode: i < declarees ? 'C1' : `X${i}`,
            }));
            prisma.mission.findMany.mockResolvedValueOnce([mission({ competences, postalCode })]);

            const [match] = (await service.getMatchesForWorker('user-1')).matches;

            const overlap = declarees / nombreDeCompetences;
            const attendu = Math.round((overlap * 0.6 + zone * 0.4) * 100);

            expect(match.score).toBe(attendu);
            expect(match.detail.competences.points + match.detail.zone.points).toBe(match.score);
          }
        }
      }
    });
  });

  // Plus de fenêtre de disponibilité : une mission lointaine reste proposée, c'est
  // l'intérimaire qui juge (décision produit du 21/09).
  it('ne filtre pas sur les dates de la mission', async () => {
    prisma.mission.findMany.mockResolvedValueOnce([
      mission({ startDate: new Date('2027-01-01'), endDate: new Date('2027-01-05') }),
    ]);

    const { matches } = await service.getMatchesForWorker('user-1');

    expect(matches).toHaveLength(1);
  });

  it('exclut une mission sur un créneau non accepté', async () => {
    prisma.mission.findMany.mockResolvedValueOnce([mission({ shift: Shift.NUIT })]);

    const { matches } = await service.getMatchesForWorker('user-1');

    expect(matches).toEqual([]);
  });

  // Règle du CLAUDE.md : « un profil sans l'habilitation requise ne remonte jamais, quel que
  // soit son score ». La mission est écartée avant tout scoring, et seulement comptée.
  it("écarte une mission dont l'habilitation obligatoire manque au profil", async () => {
    prisma.mission.findMany.mockResolvedValueOnce([
      mission({ habilitations: [{ type: CertificationType.CACES_R489_5 }] }),
    ]);

    const { matches, masqueesFauteHabilitation } = await service.getMatchesForWorker('user-1');

    expect(matches).toEqual([]);
    expect(masqueesFauteHabilitation).toEqual({
      missions: 1,
      certifications: [CertificationType.CACES_R489_5],
    });
  });

  it('écarte aussi une mission dont le CACES détenu a expiré', async () => {
    prisma.worker.findUnique.mockResolvedValueOnce({
      ...baseWorker,
      certifications: [{ type: CertificationType.CACES_R489_3, expiresAt: new Date('2020-01-01') }],
    });

    const { matches, masqueesFauteHabilitation } = await service.getMatchesForWorker('user-1');

    expect(matches).toEqual([]);
    expect(masqueesFauteHabilitation.missions).toBe(1);
  });

  // L'onboarding est différable (docs/parcours-interimaire.md) : un critère jamais renseigné
  // ne doit pas vider la liste. Une fois renseigné, il filtre — cas couvert au-dessus.
  it('ne filtre pas sur le créneau tant que le profil n’en déclare aucun', async () => {
    prisma.worker.findUnique.mockResolvedValueOnce({ ...baseWorker, shifts: [] });
    prisma.mission.findMany.mockResolvedValueOnce([mission({ shift: Shift.NUIT })]);

    const { matches } = await service.getMatchesForWorker('user-1');

    expect(matches).toHaveLength(1);
  });

  it('trie les résultats par score décroissant', async () => {
    prisma.mission.findMany.mockResolvedValueOnce([
      mission({ id: 'faible', postalCode: '69007', competences: [{ competenceCode: 'C9' }] }),
      mission({ id: 'fort' }),
    ]);

    const { matches } = await service.getMatchesForWorker('user-1');

    expect(matches.map((m) => m.missionId)).toEqual(['fort', 'faible']);
  });

  it('journalise le calcul dans MongoDB sans faire échouer la réponse si ça écrit mal', async () => {
    insertOne.mockRejectedValueOnce(new Error('mongo indisponible'));

    const { matches } = await service.getMatchesForWorker('user-1');

    expect(matches).toHaveLength(1);
    expect(insertOne).toHaveBeenCalledWith(
      expect.objectContaining({ workerId: 'worker-1', missionsEvaluated: 1, missionsMasquees: 0 }),
    );
  });

  it('refuse un compte sans profil intérimaire', async () => {
    prisma.worker.findUnique.mockResolvedValueOnce(null);

    await expect(service.getMatchesForWorker('user-1')).rejects.toThrow(NotFoundException);
  });

  describe('notification n8n des nouveaux matchs', () => {
    // Pas d'historique à comparer : notifier ici enverrait un email à chaque inscription
    // dès que des missions correspondent, une rafale plutôt qu'une vraie nouveauté.
    it('ne notifie rien au tout premier calcul (pas d’historique)', async () => {
      await service.getMatchesForWorker('user-1');
      await flushPromises();

      expect(n8n.notifyMatch).not.toHaveBeenCalled();
    });

    it('ne notifie pas un match déjà présent au calcul précédent', async () => {
      mongo.getDb = jest.fn(() => ({
        collection: () => ({ insertOne, find: mockFindLogs([{ matchIds: ['mission-1'] }]) }),
      }));

      await service.getMatchesForWorker('user-1');
      await flushPromises();

      expect(n8n.notifyMatch).not.toHaveBeenCalled();
    });

    it('notifie seulement les matchs absents du calcul précédent', async () => {
      prisma.mission.findMany.mockResolvedValueOnce([
        mission({ id: 'mission-1' }),
        mission({ id: 'mission-2' }),
      ]);
      mongo.getDb = jest.fn(() => ({
        collection: () => ({ insertOne, find: mockFindLogs([{ matchIds: ['mission-1'] }]) }),
      }));

      await service.getMatchesForWorker('user-1');
      await flushPromises();

      expect(n8n.notifyMatch).toHaveBeenCalledTimes(1);
      expect(n8n.notifyMatch).toHaveBeenCalledWith(
        expect.objectContaining({
          interimaire: { prenom: 'Camille', nom: 'Martin', email: 'camille.martin@exemple.fr' },
          entreprise: { email: 'rh@loginord.fr' },
          mission: expect.objectContaining({ titre: 'Cariste' }),
        }),
      );
      const [payload] = n8n.notifyMatch.mock.calls[0] as [{ mission: { url: string } }];
      expect(payload.mission.url).toContain('mission-2');
    });

    // Le journal indisponible retombe sur « pas d'historique » : mêmes règles que le premier
    // calcul, pas de risque de spam ou de doublon si Mongo redevient joignable entre-temps.
    it('ne notifie rien si Mongo est indisponible pour lire l’historique', async () => {
      mongo.getDb = jest.fn(() => ({
        collection: () => ({
          insertOne,
          find: jest.fn(() => {
            throw new Error('mongo indisponible');
          }),
        }),
      }));

      await service.getMatchesForWorker('user-1');
      await flushPromises();

      expect(n8n.notifyMatch).not.toHaveBeenCalled();
    });
  });

  it('marque une mission comme déjà candidatée', async () => {
    prisma.worker.findUnique.mockResolvedValueOnce({
      ...baseWorker,
      candidatures: [{ missionId: 'mission-1' }],
    });

    const { matches } = await service.getMatchesForWorker('user-1');

    expect(matches[0].applied).toBe(true);
  });

  describe('missingCertificationsFor', () => {
    it('renvoie les habilitations exigées non couvertes (réutilisé par les candidatures)', async () => {
      prisma.mission.findUnique.mockResolvedValueOnce({
        habilitations: [{ type: CertificationType.CACES_R489_5 }],
      });

      const missing = await service.missingCertificationsFor('worker-1', 'mission-1');

      expect(missing).toEqual([CertificationType.CACES_R489_5]);
    });

    it('ignore une habilitation expirée : elle compte comme manquante', async () => {
      prisma.worker.findUnique.mockResolvedValueOnce({
        ...baseWorker,
        certifications: [
          { type: CertificationType.CACES_R489_3, expiresAt: new Date('2020-01-01') },
        ],
      });
      prisma.mission.findUnique.mockResolvedValueOnce({
        habilitations: [{ type: CertificationType.CACES_R489_3 }],
      });

      const missing = await service.missingCertificationsFor('worker-1', 'mission-1');

      expect(missing).toEqual([CertificationType.CACES_R489_3]);
    });

    it('refuse une mission inconnue', async () => {
      prisma.mission.findUnique.mockResolvedValueOnce(null);

      await expect(service.missingCertificationsFor('worker-1', 'mission-1')).rejects.toThrow(
        NotFoundException,
      );
    });
  });

  // Île-de-France uniquement, et c'est assumé : hors de ces huit départements la fonction
  // rend 0. Ces tests verrouillent les deux trous corrigés (91↔92 et 77↔91), que la version
  // précédente rendait à 0 alors que ce sont de vrais voisins.
  describe('departmentMatchRate', () => {
    const IDF = ['75', '77', '78', '91', '92', '93', '94', '95'];

    it('rend 1 dans le même département', () => {
      expect(departmentMatchRate('95700', '95100')).toBe(1);
      expect(departmentMatchRate('75001', '75020')).toBe(1);
    });

    it('rend 0,5 entre deux départements franciliens voisins', () => {
      expect(departmentMatchRate('95700', '93200')).toBe(0.5);
      expect(departmentMatchRate('75001', '92100')).toBe(0.5);
      expect(departmentMatchRate('77000', '94000')).toBe(0.5);
    });

    // Les deux paires que la table incomplète rendait à 0.
    it('rend 0,5 sur les deux voisinages qui manquaient (91-92 et 77-91)', () => {
      expect(departmentMatchRate('91000', '92100')).toBe(0.5);
      expect(departmentMatchRate('77000', '91000')).toBe(0.5);
    });

    it('rend 0 entre deux départements franciliens non voisins', () => {
      // Paris et le Val-d'Oise ne se touchent pas : 92 et 93 s'intercalent.
      expect(departmentMatchRate('75001', '95700')).toBe(0);
      expect(departmentMatchRate('78000', '93200')).toBe(0);
    });

    it('rend 0 pour un département lointain', () => {
      expect(departmentMatchRate('95700', '69007')).toBe(0);
      expect(departmentMatchRate('75001', '13001')).toBe(0);
    });

    // Limite assumée du POC : la table ne couvre que l'Île-de-France. Le Nord et le
    // Pas-de-Calais sont voisins dans la réalité, pas ici.
    it('rend 0 hors de la table, même entre voisins réels', () => {
      expect(departmentMatchRate('59000', '62000')).toBe(0);
      expect(departmentMatchRate('69001', '38000')).toBe(0);
    });

    it('rend 0 quand le code postal est inexploitable', () => {
      expect(departmentMatchRate('', '95700')).toBe(0);
      expect(departmentMatchRate('ABCDE', '95700')).toBe(0);
    });

    it('est symétrique sur toutes les paires franciliennes', () => {
      for (const a of IDF) {
        for (const b of IDF) {
          expect(departmentMatchRate(`${a}000`, `${b}000`)).toBe(
            departmentMatchRate(`${b}000`, `${a}000`),
          );
        }
      }
    });

    // Une table où 92 liste 91 sans que 91 liste 92 marcherait quand même, grâce au test
    // bidirectionnel de la fonction — mais elle serait fausse à la lecture, et le prochain
    // qui l'étendrait hériterait du piège.
    it('a une table d’adjacence elle-même symétrique et sans auto-référence', () => {
      const voisinages = new Map<string, string[]>();
      for (const departement of IDF) {
        voisinages.set(
          departement,
          IDF.filter(
            (autre) =>
              autre !== departement &&
              departmentMatchRate(`${departement}000`, `${autre}000`) === 0.5,
          ),
        );
      }

      for (const [departement, voisins] of voisinages) {
        expect(voisins).not.toContain(departement);
        for (const voisin of voisins) {
          expect(voisinages.get(voisin)).toContain(departement);
        }
      }
    });

    it('accepte une table fournie à l’appel, sans toucher à celle par défaut', () => {
      const table = { '01': ['99'], '99': ['01'] } as const;

      expect(departmentMatchRate('01000', '99000', table)).toBe(0.5);
      expect(departmentMatchRate('95700', '93200', table)).toBe(0);
      // La table par défaut n'a pas bougé.
      expect(departmentMatchRate('95700', '93200')).toBe(0.5);
    });
  });
});

// Validité d'une habilitation. Le test de bord ci-dessous a son JUMEAU côté site
// (apps/web/src/lib/habilitations.spec.ts) : c'est lui, et non un module partagé — il n'y en
// a pas dans ce monorepo —, qui empêche les deux règles de diverger. Modifier l'une sans
// l'autre doit casser un test.
describe('certificationValide', () => {
  const LE_23_SEPTEMBRE = new Date('2026-09-23T09:00:00Z');

  it('laisse valide une habilitation sans date d’expiration', () => {
    expect(certificationValide(null, LE_23_SEPTEMBRE)).toBe(true);
  });

  it('écarte une date passée', () => {
    expect(certificationValide(new Date('2026-09-22T00:00:00Z'), LE_23_SEPTEMBRE)).toBe(false);
    expect(certificationValide(new Date('2020-01-01T00:00:00Z'), LE_23_SEPTEMBRE)).toBe(false);
  });

  it('laisse valide une date à venir', () => {
    expect(certificationValide(new Date('2026-09-24T00:00:00Z'), LE_23_SEPTEMBRE)).toBe(true);
  });

  // LE CAS LIMITE. Une carte CACES qui porte « 23/09 » couvre le 23/09 en entier. Comparer
  // des instants — une colonne `@db.Date` revient à minuit UTC, `new Date()` est après —
  // écartait son titulaire dès le matin et lui faisait perdre un jour de validité.
  it('compte encore le jour même de l’expiration', () => {
    expect(certificationValide(new Date('2026-09-23T00:00:00Z'), LE_23_SEPTEMBRE)).toBe(true);
  });

  // LA BASCULE, à MINUIT HEURE DE PARIS et non minuit UTC. Le jumeau de ce test est dans
  // habilitations.spec.ts, aux mêmes instants : c'est lui qui tient les deux règles ensemble.
  //
  // CADANS est une plateforme française, la date métier est celle de Paris — et nos missions
  // du matin commencent à 6 h. En septembre (heure d'été), minuit à Paris vaut 22:00 UTC.
  it('bascule à minuit heure de Paris, pas à minuit UTC', () => {
    const expiration = new Date('2026-09-23T00:00:00Z');

    // 23:59 à Paris, le 23 : la carte court encore.
    expect(certificationValide(expiration, new Date('2026-09-23T21:59:00Z'))).toBe(true);
    // 00:00 à Paris, le 24 : elle ne court plus.
    expect(certificationValide(expiration, new Date('2026-09-23T22:00:00Z'))).toBe(false);
  });

  // Le décalage change en hiver : minuit à Paris vaut alors 23:00 UTC. Une règle écrite en
  // UTC serait juste six mois par an, et fausse les six autres.
  it('suit le passage à l’heure d’hiver', () => {
    const expiration = new Date('2026-01-15T00:00:00Z');

    expect(certificationValide(expiration, new Date('2026-01-15T22:59:00Z'))).toBe(true);
    expect(certificationValide(expiration, new Date('2026-01-15T23:00:00Z'))).toBe(false);
  });

  it('applique la même règle à la liste consommée par le matching et les candidatures', () => {
    const types = validCertificationTypes(
      [
        { type: CertificationType.CACES_R489_3, expiresAt: new Date('2026-09-23T00:00:00Z') },
        { type: CertificationType.CACES_R489_5, expiresAt: new Date('2026-09-22T00:00:00Z') },
        { type: CertificationType.CACES_R485_1, expiresAt: null },
      ],
      LE_23_SEPTEMBRE,
    );

    // Celle qui expire aujourd'hui compte ; celle d'hier, non.
    expect(types.sort()).toEqual([CertificationType.CACES_R485_1, CertificationType.CACES_R489_3]);
  });
});

// Formule partagée par le matching (vue intérimaire) et les candidatures (vue entreprise).
// C'est elle, et non deux calculs parallèles, qui garantit que les deux parties voient le
// MÊME chiffre — deux implémentations auraient fini par diverger et personne n'aurait su
// laquelle fait foi.
describe('scoreCandidat', () => {
  const MEME_DEPARTEMENT = ['95700', '95000'] as const;
  const DEPARTEMENT_VOISIN = ['95700', '78000'] as const;
  const AILLEURS = ['95700', '69007'] as const;

  it('ventile 60 points de compétences et 40 de zone', () => {
    const { score, detail } = scoreCandidat(['a', 'b'], new Set(['a']), ...MEME_DEPARTEMENT);

    expect(detail).toEqual({
      competences: { points: 30, max: 60 },
      zone: { points: 40, max: 40 },
    });
    // Le total est la somme des parties, jamais une valeur indépendante.
    expect(score).toBe(detail.competences.points + detail.zone.points);
    expect(score).toBe(70);
  });

  // Une mission sans compétence souhaitée ne doit pas pénaliser : elle n'a rien demandé.
  it('donne 100 % de la part compétences quand la mission n’en exige aucune', () => {
    expect(scoreCandidat([], new Set(), ...MEME_DEPARTEMENT).score).toBe(100);
  });

  it('donne zéro sur les compétences quand aucune ne correspond', () => {
    const { detail } = scoreCandidat(['a', 'b'], new Set(['z']), ...MEME_DEPARTEMENT);
    expect(detail.competences.points).toBe(0);
  });

  it.each([
    ['même département', MEME_DEPARTEMENT[0], MEME_DEPARTEMENT[1], 40],
    ['département voisin', DEPARTEMENT_VOISIN[0], DEPARTEMENT_VOISIN[1], 20],
    ['hors zone', AILLEURS[0], AILLEURS[1], 0],
  ])('%s vaut %s points de zone', (_cas, profil, mission, attendus) => {
    expect(scoreCandidat([], new Set(), profil, mission).detail.zone.points).toBe(attendus);
  });

  it('plafonne à 100 et plancher à 0', () => {
    expect(scoreCandidat(['a'], new Set(['a']), ...MEME_DEPARTEMENT).score).toBe(100);
    expect(scoreCandidat(['a'], new Set(), ...AILLEURS).score).toBe(0);
  });
});
