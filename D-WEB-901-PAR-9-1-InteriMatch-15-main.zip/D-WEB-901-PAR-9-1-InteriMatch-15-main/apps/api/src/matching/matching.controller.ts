import { Controller, Get } from '@nestjs/common';
import { Role } from '@prisma/client';
import { CurrentUser, Roles } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import { MatchesView, MatchingService } from './matching.service';

@Roles(Role.WORKER)
@Controller('matches')
export class MatchingController {
  constructor(private readonly matching: MatchingService) {}

  // Ne renvoie que les missions réellement proposables : le filtrage bloquant sur les
  // habilitations est appliqué dans le service, avant le scoring.
  @Get()
  findAll(@CurrentUser() user: SessionUser): Promise<MatchesView> {
    return this.matching.getMatchesForWorker(user.id);
  }
}
