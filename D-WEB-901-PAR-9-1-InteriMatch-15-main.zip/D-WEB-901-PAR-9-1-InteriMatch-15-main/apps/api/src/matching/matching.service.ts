import { Injectable, NotFoundException } from '@nestjs/common';
import { CertificationType, Shift } from '@prisma/client';
import { MongoService } from '../mongo/mongo.service';
import { N8nService } from '../n8n/n8n.service';
import { PrismaService } from '../prisma/prisma.service';

// Ventilation du score, telle qu'elle est DÉJÀ calculée : on cesse seulement de jeter le
// détail après l'avoir obtenu. `max` accompagne les points pour que l'écran n'ait pas à
// réécrire 60 et 40 de son côté — sans quoi les poids du matching seraient dupliqués dans
// le front, avec la garantie qu'ils divergent un jour.
export interface MatchScoreDetail {
  competences: { points: number; max: number };
  zone: { points: number; max: number };
}

export interface MatchView {
  missionId: string;
  posteLabel: string;
  companyName: string;
  siteLabel: string;
  postalCode: string;
  startDate: string;
  endDate: string;
  shift: Shift;
  hourlyRate: string;
  score: number;
  // Somme des deux lignes de `detail`, et non une valeur indépendante : la zone vaut 0, 20 ou
  // 40 points pile, donc l'arrondi du total et celui des parties ne peuvent pas diverger. Un
  // test le vérifie sur plusieurs taux de recouvrement et sur les trois valeurs de zone.
  detail: MatchScoreDetail;
  // Candidature déjà déposée sur cette mission : l'écran affiche « Candidature envoyée »
  // plutôt qu'un bouton qui échouerait.
  //
  // `blocked` et `missingCertifications` ne reviennent pas avec : une mission dont
  // l'habilitation manque n'est plus renvoyée du tout (filtrage bloquant), elle est comptée
  // dans `masqueesFauteHabilitation`. Les afficher ici laisserait croire qu'on peut postuler
  // sur une mission qu'on ne verra jamais.
  applied: boolean;
}

// Missions écartées par le filtrage bloquant. Elles ne sont pas détaillées — ce ne sont pas
// des propositions — mais comptées, pour l'incitation promise par docs/parcours-interimaire.md :
// « Ajoutez vos CACES pour voir davantage de missions ».
export interface MissionsMasqueesView {
  missions: number;
  certifications: CertificationType[];
}

export interface MatchesView {
  matches: MatchView[];
  masqueesFauteHabilitation: MissionsMasqueesView;
}

// Jour calendaire d'ici, en heure de Paris. CADANS est une plateforme française : la date
// métier est celle de Paris, pas celle d'UTC. L'écart n'est pas théorique — nos missions du
// matin commencent à 6 h, et une comparaison en UTC laissait une habilitation valide deux
// heures après minuit heure française.
//
// `Intl` avec `timeZone` fait le travail, y compris le passage heure d'été / heure d'hiver :
// la bascule tombe à 22:00 UTC en septembre et à 23:00 UTC en janvier, et c'est bien minuit
// à Paris dans les deux cas.
const JOUR_PARIS = new Intl.DateTimeFormat('fr-FR', {
  timeZone: 'Europe/Paris',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});

// « 2026-09-23 » : zéros compris, donc comparable directement par `<` et `>=`.
function jourParis(instant: Date): string {
  const parts = Object.fromEntries(
    JOUR_PARIS.formatToParts(instant).map((part) => [part.type, part.value]),
  );
  return `${parts.year}-${parts.month}-${parts.day}`;
}

// `expiresAt` vient d'une colonne `@db.Date` : Prisma la rend à MINUIT UTC, et ses composants
// UTC sont la date écrite sur la carte CACES. On les lit tels quels plutôt que de convertir
// l'instant — convertir donnerait ici le même résultat, mais par accident (Paris est en
// avance sur UTC), et le jour où quelqu'un stockerait autre chose, ce serait faux.
function jourInscrit(expiresAt: Date): string {
  const mois = String(expiresAt.getUTCMonth() + 1).padStart(2, '0');
  const jour = String(expiresAt.getUTCDate()).padStart(2, '0');
  return `${expiresAt.getUTCFullYear()}-${mois}-${jour}`;
}

/**
 * Une habilitation est valide JUSQU'À LA FIN de son jour d'expiration, heure de Paris.
 *
 * La comparaison porte sur le JOUR, pas sur l'instant. Une comparaison d'instants écartait
 * une habilitation « expire le 23/09 » dès le 23/09 au matin, parce qu'une colonne `@db.Date`
 * revient à minuit UTC et que `new Date()` est postérieur : l'intérimaire perdait un jour de
 * validité sur une carte CACES qui, elle, court jusqu'au soir.
 *
 * RÈGLE MIROIR de `estExpiree` (apps/web/src/lib/habilitations.ts). Il n'y a pas de paquet
 * partagé dans ce monorepo (`workspaces: apps/*`) : ce qui empêche les deux de diverger est
 * le TEST DE BORD écrit à l'identique des deux côtés — le jour même compte encore, et la
 * bascule tombe à minuit heure de Paris. Modifier l'une sans l'autre casse un test.
 */
export function certificationValide(expiresAt: Date | null, today: Date = new Date()): boolean {
  if (!expiresAt) {
    return true;
  }
  return jourInscrit(expiresAt) >= jourParis(today);
}

// Cette règle est également utilisée par les candidatures.
export function validCertificationTypes(
  certifications: { type: CertificationType; expiresAt: Date | null }[],
  today: Date = new Date(),
): CertificationType[] {
  return certifications
    .filter((cert) => certificationValide(cert.expiresAt, today))
    .map((cert) => cert.type);
}

type DepartmentNeighbors = Readonly<Record<string, readonly string[]>>;

// Adjacence des huit départements d'Île-de-France. Chaque département est une clé et liste
// TOUS ses voisins franciliens : la table est symétrique, et un test le vérifie.
//
// **Volontairement limitée à l'Île-de-France.** Hors de ces huit départements, la fonction
// rend 0 — un intérimaire lyonnais ne verra jamais une mission iséroise remonter au titre du
// voisinage. C'est une limite assumée du POC, pas un oubli : l'extension nationale (101
// départements) et le passage à une vraie distance en kilomètres sont décrits dans
// docs/perspectives.md.
//
// Seuls les voisins FRANCILIENS figurent ici. L'Eure (27), l'Oise (60) et l'Eure-et-Loir (28)
// touchent bien le 78 et le 95, mais les y mettre ferait croire à une couverture nationale
// partielle, impossible à raisonner : une mission dans l'Oise scorerait 0,5 depuis le 95 et 0
// depuis le 60 lui-même, faute d'entrée pour le 60.
const DEPARTMENTS_NEIGHBORS: DepartmentNeighbors = {
  '75': ['92', '93', '94'],
  '77': ['91', '93', '94', '95'],
  '78': ['91', '92', '95'],
  '91': ['77', '78', '92', '94'],
  '92': ['75', '78', '91', '93', '94', '95'],
  '93': ['75', '77', '92', '94', '95'],
  '94': ['75', '77', '91', '92', '93'],
  '95': ['77', '78', '92', '93'],
};

export function departmentMatchRate(
  workerPostalCode: string,
  missionPostalCode: string,
  neighbors: DepartmentNeighbors = DEPARTMENTS_NEIGHBORS,
): number {
  const workerDepartment = workerPostalCode.slice(0, 2);
  const missionDepartment = missionPostalCode.slice(0, 2);

  if (workerDepartment === missionDepartment) {
    return 1;
  }

  const workerNeighbors = neighbors[workerDepartment] ?? [];
  const missionNeighbors = neighbors[missionDepartment] ?? [];

  return workerNeighbors.includes(missionDepartment) || missionNeighbors.includes(workerDepartment)
    ? 0.5
    : 0;
}

// Poids du score : recouvrement de compétences d'abord, zone ensuite. Ce sont des constantes
// de code, ajustables sans migration. Les exposer via `MatchScoreDetail.max` évite que l'écran
// ait à les connaître.
const POIDS_COMPETENCES = 0.6;
const POIDS_ZONE = 0.4;

/**
 * Score d'un profil sur une mission, et sa ventilation.
 *
 * Extrait de la boucle de matching pour que les CANDIDATURES l'utilisent aussi : l'entreprise
 * qui choisit doit voir le même chiffre que l'intérimaire à qui on l'a montré. Deux calculs
 * séparés auraient fini par diverger, et personne n'aurait su lequel fait foi.
 *
 * Fonction pure : ni base, ni filtre bloquant. Les habilitations et le créneau sont des
 * CONDITIONS D'ACCÈS, pas des points — un profil qui n'a pas le CACES ne remonte pas du tout,
 * il n'a pas un score plus bas.
 */
export function scoreCandidat(
  competencesMission: readonly string[],
  competencesDeclarees: ReadonlySet<string>,
  codePostalProfil: string,
  codePostalMission: string,
): { score: number; detail: MatchScoreDetail } {
  // Une mission sans compétence requise obtient 100 % sur cette composante.
  const competenceMatchRate =
    competencesMission.length === 0
      ? 1
      : competencesMission.filter((code) => competencesDeclarees.has(code)).length /
        competencesMission.length;

  // Zone : même département = 100 %, département voisin = 50 %, sinon 0 %. Île-de-France
  // seulement (voir DEPARTMENTS_NEIGHBORS).
  const zoneScore = departmentMatchRate(codePostalProfil, codePostalMission);

  return {
    // Somme des deux lignes de `detail`, et non une valeur indépendante : la zone vaut 0, 20
    // ou 40 points pile, donc l'arrondi du total et celui des parties ne peuvent pas diverger.
    score: Math.round((competenceMatchRate * POIDS_COMPETENCES + zoneScore * POIDS_ZONE) * 100),
    detail: {
      competences: {
        points: Math.round(competenceMatchRate * POIDS_COMPETENCES * 100),
        max: Math.round(POIDS_COMPETENCES * 100),
      },
      zone: {
        points: Math.round(zoneScore * POIDS_ZONE * 100),
        max: Math.round(POIDS_ZONE * 100),
      },
    },
  };
}

// Donnée complémentaire à un match, utile seulement pour notifier n8n : jamais exposée dans
// MatchView, sans quoi l'email de l'entreprise fuiterait dans la réponse HTTP au worker.
interface MatchNotifiable {
  companyEmail: string;
}

@Injectable()
export class MatchingService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly mongo: MongoService,
    private readonly n8n: N8nService,
  ) {}

  async getMatchesForWorker(userId: string): Promise<MatchesView> {
    const worker = await this.prisma.worker.findUnique({
      where: { userId },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        postalCode: true,
        shifts: true,
        skills: { select: { competenceCode: true } },
        certifications: { select: { type: true, expiresAt: true } },
        user: { select: { email: true } },
        candidatures: { select: { missionId: true } },
      },
    });

    if (!worker) {
      throw new NotFoundException('Profil intérimaire introuvable');
    }

    // Un seul instant de référence pour tout le calcul.
    const now = new Date();

    const validCertifications = new Set(validCertificationTypes(worker.certifications, now));
    const declaredSkills = new Set(worker.skills.map((skill) => skill.competenceCode));
    const appliedMissionIds = new Set(
      worker.candidatures.map((candidature) => candidature.missionId),
    );
    const missions = await this.prisma.mission.findMany({
      where: { status: 'OUVERTE' },
      include: {
        poste: { select: { label: true } },
        company: {
          select: {
            legalName: true,
            user: { select: { email: true } },
          },
        },
        habilitations: { select: { type: true } },
        competences: { select: { competenceCode: true } },
      },
    });

    const matches: MatchView[] = [];
    const notifiable = new Map<string, MatchNotifiable>();

    // Les missions sans habilitation suffisante sont masquées, pas retournées.
    let missionsMasquees = 0;
    const habilitationsDebloquantes = new Set<CertificationType>();

    for (const mission of missions) {
      // Premier filtre bloquant : le créneau. Il n'y a pas de fenêtre de disponibilité à
      // comparer — un intérimaire qui consulte la plateforme est considéré disponible
      // (décision produit du 21/09).
      if (!this.acceptsShift(worker, mission.shift)) {
        continue;
      }

      // Second filtre bloquant, AVANT tout scoring : un profil sans le CACES exigé ne remonte
      // jamais, quel que soit son score. C'est la règle produit du CLAUDE.md, et
      // docs/parcours-interimaire.md la formule côté écran. L'ordre compte : le créneau
      // d'abord, les habilitations ensuite, le scoring en dernier — c'est ce qui fait qu'une
      // mission écartée par le créneau n'est pas comptée dans `masqueesFauteHabilitation`.
      const manquantes = mission.habilitations
        .map((habilitation) => habilitation.type)
        .filter((type) => !validCertifications.has(type));

      if (manquantes.length > 0) {
        missionsMasquees += 1;
        manquantes.forEach((type) => habilitationsDebloquantes.add(type));
        continue;
      }

      // Formule conservée : compétences 60 %, zone 40 %. Partagée avec les candidatures, pour
      // que l'entreprise voie le même chiffre que l'intérimaire.
      const { score, detail } = scoreCandidat(
        mission.competences.map((competence) => competence.competenceCode),
        declaredSkills,
        worker.postalCode,
        mission.postalCode,
      );

      matches.push({
        missionId: mission.id,
        posteLabel: mission.poste.label,
        companyName: mission.company.legalName,
        siteLabel: mission.siteLabel,
        postalCode: mission.postalCode,
        startDate: mission.startDate.toISOString().slice(0, 10),
        endDate: mission.endDate.toISOString().slice(0, 10),
        shift: mission.shift,
        hourlyRate: mission.hourlyRate.toString(),
        score,
        detail,
        applied: appliedMissionIds.has(mission.id),
      });

      notifiable.set(mission.id, {
        companyEmail: mission.company.user.email,
      });
    }

    // Score décroissant, puis date de début pour un ordre déterministe.
    matches.sort((a, b) => {
      if (b.score !== a.score) {
        return b.score - a.score;
      }

      return a.startDate.localeCompare(b.startDate);
    });

    // Notification n8n « match-notification » seulement pour les missions absentes du calcul
    // précédent de ce worker : sinon chaque rechargement de /matches relancerait un email pour
    // des matchs déjà vus. Rien n'est envoyé au tout premier calcul (pas d'historique à
    // comparer), ce qui évite une rafale à l'inscription.
    const previousMatchIds = await this.previousMatchIds(worker.id);

    if (previousMatchIds) {
      for (const match of matches) {
        if (previousMatchIds.has(match.missionId)) {
          continue;
        }

        const extra = notifiable.get(match.missionId);
        if (!extra) {
          continue;
        }

        void this.n8n
          .notifyMatch({
            interimaire: {
              prenom: worker.firstName,
              nom: worker.lastName,
              email: worker.user.email,
            },
            entreprise: {
              email: extra.companyEmail,
            },
            mission: {
              titre: match.posteLabel,
              entreprise: match.companyName,
              ville: match.siteLabel,
              codePostal: match.postalCode,
              dateDebut: match.startDate,
              remuneration: `${match.hourlyRate} € / h`,
              url: missionUrl(match.missionId),
            },
            score: match.score,
          })
          .catch(() => {
            // Une erreur n8n ne doit pas faire échouer le matching.
          });
      }
    }

    await this.logComputation(
      worker.id,
      missions.length,
      matches.length,
      missionsMasquees,
      matches.map((match) => match.missionId),
    );

    return {
      matches,
      masqueesFauteHabilitation: {
        missions: missionsMasquees,
        certifications: [...habilitationsDebloquantes].sort(),
      },
    };
  }

  // Si aucun créneau n'est renseigné, le filtre reste désactivé.
  private acceptsShift(worker: { shifts: Shift[] }, shift: Shift): boolean {
    return worker.shifts.length === 0 || worker.shifts.includes(shift);
  }

  // null = premier calcul ou historique Mongo indisponible : dans les deux cas,
  // aucune notification n'est envoyée pour éviter les doublons.
  private async previousMatchIds(workerId: string): Promise<Set<string> | null> {
    try {
      const logs = await this.mongo
        .getDb()
        .collection('matching_logs')
        .find({ workerId })
        .sort({ computedAt: -1 })
        .limit(1)
        .toArray();

      if (logs.length === 0) {
        return null;
      }

      const matchIds = (logs[0] as { matchIds?: unknown }).matchIds;

      return new Set(Array.isArray(matchIds) ? (matchIds as string[]) : []);
    } catch {
      return null;
    }
  }

  // Même règle de validité que le matching, réutilisée par les candidatures.
  async missingCertificationsFor(
    workerId: string,
    missionId: string,
  ): Promise<CertificationType[]> {
    const [worker, mission] = await Promise.all([
      this.prisma.worker.findUnique({
        where: { id: workerId },
        select: {
          certifications: { select: { type: true, expiresAt: true } },
        },
      }),
      this.prisma.mission.findUnique({
        where: { id: missionId },
        select: {
          habilitations: { select: { type: true } },
        },
      }),
    ]);

    if (!worker) {
      throw new NotFoundException('Profil intérimaire introuvable');
    }

    if (!mission) {
      throw new NotFoundException('Mission introuvable');
    }

    const validCertifications = new Set(validCertificationTypes(worker.certifications, new Date()));

    return mission.habilitations
      .map((habilitation) => habilitation.type)
      .filter((type) => !validCertifications.has(type));
  }

  // Le journal Mongo est secondaire : son indisponibilité ne doit jamais bloquer
  // la réponse du matching.
  private async logComputation(
    workerId: string,
    missionsEvaluated: number,
    matchesFound: number,
    missionsMasquees: number,
    matchIds: string[],
  ): Promise<void> {
    try {
      await this.mongo.getDb().collection('matching_logs').insertOne({
        workerId,
        computedAt: new Date(),
        missionsEvaluated,
        matchesFound,
        missionsMasquees,
        matchIds,
      });
    } catch {
      // Trace non critique.
    }
  }
}

function missionUrl(missionId: string): string {
  const base = (process.env.WEB_URL ?? 'http://localhost:3000').replace(/\/$/, '');

  return `${base}/missions/${missionId}`;
}
