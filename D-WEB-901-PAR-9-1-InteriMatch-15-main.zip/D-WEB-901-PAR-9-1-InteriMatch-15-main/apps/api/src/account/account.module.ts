import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { PrismaModule } from '../prisma/prisma.module';
import { AccountController } from './account.controller';
import { AccountService } from './account.service';

// AuthModule est importé pour PasswordService : les mots de passe doivent être hachés et
// vérifiés avec exactement les mêmes paramètres argon2 que l'inscription et la connexion.
@Module({
  imports: [PrismaModule, AuthModule],
  controllers: [AccountController],
  providers: [AccountService],
})
export class AccountModule {}
