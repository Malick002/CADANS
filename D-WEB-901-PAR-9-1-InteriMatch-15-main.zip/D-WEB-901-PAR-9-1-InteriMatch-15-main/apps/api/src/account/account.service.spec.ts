import { BadRequestException, ConflictException } from '@nestjs/common';
import { PasswordService } from '../auth/password.service';
import { PrismaService } from '../prisma/prisma.service';
import { AccountService } from './account.service';

const MAINTENANT = new Date('2026-09-23T10:00:00.000Z');
const USER_ID = 'user-1';

const compte = {
  email: 'nadia@entrepot-nord.fr',
  passwordHash: 'hash-argon2',
  updatedAt: MAINTENANT,
};

describe('AccountService', () => {
  let prisma: {
    user: { findUnique: jest.Mock; update: jest.Mock };
    passwordResetToken: { updateMany: jest.Mock };
  };
  let passwords: { hash: jest.Mock; verify: jest.Mock };
  let service: AccountService;

  // Prisma n'envoie QUE les colonnes du `select`. La doublure doit faire pareil, sinon
  // l'assertion « la réponse ne contient jamais le hash » ne vérifie rien : elle passerait
  // même si le service demandait `passwordHash` pour le rendre à l'écran.
  const selon = (select: Record<string, boolean> | undefined) =>
    Object.fromEntries(Object.entries(compte).filter(([cle]) => select?.[cle] === true)) as Partial<
      typeof compte
    >;

  beforeEach(() => {
    prisma = {
      user: {
        findUnique: jest
          .fn()
          .mockImplementation(({ select }: { select?: Record<string, boolean> }) =>
            Promise.resolve(selon(select)),
          ),
        update: jest
          .fn()
          .mockImplementation(({ data }: { data: Record<string, string> }) =>
            Promise.resolve({ email: data.email ?? compte.email, updatedAt: MAINTENANT }),
          ),
      },
      passwordResetToken: { updateMany: jest.fn().mockResolvedValue({ count: 0 }) },
    };
    passwords = {
      hash: jest.fn().mockResolvedValue('nouveau-hash'),
      // Par défaut le mot de passe actuel est le bon ; chaque test qui veut l'inverse le dit.
      verify: jest.fn().mockResolvedValue(true),
    };
    service = new AccountService(
      prisma as unknown as PrismaService,
      passwords as unknown as PasswordService,
    );
    jest.spyOn(service['logger'], 'log').mockImplementation(() => undefined);
  });

  describe('changeEmail', () => {
    const dto = { email: 'nadia@nouvelle-adresse.fr', currentPassword: 'MotDePasse#2026' };

    it('change l’adresse après vérification du mot de passe actuel', async () => {
      // `findUnique` sert deux fois : le compte, puis la recherche d'une adresse déjà prise.
      // 1er appel : le compte (avec son hash) ; 2e : la recherche d'adresse déjà prise.
      prisma.user.findUnique.mockResolvedValueOnce(compte).mockResolvedValueOnce(null);

      const resultat = await service.changeEmail(USER_ID, dto);

      expect(passwords.verify).toHaveBeenCalledWith('hash-argon2', 'MotDePasse#2026');
      expect(prisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { id: USER_ID },
          data: { email: 'nadia@nouvelle-adresse.fr' },
        }),
      );
      expect(resultat.email).toBe('nadia@nouvelle-adresse.fr');
    });

    // Le point de sécurité : sans ce contrôle, un poste laissé ouvert suffirait à s'emparer
    // du compte — changer l'adresse, puis demander une réinitialisation sur la nouvelle.
    it('refuse sans le bon mot de passe actuel, et n’écrit rien', async () => {
      passwords.verify.mockResolvedValue(false);

      await expect(service.changeEmail(USER_ID, dto)).rejects.toBeInstanceOf(BadRequestException);
      expect(prisma.user.update).not.toHaveBeenCalled();
    });

    it('refuse une adresse déjà utilisée par un autre compte', async () => {
      prisma.user.findUnique
        .mockResolvedValueOnce(compte)
        .mockResolvedValueOnce({ id: 'un-autre' });

      await expect(service.changeEmail(USER_ID, dto)).rejects.toBeInstanceOf(ConflictException);
      expect(prisma.user.update).not.toHaveBeenCalled();
    });

    // Renvoyer la même adresse n'est pas une erreur, mais ce n'est pas non plus une
    // modification : on n'écrit pas, et `updatedAt` ne bouge pas pour rien.
    it('ne touche à rien si l’adresse est inchangée', async () => {
      const resultat = await service.changeEmail(USER_ID, {
        email: compte.email,
        currentPassword: 'MotDePasse#2026',
      });

      expect(resultat.email).toBe(compte.email);
      expect(prisma.user.update).not.toHaveBeenCalled();
    });
  });

  describe('changePassword', () => {
    const dto = { currentPassword: 'MotDePasse#2026', password: 'NouveauMotDePasse#2027' };

    it('hache le nouveau mot de passe et révoque les liens de réinitialisation', async () => {
      await service.changePassword(USER_ID, dto);

      expect(passwords.verify).toHaveBeenCalledWith('hash-argon2', 'MotDePasse#2026');
      expect(passwords.hash).toHaveBeenCalledWith('NouveauMotDePasse#2027');
      expect(prisma.user.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: { passwordHash: 'nouveau-hash' } }),
      );
      // Un lien reçu par email avant le changement ne doit plus rouvrir le compte.
      expect(prisma.passwordResetToken.updateMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { userId: USER_ID, usedAt: null } }),
      );
    });

    it('refuse sans le bon mot de passe actuel, et n’écrit rien', async () => {
      passwords.verify.mockResolvedValue(false);

      await expect(service.changePassword(USER_ID, dto)).rejects.toBeInstanceOf(
        BadRequestException,
      );
      expect(prisma.user.update).not.toHaveBeenCalled();
      expect(prisma.passwordResetToken.updateMany).not.toHaveBeenCalled();
    });

    // Sinon l'écran annonce un changement qui n'en est pas un, et l'utilisateur croit son
    // compte renouvelé alors que le mot de passe éventuellement compromis reste en place.
    it('refuse un nouveau mot de passe identique à l’actuel', async () => {
      await expect(
        service.changePassword(USER_ID, {
          currentPassword: 'MotDePasse#2026',
          password: 'MotDePasse#2026',
        }),
      ).rejects.toThrow('différent');
      expect(prisma.user.update).not.toHaveBeenCalled();
    });

    // Le message ne doit rien apprendre de plus que « ce n'est pas le bon » — ni si le
    // compte existe, ni quelle règle le nouveau mot de passe enfreint.
    it('donne le même message quelle que soit l’opération refusée', async () => {
      passwords.verify.mockResolvedValue(false);

      const email = await service
        .changeEmail(USER_ID, { email: 'x@y.fr', currentPassword: 'faux' })
        .catch((error: Error) => error.message);
      const motDePasse = await service
        .changePassword(USER_ID, { currentPassword: 'faux', password: 'NouveauMotDePasse#2027' })
        .catch((error: Error) => error.message);

      expect(email).toBe(motDePasse);
    });
  });

  describe('get', () => {
    it('renvoie l’adresse du compte connecté, jamais le hash', async () => {
      const resultat = await service.get(USER_ID);

      expect(resultat).toEqual({ email: compte.email, updatedAt: MAINTENANT });
      expect(JSON.stringify(resultat)).not.toContain('hash');
    });

    it('refuse un compte introuvable', async () => {
      prisma.user.findUnique.mockResolvedValue(null);

      await expect(service.get(USER_ID)).rejects.toBeInstanceOf(BadRequestException);
    });
  });
});
