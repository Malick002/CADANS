import { Body, Controller, Get, Put } from '@nestjs/common';
import { CurrentUser } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import { AccountService, AccountView } from './account.service';
import { ChangeEmailDto } from './dto/change-email.dto';
import { ChangePasswordDto } from './dto/change-password.dto';

// Pas de @Roles : les identifiants de connexion sont les mêmes pour une entreprise, un
// intérimaire ou un agent CADANS. Les routes restent protégées — la session est exigée par
// défaut (SessionGuard), seules les routes @Public y échappent.
//
// L'identifiant du compte vient toujours de la session (@CurrentUser), jamais du corps de la
// requête : sans cela, n'importe quel utilisateur connecté changerait le mot de passe d'un
// autre en passant son identifiant.
@Controller('account/me')
export class AccountController {
  constructor(private readonly account: AccountService) {}

  @Get()
  get(@CurrentUser() user: SessionUser): Promise<AccountView> {
    return this.account.get(user.id);
  }

  @Put('email')
  changeEmail(@CurrentUser() user: SessionUser, @Body() dto: ChangeEmailDto): Promise<AccountView> {
    return this.account.changeEmail(user.id, dto);
  }

  @Put('password')
  changePassword(
    @CurrentUser() user: SessionUser,
    @Body() dto: ChangePasswordDto,
  ): Promise<AccountView> {
    return this.account.changePassword(user.id, dto);
  }
}
