import { BadRequestException, ConflictException, Injectable, Logger } from '@nestjs/common';
import { PasswordService } from '../auth/password.service';
import { PrismaService } from '../prisma/prisma.service';
import { ChangeEmailDto } from './dto/change-email.dto';
import { ChangePasswordDto } from './dto/change-password.dto';

export interface AccountView {
  email: string;
  // Dernière modification du compte, pour que l'écran puisse dire « modifié le … » plutôt
  // que de laisser l'utilisateur se demander si son changement a bien été pris.
  updatedAt: Date;
}

// Message unique pour un mot de passe actuel erroné, quelle que soit l'opération : il ne
// doit rien apprendre de plus que « ce n'est pas le bon ».
const MOT_DE_PASSE_INVALIDE = 'Le mot de passe actuel est incorrect';

/**
 * Identifiants de connexion, communs aux deux rôles : l'entreprise et l'intérimaire ont le
 * même besoin, et la table `User` est la même. Les données de PROFIL, elles, restent dans
 * `companies` et `workers` — ce sont deux modèles différents.
 *
 * Les deux opérations exigent le mot de passe actuel. C'est la seule barrière disponible :
 * il n'y a ni double authentification, ni confirmation par email dans ce POC.
 */
@Injectable()
export class AccountService {
  private readonly logger = new Logger(AccountService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly passwords: PasswordService,
  ) {}

  async get(userId: string): Promise<AccountView> {
    return this.requireUser(userId);
  }

  /**
   * Change l'adresse de connexion.
   *
   * La session n'est PAS réémise, et c'est volontaire : le jeton ne porte que `sub` et
   * `role` (token.service.ts), jamais l'email. Une adresse modifiée n'y change rien, et
   * forcer une reconnexion serait un désagrément sans contrepartie.
   */
  async changeEmail(userId: string, dto: ChangeEmailDto): Promise<AccountView> {
    const user = await this.requireUserWithHash(userId);
    await this.assertCurrentPassword(user.passwordHash, dto.currentPassword);

    // Adresse inchangée : on ne touche à rien plutôt que de faire croire à une modification.
    if (user.email === dto.email) {
      return { email: user.email, updatedAt: user.updatedAt };
    }

    const occupe = await this.prisma.user.findUnique({
      where: { email: dto.email },
      select: { id: true },
    });
    // 409 explicite, comme à l'inscription : le compromis sur l'énumération des comptes est
    // déjà assumé là-bas (docs/api.md, « Sécurité en résumé »), et ici l'utilisateur vient
    // d'apporter son mot de passe — il est chez lui.
    if (occupe) {
      throw new ConflictException('Cette adresse email est déjà utilisée');
    }

    const misAJour = await this.prisma.user.update({
      where: { id: userId },
      data: { email: dto.email },
      select: { email: true, updatedAt: true },
    });

    // L'ancienne adresse n'est pas journalisée : ce serait une donnée personnelle de plus,
    // conservée sans finalité.
    this.logger.log(`Adresse de connexion modifiée pour le compte ${userId}`);
    return misAJour;
  }

  async changePassword(userId: string, dto: ChangePasswordDto): Promise<AccountView> {
    const user = await this.requireUserWithHash(userId);
    await this.assertCurrentPassword(user.passwordHash, dto.currentPassword);

    if (dto.password === dto.currentPassword) {
      throw new BadRequestException('Le nouveau mot de passe doit être différent de l’actuel');
    }

    const misAJour = await this.prisma.user.update({
      where: { id: userId },
      data: { passwordHash: await this.passwords.hash(dto.password) },
      select: { email: true, updatedAt: true },
    });

    // Même logique que la réinitialisation par email : les liens en circulation tombent.
    await this.prisma.passwordResetToken.updateMany({
      where: { userId, usedAt: null },
      data: { usedAt: new Date() },
    });

    // Les sessions JWT déjà émises restent valides jusqu'à leur expiration : sans stockage
    // des sessions, l'API ne sait pas les révoquer. Même limite que password-reset.service,
    // à traiter le jour où une liste de révocation existera.
    this.logger.log(`Mot de passe modifié pour le compte ${userId}`);
    return misAJour;
  }

  private async requireUser(userId: string): Promise<AccountView> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { email: true, updatedAt: true },
    });
    if (!user) {
      // La session porte un compte qui n'existe plus : rien à faire côté utilisateur.
      throw new BadRequestException('Compte introuvable');
    }
    return user;
  }

  private async requireUserWithHash(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { email: true, passwordHash: true, updatedAt: true },
    });
    if (!user) {
      throw new BadRequestException('Compte introuvable');
    }
    return user;
  }

  private async assertCurrentPassword(hash: string, fourni: string): Promise<void> {
    if (!(await this.passwords.verify(hash, fourni))) {
      throw new BadRequestException(MOT_DE_PASSE_INVALIDE);
    }
  }
}
