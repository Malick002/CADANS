import { IsNotEmpty, IsString, Matches, MaxLength, MinLength } from 'class-validator';
import {
  PASSWORD_MAX_LENGTH,
  PASSWORD_MESSAGE,
  PASSWORD_MIN_LENGTH,
  PASSWORD_PATTERN,
} from '../../auth/dto/validation';

export class ChangePasswordDto {
  @IsString()
  @IsNotEmpty({ message: 'Saisissez votre mot de passe actuel' })
  @MaxLength(PASSWORD_MAX_LENGTH)
  currentPassword: string;

  // Mêmes règles qu'à l'inscription (CredentialsDto) : les constantes sont partagées, pour
  // qu'un durcissement de la politique s'applique partout d'un coup.
  @IsString()
  @MinLength(PASSWORD_MIN_LENGTH, {
    message: `Le mot de passe doit contenir au moins ${PASSWORD_MIN_LENGTH} caractères`,
  })
  @MaxLength(PASSWORD_MAX_LENGTH)
  @Matches(PASSWORD_PATTERN, { message: PASSWORD_MESSAGE })
  password: string;
}
