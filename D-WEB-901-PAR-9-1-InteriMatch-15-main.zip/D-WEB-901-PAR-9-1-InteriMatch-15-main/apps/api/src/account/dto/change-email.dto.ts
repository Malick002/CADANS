import { IsEmail, IsNotEmpty, IsString, MaxLength } from 'class-validator';
import { NormalizeEmail } from '../../auth/dto/validation';

export class ChangeEmailDto {
  @NormalizeEmail()
  @IsEmail({}, { message: "L'adresse email n'est pas valide" })
  @MaxLength(255)
  email: string;

  // Le mot de passe actuel est EXIGÉ pour changer d'adresse : l'email est l'identifiant de
  // connexion et la cible de la réinitialisation. Sans ce contrôle, un poste laissé ouvert
  // suffirait à s'emparer du compte — on changerait l'adresse, puis on demanderait un
  // nouveau mot de passe sur la nouvelle boîte. Aucune règle de format ici : on vérifie un
  // mot de passe existant, pas on en impose un nouveau.
  @IsString()
  @IsNotEmpty({ message: 'Saisissez votre mot de passe actuel' })
  @MaxLength(128)
  currentPassword: string;
}
