import {
  Body,
  Controller,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { Role } from '@prisma/client';
import { CurrentUser, Public, Roles } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import { ChangeStatusDto } from './dto/change-status.dto';
import { CreateMissionDto } from './dto/create-mission.dto';
import { ListMissionsQueryDto } from './dto/list-missions-query.dto';
import { PrefillMissionDto } from './dto/prefill-mission.dto';
import { MissionsService, MissionView } from './missions.service';
import { MissionPrefill, OffrePrefillService } from './offre-prefill.service';

// Deux publics sur le même contrôleur. Les deux routes en lecture marquées @Public sont les
// pages d'annonce, rendues côté serveur et indexables (exigence SEO du sujet) ; tout le reste
// est réservé à l'entreprise propriétaire, dont l'identifiant vient toujours de la session
// (@CurrentUser), jamais d'un paramètre d'URL ou du corps de la requête.
//
// @Roles est porté par chaque méthode et non par la classe : RolesGuard ne consulte pas
// IS_PUBLIC_KEY, un @Roles de classe l'emporterait donc sur @Public et les deux routes
// d'annonce répondraient 401.
@Controller('missions')
export class MissionsController {
  constructor(
    private readonly missions: MissionsService,
    private readonly prefillOffre: OffrePrefillService,
  ) {}

  // Les deux routes de préremplissage portent deux segments : elles ne peuvent pas être
  // confondues avec ':id'. Elles sont néanmoins déclarées en tête, par lisibilité.
  //
  // Publique et sans effet de bord : elle ne dit qu'une chose, si le serveur a les
  // identifiants France Travail. L'écran de création s'en sert pour afficher — ou masquer —
  // l'entrée « Partir d'une offre » avant toute interaction, et la page est rendue côté
  // serveur sans session (comme GET /referentiel/postes).
  @Public()
  @Get('prefill/disponibilite')
  prefillDisponible(): { disponible: boolean } {
    return { disponible: this.prefillOffre.disponible() };
  }

  // POST pour un usage de lecture, à dessein : ce que l'entreprise colle est une URL
  // complète, qu'un paramètre de requête ferait encoder puis journaliser dans les accès du
  // serveur. L'appel n'est de toute façon ni idempotent-critique ni cacheable — il consomme
  // le quota d'une API externe.
  @Roles(Role.COMPANY)
  @Post('prefill')
  prefill(@Body() dto: PrefillMissionDto): Promise<MissionPrefill> {
    return this.prefillOffre.prefill(dto.source);
  }

  // Déclarée avant ':id' pour que 'ouvertes' ne soit pas interprété comme un identifiant.
  @Public()
  @Get('ouvertes')
  findOpen(): Promise<MissionView[]> {
    return this.missions.findOpen();
  }

  @Public()
  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string): Promise<MissionView> {
    return this.missions.findOne(id);
  }

  @Roles(Role.COMPANY)
  @Post()
  create(@CurrentUser() user: SessionUser, @Body() dto: CreateMissionDto): Promise<MissionView> {
    return this.missions.create(user.id, dto);
  }

  @Roles(Role.COMPANY)
  @Get()
  findAll(
    @CurrentUser() user: SessionUser,
    @Query() query: ListMissionsQueryDto,
  ): Promise<MissionView[]> {
    return this.missions.findAllForCompany(user.id, query.status);
  }

  @Roles(Role.COMPANY)
  @Put(':id')
  update(
    @CurrentUser() user: SessionUser,
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: CreateMissionDto,
  ): Promise<MissionView> {
    return this.missions.update(user.id, id, dto);
  }

  @Roles(Role.COMPANY)
  @Patch(':id/status')
  changeStatus(
    @CurrentUser() user: SessionUser,
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: ChangeStatusDto,
  ): Promise<MissionView> {
    return this.missions.changeStatus(user.id, id, dto.status, dto.workerId);
  }
}
