import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
  Logger,
  NotFoundException,
  ServiceUnavailableException,
} from '@nestjs/common';
import { FranceTravailClient, OffreFranceTravailError } from '../referentiel/france-travail.client';
import { extraireReferenceOffre, urlOffrePublique } from '../referentiel/offre-reference';
import { ReferentielService } from '../referentiel/referentiel.service';
import {
  RemunerationOffre,
  remunerationDepuisOffre,
  ValeursPreremplies,
  valeursDepuisOffre,
} from './offre-prefill';

export interface MissionPrefill {
  reference: string;
  // Intitulé de l'offre, affiché tel quel dans la mention de provenance. Il n'est PAS
  // prérempli dans un champ : le poste de la mission vient du référentiel, pas du titre d'une
  // annonce rédigée par quelqu'un d'autre.
  intituleOffre: string;
  urlOffre: string;
  valeurs: ValeursPreremplies;
  // Détail de la rémunération, à côté de `valeurs.hourlyRate` et non dedans : `valeurs` ne
  // porte que des valeurs de formulaire, alors qu'il s'agit ici de dire D'OÙ vient le taux
  // proposé — converti d'un salaire mensuel, borne basse d'une fourchette, ou format non
  // reconnu. L'écran en fait une mention sous le champ ; sans elle, un taux estimé passerait
  // pour une donnée de l'offre.
  remuneration?: RemunerationOffre;
}

/**
 * Préremplissage d'une mission à partir d'une offre France Travail.
 *
 * Trois responsabilités, dans cet ordre : reconnaître la référence dans ce que l'utilisateur a
 * collé, lire l'offre, la traduire en valeurs de formulaire. Aucune écriture : rien n'est
 * stocké ici, et la seule trace qui survivra est `Mission.sourceOffreId`, enregistrée plus
 * tard si — et seulement si — l'entreprise publie la mission.
 *
 * Toute panne se termine par un code HTTP et une phrase que l'écran peut afficher telle
 * quelle, jamais par une erreur technique : l'entreprise doit pouvoir continuer au formulaire
 * vierge dans tous les cas.
 */
@Injectable()
export class OffrePrefillService {
  private readonly logger = new Logger(OffrePrefillService.name);

  constructor(
    private readonly franceTravail: FranceTravailClient,
    private readonly referentiel: ReferentielService,
  ) {}

  // Sert à masquer l'entrée « Partir d'une offre » quand les identifiants ne sont pas
  // configurés (développement sans compte, déploiement où les variables manquent) : une
  // entrée qui échoue à tous les coups vaut moins qu'une entrée absente.
  disponible(): boolean {
    return this.franceTravail.configured;
  }

  async prefill(saisie: string): Promise<MissionPrefill> {
    const reference = extraireReferenceOffre(saisie);
    if (!reference) {
      throw new BadRequestException(
        'Ce lien ne contient pas d’identifiant d’offre France Travail. Collez l’adresse ' +
          'complète de l’offre, ou son identifiant seul (7 caractères, par exemple 214GWTK).',
      );
    }

    if (!this.disponible()) {
      throw new ServiceUnavailableException(
        'Le préremplissage depuis France Travail n’est pas configuré sur ce serveur. ' +
          'Saisissez la mission dans le formulaire.',
      );
    }

    const offre = await this.lireOffre(reference);
    const postes = await this.referentiel.postesExposes();

    // La durée hebdomadaire vient de la même offre : elle sert de base à la conversion d'un
    // salaire mensuel ou annuel, et l'écran l'affiche pour que l'estimation soit vérifiable.
    const remuneration = remunerationDepuisOffre(offre.salaire?.libelle, offre.dureeTravailLibelle);

    return {
      reference,
      intituleOffre: offre.intitule,
      urlOffre: urlOffrePublique(reference),
      valeurs: valeursDepuisOffre(offre, postes),
      ...(remuneration ? { remuneration } : {}),
    };
  }

  // Traduit les trois échecs du client en réponses HTTP. Le message technique reste dans les
  // journaux, celui qui part à l'écran dit quoi faire.
  private async lireOffre(reference: string) {
    try {
      return await this.franceTravail.offreEmploi(reference);
    } catch (error) {
      if (!(error instanceof OffreFranceTravailError)) {
        throw error;
      }
      this.logger.warn(`Préremplissage ${reference} : ${error.message}`);

      if (error.raison === 'introuvable') {
        throw new NotFoundException(
          `L’offre n° ${reference} est introuvable ou n’est plus en ligne. ` +
            'Vérifiez le lien, ou saisissez la mission dans le formulaire.',
        );
      }
      if (error.raison === 'quota') {
        // 429 et non 503 : le service fonctionne, c'est notre consommation qui est au plafond.
        // L'entreprise doit savoir que réessayer plus tard marchera.
        throw new HttpException(
          'Trop de demandes envoyées à France Travail pour le moment. Réessayez dans ' +
            'quelques minutes, ou saisissez la mission dans le formulaire.',
          HttpStatus.TOO_MANY_REQUESTS,
        );
      }
      throw new ServiceUnavailableException(
        'France Travail ne répond pas pour l’instant. Saisissez la mission dans le ' +
          'formulaire, vous pourrez la publier normalement.',
      );
    }
  }
}
