import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { CertificationType, Mission, MissionStatus, MotifRecours } from '@prisma/client';
import { ContractsService } from '../contracts/contracts.service';
import { N8nService } from '../n8n/n8n.service';
import { PrismaService } from '../prisma/prisma.service';
import { CreateMissionDto } from './dto/create-mission.dto';

export interface MissionView {
  id: string;
  posteCode: string;
  posteLabel: string;
  companyName: string;
  siteLabel: string;
  postalCode: string;
  startDate: string;
  endDate: string;
  shift: Mission['shift'];
  motifRecours: MotifRecours;
  remplaceNom: string | null;
  remplaceQualification: string | null;
  hourlyRate: string;
  description: string | null;
  status: MissionStatus;
  requiredCertifications: CertificationType[];
  competenceCodes: string[];
  // Référence de l'offre France Travail dont la mission a été préremplie, le cas échéant.
  sourceOffreId: string | null;
  createdAt: Date;
  updatedAt: Date;
}

type MissionWithRelations = Mission & {
  poste: { label: string };
  company: { legalName: string };
  habilitations: { type: CertificationType }[];
  competences: { competenceCode: string }[];
};

const MISSION_INCLUDE = {
  poste: { select: { label: true } },
  company: { select: { legalName: true } },
  habilitations: { select: { type: true } },
  competences: { select: { competenceCode: true } },
} as const;

@Injectable()
export class MissionsService {
  private readonly logger = new Logger(MissionsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly n8n: N8nService,
    private readonly contracts: ContractsService,
  ) {}

  async create(userId: string, dto: CreateMissionDto): Promise<MissionView> {
    const companyId = await this.companyId(userId);
    await this.assertPosteExpose(dto.posteCode);
    await this.assertCompetencesExist(dto.competenceCodes ?? []);

    if (new Date(dto.endDate) < new Date(dto.startDate)) {
      throw new BadRequestException('La date de fin ne peut pas précéder la date de début');
    }

    const certifications = dedupe(dto.requiredCertifications ?? []);
    const competenceCodes = dedupe(dto.competenceCodes ?? []);

    const mission = await this.prisma.mission.create({
      data: {
        companyId,
        posteCode: dto.posteCode,
        siteLabel: dto.siteLabel,
        postalCode: dto.postalCode,
        startDate: new Date(dto.startDate),
        endDate: new Date(dto.endDate),
        shift: dto.shift,
        ...motifFields(dto),
        hourlyRate: dto.hourlyRate,
        description: dto.description ?? null,
        sourceOffreId: dto.sourceOffreId ?? null,
        habilitations: { create: certifications.map((type) => ({ type })) },
        competences: { create: competenceCodes.map((competenceCode) => ({ competenceCode })) },
      },
      include: MISSION_INCLUDE,
    });

    return toView(mission);
  }

  async findAllForCompany(userId: string, status?: MissionStatus): Promise<MissionView[]> {
    const companyId = await this.companyId(userId);
    const missions = await this.prisma.mission.findMany({
      where: { companyId, ...(status ? { status } : {}) },
      include: MISSION_INCLUDE,
      orderBy: { createdAt: 'desc' },
    });

    return missions.map(toView);
  }

  // Remplace la mission en entier (l'écran renvoie le formulaire complet). Habilitations et
  // compétences sont remises à plat dans la même requête que la mission : `deleteMany` imbriqué
  // plutôt que séparé, sinon un échec laisserait la mission sans ses habilitations.
  async update(userId: string, missionId: string, dto: CreateMissionDto): Promise<MissionView> {
    await this.assertOwner(userId, missionId);
    await this.assertPosteExpose(dto.posteCode);
    await this.assertCompetencesExist(dto.competenceCodes ?? []);

    if (new Date(dto.endDate) < new Date(dto.startDate)) {
      throw new BadRequestException('La date de fin ne peut pas précéder la date de début');
    }

    const certifications = dedupe(dto.requiredCertifications ?? []);
    const competenceCodes = dedupe(dto.competenceCodes ?? []);

    const mission = await this.prisma.mission.update({
      where: { id: missionId },
      data: {
        posteCode: dto.posteCode,
        siteLabel: dto.siteLabel,
        postalCode: dto.postalCode,
        startDate: new Date(dto.startDate),
        endDate: new Date(dto.endDate),
        shift: dto.shift,
        ...motifFields(dto),
        hourlyRate: dto.hourlyRate,
        description: dto.description ?? null,
        // `sourceOffreId` n'est VOLONTAIREMENT pas mis à jour : la provenance est un fait
        // historique, pas une propriété modifiable. L'écran de modification ne la renvoie
        // pas, et l'inclure ici l'effacerait à la première correction de la mission.
        habilitations: { deleteMany: {}, create: certifications.map((type) => ({ type })) },
        competences: {
          deleteMany: {},
          create: competenceCodes.map((competenceCode) => ({ competenceCode })),
        },
      },
      include: MISSION_INCLUDE,
    });

    return toView(mission);
  }

  // Ouverte → Pourvue → Terminée. Sans cette route une mission resterait ouverte à vie, et
  // la liste publique afficherait des missions déjà pourvues.
  //
  // Passer à POURVUE exige l'intérimaire retenu (workerId, validé par ChangeStatusDto) :
  // pas de file de candidature dans ce POC, l'entreprise choisit hors plateforme et
  // renseigne son identifiant ici. C'est ce qui déclenche le contrat et la notification
  // n8n « mission-pourvue » (n8n/README.md).
  async changeStatus(
    userId: string,
    missionId: string,
    status: MissionStatus,
    workerId?: string,
  ): Promise<MissionView> {
    await this.assertOwner(userId, missionId);
    if (status === MissionStatus.POURVUE) {
      await this.assertWorkerExists(workerId!);
    }

    const mission = await this.prisma.mission.update({
      where: { id: missionId },
      data: {
        status,
        ...(status === MissionStatus.POURVUE ? { assignedWorkerId: workerId } : {}),
      },
      include: MISSION_INCLUDE,
    });

    if (status === MissionStatus.POURVUE) {
      // Notification et génération du contrat : un aval de l'action, jamais une condition
      // de sa réussite. La réponse HTTP ne dépend pas de n8n ou de la génération du PDF.
      void this.notifyMissionPourvue(missionId, workerId!);
    }

    return toView(mission);
  }

  // Liste publique des missions à pourvoir, les plus récentes d'abord. C'est la page que les
  // moteurs indexent : elle doit se lire sans session, et ne montrer que ce qui est ouvert.
  async findOpen(): Promise<MissionView[]> {
    const missions = await this.prisma.mission.findMany({
      where: { status: MissionStatus.OUVERTE },
      include: MISSION_INCLUDE,
      orderBy: { createdAt: 'desc' },
    });
    return missions.map(toView);
  }

  // Fiche publique d'une mission, quel que soit son statut : une URL partagée ou indexée ne
  // doit pas retourner 404 le jour où la mission est pourvue.
  async findOne(missionId: string): Promise<MissionView> {
    const mission = await this.prisma.mission.findUnique({
      where: { id: missionId },
      include: MISSION_INCLUDE,
    });
    if (!mission) {
      throw new NotFoundException('Mission introuvable');
    }
    return toView(mission);
  }

  private async companyId(userId: string): Promise<string> {
    const company = await this.prisma.company.findUnique({
      where: { userId },
      select: { id: true },
    });
    if (!company) {
      throw new NotFoundException('Profil entreprise introuvable');
    }
    return company.id;
  }

  // Le poste doit exister, être actif et faire partie de ceux proposés aux entreprises.
  // Le référentiel ROME importé contient aussi des métiers hors entrepôt et des synonymes
  // non retenus (colonne `exposed`, curation décrite dans docs/referentiel-matching.md) : sans ce filtre, une
  // entreprise pourrait publier une mission de transport routier, hors périmètre du POC.
  private async assertPosteExpose(posteCode: string): Promise<void> {
    const poste = await this.prisma.poste.findFirst({
      where: { code: posteCode, exposed: true, active: true },
      select: { code: true },
    });
    if (!poste) {
      throw new BadRequestException("Ce poste n'existe pas ou n'est pas proposé");
    }
  }

  // 403 et non 404 : la mission existe et sa fiche est publique, elle n'est simplement pas
  // la vôtre. On ne révèle rien qu'un visiteur ne puisse déjà lire.
  private async assertOwner(userId: string, missionId: string): Promise<void> {
    const mission = await this.prisma.mission.findUnique({
      where: { id: missionId },
      select: { company: { select: { userId: true } } },
    });
    if (!mission) {
      throw new NotFoundException('Mission introuvable');
    }
    if (mission.company.userId !== userId) {
      throw new ForbiddenException('Cette mission appartient à une autre entreprise');
    }
  }

  private async assertCompetencesExist(codes: string[]): Promise<void> {
    const unique = dedupe(codes);
    if (unique.length === 0) {
      return;
    }
    const found = await this.prisma.competence.findMany({
      where: { code: { in: unique } },
      select: { code: true },
    });
    if (found.length !== unique.length) {
      throw new BadRequestException('Une ou plusieurs compétences sont inconnues du référentiel');
    }
  }

  private async assertWorkerExists(workerId: string): Promise<void> {
    const worker = await this.prisma.worker.findUnique({
      where: { id: workerId },
      select: { id: true },
    });
    if (!worker) {
      throw new BadRequestException('Cet intérimaire est introuvable');
    }
  }

  // Requêtes séparées de la mise à jour ci-dessus : ni le contrat ni la notification ne
  // doivent retarder ou faire échouer la réponse HTTP à l'entreprise. Toute erreur ici est
  // journalisée, jamais relancée (même logique que MailService).
  //
  // L'ordre compte toujours : les contrats sont générés et stockés d'ABORD, la notification
  // ensuite — elle porte un lien vers eux. S'ils manquent (informations d'embauche
  // incomplètes), l'email part quand même : prévenir l'intérimaire qu'il est retenu, et lui
  // dire ce qu'il lui reste à renseigner, vaut mieux que ne rien envoyer du tout.
  private async notifyMissionPourvue(missionId: string, workerId: string): Promise<void> {
    try {
      const generation = await this.contracts.generateForMission(missionId);
      if (generation.contratDeMissionManquant) {
        this.logger.log(
          `Mission ${missionId} : contrat de mission différé, informations d'embauche incomplètes.`,
        );
      }

      const [mission, worker] = await Promise.all([
        this.prisma.mission.findUnique({
          where: { id: missionId },
          include: {
            poste: { select: { label: true } },
            company: { select: { user: { select: { email: true } } } },
          },
        }),
        this.prisma.worker.findUnique({
          where: { id: workerId },
          include: { user: { select: { email: true } } },
        }),
      ]);
      if (!mission || !worker) {
        return;
      }

      await this.n8n.notifyMissionPourvue({
        interimaire: { prenom: worker.firstName, nom: worker.lastName, email: worker.user.email },
        entreprise: { email: mission.company.user.email },
        mission: {
          titre: mission.poste.label,
          ville: mission.siteLabel,
          codePostal: mission.postalCode,
          dateDebut: mission.startDate.toISOString().slice(0, 10),
          dateFin: mission.endDate.toISOString().slice(0, 10),
          remuneration: `${mission.hourlyRate.toString()} € / h`,
          url: missionUrl(mission.id),
        },
      });
    } catch (error) {
      this.logger.warn(
        `Notification « mission pourvue » impossible pour ${missionId} : ${(error as Error).message}`,
      );
    }
  }
}

// Les deux champs du remplacement sont remis à null dès que le motif n'est plus un
// remplacement : sans ça, changer le motif d'une mission laisserait au contrat le nom d'un
// salarié qui n'a plus rien à y faire.
function motifFields(dto: CreateMissionDto) {
  const remplacement = dto.motifRecours === MotifRecours.REMPLACEMENT;
  return {
    motifRecours: dto.motifRecours,
    remplaceNom: remplacement ? (dto.remplaceNom ?? null) : null,
    remplaceQualification: remplacement ? (dto.remplaceQualification ?? null) : null,
  };
}

function dedupe<T>(values: T[]): T[] {
  return [...new Set(values)];
}

// Fiche publique de la mission (`/missions/:id`, rendue côté serveur par apps/web) : c'est
// l'URL que portent les emails n8n.
function missionUrl(missionId: string): string {
  const base = (process.env.WEB_URL ?? 'http://localhost:3000').replace(/\/$/, '');
  return `${base}/missions/${missionId}`;
}

function toView(mission: MissionWithRelations): MissionView {
  return {
    id: mission.id,
    posteCode: mission.posteCode,
    posteLabel: mission.poste.label,
    companyName: mission.company.legalName,
    siteLabel: mission.siteLabel,
    postalCode: mission.postalCode,
    startDate: mission.startDate.toISOString().slice(0, 10),
    endDate: mission.endDate.toISOString().slice(0, 10),
    shift: mission.shift,
    motifRecours: mission.motifRecours,
    remplaceNom: mission.remplaceNom,
    remplaceQualification: mission.remplaceQualification,
    hourlyRate: mission.hourlyRate.toString(),
    description: mission.description,
    status: mission.status,
    requiredCertifications: mission.habilitations.map((h) => h.type),
    competenceCodes: mission.competences.map((c) => c.competenceCode),
    sourceOffreId: mission.sourceOffreId,
    createdAt: mission.createdAt,
    updatedAt: mission.updatedAt,
  };
}
