import { CertificationType, Shift } from '@prisma/client';
import { OffreEmploi } from '../referentiel/offre-emploi';
import { PosteExpose } from '../referentiel/referentiel.service';
import {
  creneau,
  DESCRIPTION_MAX,
  dureeHebdomadaire,
  heuresParMois,
  nettoyerDescription,
  posteCorrespondant,
  remunerationDepuisOffre,
  valeursDepuisOffre,
} from './offre-prefill';

// Extrait du référentiel tel que le renvoie ReferentielService.postesExposes() : seulement
// des postes exposés et actifs, triés par code ROME puis classification.
const POSTES: PosteExpose[] = [
  {
    code: '11679',
    label: 'Cariste',
    classification: 'PRINCIPALE',
    rome: { code: 'N1101', label: 'Cariste' },
    habilitationsSuggerees: [CertificationType.CACES_R489_3],
  },
  {
    code: '11684',
    label: "Cariste d'entrepôt",
    classification: 'SYNONYME',
    rome: { code: 'N1101', label: 'Cariste' },
    habilitationsSuggerees: [CertificationType.CACES_R489_3],
  },
  {
    code: '17993',
    label: 'Préparateur / Préparatrice de commandes',
    classification: 'PRINCIPALE',
    rome: { code: 'N1103', label: 'Préparateur / Préparatrice de commandes' },
    habilitationsSuggerees: [],
  },
];

// Offre réelle, réduite aux champs lus : GET /partenaire/offresdemploi/v2/offres/214GWTK,
// relevée le 23/09/2026. Les blocs `contact`, `agence` et `entreprise` de la réponse ne sont
// volontairement pas reproduits — le type ne les déclare pas, ils ne sont jamais lus.
const OFFRE: OffreEmploi = {
  id: '214GWTK',
  intitule: 'Cariste (H/F)',
  description: 'Poste basé dans le secteur de Sarrebourg. Vous êtes titulaire des caces 1-3-5 ?',
  romeCode: 'N1101',
  appellationlibelle: 'Cariste secteur industrie',
  lieuTravail: { libelle: '57 - Sarrebourg', codePostal: '57400' },
  salaire: { libelle: 'Horaire de 13.0 Euros à 13.0 Euros' },
  dureeTravailLibelle: '38H/semaine\nTravail posté (2x8, 3x8, 5x8, etc.)',
};

describe('nettoyerDescription', () => {
  it('retire les adresses électroniques', () => {
    const propre = nettoyerDescription(
      'Envoyez votre CV à recrutement.saverne@partnaire.fr dès aujourd’hui',
    );
    expect(propre).not.toMatch(/@/);
    expect(propre).toContain('Envoyez votre CV à');
  });

  it('retire les numéros de téléphone, quel que soit le séparateur', () => {
    for (const numero of [
      '03 87 23 45 67',
      '03.87.23.45.67',
      '03-87-23-45-67',
      '0387234567',
      '+33 3 87 23 45 67',
      '+33 (0)3 87 23 45 67',
    ]) {
      const propre = nettoyerDescription(`Appelez le ${numero} pour postuler`);
      expect(propre).toBe('Appelez le pour postuler');
    }
  });

  it('retire les URL, avec ou sans schéma', () => {
    const propre = nettoyerDescription(
      'Postulez sur https://job.mytalentplug.com/api/JobOffer/redirect/?id=0fe8 ou www.partnaire.fr',
    );
    expect(propre).toBe('Postulez sur ou');
  });

  // Une URL contient un « @ » et des chiffres : traitée après les courriels ou les
  // téléphones, elle laisserait des moignons. L'ordre des passes est donc vérifié ici.
  it('retire une URL contenant une arobase sans en laisser de reste', () => {
    const propre = nettoyerDescription('Détails : https://exemple.fr/u@v/03.87.23.45.67/fin.');
    expect(propre).toBe('Détails.');
  });

  // Le nettoyage ne doit JAMAIS retoucher une phrase qu'il n'a pas caviardée. L'espace avant
  // le point d'interrogation est correct en français, et une passe de ponctuation appliquée à
  // tout le texte le supprimait.
  it('ne retouche pas la ponctuation d’un texte sans coordonnées', () => {
    const texte = 'Vous êtes titulaire des caces 1-3-5 ? Postulez !';
    expect(nettoyerDescription(texte)).toBe(texte);
  });

  it('nettoie la ponctuation et les lignes vides laissées par les suppressions', () => {
    const propre = nettoyerDescription(
      'Contactez-nous au 03 87 23 45 67.\n\n\n\nOu par mail : contact@exemple.fr.\n\nÀ bientôt',
    );
    expect(propre).toBe('Contactez-nous au.\n\nOu par mail.\n\nÀ bientôt');
  });

  // Résidu constaté sur l'offre réelle 214GYJJ : l'agence encadre son adresse de
  // parenthèses, et le caviardage laissait un « ( ) » au milieu de la phrase.
  it('retire les délimiteurs qui n’encadrent plus rien', () => {
    expect(nettoyerDescription('Envoyez votre candidature (recrute@agence.fr) ou appelez')).toBe(
      'Envoyez votre candidature ou appelez',
    );
    expect(nettoyerDescription('Voir « https://exemple.fr » pour plus')).toBe('Voir pour plus');
  });

  it('ne laisse pas d’indentation quand la coordonnée ouvrait la ligne', () => {
    expect(nettoyerDescription('Contact\ncontact@exemple.fr\nMerci')).toBe('Contact\nMerci');
  });

  it('rend undefined quand il ne reste rien d’exploitable', () => {
    expect(
      nettoyerDescription('https://exemple.fr contact@exemple.fr 03 87 23 45 67'),
    ).toBeUndefined();
    expect(nettoyerDescription('   ')).toBeUndefined();
    expect(nettoyerDescription(undefined)).toBeUndefined();
    expect(nettoyerDescription('')).toBeUndefined();
  });

  // La colonne accepte 2000 caractères et le DTO les refuse au-delà : couper ici évite que
  // l'entreprise voie son formulaire rejeté sur un texte qu'elle n'a pas écrit.
  it('tronque au maximum du champ, sur une frontière de mot', () => {
    const long = `${'mot '.repeat(800)}fin`;
    const propre = nettoyerDescription(long)!;

    expect(propre.length).toBeLessThanOrEqual(DESCRIPTION_MAX);
    expect(propre.endsWith('…')).toBe(true);
    expect(propre).not.toMatch(/mo…$/);
  });

  it('laisse intact un texte qui ne contient aucune coordonnée', () => {
    const texte = 'Vous préparez les commandes à l’aide du picking vocal.\n\nPort de charges.';
    expect(nettoyerDescription(texte)).toBe(texte);
  });
});

describe('posteCorrespondant', () => {
  it('retient le poste dont le libellé correspond exactement à l’appellation de l’offre', () => {
    const poste = posteCorrespondant(
      { ...OFFRE, appellationlibelle: "Cariste d'entrepôt" },
      POSTES,
    );
    expect(poste?.code).toBe('11684');
  });

  it('ignore la casse, les accents et la ponctuation du libellé', () => {
    const poste = posteCorrespondant(
      { ...OFFRE, romeCode: 'N1103', appellationlibelle: 'PREPARATEUR/PREPARATRICE DE COMMANDES' },
      POSTES,
    );
    expect(poste?.code).toBe('17993');
  });

  // « Cariste secteur industrie » est une appellation réelle de N1101, écartée par la
  // curation (hors entrepôt strict) : elle n'a pas d'équivalent exposé.
  it('retombe sur l’appellation principale du code ROME quand l’appellation n’est pas exposée', () => {
    expect(posteCorrespondant(OFFRE, POSTES)?.code).toBe('11679');
  });

  it('ne rend rien pour un code ROME hors périmètre', () => {
    expect(posteCorrespondant({ ...OFFRE, romeCode: 'N1303' }, POSTES)).toBeUndefined();
  });

  it('ne rend rien quand l’offre ne porte pas de code ROME', () => {
    expect(posteCorrespondant({ ...OFFRE, romeCode: undefined }, POSTES)).toBeUndefined();
  });
});

// Les six formes relevées le 23/09/2026 sur 450 offres d'intérim des trois codes ROME.
describe('remunerationDepuisOffre', () => {
  describe('salaire horaire : repris tel quel, sans conversion', () => {
    it('lit un montant simple', () => {
      expect(remunerationDepuisOffre('Horaire de 12.31 Euros')).toEqual({
        libelle: 'Horaire de 12.31 Euros',
        estimation: {
          taux: '12.31',
          periode: 'horaire',
          montant: 12.31,
          fourchette: false,
          heuresHebdo: 35,
          dureeLue: false,
        },
      });
    });

    // Proposer le haut de la fourchette gonflerait une rémunération contractuelle : c'est la
    // borne BASSE qui est retenue, et le drapeau dit à l'écran de le signaler.
    it('retient la borne basse d’une fourchette et le signale', () => {
      expect(
        remunerationDepuisOffre('Horaire de 12.31 Euros à 12.74 Euros')?.estimation,
      ).toMatchObject({ taux: '12.31', periode: 'horaire', montant: 12.31, fourchette: true });
    });

    it('accepte la virgule décimale', () => {
      expect(remunerationDepuisOffre('Horaire de 12,54 Euros')?.estimation?.taux).toBe('12.54');
    });
  });

  describe('salaire mensuel et annuel : convertis, et marqués comme estimés', () => {
    // 2206 ÷ (35 × 52 ÷ 12) = 2206 ÷ 151,6667 = 14,5451… → 14,55.
    it('convertit un salaire mensuel sur la base de la durée hebdomadaire', () => {
      expect(remunerationDepuisOffre('Mensuel de 2206.0 Euros', '35H/semaine')?.estimation).toEqual(
        {
          taux: '14.55',
          periode: 'mensuel',
          montant: 2206,
          fourchette: false,
          heuresHebdo: 35,
          dureeLue: true,
        },
      );
    });

    // 22405 ÷ 12 ÷ 151,6667 = 12,3104… → 12,31, soit le SMIC : le contrôle de vraisemblance
    // passe, la base de conversion n'est pas absurde.
    it('convertit un salaire annuel en passant par le mois', () => {
      expect(
        remunerationDepuisOffre('Annuel de 22405.0 Euros à 25000.0 Euros', '35H/semaine')
          ?.estimation,
      ).toMatchObject({ taux: '12.31', periode: 'annuel', montant: 22405, fourchette: true });
    });

    it('retient aussi la borne basse pour un mensuel en fourchette', () => {
      const estimation = remunerationDepuisOffre(
        'Mensuel de 2206.0 Euros à 2500.0 Euros',
        '35H/semaine',
      )?.estimation;
      expect(estimation?.montant).toBe(2206);
      expect(estimation?.fourchette).toBe(true);
    });

    // LE point de cette amélioration : une mission à 38 h convertie sur 35 h surestime le
    // taux horaire de 8 %, et ce taux-là finit au contrat de mission.
    it.each([
      ['35H/semaine', 35, '14.55'],
      ['38H/semaine', 38, '13.40'],
      ['40H/semaine', 40, '12.73'],
    ])('convertit 2 206 € mensuels avec « %s »', (duree, heuresHebdo, taux) => {
      expect(remunerationDepuisOffre('Mensuel de 2206.0 Euros', duree)?.estimation).toMatchObject({
        taux,
        heuresHebdo,
        dureeLue: true,
      });
    });

    it('applique la même durée à un salaire annuel', () => {
      expect(
        remunerationDepuisOffre('Annuel de 22405.0 Euros', '38H/semaine')?.estimation,
      ).toMatchObject({ taux: '11.34', heuresHebdo: 38, dureeLue: true });
    });

    // Un taux horaire n'est pas converti : la durée ne change rien, mais elle est tout de
    // même rapportée — l'écran n'a alors aucune base à citer, et n'en cite aucune.
    it('ne touche pas à un taux horaire, quelle que soit la durée', () => {
      expect(
        remunerationDepuisOffre('Horaire de 13.0 Euros', '40H/semaine')?.estimation?.taux,
      ).toBe('13.00');
    });
  });

  // Repli : la durée sert de base, encore faut-il qu'elle soit lisible et vraisemblable.
  describe('base de conversion : durée de l’offre, sinon 35 h', () => {
    it('retombe sur 35 h quand l’offre ne donne aucune durée', () => {
      expect(remunerationDepuisOffre('Mensuel de 2206.0 Euros')?.estimation).toMatchObject({
        taux: '14.55',
        heuresHebdo: 35,
        dureeLue: false,
      });
    });

    it('retombe sur 35 h quand la durée est illisible', () => {
      expect(
        remunerationDepuisOffre('Mensuel de 2206.0 Euros', 'Travail en journée')?.estimation,
      ).toMatchObject({ heuresHebdo: 35, dureeLue: false });
    });

    // « Temps partiel - 3H/semaine » existe dans l'échantillon : convertir un salaire mensuel
    // sur 13 h de base donnerait un taux horaire aberrant, qui partirait au contrat.
    it.each(['Temps partiel - 3H/semaine', '60H/semaine', '19H/semaine', '49H/semaine'])(
      'retombe sur 35 h pour une durée hors plage (« %s »)',
      (duree) => {
        expect(remunerationDepuisOffre('Mensuel de 2206.0 Euros', duree)?.estimation).toMatchObject(
          { heuresHebdo: 35, dureeLue: false },
        );
      },
    );
  });

  describe('arrondi au centime', () => {
    // `toFixed` seul dépend de la représentation binaire : (1.005).toFixed(2) rend « 1.00 ».
    // L'arrondi est donc fait sur la valeur avant formatage.
    it('arrondit au centime supérieur quand il le faut', () => {
      // 2000 ÷ 151,6667 = 13,18681… → 13,19
      expect(
        remunerationDepuisOffre('Mensuel de 2000 Euros', '35H/semaine')?.estimation?.taux,
      ).toBe('13.19');
      // 2100 ÷ 151,6667 = 13,84615… → 13,85
      expect(
        remunerationDepuisOffre('Mensuel de 2100 Euros', '35H/semaine')?.estimation?.taux,
      ).toBe('13.85');
    });

    it('rend toujours deux décimales, même sur un compte rond', () => {
      expect(remunerationDepuisOffre('Horaire de 13 Euros')?.estimation?.taux).toBe('13.00');
      expect(remunerationDepuisOffre('Horaire de 13.5 Euros')?.estimation?.taux).toBe('13.50');
    });
  });

  describe('format non reconnu : champ vide, libellé brut conservé', () => {
    it.each(['Selon profil', 'À négocier', 'Horaire de zéro Euros', 'Mensuel de 0 Euros'])(
      'ne propose rien pour « %s », mais garde le libellé',
      (libelle) => {
        expect(remunerationDepuisOffre(libelle)).toEqual({ libelle });
      },
    );

    // Un montant absurde dépasserait Decimal(5,2) : l'API refuserait l'enregistrement. Mieux
    // vaut ne rien proposer qu'un champ que la publication rejettera.
    it('ne propose rien au-delà de ce que la colonne accepte', () => {
      expect(remunerationDepuisOffre('Horaire de 1000000 Euros')?.estimation).toBeUndefined();
    });

    it('ne rend rien quand l’offre n’a pas de salaire', () => {
      expect(remunerationDepuisOffre(undefined)).toBeUndefined();
      expect(remunerationDepuisOffre('   ')).toBeUndefined();
    });
  });

  // 6 offres sur 450 ajoutent un complément libre. Il n'est pas convertible — c'est
  // précisément pourquoi le libellé brut reste affiché à l'entreprise.
  it('lit le salaire de base et conserve le complément dans le libellé', () => {
    const remuneration = remunerationDepuisOffre(
      'Mensuel de 2015 Euros à 2300 Euros - 13ème mois + prime de panier',
      '35H/semaine',
    );

    expect(remuneration?.estimation?.taux).toBe('13.29');
    expect(remuneration?.libelle).toContain('13ème mois + prime de panier');
  });
});

// Formes relevées le 23/09/2026 sur 450 offres : « 35H/semaine » (434),
// « Temps partiel - 24H/semaine » (13), « 38H45/semaine » (3).
describe('dureeHebdomadaire', () => {
  it('lit la forme courante', () => {
    expect(dureeHebdomadaire('35H/semaine\nTravail en journée')).toBe(35);
    expect(dureeHebdomadaire('40H/semaine')).toBe(40);
  });

  it('lit un temps partiel resté dans la plage plausible', () => {
    expect(dureeHebdomadaire('Temps partiel - 24H/semaine')).toBe(24);
  });

  // « 38H45 » = 38 h 45 min. Lu naïvement, il donnerait 38 h (acceptable) ou 3845 h
  // (catastrophique) : les minutes sont lues explicitement.
  it('lit les heures ET les minutes', () => {
    expect(dureeHebdomadaire('38H45/semaine')).toBeCloseTo(38.75, 5);
    expect(dureeHebdomadaire('37H30/semaine')).toBeCloseTo(37.5, 5);
  });

  it.each([
    ['une durée absente', undefined],
    ['un libellé sans durée', 'Travail posté (2x8, 3x8, 5x8, etc.)'],
    ['une chaîne vide', ''],
    ['un temps partiel très court', 'Temps partiel - 3H/semaine'],
    ['une durée sous la plage', '19H/semaine'],
    ['une durée au-dessus de la plage', '49H/semaine'],
    ['des minutes impossibles', '38H90/semaine'],
  ])('ne rend rien pour %s', (_cas, libelle) => {
    expect(dureeHebdomadaire(libelle)).toBeUndefined();
  });

  it('accepte les bornes de la plage', () => {
    expect(dureeHebdomadaire('20H/semaine')).toBe(20);
    expect(dureeHebdomadaire('48H/semaine')).toBe(48);
  });
});

describe('heuresParMois', () => {
  // Base mensuelle = durée hebdomadaire × 52 ÷ 12. Pour 35 h, la durée légale mensuelle.
  it('applique la formule de la demande', () => {
    expect(heuresParMois(35)).toBeCloseTo(151.6667, 3);
    expect(heuresParMois(38)).toBeCloseTo(164.6667, 3);
    expect(heuresParMois(40)).toBeCloseTo(173.3333, 3);
  });
});

describe('creneau', () => {
  it('reconnaît le travail en journée', () => {
    expect(creneau('35H/semaine\nTravail en journée')).toBe(Shift.JOURNEE);
  });

  it('reconnaît le travail de nuit', () => {
    expect(creneau('35H/semaine\nTravail de nuit')).toBe(Shift.NUIT);
  });

  // Aucun de nos quatre créneaux ne décrit un 3x8 : en choisir un serait inventer l'horaire
  // que l'article L. 1251-43 4° fait figurer au contrat.
  it.each([
    '38H/semaine\nTravail posté (2x8, 3x8, 5x8, etc.)',
    '35H/semaine\nTravail en horaires décalés',
    '35H/semaine\nTravail en horaires fixes',
    '35H/semaine',
  ])('ne devine pas le créneau de « %s »', (duree) => {
    expect(creneau(duree)).toBeUndefined();
  });

  it('ne rend rien sans durée', () => {
    expect(creneau(undefined)).toBeUndefined();
  });
});

describe('valeursDepuisOffre', () => {
  it('reprend les champs que l’offre porte vraiment', () => {
    expect(valeursDepuisOffre(OFFRE, POSTES)).toEqual({
      posteCode: '11679',
      siteLabel: '57 - Sarrebourg',
      postalCode: '57400',
      hourlyRate: '13.00',
      description:
        'Poste basé dans le secteur de Sarrebourg. Vous êtes titulaire des caces 1-3-5 ?',
    });
  });

  // Le point de fond : ces quatre champs ne sont JAMAIS déduits. Un formulaire qui les
  // affiche remplis passerait la relecture, et partirait faux au contrat.
  it('n’invente ni dates, ni motif de recours, ni compétences, ni habilitations', () => {
    const valeurs = valeursDepuisOffre(OFFRE, POSTES) as Record<string, unknown>;

    expect(valeurs).not.toHaveProperty('startDate');
    expect(valeurs).not.toHaveProperty('endDate');
    expect(valeurs).not.toHaveProperty('motifRecours');
    expect(valeurs).not.toHaveProperty('competenceCodes');
    expect(valeurs).not.toHaveProperty('requiredCertifications');
  });

  it('omet les clés qu’il n’a pas pu remplir plutôt que de les rendre vides', () => {
    const valeurs = valeursDepuisOffre(
      { id: '214GWTK', intitule: 'Cariste (H/F)', romeCode: 'N1303' },
      POSTES,
    );
    expect(valeurs).toEqual({});
  });

  // Le champ du formulaire reçoit bien le taux converti : c'était le point de la demande,
  // laisser le champ vide sur une offre au mois privait l'entreprise du champ le plus regardé.
  // L'offre de référence porte « 38H/semaine » : c'est cette durée qui sert de base, pas 35.
  it('remplit le champ à partir d’un salaire mensuel, sur la durée de l’offre', () => {
    const valeurs = valeursDepuisOffre(
      { ...OFFRE, salaire: { libelle: 'Mensuel de 2206.0 Euros' } },
      POSTES,
    );
    expect(valeurs.hourlyRate).toBe('13.40');
  });

  it('laisse le champ vide quand le format du salaire n’est pas reconnu', () => {
    const valeurs = valeursDepuisOffre({ ...OFFRE, salaire: { libelle: 'Selon profil' } }, POSTES);
    expect(valeurs.hourlyRate).toBeUndefined();
  });

  it('écarte un code postal qui n’en est pas un', () => {
    const valeurs = valeursDepuisOffre(
      { ...OFFRE, lieuTravail: { libelle: 'Belgique', codePostal: '1000' } },
      POSTES,
    );
    expect(valeurs.postalCode).toBeUndefined();
    expect(valeurs.siteLabel).toBe('Belgique');
  });

  it('tronque un libellé de site trop long pour la colonne', () => {
    const valeurs = valeursDepuisOffre(
      { ...OFFRE, lieuTravail: { libelle: 'x'.repeat(400) } },
      POSTES,
    );
    expect(valeurs.siteLabel).toHaveLength(255);
  });

  it('nettoie la description avant de la proposer au formulaire', () => {
    const valeurs = valeursDepuisOffre(
      { ...OFFRE, description: 'Candidatez : recrute@partnaire.fr ou au 03 87 23 45 67.' },
      POSTES,
    );
    // Le caviardage ne réécrit pas la phrase : « ou au » reste, et c'est à l'entreprise de
    // relire — d'où l'étiquette affichée sous le champ.
    expect(valeurs.description).toBe('Candidatez ou au.');
  });
});
