import { CertificationType } from '@prisma/client';

// Libellés des habilitations, côté API. Miroir de apps/web/src/lib/certifications.ts : le
// contrat PDF est produit par l'API, il ne peut pas lire un fichier du site. Même convention
// que la validation, dupliquée entre auth/dto et web/lib/validation.ts (CLAUDE.md) — toute
// évolution de l'enum CertificationType doit être répercutée des deux côtés.
//
// Le tiret n'est pas cosmétique : la recommandation CNAM s'écrit « R489-5 », catégorie
// comprise. Un cariste ne reconnaît pas « CACES R489 5 ».
const CERTIFICATION_LABELS: Record<CertificationType, string> = {
  CACES_R489_1A: 'CACES R489-1A',
  CACES_R489_1B: 'CACES R489-1B',
  CACES_R489_2A: 'CACES R489-2A',
  CACES_R489_2B: 'CACES R489-2B',
  CACES_R489_3: 'CACES R489-3',
  CACES_R489_4: 'CACES R489-4',
  CACES_R489_5: 'CACES R489-5',
  CACES_R489_6: 'CACES R489-6',
  CACES_R489_7: 'CACES R489-7',
  CACES_R485_1: 'CACES R485-1',
  CACES_R485_2: 'CACES R485-2',
  HABILITATION_ELECTRIQUE: 'Habilitation électrique',
};

export function certificationLabel(type: CertificationType): string {
  return CERTIFICATION_LABELS[type] ?? type;
}
