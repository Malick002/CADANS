import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { CertificationType, MotifRecours, Shift } from '@prisma/client';
import { ContractsService } from '../contracts/contracts.service';
import { N8nService } from '../n8n/n8n.service';
import { PrismaService } from '../prisma/prisma.service';
import { CreateMissionDto } from './dto/create-mission.dto';
import { MissionsService } from './missions.service';

const now = new Date('2026-09-21T08:00:00Z');

// Les notifications de mission pourvue partent en tâche de fond (`void`), derrière deux
// attentes internes (lecture Prisma puis génération du PDF) : il faut laisser la
// microtask queue se vider avant de vérifier qu'elles ont bien eu lieu.
const flushPromises = () => new Promise((resolve) => setImmediate(resolve));

const dto: CreateMissionDto = {
  posteCode: 'N1101-1',
  siteLabel: 'LogiNord - Roissy (95)',
  postalCode: '95700',
  startDate: '2026-09-18',
  endDate: '2026-09-22',
  shift: Shift.MATIN,
  motifRecours: MotifRecours.ACCROISSEMENT_TEMPORAIRE,
  hourlyRate: 13.5,
  description: 'Préparation de commandes en entrepôt frigorifique.',
  requiredCertifications: [CertificationType.CACES_R489_3],
  competenceCodes: ['C1', 'C2'],
};

const worker = {
  id: 'worker-1',
  firstName: 'Camille',
  lastName: 'Martin',
  city: 'Roissy-en-France',
  postalCode: '95700',
  user: { email: 'camille.martin@exemple.fr' },
};

describe('MissionsService', () => {
  let prisma: {
    company: { findUnique: jest.Mock };
    poste: { findFirst: jest.Mock };
    competence: { findMany: jest.Mock };
    worker: { findUnique: jest.Mock };
    mission: {
      create: jest.Mock;
      findMany: jest.Mock;
      findUnique: jest.Mock;
      update: jest.Mock;
    };
  };
  let n8n: { notifyMissionPourvue: jest.Mock };
  let contracts: { generateForMission: jest.Mock };
  let service: MissionsService;

  const openMissionRow = {
    id: 'mission-1',
    companyId: 'company-1',
    posteCode: dto.posteCode,
    siteLabel: dto.siteLabel,
    postalCode: dto.postalCode,
    startDate: new Date(dto.startDate),
    endDate: new Date(dto.endDate),
    shift: dto.shift,
    hourlyRate: dto.hourlyRate,
    description: dto.description,
    status: 'OUVERTE',
    createdAt: now,
    updatedAt: now,
    poste: { label: 'Cariste' },
    company: { legalName: 'LogiNord SAS' },
    habilitations: [{ type: CertificationType.CACES_R489_3 }],
    competences: [{ competenceCode: 'C1' }],
  };

  beforeEach(() => {
    prisma = {
      company: { findUnique: jest.fn().mockResolvedValue({ id: 'company-1' }) },
      poste: { findFirst: jest.fn().mockResolvedValue({ code: dto.posteCode }) },
      competence: {
        findMany: jest.fn().mockResolvedValue([{ code: 'C1' }, { code: 'C2' }]),
      },
      worker: { findUnique: jest.fn().mockResolvedValue(worker) },
      mission: {
        create: jest.fn(),
        findMany: jest.fn(),
        findUnique: jest.fn().mockResolvedValue({
          company: {
            userId: 'user-1',
            legalName: 'LogiNord SAS',
            siret: '73282932000074',
            addressLine: '12 rue des Docks',
            postalCode: '95700',
            city: 'Roissy-en-France',
            user: { email: 'rh@loginord.fr' },
          },
          poste: { label: 'Cariste' },
          id: 'mission-1',
          siteLabel: 'LogiNord - Roissy (95)',
          postalCode: '95700',
          startDate: new Date(dto.startDate),
          endDate: new Date(dto.endDate),
          shift: Shift.MATIN,
          description: 'Préparation de commandes en entrepôt frigorifique.',
          hourlyRate: { toString: () => '13.5' },
          habilitations: [{ type: CertificationType.CACES_R489_3 }],
        }),
        update: jest.fn(),
      },
    };
    n8n = { notifyMissionPourvue: jest.fn().mockResolvedValue(undefined) };
    contracts = {
      generateForMission: jest.fn().mockResolvedValue({
        generes: ['MISE_A_DISPOSITION', 'MISSION'],
        contratDeMissionManquant: false,
      }),
    };
    prisma.mission.create.mockImplementation(({ data }) =>
      Promise.resolve({
        id: 'mission-1',
        companyId: data.companyId,
        posteCode: data.posteCode,
        siteLabel: data.siteLabel,
        postalCode: data.postalCode,
        startDate: data.startDate,
        endDate: data.endDate,
        shift: data.shift,
        motifRecours: data.motifRecours,
        remplaceNom: data.remplaceNom,
        remplaceQualification: data.remplaceQualification,
        hourlyRate: data.hourlyRate,
        description: data.description,
        status: 'OUVERTE',
        createdAt: now,
        updatedAt: now,
        poste: { label: 'Cariste' },
        company: { legalName: 'LogiNord SAS' },
        habilitations: data.habilitations.create,
        competences: data.competences.create,
      }),
    );
    prisma.mission.update.mockImplementation(({ where, data }) =>
      Promise.resolve({
        id: where.id,
        companyId: 'company-1',
        posteCode: data.posteCode ?? dto.posteCode,
        siteLabel: data.siteLabel ?? dto.siteLabel,
        postalCode: data.postalCode ?? dto.postalCode,
        startDate: data.startDate ?? new Date(dto.startDate),
        endDate: data.endDate ?? new Date(dto.endDate),
        shift: data.shift ?? dto.shift,
        hourlyRate: data.hourlyRate ?? dto.hourlyRate,
        description: data.description ?? null,
        status: data.status ?? 'OUVERTE',
        createdAt: now,
        updatedAt: now,
        poste: { label: 'Cariste' },
        company: { legalName: 'LogiNord SAS' },
        habilitations: data.habilitations?.create ?? [],
        competences: data.competences?.create ?? [],
      }),
    );
    service = new MissionsService(
      prisma as unknown as PrismaService,
      n8n as unknown as N8nService,
      contracts as unknown as ContractsService,
    );
  });

  it("crée la mission pour l'entreprise de la session, avec ses habilitations et compétences", async () => {
    const view = await service.create('user-1', dto);

    expect(prisma.company.findUnique).toHaveBeenCalledWith({
      where: { userId: 'user-1' },
      select: { id: true },
    });
    const { data } = prisma.mission.create.mock.calls[0][0];
    expect(data.companyId).toBe('company-1');
    expect(data.habilitations.create).toEqual([{ type: CertificationType.CACES_R489_3 }]);
    expect(data.competences.create).toEqual([{ competenceCode: 'C1' }, { competenceCode: 'C2' }]);

    expect(view).toMatchObject({
      id: 'mission-1',
      posteCode: dto.posteCode,
      posteLabel: 'Cariste',
      status: 'OUVERTE',
      requiredCertifications: [CertificationType.CACES_R489_3],
      competenceCodes: ['C1', 'C2'],
    });
  });

  it("refuse un compte sans profil entreprise (ex. session d'un intérimaire)", async () => {
    prisma.company.findUnique.mockResolvedValueOnce(null);

    await expect(service.create('user-1', dto)).rejects.toThrow(NotFoundException);
    expect(prisma.mission.create).not.toHaveBeenCalled();
  });

  it('refuse un poste absent du référentiel', async () => {
    prisma.poste.findFirst.mockResolvedValueOnce(null);

    await expect(service.create('user-1', dto)).rejects.toThrow(BadRequestException);
    expect(prisma.mission.create).not.toHaveBeenCalled();
  });

  // Le référentiel importé contient aussi des métiers hors entrepôt et des synonymes non
  // retenus : seuls les postes exposés et actifs sont publiables (périmètre entrepôt).
  it('ne consulte que les postes exposés et actifs', async () => {
    await service.create('user-1', dto);

    expect(prisma.poste.findFirst).toHaveBeenCalledWith({
      where: { code: dto.posteCode, exposed: true, active: true },
      select: { code: true },
    });
  });

  it('refuse une compétence inconnue du référentiel', async () => {
    prisma.competence.findMany.mockResolvedValueOnce([{ code: 'C1' }]);

    await expect(service.create('user-1', dto)).rejects.toThrow(BadRequestException);
    expect(prisma.mission.create).not.toHaveBeenCalled();
  });

  it('refuse une date de fin antérieure à la date de début', async () => {
    await expect(
      service.create('user-1', { ...dto, startDate: '2026-09-22', endDate: '2026-09-18' }),
    ).rejects.toThrow(BadRequestException);
    expect(prisma.mission.create).not.toHaveBeenCalled();
  });

  it('remplace habilitations et compétences dans la même requête que la mission', async () => {
    await service.update('user-1', 'mission-1', dto);

    const { data } = prisma.mission.update.mock.calls[0][0];
    // deleteMany imbriqué et non une requête séparée : un échec ne peut pas laisser la
    // mission sans ses habilitations.
    expect(data.habilitations).toEqual({
      deleteMany: {},
      create: [{ type: CertificationType.CACES_R489_3 }],
    });
    expect(data.competences.deleteMany).toEqual({});
  });

  it("refuse de modifier la mission d'une autre entreprise", async () => {
    prisma.mission.findUnique.mockResolvedValueOnce({ company: { userId: 'quelqun-dautre' } });

    await expect(service.update('user-1', 'mission-1', dto)).rejects.toThrow(ForbiddenException);
    expect(prisma.mission.update).not.toHaveBeenCalled();
  });

  it('refuse de changer le statut de la mission d’une autre entreprise', async () => {
    prisma.mission.findUnique.mockResolvedValueOnce({ company: { userId: 'quelqun-dautre' } });

    await expect(service.changeStatus('user-1', 'mission-1', 'POURVUE' as never)).rejects.toThrow(
      ForbiddenException,
    );
    expect(prisma.mission.update).not.toHaveBeenCalled();
  });

  it('change le statut d’une mission dont la session est propriétaire', async () => {
    const view = await service.changeStatus('user-1', 'mission-1', 'TERMINEE' as never);

    expect(view.status).toBe('TERMINEE');
    expect(n8n.notifyMissionPourvue).not.toHaveBeenCalled();
  });

  // Pas de file de candidature dans ce POC (décision de périmètre, docs/parcours-entreprise.md) : l'entreprise doit désigner
  // l'intérimaire retenu pour que la mission puisse passer à POURVUE.
  it('refuse de passer une mission à POURVUE sans intérimaire retenu introuvable', async () => {
    prisma.worker.findUnique.mockResolvedValueOnce(null);

    await expect(
      service.changeStatus('user-1', 'mission-1', 'POURVUE' as never, 'worker-inconnu'),
    ).rejects.toThrow(BadRequestException);
    expect(prisma.mission.update).not.toHaveBeenCalled();
  });

  it('enregistre l’intérimaire retenu et notifie n8n quand la mission passe à POURVUE', async () => {
    const view = await service.changeStatus('user-1', 'mission-1', 'POURVUE' as never, 'worker-1');
    expect(view.status).toBe('POURVUE');

    const { data } = prisma.mission.update.mock.calls[0][0];
    expect(data.assignedWorkerId).toBe('worker-1');

    await flushPromises();
    // Les deux contrats sont générés et stockés AVANT la notification : elle porte un lien
    // vers eux. Le détail des mentions de chaque document est vérifié par
    // contracts.service.spec.ts et contract-pdf.service.spec.ts.
    expect(contracts.generateForMission).toHaveBeenCalledWith('mission-1');
    expect(n8n.notifyMissionPourvue).toHaveBeenCalledWith(
      expect.objectContaining({
        interimaire: { prenom: 'Camille', nom: 'Martin', email: 'camille.martin@exemple.fr' },
        entreprise: { email: 'rh@loginord.fr' },
      }),
    );
    // Le contrat ne part plus en pièce jointe : l'envoyer sur un webhook qui n'en fait rien,
    // c'était transporter l'état civil du salarié à chaque mission pourvue, pour rien.
    expect(Object.keys(n8n.notifyMissionPourvue.mock.calls[0][0])).not.toContain(
      'contrat_pdf_base64',
    );
  });

  // La notification et le contrat sont un aval, jamais une condition de la réponse HTTP :
  // un échec ici ne doit ni la retarder ni la faire échouer (même logique que MailService).
  it('ne fait pas échouer le changement de statut si la notification échoue', async () => {
    contracts.generateForMission.mockRejectedValueOnce(new Error('pdf-lib indisponible'));

    const view = await service.changeStatus('user-1', 'mission-1', 'POURVUE' as never, 'worker-1');
    expect(view.status).toBe('POURVUE');

    await flushPromises();
    expect(n8n.notifyMissionPourvue).not.toHaveBeenCalled();
  });

  // Informations d'embauche incomplètes : la mise à disposition est générée, le contrat de
  // mission non. L'email part quand même — prévenir l'intérimaire qu'il est retenu, et lui
  // dire ce qu'il lui reste à renseigner, vaut mieux que ne rien envoyer du tout.
  it('notifie quand même quand le contrat de mission n’a pas pu être généré', async () => {
    contracts.generateForMission.mockResolvedValueOnce({
      generes: ['MISE_A_DISPOSITION'],
      contratDeMissionManquant: true,
    });

    await service.changeStatus('user-1', 'mission-1', 'POURVUE' as never, 'worker-1');
    await flushPromises();

    expect(n8n.notifyMissionPourvue).toHaveBeenCalledWith(
      // L'URL de la mission : c'est d'elle que le workflow déduit les liens de signature.
      expect.objectContaining({
        mission: expect.objectContaining({ url: expect.stringContaining('/missions/') }),
      }),
    );
  });

  // Le motif du recours est la première mention obligatoire du contrat de mise à disposition
  // (L. 1251-43 1°), et les deux champs du remplacement doivent disparaître dès que le motif
  // n'en est plus un — sinon le contrat garderait le nom d'un salarié qui n'y a plus sa place.
  it('enregistre le motif du recours, et n’écrit le remplacé que pour un remplacement', async () => {
    await service.create('user-1', {
      ...dto,
      motifRecours: MotifRecours.REMPLACEMENT,
      remplaceNom: 'Julien Lefevre',
      remplaceQualification: 'Cariste',
    });
    expect(prisma.mission.create.mock.calls[0][0].data).toMatchObject({
      motifRecours: MotifRecours.REMPLACEMENT,
      remplaceNom: 'Julien Lefevre',
      remplaceQualification: 'Cariste',
    });

    await service.create('user-1', {
      ...dto,
      motifRecours: MotifRecours.SAISONNIER,
      remplaceNom: 'Julien Lefevre',
      remplaceQualification: 'Cariste',
    });
    expect(prisma.mission.create.mock.calls[1][0].data).toMatchObject({
      motifRecours: MotifRecours.SAISONNIER,
      remplaceNom: null,
      remplaceQualification: null,
    });
  });

  it('signale une mission introuvable', async () => {
    prisma.mission.findUnique.mockResolvedValueOnce(null);

    await expect(service.findOne('mission-inconnue')).rejects.toThrow(NotFoundException);
  });

  // Liste publique : c'est la page indexée, elle ne montre que ce qui est à pourvoir.
  it('ne liste publiquement que les missions ouvertes, les plus récentes d’abord', async () => {
    prisma.mission.findMany.mockResolvedValue([]);

    await service.findOpen();

    expect(prisma.mission.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { status: 'OUVERTE' },
        orderBy: { createdAt: 'desc' },
      }),
    );
  });

  it("liste les missions de l'entreprise, filtrées par statut si demandé", async () => {
    prisma.mission.findMany.mockResolvedValue([]);

    await service.findAllForCompany('user-1', 'OUVERTE' as never);

    expect(prisma.mission.findMany).toHaveBeenCalledWith(
      expect.objectContaining({ where: { companyId: 'company-1', status: 'OUVERTE' } }),
    );
  });

  // Tests portes depuis version-khadija et adaptes : ses findAllOpen / findOneOpen
  // dupliquaient findOpen / findOne de main, qui font autorite.
  describe('pages publiques', () => {
    it('liste les missions ouvertes avec le nom de leur entreprise, sans exposer companyId', async () => {
      prisma.mission.findMany.mockResolvedValueOnce([openMissionRow]);

      const missions = await service.findOpen();

      expect(prisma.mission.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { status: 'OUVERTE' } }),
      );
      expect(missions).toEqual([
        expect.objectContaining({ id: 'mission-1', companyName: 'LogiNord SAS' }),
      ]);
      expect(missions[0]).not.toHaveProperty('companyId');
    });

    it('renvoie le détail public d’une mission ouverte', async () => {
      prisma.mission.findUnique.mockResolvedValueOnce(openMissionRow);

      const mission = await service.findOne('mission-1');

      expect(mission).toMatchObject({ id: 'mission-1', companyName: 'LogiNord SAS' });
    });

    it('refuse une mission inconnue', async () => {
      prisma.mission.findUnique.mockResolvedValueOnce(null);

      await expect(service.findOne('inconnue')).rejects.toThrow(NotFoundException);
    });

    // Ce test disait l'inverse sur version-khadija : findOneOpen y renvoyait 404 des que la
    // mission n'etait plus ouverte. Arbitrage du 21/09 : une URL indexee ou partagee ne doit
    // pas disparaitre. La fiche reste lisible, c'est la CANDIDATURE qui est refusee cote API
    // (voir candidatures.service.spec.ts), et la fiche porte un noindex.
    it('renvoie la fiche d’une mission pourvue, pour ne pas casser une URL indexée', async () => {
      prisma.mission.findUnique.mockResolvedValueOnce({ ...openMissionRow, status: 'POURVUE' });

      const mission = await service.findOne('mission-1');

      expect(mission.status).toBe('POURVUE');
    });
  });
});
