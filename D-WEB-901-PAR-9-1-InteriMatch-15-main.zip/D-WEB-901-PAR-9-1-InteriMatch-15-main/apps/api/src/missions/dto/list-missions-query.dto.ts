import { MissionStatus } from '@prisma/client';
import { IsEnum, IsOptional } from 'class-validator';

// Filtre facultatif, pour les onglets du tableau de bord (Toutes/Ouvertes/Pourvues/Terminées).
export class ListMissionsQueryDto {
  @IsOptional()
  @IsEnum(MissionStatus, { message: 'Statut inconnu' })
  status?: MissionStatus;
}
