import { IsNotEmpty, IsString, MaxLength } from 'class-validator';
import { Trim } from '../../auth/dto/validation';

export class PrefillMissionDto {
  // URL de la fiche publique ou identifiant seul : c'est le service qui reconnaît lequel des
  // deux (extraireReferenceOffre). La borne à 500 caractères évite qu'un copier-coller de page
  // entière parte au serveur ; les URL France Travail avec leurs paramètres de suivi font
  // moins de 200 caractères.
  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Collez l’adresse de l’offre ou son identifiant' })
  @MaxLength(500)
  source: string;
}
