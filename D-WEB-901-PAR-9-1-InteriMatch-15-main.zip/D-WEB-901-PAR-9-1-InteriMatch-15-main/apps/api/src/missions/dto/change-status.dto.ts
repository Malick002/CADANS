import { MissionStatus } from '@prisma/client';
import { IsEnum, IsUUID, ValidateIf } from 'class-validator';

// Ouverte → Pourvue → Terminée. Les trois statuts ont leur couleur dans la charte, et
// l'information n'est jamais portée par la seule couleur (RGAA 4.1).
export class ChangeStatusDto {
  @IsEnum(MissionStatus, { message: 'Statut de mission inconnu' })
  status: MissionStatus;

  // Intérimaire retenu : obligatoire seulement en passant à POURVUE, c'est le déclencheur
  // du contrat et de la notification n8n (n8n/README.md).
  @ValidateIf((dto: ChangeStatusDto) => dto.status === MissionStatus.POURVUE)
  @IsUUID('4', { message: "L'identifiant de l'intérimaire retenu est invalide" })
  workerId?: string;
}
