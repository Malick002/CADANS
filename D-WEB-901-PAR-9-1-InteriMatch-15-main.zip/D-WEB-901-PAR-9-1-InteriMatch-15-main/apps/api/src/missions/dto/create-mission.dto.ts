import { CertificationType, MotifRecours, Shift } from '@prisma/client';
import {
  ArrayMaxSize,
  ValidateIf,
  IsArray,
  IsDateString,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  Matches,
  MaxLength,
} from 'class-validator';
import { POSTAL_CODE_PATTERN, Trim } from '../../auth/dto/validation';
import { OFFRE_ID_PATTERN } from '../../referentiel/offre-reference';

export class CreateMissionDto {
  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(20)
  posteCode: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  siteLabel: string;

  @Trim()
  @Matches(POSTAL_CODE_PATTERN, { message: 'Le code postal doit comporter 5 chiffres' })
  postalCode: string;

  @IsDateString()
  startDate: string;

  @IsDateString()
  endDate: string;

  @IsEnum(Shift, { message: 'Créneau inconnu' })
  shift: Shift;

  // Première mention obligatoire du contrat de mise à disposition (art. L. 1251-43 1°).
  // Obligatoire à la création : un contrat sans motif de recours n'est pas régularisable
  // après coup, il faudrait un avenant.
  @IsEnum(MotifRecours, { message: 'Motif de recours inconnu' })
  motifRecours: MotifRecours;

  // Exigés par le même article quand le motif est un remplacement : le contrat doit nommer
  // le salarié remplacé et sa qualification. `ValidateIf` plutôt qu'`IsOptional` : avec
  // `IsOptional`, un champ absent passerait silencieusement, et le contrat sortirait muet
  // sur une mention que la loi impose.
  @ValidateIf((dto: CreateMissionDto) => dto.motifRecours === MotifRecours.REMPLACEMENT)
  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Nommez le salarié remplacé' })
  @MaxLength(200)
  remplaceNom?: string;

  @ValidateIf((dto: CreateMissionDto) => dto.motifRecours === MotifRecours.REMPLACEMENT)
  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Indiquez la qualification du salarié remplacé' })
  @MaxLength(200)
  remplaceQualification?: string;

  @IsNumber({ maxDecimalPlaces: 2 })
  @IsPositive()
  hourlyRate: number;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  description?: string;

  // Habilitations exigées : vide si aucune (option « — » de la maquette).
  @IsOptional()
  @IsArray()
  @ArrayMaxSize(20)
  @IsEnum(CertificationType, { each: true, message: 'Habilitation inconnue' })
  requiredCertifications?: CertificationType[];

  // Compétences souhaitées : codes du référentiel (GET /referentiel/competences), existence
  // vérifiée par le service.
  @IsOptional()
  @IsArray()
  @ArrayMaxSize(20)
  @IsString({ each: true })
  competenceCodes?: string[];

  // Référence de l'offre France Travail à l'origine du préremplissage, renvoyée telle quelle
  // par l'écran. C'est la SEULE donnée de l'offre conservée en plus des champs du formulaire :
  // elle sert à afficher la provenance. Le format est contraint pour qu'on ne puisse pas
  // ranger une chaîne quelconque dans cette colonne.
  @IsOptional()
  @Trim()
  @Matches(OFFRE_ID_PATTERN, { message: 'Référence d’offre France Travail invalide' })
  sourceOffreId?: string;
}
