import { CertificationType } from '@prisma/client';
import { FranceTravailClient, OffreFranceTravailError } from '../referentiel/france-travail.client';
import { PosteExpose, ReferentielService } from '../referentiel/referentiel.service';
import { OffrePrefillService } from './offre-prefill.service';

// Le client France Travail est une doublure : aucun test de ce fichier n'atteint le réseau.
// Les codes HTTP réels sont couverts par france-travail.client.spec.ts ; ici on vérifie la
// traduction de chaque échec en réponse HTTP et en phrase affichable.

const POSTES: PosteExpose[] = [
  {
    code: '11679',
    label: 'Cariste',
    classification: 'PRINCIPALE',
    rome: { code: 'N1101', label: 'Cariste' },
    habilitationsSuggerees: [CertificationType.CACES_R489_3],
  },
];

const OFFRE = {
  id: '214GWTK',
  intitule: 'Cariste (H/F)',
  description: 'Préparation de commandes. Contact : recrute@agence.fr',
  romeCode: 'N1101',
  appellationlibelle: 'Cariste',
  lieuTravail: { libelle: '57 - Sarrebourg', codePostal: '57400' },
  salaire: { libelle: 'Horaire de 13.0 Euros' },
  dureeTravailLibelle: '35H/semaine\nTravail en journée',
};

describe('OffrePrefillService', () => {
  let offreEmploi: jest.Mock;
  let configured: boolean;
  let service: OffrePrefillService;

  beforeEach(() => {
    configured = true;
    offreEmploi = jest.fn().mockResolvedValue(OFFRE);
    const client = {
      get configured() {
        return configured;
      },
      offreEmploi,
    } as unknown as FranceTravailClient;
    const referentiel = {
      postesExposes: jest.fn().mockResolvedValue(POSTES),
    } as unknown as ReferentielService;

    service = new OffrePrefillService(client, referentiel);
    // Les échecs sont journalisés : on ne veut pas les voir dans la sortie des tests.
    jest.spyOn(service['logger'], 'warn').mockImplementation(() => undefined);
  });

  describe('succès', () => {
    it('préremplit depuis une URL et rend de quoi afficher la provenance', async () => {
      const resultat = await service.prefill(
        'https://candidat.francetravail.fr/offres/recherche/detail/214GWTK',
      );

      expect(offreEmploi).toHaveBeenCalledWith('214GWTK');
      expect(resultat).toEqual({
        reference: '214GWTK',
        intituleOffre: 'Cariste (H/F)',
        urlOffre: 'https://candidat.francetravail.fr/offres/recherche/detail/214GWTK',
        valeurs: {
          posteCode: '11679',
          siteLabel: '57 - Sarrebourg',
          postalCode: '57400',
          hourlyRate: '13.00',
          shift: 'JOURNEE',
          description: 'Préparation de commandes. Contact',
        },
        remuneration: {
          libelle: 'Horaire de 13.0 Euros',
          estimation: {
            taux: '13.00',
            periode: 'horaire',
            montant: 13,
            fourchette: false,
            heuresHebdo: 35,
            dureeLue: true,
          },
        },
      });
    });

    // L'écran a besoin de savoir que le taux est CONVERTI pour le dire : sans cette partie de
    // la réponse, une estimation passerait pour une donnée de l'offre.
    it('dit d’où vient un taux converti depuis un salaire mensuel', async () => {
      offreEmploi.mockResolvedValue({
        ...OFFRE,
        salaire: { libelle: 'Mensuel de 2206.0 Euros à 2500.0 Euros' },
      });

      const resultat = await service.prefill('214GWTK');

      expect(resultat.valeurs.hourlyRate).toBe('14.55');
      expect(resultat.remuneration).toEqual({
        libelle: 'Mensuel de 2206.0 Euros à 2500.0 Euros',
        estimation: {
          taux: '14.55',
          periode: 'mensuel',
          montant: 2206,
          fourchette: true,
          heuresHebdo: 35,
          dureeLue: true,
        },
      });
    });

    // La durée vient de la MÊME offre que le salaire : le service doit passer les deux au
    // convertisseur. Sur 38 h, le même salaire donne 13,40 € et non 14,55 € — 8 % d'écart,
    // sur un taux qui finit au contrat de mission.
    it('convertit sur la durée hebdomadaire portée par l’offre', async () => {
      offreEmploi.mockResolvedValue({
        ...OFFRE,
        salaire: { libelle: 'Mensuel de 2206.0 Euros' },
        dureeTravailLibelle: '38H/semaine\nTravail posté (2x8, 3x8, 5x8, etc.)',
      });

      const resultat = await service.prefill('214GWTK');

      expect(resultat.valeurs.hourlyRate).toBe('13.40');
      expect(resultat.remuneration?.estimation).toMatchObject({ heuresHebdo: 38, dureeLue: true });
    });

    it('retombe sur 35 h quand l’offre ne porte pas de durée exploitable', async () => {
      offreEmploi.mockResolvedValue({
        ...OFFRE,
        salaire: { libelle: 'Mensuel de 2206.0 Euros' },
        dureeTravailLibelle: undefined,
      });

      const resultat = await service.prefill('214GWTK');

      expect(resultat.remuneration?.estimation).toMatchObject({ heuresHebdo: 35, dureeLue: false });
    });

    it('transmet le libellé brut sans estimation quand le format est inconnu', async () => {
      offreEmploi.mockResolvedValue({ ...OFFRE, salaire: { libelle: 'Selon profil' } });

      const resultat = await service.prefill('214GWTK');

      expect(resultat.valeurs.hourlyRate).toBeUndefined();
      expect(resultat.remuneration).toEqual({ libelle: 'Selon profil' });
    });

    it('omet la rémunération quand l’offre n’en porte aucune', async () => {
      offreEmploi.mockResolvedValue({ ...OFFRE, salaire: undefined });

      expect(await service.prefill('214GWTK')).not.toHaveProperty('remuneration');
    });

    it('accepte aussi l’identifiant seul', async () => {
      await service.prefill('214gwtk');
      expect(offreEmploi).toHaveBeenCalledWith('214GWTK');
    });

    // Rien de l'offre n'est stocké ici, mais la réponse ne doit déjà rien porter de plus que
    // les champs repris : ni employeur d'origine, ni coordonnées de candidature.
    it('ne laisse fuir aucune coordonnée dans ce qu’il renvoie', async () => {
      const resultat = await service.prefill('214GWTK');
      expect(JSON.stringify(resultat)).not.toMatch(/@|https?:\/\/(?!candidat\.francetravail\.fr)/);
    });
  });

  describe('échecs, tous rattrapables', () => {
    it('refuse une saisie qui ne contient pas d’identifiant, sans appeler l’API', async () => {
      await expect(service.prefill('https://exemple.fr/une-annonce')).rejects.toMatchObject({
        status: 400,
      });
      expect(offreEmploi).not.toHaveBeenCalled();
    });

    // 204 côté France Travail : l'offre a expiré, ce qui est le cas courant — les offres
    // d'intérim sont retirées vite. Le message doit dire quoi faire, pas « erreur 404 ».
    it('traduit une offre introuvable ou expirée en 404 explicite', async () => {
      offreEmploi.mockRejectedValue(new OffreFranceTravailError('introuvable', '204'));

      await expect(service.prefill('214GWTK')).rejects.toMatchObject({
        status: 404,
        response: {
          message: expect.stringContaining('214GWTK'),
        },
      });
      await expect(service.prefill('214GWTK')).rejects.toMatchObject({
        response: { message: expect.stringContaining('formulaire') },
      });
    });

    // 429 et non 503 : le service marche, c'est notre consommation qui plafonne. Réessayer
    // plus tard fonctionnera, et le message doit le dire.
    it('traduit le quota atteint en 429 qui invite à réessayer', async () => {
      offreEmploi.mockRejectedValue(new OffreFranceTravailError('quota', '429'));

      // `HttpException` construite avec une chaîne porte cette chaîne telle quelle, là où
      // NotFoundException enveloppe dans un objet. Nest sérialise les deux en
      // { statusCode, message } sur le fil — c'est le test fonctionnel qui le vérifie.
      await expect(service.prefill('214GWTK')).rejects.toMatchObject({
        status: 429,
        response: expect.stringContaining('Réessayez'),
      });
    });

    it('traduit une API indisponible en 503 qui renvoie au formulaire', async () => {
      offreEmploi.mockRejectedValue(new OffreFranceTravailError('indisponible', 'ECONNREFUSED'));

      await expect(service.prefill('214GWTK')).rejects.toMatchObject({
        status: 503,
        response: { message: expect.stringContaining('formulaire') },
      });
    });

    it('répond 503 sans appeler l’API quand les identifiants ne sont pas configurés', async () => {
      configured = false;

      await expect(service.prefill('214GWTK')).rejects.toMatchObject({ status: 503 });
      expect(offreEmploi).not.toHaveBeenCalled();
    });
  });

  describe('disponible', () => {
    it('suit la configuration du client, pour masquer l’entrée à l’écran', () => {
      expect(service.disponible()).toBe(true);
      configured = false;
      expect(service.disponible()).toBe(false);
    });
  });
});
