import { Shift } from '@prisma/client';

// Libellés des créneaux, côté API. Duplication assumée de apps/web/src/lib/shifts.ts, au même
// titre que la validation l'est entre auth/dto et web/lib/validation.ts (CLAUDE.md) : le
// contrat PDF est produit par l'API, il ne peut pas lire un fichier du site. Toute évolution
// de l'enum Shift doit être répercutée des deux côtés.
//
// Les horaires entre parenthèses sont indicatifs : la donnée stockée est le créneau, pas
// l'horaire réel. C'est la meilleure approximation disponible pour la mention « horaire »
// exigée par l'article L. 1251-43 4° du Code du travail.
const SHIFT_LABELS: Record<Shift, string> = {
  MATIN: 'Matin (6h – 14h)',
  APRES_MIDI: 'Après-midi (14h – 22h)',
  NUIT: 'Nuit (22h – 6h)',
  JOURNEE: 'Journée (8h – 17h)',
};

export function shiftLabel(shift: Shift): string {
  return SHIFT_LABELS[shift] ?? shift;
}
