import { Shift } from '@prisma/client';
import { OffreEmploi } from '../referentiel/offre-emploi';
import { PosteExpose } from '../referentiel/referentiel.service';

// Traduction d'une offre France Travail en valeurs de formulaire de mission. Fonctions pures :
// aucun accès réseau, aucun accès base, donc testables exhaustivement.
//
// Règle de fond : on ne préremplit QUE ce que l'offre dit vraiment. Une mission comporte onze
// champs, une offre en alimente quatre à six ; inventer les autres (dériver une date de fin
// d'un « Intérim - 3 Mois », convertir un salaire annuel en taux horaire) produirait un
// contrat de travail faux, que personne ne relirait parce qu'il a l'air rempli.

// Longueur maximale de la description côté CreateMissionDto : le texte repris est coupé avant
// d'arriver au formulaire, sinon l'entreprise verrait un champ refusé à l'enregistrement.
export const DESCRIPTION_MAX = 2000;

export interface ValeursPreremplies {
  posteCode?: string;
  siteLabel?: string;
  postalCode?: string;
  hourlyRate?: string;
  shift?: Shift;
  description?: string;
}

// --- Nettoyage de la description ------------------------------------------------------
//
// La description d'une offre est le texte publicitaire d'une agence de recrutement. Il
// contient couramment un courriel, un numéro de téléphone et un lien de candidature : des
// données personnelles, ou menant à des données personnelles, qui n'ont rien à faire dans une
// mission CADANS. Elles sont retirées AVANT insertion dans le formulaire — donc avant tout
// stockage, puisque rien n'est stocké tant que l'entreprise n'enregistre pas.
//
// L'ordre des trois passes n'est pas indifférent : une URL contient souvent un « @ » et des
// chiffres, elle doit partir en premier pour ne pas laisser de moignon.

// L'URL ne doit PAS emporter la ponctuation qui la suit : « Détails : https://exemple.fr/x. »
// se terminait sinon sans point, la phrase caviardée devenant bancale. La dernière classe
// force la fin du motif sur un caractère qui appartient vraiment à l'adresse.
const URLS = /\b(?:https?:\/\/|www\.)\S*[^\s.,;:!?)\]}»"']/gi;
const EMAILS = /\b[\w.%+-]+@[\w-]+(?:\.[\w-]+)+\b/gi;
// Numéros français : 0X suivi de huit chiffres, ou +33 suivi de neuf, avec espaces, points,
// tirets ou barres comme séparateurs. Les gardes empêchent de mordre au milieu d'un nombre
// plus long (un SIRET, une référence produit).
const TELEPHONES = /(?<!\d)(?:\+33\s?\(?0?\)?[\s.-]?|0)[1-9](?:[\s.\-/]?\d{2}){4}(?!\d)/g;

// Marque laissée à la place de ce qui est retiré. Elle existe pour que le recollage ne touche
// QUE les endroits réellement caviardés : une passe de ponctuation appliquée à tout le texte
// abîme ce qu'elle n'avait pas à corriger — elle mangeait par exemple l'espace avant le point
// d'interrogation français (« des caces 1-3-5 ? »), dans une phrase sans aucune coordonnée.
// U+FFFF est un « non-caractère » : Unicode garantit qu'il n'apparaît dans aucun texte
// valide, et ce n'est pas un caractère de contrôle — un NUL ferait échouer la règle ESLint
// no-control-regex, à raison.
const MARQUE = '\uFFFF';

/**
 * Rend le texte de l'offre débarrassé des URL, courriels et numéros de téléphone, recollé
 * autour des suppressions et tronqué. Rend `undefined` s'il ne reste rien d'exploitable.
 *
 * Ce n'est PAS un réécriveur : « Candidatez : recrute@… ou au 03 … » devient « Candidatez ou
 * au. », pas « Candidatez. ». Il retire des données personnelles, il ne corrige pas la prose —
 * l'entreprise relit et adapte, c'est ce que dit l'étiquette affichée sous le champ.
 */
export function nettoyerDescription(texte: string | undefined): string | undefined {
  if (!texte) {
    return undefined;
  }

  const marque = texte
    // La marque déjà présente dans le texte fausserait le recollage.
    .split(MARQUE)
    .join(' ')
    .replace(URLS, MARQUE)
    .replace(EMAILS, MARQUE)
    .replace(TELEPHONES, MARQUE);

  const recolle = marque
    // Espaces autour du trou : absorbés, pour que les deux règles suivantes voient les
    // caractères qui touchent vraiment la suppression.
    .replace(/[ \t]*\uFFFF[ \t]*/g, MARQUE)
    // « envoyez votre candidature (<trou>) » → la paire de délimiteurs n'entoure plus rien.
    // Sans cette passe, une offre réelle laisse un « ( ) » au milieu de la phrase.
    .replace(/[([{«"']\uFFFF[)\]}»"']/g, MARQUE)
    // « Ou par mail :<trou>. » → le deux-points n'introduit plus rien. L'espace qui le
    // précède part avec lui, sinon il reste collé au mot (« Ou par mail . »).
    .replace(/[ \t]*[:;,]\uFFFF/g, MARQUE)
    // « Appelez le<trou>. » → la ponctuation finale se recolle au mot précédent.
    .replace(/\uFFFF([.!?;,])/g, '$1')
    // Ligne qui ne contenait QUE la coordonnée (une adresse seule sur sa ligne) : elle
    // disparaît avec son saut de ligne, sinon elle laisse un blanc au milieu du texte.
    .replace(/^[ \t]*\uFFFF[ \t]*$\n?/gm, '')
    // En tête de ligne, le trou ne sépare rien : il part sans laisser d'indentation.
    .replace(/^[ \t]*\uFFFF[ \t]*/gm, '')
    // Ce qui reste séparait deux mots : un espace, sinon ils se colleraient.
    .split(MARQUE)
    .join(' ')
    .replace(/[ \t]{2,}/g, ' ')
    // Espaces en fin de ligne, puis lignes vides accumulées par les suppressions.
    .replace(/[ \t]+$/gm, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  if (recolle === '') {
    return undefined;
  }
  return tronquer(recolle, DESCRIPTION_MAX);
}

// Coupe sur une frontière de mot pour ne pas laisser un mot à moitié, et signale la coupure.
function tronquer(texte: string, maximum: number): string {
  if (texte.length <= maximum) {
    return texte;
  }
  const coupe = texte.slice(0, maximum - 1);
  const espace = coupe.lastIndexOf(' ');
  return `${(espace > maximum / 2 ? coupe.slice(0, espace) : coupe).trimEnd()}…`;
}

// --- Correspondance des champs --------------------------------------------------------

// Comparaison de libellés d'appellation : notre référentiel et l'offre viennent de la même
// table France Travail, la correspondance est donc souvent exacte — mais on neutralise la
// casse, les accents et la ponctuation pour ne pas échouer sur un détail typographique.
function normaliser(libelle: string): string {
  return libelle
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

/**
 * Poste du référentiel correspondant à l'offre.
 *
 * L'offre donne le code ROME et le LIBELLÉ de l'appellation, jamais son code : la
 * correspondance passe donc par le libellé, parmi les seuls postes exposés de ce code ROME.
 * À défaut — cas fréquent, « Cariste secteur industrie » est une appellation réelle mais
 * écartée par la curation — on retombe sur l'appellation PRINCIPALE du même code ROME, qui
 * est toujours exposée pour nos trois métiers. Un code ROME hors périmètre ne donne rien, et
 * l'entreprise choisit elle-même.
 */
export function posteCorrespondant(
  offre: OffreEmploi,
  postes: readonly PosteExpose[],
): PosteExpose | undefined {
  if (!offre.romeCode) {
    return undefined;
  }
  const duMetier = postes.filter((poste) => poste.rome.code === offre.romeCode);
  if (duMetier.length === 0) {
    return undefined;
  }

  if (offre.appellationlibelle) {
    const cible = normaliser(offre.appellationlibelle);
    const exact = duMetier.find((poste) => normaliser(poste.label) === cible);
    if (exact) {
      return exact;
    }
  }

  return duMetier.find((poste) => poste.classification === 'PRINCIPALE') ?? duMetier[0];
}

// --- Rémunération ---------------------------------------------------------------------
//
// FORMES RELEVÉES le 23/09/2026 sur 450 offres d'intérim des trois codes ROME du périmètre :
//
//   220  Horaire de N Euros
//   141  Horaire de N Euros à N Euros
//    33  Annuel de N Euros à N Euros
//    24  (aucun salaire)
//    23  Mensuel de N Euros à N Euros
//     3  Mensuel de N Euros
//     6  l'une des formes ci-dessus suivie d'un complément libre
//        (« - 13ème mois + prime de panier », « + N% IFM »…)
//
// Une offre sur huit exprime donc son salaire au mois ou à l'année. Les laisser de côté
// vidait le champ le plus regardé du formulaire.

// Base mensuelle = durée hebdomadaire × 52 ÷ 12. Pour 35 h, cela fait 151,67 h — la durée
// légale mensuelle. La durée vient de l'offre elle-même (`dureeTravailLibelle`) quand elle
// est lisible : une mission à 38 h convertie sur 35 h surestimerait le taux horaire de 8 %.
export function heuresParMois(dureeHebdomadaire: number): number {
  return (dureeHebdomadaire * 52) / 12;
}

// Repli quand l'offre ne donne pas de durée exploitable. Sur 450 offres relevées le
// 23/09/2026, TOUTES en portaient une — le repli ne devrait donc jamais servir en pratique,
// mais un champ de texte libre finit toujours par surprendre.
export const DUREE_HEBDO_DEFAUT = 35;

// Plage retenue comme plausible pour une mission d'entrepôt. En dessous, on est sur un temps
// partiel très court (« Temps partiel - 3H/semaine » existe dans l'échantillon) dont le
// salaire mensuel affiché est rarement cohérent ; au-dessus, la durée maximale légale est
// dépassée. Hors plage, on retombe sur 35 h plutôt que de produire un taux aberrant.
export const DUREE_HEBDO_MIN = 20;
export const DUREE_HEBDO_MAX = 48;

// FORMES RELEVÉES le 23/09/2026 sur les mêmes 450 offres, première ligne de
// `dureeTravailLibelle` :
//
//   434  « 35H/semaine »            (dont 405 à 35 h)
//    13  « Temps partiel - 24H/semaine »
//     3  « 38H45/semaine »          — heures ET minutes
//
// Le troisième cas est le piège : lu naïvement, « 38H45 » donne 38 h (acceptable) ou 3845 h
// (catastrophique). Les minutes sont donc lues explicitement.
const DUREE = /(\d{1,2})\s*H\s*(\d{1,2})?\s*\/\s*semaine/i;

/**
 * Durée hebdomadaire lue dans l'offre, en heures décimales (« 38H45/semaine » → 38,75).
 * Rend `undefined` si elle est illisible ou hors de la plage plausible : l'appelant retombe
 * alors sur `DUREE_HEBDO_DEFAUT`, et l'écran dit quelle base a servi.
 */
export function dureeHebdomadaire(libelle: string | undefined): number | undefined {
  if (!libelle) {
    return undefined;
  }
  const trouve = DUREE.exec(libelle);
  if (!trouve) {
    return undefined;
  }

  const heures = Number(trouve[1]);
  const minutes = trouve[2] === undefined ? 0 : Number(trouve[2]);
  if (!Number.isFinite(heures) || minutes >= 60) {
    return undefined;
  }

  const duree = heures + minutes / 60;
  if (duree < DUREE_HEBDO_MIN || duree > DUREE_HEBDO_MAX) {
    return undefined;
  }
  return duree;
}

// Plafond de la colonne `hourly_rate` (Decimal(5,2)). Au-delà, l'enregistrement échouerait :
// mieux vaut ne rien proposer qu'un champ que l'API refusera.
const TAUX_MAX = 999.99;

export type PeriodeSalaire = 'horaire' | 'mensuel' | 'annuel';

export interface EstimationTaux {
  // Taux horaire, deux décimales — la précision de la colonne et du champ du formulaire.
  taux: string;
  periode: PeriodeSalaire;
  // Montant lu dans l'offre (borne basse si l'offre donne une fourchette), tel quel.
  montant: number;
  fourchette: boolean;
  // Durée hebdomadaire ayant servi de base, et d'où elle vient. L'écran l'affiche : une
  // estimation dont on ne connaît pas la base ne se vérifie pas.
  heuresHebdo: number;
  dureeLue: boolean;
}

export interface RemunerationOffre {
  // Libellé brut de l'offre, TOUJOURS présent. L'écran l'affiche tel quel : c'est ce qui
  // permet à l'entreprise de voir ce que la conversion a laissé de côté (primes, paniers,
  // IFM), et c'est la seule chose à montrer quand le format n'est pas reconnu.
  libelle: string;
  // Absente si le format n'est pas reconnu : le champ reste vide, l'entreprise saisit.
  estimation?: EstimationTaux;
}

// « Mensuel de 2206.0 Euros à 2500.0 Euros - 13ème mois » → périodicité, borne basse, et le
// fait qu'il s'agissait d'une fourchette. Le complément libre qui suit est ignoré : il n'est
// pas convertible, et c'est pour cela que le libellé brut reste affiché.
const SALAIRE =
  /^\s*(horaire|mensuel|annuel)\s+de\s+(\d+(?:[.,]\d+)?)\s*euros?(\s*(?:à|a)\s*(\d+(?:[.,]\d+)?)\s*euros?)?/i;

/**
 * Lit le salaire d'une offre et, quand c'est possible, l'exprime en taux horaire.
 *
 * Un salaire mensuel ou annuel est CONVERTI sur la base de 151,67 h/mois, et le résultat est
 * marqué comme une estimation : la mention affichée dit de quel montant il vient et qu'il
 * est à vérifier. Une fourchette donne sa **borne basse** — c'est le seul choix défendable,
 * proposer le haut de la fourchette gonflerait une rémunération contractuelle.
 *
 * Format non reconnu : pas d'estimation, seulement le libellé brut. Le champ reste vide,
 * comme avant.
 */
export function remunerationDepuisOffre(
  libelle: string | undefined,
  libelleDuree?: string,
): RemunerationOffre | undefined {
  const texte = libelle?.trim();
  if (!texte) {
    return undefined;
  }

  const trouve = SALAIRE.exec(texte);
  if (!trouve) {
    return { libelle: texte };
  }

  const periode = trouve[1].toLowerCase() as PeriodeSalaire;
  const montant = Number(trouve[2].replace(',', '.'));
  const fourchette = Boolean(trouve[3]);
  if (!Number.isFinite(montant) || montant <= 0) {
    return { libelle: texte };
  }

  const duree = dureeHebdomadaire(libelleDuree);
  const heuresHebdo = duree ?? DUREE_HEBDO_DEFAUT;
  const base = heuresParMois(heuresHebdo);

  const horaire =
    periode === 'horaire' ? montant : periode === 'mensuel' ? montant / base : montant / 12 / base;

  // Arrondi au centime explicite : `toFixed` seul dépend de la représentation binaire et
  // rend 1,005 → « 1.00 ». On arrondit la valeur, puis on la formate.
  const taux = Math.round(horaire * 100) / 100;
  if (taux <= 0 || taux > TAUX_MAX) {
    return { libelle: texte };
  }

  return {
    libelle: texte,
    estimation: {
      taux: taux.toFixed(2),
      periode,
      montant,
      fourchette,
      heuresHebdo,
      dureeLue: duree !== undefined,
    },
  };
}

// « 35H/semaine\nTravail en journée » → JOURNEE. Les mentions « Travail posté (2x8, 3x8…) »,
// « horaires décalés » et « horaires fixes » ne désignent AUCUN de nos quatre créneaux :
// champ laissé vide plutôt qu'un créneau choisi au hasard, qui partirait au contrat.
export function creneau(duree: string | undefined): Shift | undefined {
  if (!duree) {
    return undefined;
  }
  const texte = normaliser(duree);
  if (texte.includes('travail de nuit') || texte.includes('en nuit')) {
    return Shift.NUIT;
  }
  if (texte.includes('en journee')) {
    return Shift.JOURNEE;
  }
  if (texte.includes('le matin') || texte.includes('en matinee')) {
    return Shift.MATIN;
  }
  if (texte.includes('apres midi')) {
    return Shift.APRES_MIDI;
  }
  return undefined;
}

const SITE_MAX = 255;

/**
 * Valeurs de formulaire déduites d'une offre.
 *
 * Ne sont JAMAIS alimentés, faute de source honnête dans l'offre :
 * - `startDate` / `endDate` : l'offre donne une durée (« Intérim - 3 Mois »), pas deux dates ;
 * - `motifRecours` : absent de l'offre, et c'est une qualification juridique (art. L. 1251-43) ;
 * - `competenceCodes` : le champ `competences` de l'API est vide sur les offres d'entrepôt.
 *
 * Les habilitations ne viennent pas non plus de l'offre (aucun champ structuré, mesuré au
 * docs/referentiel-matching.md) : c'est la suggestion attachée au poste retenu qui s'applique, comme pour une
 * mission saisie à la main.
 */
export function valeursDepuisOffre(
  offre: OffreEmploi,
  postes: readonly PosteExpose[],
): ValeursPreremplies {
  const poste = posteCorrespondant(offre, postes);
  const codePostal = offre.lieuTravail?.codePostal?.trim();
  const site = offre.lieuTravail?.libelle?.trim();

  return compacter({
    posteCode: poste?.code,
    // « 57 - Sarrebourg » : une localité, pas le nom d'un site. C'est un point de départ que
    // l'entreprise remplace par son propre libellé de site ; le nom de l'employeur d'origine
    // (`entreprise.nom`, souvent une agence concurrente) n'est jamais repris.
    siteLabel: site ? site.slice(0, SITE_MAX) : undefined,
    postalCode: codePostal && /^\d{5}$/.test(codePostal) ? codePostal : undefined,
    hourlyRate: remunerationDepuisOffre(offre.salaire?.libelle, offre.dureeTravailLibelle)
      ?.estimation?.taux,
    shift: creneau(offre.dureeTravailLibelle),
    description: nettoyerDescription(offre.description),
  });
}

// Les clés absentes valent mieux que des clés à `undefined` : la réponse JSON dit alors
// exactement ce qui a été repris, et l'écran s'en sert pour son récapitulatif.
function compacter(valeurs: ValeursPreremplies): ValeursPreremplies {
  return Object.fromEntries(
    Object.entries(valeurs).filter(([, valeur]) => valeur !== undefined),
  ) as ValeursPreremplies;
}
