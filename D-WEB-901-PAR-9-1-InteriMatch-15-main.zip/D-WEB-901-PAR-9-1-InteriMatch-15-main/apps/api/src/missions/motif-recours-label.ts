import { MotifRecours } from '@prisma/client';

// Libellés du motif de recours, côté API. Miroir de apps/web/src/lib/motifs-recours.ts, même
// convention que shift-label.ts et certification-label.ts (CLAUDE.md) : le contrat PDF est
// produit par l'API, il ne peut pas lire un fichier du site. Toute évolution de l'enum
// MotifRecours doit être répercutée des deux côtés.
//
// Les libellés reprennent la formulation du Code du travail plutôt qu'une paraphrase : c'est
// la mention qui figure au contrat (art. L. 1251-43 1°), elle doit être reconnaissable par
// qui la relit.
const MOTIF_LABELS: Record<MotifRecours, string> = {
  ACCROISSEMENT_TEMPORAIRE: 'Accroissement temporaire d’activité',
  REMPLACEMENT: 'Remplacement d’un salarié absent',
  SAISONNIER: 'Emploi à caractère saisonnier',
  USAGE: 'Emploi pour lequel il est d’usage de ne pas recourir au CDI',
};

export function motifRecoursLabel(motif: MotifRecours): string {
  return MOTIF_LABELS[motif] ?? motif;
}
