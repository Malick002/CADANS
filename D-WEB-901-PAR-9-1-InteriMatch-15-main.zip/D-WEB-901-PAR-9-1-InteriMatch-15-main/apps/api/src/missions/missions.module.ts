import { Module } from '@nestjs/common';
import { ContractsModule } from '../contracts/contracts.module';
import { N8nModule } from '../n8n/n8n.module';
import { ReferentielModule } from '../referentiel/referentiel.module';
import { MissionsController } from './missions.controller';
import { MissionsService } from './missions.service';
import { OffrePrefillService } from './offre-prefill.service';

// ReferentielModule est importé pour le préremplissage depuis une offre France Travail : il
// exporte le client de l'API et la lecture des postes exposés, dont la correspondance
// « code ROME de l'offre → poste du référentiel » a besoin.
@Module({
  imports: [N8nModule, ContractsModule, ReferentielModule],
  controllers: [MissionsController],
  providers: [MissionsService, OffrePrefillService],
})
export class MissionsModule {}
