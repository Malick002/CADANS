import { Module } from '@nestjs/common';
import { SensitiveDocumentsController } from './sensitive-documents.controller';
import { SensitiveDocumentsService } from './sensitive-documents.service';

@Module({
  controllers: [SensitiveDocumentsController],
  providers: [SensitiveDocumentsService],
  exports: [SensitiveDocumentsService],
})
export class SensitiveDocumentsModule {}
