import { IdentityDocumentType } from '@prisma/client';
import { IsEnum } from 'class-validator';

// Champs texte du formulaire multipart ; le fichier arrive dans le champ `file`.
export class UploadIdentityDocumentDto {
  @IsEnum(IdentityDocumentType, {
    message: 'Le type de pièce doit être CNI, PASSEPORT ou TITRE_SEJOUR',
  })
  type: IdentityDocumentType;
}
