import { Transform, TransformFnParams } from 'class-transformer';
import { IsISO8601, IsNotEmpty, IsOptional, IsString, Matches, MaxLength } from 'class-validator';

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const EXPIRES_AT_MESSAGE = "La date d'expiration doit être au format AAAA-MM-JJ";

const emptyToUndefined = ({ value }: TransformFnParams): unknown =>
  typeof value === 'string' && value.trim() === '' ? undefined : value;

// Champs texte du formulaire multipart ; le scan éventuel arrive dans le champ `file`.
// Le type d'habilitation est dans l'URL (PUT /workers/me/certifications/:type).
export class SaveCertificationDto {
  // Date de fin de validité, au format AAAA-MM-JJ. @IsISO8601 seul accepterait aussi une
  // date-heure (2030-06-30T10:00), une semaine (2030-W26) ou un jour ordinal (2030-181),
  // que le service ne sait pas convertir : @Matches impose la forme, @IsISO8601 vérifie
  // que la date existe (refuse 2030-02-30).
  @Transform(emptyToUndefined)
  @IsOptional()
  @Matches(DATE_PATTERN, { message: EXPIRES_AT_MESSAGE })
  @IsISO8601({ strict: true }, { message: EXPIRES_AT_MESSAGE })
  expiresAt?: string;

  @Transform(emptyToUndefined)
  @IsOptional()
  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  number?: string;
}
