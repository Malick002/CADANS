import {
  BadRequestException,
  NotFoundException,
  UnsupportedMediaTypeException,
} from '@nestjs/common';
import { CertificationType, IdentityDocumentType } from '@prisma/client';
import { EncryptionService } from '../encryption/encryption.service';
import { PrismaService } from '../prisma/prisma.service';
import { SensitiveDocumentsService } from './sensitive-documents.service';

const PDF = Buffer.from('%PDF-1.7 scan de la carte CACES');
const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3]);
const now = new Date('2026-09-17T08:00:00Z');

describe('SensitiveDocumentsService', () => {
  const originalKey = process.env.ENCRYPTION_KEY;
  let encryption: EncryptionService;
  let prisma: {
    worker: { findUnique: jest.Mock };
    identityDocument: { upsert: jest.Mock; findUnique: jest.Mock };
    certification: {
      upsert: jest.Mock;
      findMany: jest.Mock;
      findUnique: jest.Mock;
      deleteMany: jest.Mock;
    };
  };
  let service: SensitiveDocumentsService;

  beforeEach(() => {
    process.env.ENCRYPTION_KEY = Buffer.alloc(32, 3).toString('base64');
    encryption = new EncryptionService();
    prisma = {
      worker: { findUnique: jest.fn().mockResolvedValue({ id: 'worker-1' }) },
      identityDocument: { upsert: jest.fn(), findUnique: jest.fn() },
      certification: {
        upsert: jest.fn(),
        findMany: jest.fn(),
        findUnique: jest.fn(),
        deleteMany: jest.fn(),
      },
    };
    // Les upserts renvoient ce qu'ils auraient écrit.
    prisma.identityDocument.upsert.mockImplementation(({ create }) =>
      Promise.resolve({ id: 'doc-1', createdAt: now, updatedAt: now, ...create }),
    );
    prisma.certification.upsert.mockImplementation(({ create }) =>
      Promise.resolve({
        id: 'cert-1',
        documentEncrypted: null,
        documentMimeType: null,
        createdAt: now,
        updatedAt: now,
        ...create,
      }),
    );
    service = new SensitiveDocumentsService(prisma as unknown as PrismaService, encryption);
  });

  afterEach(() => {
    process.env.ENCRYPTION_KEY = originalKey;
  });

  describe("pièce d'identité", () => {
    it('chiffre le fichier avant de l’écrire en base et ne renvoie que ses métadonnées', async () => {
      const view = await service.saveIdentityDocument('user-1', IdentityDocumentType.CNI, {
        buffer: PNG,
      });

      const { create } = prisma.identityDocument.upsert.mock.calls[0][0];
      expect(Buffer.from(create.fileEncrypted).includes(PNG)).toBe(false);
      expect(
        encryption.decrypt(create.fileEncrypted, 'identity-document:worker-1').equals(PNG),
      ).toBe(true);
      expect(create.mimeType).toBe('image/png');
      expect(view).toEqual({ type: 'CNI', mimeType: 'image/png', createdAt: now, updatedAt: now });
    });

    it('exige un fichier et refuse un format non accepté', async () => {
      await expect(
        service.saveIdentityDocument('user-1', IdentityDocumentType.CNI, undefined),
      ).rejects.toThrow(BadRequestException);
      await expect(
        service.saveIdentityDocument('user-1', IdentityDocumentType.CNI, {
          buffer: Buffer.from('<svg onload=alert(1)>'),
        }),
      ).rejects.toThrow(UnsupportedMediaTypeException);
      expect(prisma.identityDocument.upsert).not.toHaveBeenCalled();
    });

    it('déchiffre le fichier au téléchargement', async () => {
      prisma.identityDocument.findUnique.mockResolvedValue({
        type: 'PASSEPORT',
        mimeType: 'application/pdf',
        fileEncrypted: encryption.encrypt(PDF, 'identity-document:worker-1'),
      });

      const file = await service.readIdentityDocumentFile('user-1');

      expect(file.content.equals(PDF)).toBe(true);
      expect(file.filename).toBe('piece-identite.pdf');
    });

    it("renvoie 404 si l'utilisateur n'a pas de profil intérimaire ou pas de pièce", async () => {
      prisma.identityDocument.findUnique.mockResolvedValue(null);
      await expect(service.getIdentityDocument('user-1')).rejects.toThrow(NotFoundException);

      prisma.worker.findUnique.mockResolvedValue(null);
      await expect(service.getIdentityDocument('user-1')).rejects.toThrow(NotFoundException);
    });
  });

  describe('habilitations', () => {
    it('garde le type et la date en clair, chiffre le numéro et le scan', async () => {
      const view = await service.saveCertification(
        'user-1',
        CertificationType.CACES_R489_3,
        { expiresAt: '2030-06-30', number: 'R489-3-000123' },
        { buffer: PDF },
      );

      const { create } = prisma.certification.upsert.mock.calls[0][0];
      expect(create.type).toBe('CACES_R489_3');
      expect(create.expiresAt).toEqual(new Date('2030-06-30T00:00:00Z'));
      expect(Buffer.from(create.numberEncrypted).toString('latin1')).not.toContain('R489-3');
      expect(
        encryption
          .decrypt(create.documentEncrypted, 'certification-document:worker-1:CACES_R489_3')
          .equals(PDF),
      ).toBe(true);
      expect(view).toMatchObject({
        type: 'CACES_R489_3',
        expiresAt: '2030-06-30',
        number: 'R489-3-000123',
        hasDocument: true,
        documentMimeType: 'application/pdf',
      });
    });

    it('conserve le scan existant quand aucun nouveau fichier n’est joint', async () => {
      await service.saveCertification('user-1', CertificationType.CACES_R489_1A, {}, undefined);

      const { update } = prisma.certification.upsert.mock.calls[0][0];
      expect(update).not.toHaveProperty('documentEncrypted');
      expect(update).toMatchObject({ expiresAt: null, numberEncrypted: null });
    });

    it('lie chaque chiffré à son type : un numéro recopié sur un autre type est illisible', async () => {
      const numberForCaces1A = encryption.encryptText(
        'R489-1A-42',
        'certification-number:worker-1:CACES_R489_1A',
      );
      prisma.certification.findMany.mockResolvedValue([
        {
          type: 'CACES_R489_5',
          expiresAt: null,
          numberEncrypted: numberForCaces1A,
          documentEncrypted: null,
          documentMimeType: null,
          updatedAt: now,
        },
      ]);

      await expect(service.listCertifications('user-1')).rejects.toThrow(/Déchiffrement/);
    });

    it('renvoie 404 pour un document ou une habilitation inexistants', async () => {
      prisma.certification.findUnique.mockResolvedValue({ documentEncrypted: null });
      prisma.certification.deleteMany.mockResolvedValue({ count: 0 });

      await expect(
        service.readCertificationDocument('user-1', CertificationType.CACES_R485_1),
      ).rejects.toThrow(NotFoundException);
      await expect(
        service.deleteCertification('user-1', CertificationType.CACES_R485_1),
      ).rejects.toThrow(NotFoundException);
    });

    it("ne supprime que l'habilitation de l'intérimaire connecté", async () => {
      prisma.certification.deleteMany.mockResolvedValue({ count: 1 });

      await service.deleteCertification('user-1', CertificationType.CACES_R485_1);

      expect(prisma.certification.deleteMany).toHaveBeenCalledWith({
        where: { workerId: 'worker-1', type: 'CACES_R485_1' },
      });
    });
  });
});
