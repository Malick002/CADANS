import {
  BadRequestException,
  Injectable,
  NotFoundException,
  UnsupportedMediaTypeException,
} from '@nestjs/common';
import {
  Certification,
  CertificationStatus,
  CertificationType,
  IdentityDocumentType,
} from '@prisma/client';
import { EncryptionService } from '../encryption/encryption.service';
import { PrismaService } from '../prisma/prisma.service';
import { SaveCertificationDto } from './dto/save-certification.dto';
import { DOCUMENT_EXTENSIONS, detectDocumentType, DocumentMimeType } from './file-type';

// Sous-ensemble du fichier fourni par multer dont le service a besoin.
export interface UploadedDocument {
  buffer: Buffer;
}

export interface IdentityDocumentView {
  type: IdentityDocumentType;
  mimeType: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface CertificationView {
  type: CertificationType;
  expiresAt: string | null;
  number: string | null;
  hasDocument: boolean;
  documentMimeType: string | null;
  // Vérification humaine du justificatif par un agent CADANS. Le matching ne s'en sert
  // PAS : une habilitation vaut par sa présence et sa date d'expiration, comme avant.
  verificationStatus: CertificationStatus;
  // Renseigné seulement quand le statut vaut REFUSE : l'intérimaire doit savoir quoi
  // corriger, un refus muet ne lui apprend rien.
  refusalMotif: string | null;
  verifiedAt: string | null;
  updatedAt: Date;
}

export interface DecryptedFile {
  content: Buffer;
  mimeType: string;
  filename: string;
}

// Contextes de chiffrement : chaque chiffré est lié à son intérimaire et à son usage.
const identityContext = (workerId: string): string => `identity-document:${workerId}`;
const numberContext = (workerId: string, type: CertificationType): string =>
  `certification-number:${workerId}:${type}`;
const documentContext = (workerId: string, type: CertificationType): string =>
  `certification-document:${workerId}:${type}`;

@Injectable()
export class SensitiveDocumentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
  ) {}

  async saveIdentityDocument(
    userId: string,
    type: IdentityDocumentType,
    file: UploadedDocument | undefined,
  ): Promise<IdentityDocumentView> {
    const { content, mimeType } = validateDocument(file, true);
    const workerId = await this.workerId(userId);
    const fileEncrypted = this.encryption.encrypt(content, identityContext(workerId));

    // Une seule pièce par intérimaire : un nouvel envoi remplace la précédente.
    const document = await this.prisma.identityDocument.upsert({
      where: { workerId },
      create: { workerId, type, fileEncrypted, mimeType },
      update: { type, fileEncrypted, mimeType },
    });

    return toIdentityView(document);
  }

  async getIdentityDocument(userId: string): Promise<IdentityDocumentView> {
    return toIdentityView(await this.findIdentityDocument(await this.workerId(userId)));
  }

  async readIdentityDocumentFile(userId: string): Promise<DecryptedFile> {
    const workerId = await this.workerId(userId);
    const document = await this.findIdentityDocument(workerId);

    return {
      content: this.encryption.decrypt(document.fileEncrypted, identityContext(workerId)),
      mimeType: document.mimeType,
      filename: `piece-identite.${extensionFor(document.mimeType)}`,
    };
  }

  // Crée ou met à jour l'habilitation d'un type donné. Le numéro et la date sont
  // remplacés à chaque envoi ; le scan n'est remplacé que si un nouveau fichier est joint.
  async saveCertification(
    userId: string,
    type: CertificationType,
    dto: SaveCertificationDto,
    file: UploadedDocument | undefined,
  ): Promise<CertificationView> {
    const workerId = await this.workerId(userId);
    const expiresAt = dto.expiresAt ? new Date(`${dto.expiresAt}T00:00:00Z`) : null;
    const numberEncrypted = dto.number
      ? this.encryption.encryptText(dto.number, numberContext(workerId, type))
      : null;

    // Un nouveau justificatif remet la vérification à zéro : le document validé la semaine
    // dernière n'est plus celui qui est en base. Sans ce retour à EN_ATTENTE, remplacer son
    // fichier après un refus — ou après une validation — conserverait l'ancienne décision.
    const document = file ? validateDocument(file, false) : null;
    const documentFields = document
      ? {
          documentEncrypted: this.encryption.encrypt(
            document.content,
            documentContext(workerId, type),
          ),
          documentMimeType: document.mimeType,
          verificationStatus: CertificationStatus.EN_ATTENTE,
          refusalMotif: null,
          verifiedAt: null,
          verifiedByUserId: null,
        }
      : {};

    const certification = await this.prisma.certification.upsert({
      where: { workerId_type: { workerId, type } },
      create: { workerId, type, expiresAt, numberEncrypted, ...documentFields },
      update: { expiresAt, numberEncrypted, ...documentFields },
    });

    return this.toCertificationView(workerId, certification);
  }

  async listCertifications(userId: string): Promise<CertificationView[]> {
    const workerId = await this.workerId(userId);
    const certifications = await this.prisma.certification.findMany({
      where: { workerId },
      orderBy: { type: 'asc' },
    });

    return certifications.map((certification) => this.toCertificationView(workerId, certification));
  }

  async readCertificationDocument(userId: string, type: CertificationType): Promise<DecryptedFile> {
    const workerId = await this.workerId(userId);
    const certification = await this.prisma.certification.findUnique({
      where: { workerId_type: { workerId, type } },
    });

    if (!certification?.documentEncrypted || !certification.documentMimeType) {
      throw new NotFoundException('Aucun document pour cette habilitation');
    }

    return {
      content: this.encryption.decrypt(
        certification.documentEncrypted,
        documentContext(workerId, type),
      ),
      mimeType: certification.documentMimeType,
      filename: `${type.toLowerCase()}.${extensionFor(certification.documentMimeType)}`,
    };
  }

  async deleteCertification(userId: string, type: CertificationType): Promise<void> {
    const workerId = await this.workerId(userId);
    const { count } = await this.prisma.certification.deleteMany({ where: { workerId, type } });

    if (count === 0) {
      throw new NotFoundException('Habilitation introuvable');
    }
  }

  private async workerId(userId: string): Promise<string> {
    const worker = await this.prisma.worker.findUnique({
      where: { userId },
      select: { id: true },
    });
    if (!worker) {
      throw new NotFoundException('Profil intérimaire introuvable');
    }
    return worker.id;
  }

  private async findIdentityDocument(workerId: string) {
    const document = await this.prisma.identityDocument.findUnique({ where: { workerId } });
    if (!document) {
      throw new NotFoundException("Aucune pièce d'identité enregistrée");
    }
    return document;
  }

  private toCertificationView(workerId: string, certification: Certification): CertificationView {
    return {
      type: certification.type,
      expiresAt: certification.expiresAt?.toISOString().slice(0, 10) ?? null,
      number: certification.numberEncrypted
        ? this.encryption.decryptText(
            certification.numberEncrypted,
            numberContext(workerId, certification.type),
          )
        : null,
      hasDocument: certification.documentEncrypted !== null,
      documentMimeType: certification.documentMimeType,
      verificationStatus: certification.verificationStatus,
      refusalMotif: certification.refusalMotif,
      verifiedAt: certification.verifiedAt?.toISOString() ?? null,
      updatedAt: certification.updatedAt,
    };
  }
}

function validateDocument(
  file: UploadedDocument | undefined,
  required: boolean,
): { content: Buffer; mimeType: DocumentMimeType } {
  if (!file || file.buffer.length === 0) {
    throw new BadRequestException(
      required ? 'Le fichier est obligatoire (champ « file »)' : 'Le fichier envoyé est vide',
    );
  }

  const mimeType = detectDocumentType(file.buffer);
  if (!mimeType) {
    throw new UnsupportedMediaTypeException('Formats acceptés : PDF, JPEG ou PNG');
  }

  return { content: file.buffer, mimeType };
}

function toIdentityView(document: {
  type: IdentityDocumentType;
  mimeType: string;
  createdAt: Date;
  updatedAt: Date;
}): IdentityDocumentView {
  return {
    type: document.type,
    mimeType: document.mimeType,
    createdAt: document.createdAt,
    updatedAt: document.updatedAt,
  };
}

function extensionFor(mimeType: string): string {
  return DOCUMENT_EXTENSIONS[mimeType as DocumentMimeType] ?? 'bin';
}
