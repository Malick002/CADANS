// Taille maximale d'un document envoyé : un scan ou une photo de pièce d'identité.
export const MAX_DOCUMENT_SIZE_BYTES = 5 * 1024 * 1024;

export type DocumentMimeType = 'application/pdf' | 'image/jpeg' | 'image/png';

// Signatures binaires des formats acceptés. On se fie au contenu réel du fichier,
// jamais au type annoncé par le navigateur, qui est falsifiable.
const SIGNATURES: { mimeType: DocumentMimeType; bytes: number[] }[] = [
  { mimeType: 'application/pdf', bytes: [0x25, 0x50, 0x44, 0x46, 0x2d] }, // %PDF-
  { mimeType: 'image/png', bytes: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a] },
  { mimeType: 'image/jpeg', bytes: [0xff, 0xd8, 0xff] },
];

export function detectDocumentType(content: Buffer): DocumentMimeType | null {
  const match = SIGNATURES.find(({ bytes }) =>
    bytes.every((byte, index) => content[index] === byte),
  );
  return match?.mimeType ?? null;
}

export const DOCUMENT_EXTENSIONS: Record<DocumentMimeType, string> = {
  'application/pdf': 'pdf',
  'image/jpeg': 'jpg',
  'image/png': 'png',
};
