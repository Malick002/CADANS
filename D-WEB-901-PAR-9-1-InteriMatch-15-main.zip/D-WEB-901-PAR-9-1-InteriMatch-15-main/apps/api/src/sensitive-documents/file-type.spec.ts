import { detectDocumentType } from './file-type';

describe('detectDocumentType', () => {
  it('reconnaît PDF, PNG et JPEG à leur contenu', () => {
    expect(detectDocumentType(Buffer.from('%PDF-1.7\n...'))).toBe('application/pdf');
    expect(
      detectDocumentType(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0])),
    ).toBe('image/png');
    expect(detectDocumentType(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0]))).toBe('image/jpeg');
  });

  it('refuse un autre format, même renommé en .pdf', () => {
    expect(detectDocumentType(Buffer.from('<html><script>alert(1)</script>'))).toBeNull();
    expect(detectDocumentType(Buffer.from('MZ\x90\x00'))).toBeNull();
    expect(detectDocumentType(Buffer.alloc(0))).toBeNull();
  });
});
