import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Header,
  HttpCode,
  HttpStatus,
  Param,
  ParseEnumPipe,
  Put,
  StreamableFile,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { CertificationType, Role } from '@prisma/client';
import { CurrentUser, Roles } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import { SaveCertificationDto } from './dto/save-certification.dto';
import { UploadIdentityDocumentDto } from './dto/upload-identity-document.dto';
import { MAX_DOCUMENT_SIZE_BYTES } from './file-type';
import {
  CertificationView,
  DecryptedFile,
  IdentityDocumentView,
  SensitiveDocumentsService,
} from './sensitive-documents.service';

// Fichier gardé en mémoire le temps d'être chiffré : jamais écrit en clair sur le disque.
const documentUpload = FileInterceptor('file', {
  limits: { fileSize: MAX_DOCUMENT_SIZE_BYTES, files: 1, fields: 5 },
});

const certificationTypePipe = new ParseEnumPipe(CertificationType, {
  exceptionFactory: () => new BadRequestException("Type d'habilitation inconnu"),
});

// Chaque intérimaire n'accède qu'à ses propres documents : l'identifiant vient toujours
// de la session, jamais de l'URL.
@Roles(Role.WORKER)
@Controller('workers/me')
export class SensitiveDocumentsController {
  constructor(private readonly documents: SensitiveDocumentsService) {}

  @Put('identity-document')
  @UseInterceptors(documentUpload)
  saveIdentityDocument(
    @CurrentUser() user: SessionUser,
    @Body() dto: UploadIdentityDocumentDto,
    @UploadedFile() file: Express.Multer.File | undefined,
  ): Promise<IdentityDocumentView> {
    return this.documents.saveIdentityDocument(user.id, dto.type, file);
  }

  @Get('identity-document')
  getIdentityDocument(@CurrentUser() user: SessionUser): Promise<IdentityDocumentView> {
    return this.documents.getIdentityDocument(user.id);
  }

  @Get('identity-document/file')
  @Header('Cache-Control', 'no-store')
  @Header('X-Content-Type-Options', 'nosniff')
  async downloadIdentityDocument(@CurrentUser() user: SessionUser): Promise<StreamableFile> {
    return toStreamableFile(await this.documents.readIdentityDocumentFile(user.id));
  }

  @Get('certifications')
  listCertifications(@CurrentUser() user: SessionUser): Promise<CertificationView[]> {
    return this.documents.listCertifications(user.id);
  }

  @Put('certifications/:type')
  @UseInterceptors(documentUpload)
  saveCertification(
    @CurrentUser() user: SessionUser,
    @Param('type', certificationTypePipe) type: CertificationType,
    @Body() dto: SaveCertificationDto,
    @UploadedFile() file: Express.Multer.File | undefined,
  ): Promise<CertificationView> {
    return this.documents.saveCertification(user.id, type, dto, file);
  }

  @Get('certifications/:type/document')
  @Header('Cache-Control', 'no-store')
  @Header('X-Content-Type-Options', 'nosniff')
  async downloadCertificationDocument(
    @CurrentUser() user: SessionUser,
    @Param('type', certificationTypePipe) type: CertificationType,
  ): Promise<StreamableFile> {
    return toStreamableFile(await this.documents.readCertificationDocument(user.id, type));
  }

  @Delete('certifications/:type')
  @HttpCode(HttpStatus.NO_CONTENT)
  deleteCertification(
    @CurrentUser() user: SessionUser,
    @Param('type', certificationTypePipe) type: CertificationType,
  ): Promise<void> {
    return this.documents.deleteCertification(user.id, type);
  }
}

// Documents déposés par les utilisateurs : téléchargement forcé (attachment), jamais mis en
// cache (no-store), et nosniff interdit au navigateur de réinterpréter le contenu comme un
// autre type (par exemple du HTML exécutable) que celui annoncé.
function toStreamableFile(file: DecryptedFile): StreamableFile {
  return new StreamableFile(file.content, {
    type: file.mimeType,
    disposition: `attachment; filename="${file.filename}"`,
    length: file.content.length,
  });
}
