import { Injectable } from '@nestjs/common';
import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';

const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32;
// IV de 12 octets : taille recommandée pour GCM (NIST SP 800-38D).
const IV_LENGTH = 12;
const TAG_LENGTH = 16;
// Version du format stocké : permettra une rotation de clé ou d'algorithme sans
// rendre illisibles les données déjà chiffrées.
const FORMAT_VERSION = 1;
const HEADER_LENGTH = 1 + IV_LENGTH + TAG_LENGTH;

// Clé d'exemple de .env.example : publique (commitée dans le dépôt), elle permettrait de
// déchiffrer les documents. Tolérée en local, refusée en production. À garder synchronisée.
export const EXAMPLE_ENCRYPTION_KEY = 'VEcrA1/ATfG9XpKoFxfpOa81O36h87pyUcDxnosE3gQ=';

export class DecryptionError extends Error {
  constructor() {
    super('Déchiffrement impossible : donnée altérée, mauvaise clé ou mauvais contexte');
  }
}

/**
 * Chiffrement au repos des données sensibles (pièces d'identité, habilitations),
 * avec AES-256-GCM de node:crypto.
 *
 * Format stocké : version (1 octet) | IV (12) | tag d'authentification (16) | chiffré.
 *
 * GCM authentifie les données : une valeur modifiée en base est détectée au
 * déchiffrement. Le « contexte » (ex. `identity-document:<workerId>`) est lié au chiffré
 * comme donnée additionnelle authentifiée : copier le document chiffré d'un intérimaire
 * sur la ligne d'un autre le rend indéchiffrable.
 */
@Injectable()
export class EncryptionService {
  private readonly key: Buffer;

  constructor() {
    if (
      process.env.NODE_ENV === 'production' &&
      process.env.ENCRYPTION_KEY === EXAMPLE_ENCRYPTION_KEY
    ) {
      throw new Error(
        "ENCRYPTION_KEY vaut la clé d'exemple de .env.example, publique : interdit en production. " +
          'Générer une clé : openssl rand -base64 32',
      );
    }

    const key = Buffer.from(process.env.ENCRYPTION_KEY ?? '', 'base64');
    if (key.length !== KEY_LENGTH) {
      // Refuser de démarrer plutôt que d'écrire des données sensibles en clair.
      throw new Error(
        `ENCRYPTION_KEY absente ou invalide : ${KEY_LENGTH} octets encodés en base64 attendus. ` +
          'Générer une clé : openssl rand -base64 32',
      );
    }
    this.key = key;
  }

  // Renvoie un Uint8Array sur un ArrayBuffer dédié : type attendu par Prisma pour Bytes.
  encrypt(plaintext: Buffer, context: string): Uint8Array<ArrayBuffer> {
    const iv = randomBytes(IV_LENGTH);
    const cipher = createCipheriv(ALGORITHM, this.key, iv, { authTagLength: TAG_LENGTH });
    cipher.setAAD(Buffer.from(context, 'utf8'));
    const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);

    return new Uint8Array(
      Buffer.concat([Buffer.from([FORMAT_VERSION]), iv, cipher.getAuthTag(), encrypted]),
    );
  }

  decrypt(payload: Uint8Array, context: string): Buffer {
    const data = Buffer.from(payload);
    if (data.length < HEADER_LENGTH || data[0] !== FORMAT_VERSION) {
      throw new DecryptionError();
    }

    const iv = data.subarray(1, 1 + IV_LENGTH);
    const tag = data.subarray(1 + IV_LENGTH, HEADER_LENGTH);
    const encrypted = data.subarray(HEADER_LENGTH);

    try {
      const decipher = createDecipheriv(ALGORITHM, this.key, iv, { authTagLength: TAG_LENGTH });
      decipher.setAAD(Buffer.from(context, 'utf8'));
      decipher.setAuthTag(tag);
      return Buffer.concat([decipher.update(encrypted), decipher.final()]);
    } catch {
      throw new DecryptionError();
    }
  }

  encryptText(plaintext: string, context: string): Uint8Array<ArrayBuffer> {
    return this.encrypt(Buffer.from(plaintext, 'utf8'), context);
  }

  decryptText(payload: Uint8Array, context: string): string {
    return this.decrypt(payload, context).toString('utf8');
  }
}
