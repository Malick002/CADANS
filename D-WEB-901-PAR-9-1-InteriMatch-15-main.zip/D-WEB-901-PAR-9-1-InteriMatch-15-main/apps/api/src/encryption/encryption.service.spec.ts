import { randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { DecryptionError, EncryptionService, EXAMPLE_ENCRYPTION_KEY } from './encryption.service';

const KEY = Buffer.alloc(32, 1).toString('base64');

describe('EncryptionService', () => {
  const originalKey = process.env.ENCRYPTION_KEY;
  let service: EncryptionService;

  beforeEach(() => {
    process.env.ENCRYPTION_KEY = KEY;
    service = new EncryptionService();
  });

  afterEach(() => {
    process.env.ENCRYPTION_KEY = originalKey;
  });

  it('refuse de démarrer sans clé ou avec une clé qui ne fait pas 32 octets', () => {
    delete process.env.ENCRYPTION_KEY;
    expect(() => new EncryptionService()).toThrow(/ENCRYPTION_KEY/);

    process.env.ENCRYPTION_KEY = Buffer.alloc(16).toString('base64');
    expect(() => new EncryptionService()).toThrow(/ENCRYPTION_KEY/);
  });

  describe("clé d'exemple de .env.example", () => {
    const originalNodeEnv = process.env.NODE_ENV;

    afterEach(() => {
      process.env.NODE_ENV = originalNodeEnv;
    });

    it('est refusée en production', () => {
      process.env.NODE_ENV = 'production';
      process.env.ENCRYPTION_KEY = EXAMPLE_ENCRYPTION_KEY;

      expect(() => new EncryptionService()).toThrow(/clé d'exemple/);
    });

    it('reste acceptée en local', () => {
      process.env.NODE_ENV = 'development';
      process.env.ENCRYPTION_KEY = EXAMPLE_ENCRYPTION_KEY;

      expect(() => new EncryptionService()).not.toThrow();
    });

    it('correspond bien à la valeur écrite dans .env.example', () => {
      const envExample = readFileSync(join(__dirname, '../../../../.env.example'), 'utf8');

      expect(envExample).toContain(`ENCRYPTION_KEY=${EXAMPLE_ENCRYPTION_KEY}\n`);
    });
  });

  it('déchiffre ce qu’il a chiffré, binaire comme texte', () => {
    const file = randomBytes(2048);

    expect(service.decrypt(service.encrypt(file, 'ctx'), 'ctx').equals(file)).toBe(true);
    expect(service.decryptText(service.encryptText('CACES-123456', 'ctx'), 'ctx')).toBe(
      'CACES-123456',
    );
  });

  it('ne laisse pas le clair apparaître dans le chiffré', () => {
    const encrypted = Buffer.from(service.encryptText('NUMERO-CERTIFICAT-SECRET', 'ctx'));

    expect(encrypted.toString('latin1')).not.toContain('NUMERO-CERTIFICAT-SECRET');
  });

  it('utilise un IV aléatoire : deux chiffrements du même contenu diffèrent', () => {
    const first = Buffer.from(service.encryptText('identique', 'ctx'));
    const second = Buffer.from(service.encryptText('identique', 'ctx'));

    expect(first.equals(second)).toBe(false);
  });

  it('détecte un chiffré modifié en base', () => {
    const encrypted = service.encryptText('pièce d’identité', 'ctx');
    const tampered = Buffer.from(encrypted);
    tampered[tampered.length - 1] ^= 0xff;

    expect(() => service.decrypt(tampered, 'ctx')).toThrow(DecryptionError);
  });

  it("refuse de déchiffrer avec le contexte d'un autre intérimaire", () => {
    const encrypted = service.encryptText('document', 'identity-document:worker-a');

    expect(() => service.decrypt(encrypted, 'identity-document:worker-b')).toThrow(DecryptionError);
  });

  it('refuse de déchiffrer avec une autre clé', () => {
    const encrypted = service.encryptText('document', 'ctx');
    process.env.ENCRYPTION_KEY = Buffer.alloc(32, 2).toString('base64');

    expect(() => new EncryptionService().decrypt(encrypted, 'ctx')).toThrow(DecryptionError);
  });

  it('refuse une donnée trop courte ou de version inconnue', () => {
    const encrypted = Buffer.from(service.encryptText('document', 'ctx'));
    encrypted[0] = 9;

    expect(() => service.decrypt(Buffer.from([1, 2, 3]), 'ctx')).toThrow(DecryptionError);
    expect(() => service.decrypt(encrypted, 'ctx')).toThrow(DecryptionError);
  });
});
