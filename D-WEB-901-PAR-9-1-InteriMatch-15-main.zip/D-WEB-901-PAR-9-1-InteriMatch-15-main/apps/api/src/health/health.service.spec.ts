import { Test } from '@nestjs/testing';
import { MongoService } from '../mongo/mongo.service';
import { PrismaService } from '../prisma/prisma.service';
import { HealthService } from './health.service';

describe('HealthService', () => {
  const buildService = async (options: {
    postgresOk: boolean;
    mongoOk: boolean;
  }): Promise<HealthService> => {
    const queryRaw = options.postgresOk
      ? jest.fn().mockResolvedValue([{ '?column?': 1 }])
      : jest.fn().mockRejectedValue(new Error('ECONNREFUSED'));

    const moduleRef = await Test.createTestingModule({
      providers: [
        HealthService,
        { provide: PrismaService, useValue: { $queryRaw: queryRaw } },
        { provide: MongoService, useValue: { ping: jest.fn().mockResolvedValue(options.mongoOk) } },
      ],
    }).compile();

    return moduleRef.get(HealthService);
  };

  it('rend un état global up quand les deux bases répondent', async () => {
    const service = await buildService({ postgresOk: true, mongoOk: true });

    const report = await service.check();

    expect(report).toMatchObject({ status: 'up', postgres: 'up', mongo: 'up' });
    expect(report.uptimeSeconds).toBeGreaterThanOrEqual(0);
  });

  it('rend un état global down si PostgreSQL est injoignable', async () => {
    const service = await buildService({ postgresOk: false, mongoOk: true });

    expect(await service.check()).toMatchObject({ status: 'down', postgres: 'down', mongo: 'up' });
  });

  it('rend un état global down si MongoDB est injoignable', async () => {
    const service = await buildService({ postgresOk: true, mongoOk: false });

    expect(await service.check()).toMatchObject({ status: 'down', postgres: 'up', mongo: 'down' });
  });

  it('rend un état global down si les deux bases sont injoignables', async () => {
    const service = await buildService({ postgresOk: false, mongoOk: false });

    expect(await service.check()).toMatchObject({
      status: 'down',
      postgres: 'down',
      mongo: 'down',
    });
  });
});
