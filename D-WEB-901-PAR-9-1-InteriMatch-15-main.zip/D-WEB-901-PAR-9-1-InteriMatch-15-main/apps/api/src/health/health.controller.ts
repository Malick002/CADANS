import { Controller, Get } from '@nestjs/common';
import { Public } from '../auth/decorators';
import { HealthReport, HealthService } from './health.service';

@Public()
@Controller('health')
export class HealthController {
  constructor(private readonly healthService: HealthService) {}

  @Get()
  check(): Promise<HealthReport> {
    return this.healthService.check();
  }
}
