import { Injectable } from '@nestjs/common';
import { MongoService } from '../mongo/mongo.service';
import { PrismaService } from '../prisma/prisma.service';

export type ServiceState = 'up' | 'down';

export interface HealthReport {
  status: ServiceState;
  postgres: ServiceState;
  mongo: ServiceState;
  uptimeSeconds: number;
}

@Injectable()
export class HealthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly mongo: MongoService,
  ) {}

  async check(): Promise<HealthReport> {
    // Les deux sondes sont indépendantes : on les lance en parallèle.
    const [postgres, mongo] = await Promise.all([this.checkPostgres(), this.checkMongo()]);

    return {
      status: postgres === 'up' && mongo === 'up' ? 'up' : 'down',
      postgres,
      mongo,
      uptimeSeconds: Math.round(process.uptime()),
    };
  }

  private async checkPostgres(): Promise<ServiceState> {
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      return 'up';
    } catch {
      return 'down';
    }
  }

  private async checkMongo(): Promise<ServiceState> {
    return (await this.mongo.ping()) ? 'up' : 'down';
  }
}
