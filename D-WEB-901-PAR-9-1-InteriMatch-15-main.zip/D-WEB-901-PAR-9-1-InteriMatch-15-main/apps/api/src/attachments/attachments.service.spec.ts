import {
  BadRequestException,
  ConflictException,
  NotFoundException,
  PayloadTooLargeException,
  UnsupportedMediaTypeException,
} from '@nestjs/common';
import { Role } from '@prisma/client';
import { EncryptionService } from '../encryption/encryption.service';
import { PrismaService } from '../prisma/prisma.service';
import { MAX_DOCUMENT_SIZE_BYTES } from '../sensitive-documents/file-type';
import { AttachmentsService } from './attachments.service';

const MISSION_ID = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
const PDF = Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.from('consignes de sécurité')]);

function encryption(): EncryptionService {
  process.env.ENCRYPTION_KEY = Buffer.alloc(32, 7).toString('base64');
  return new EncryptionService();
}

interface Row {
  id: string;
  missionId: string;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  fileEncrypted: Uint8Array;
  createdAt: Date;
}

function harnais(options: { retenu?: boolean; mission?: boolean; signe?: boolean } = {}) {
  const rows: Row[] = [];
  const prisma = {
    mission: {
      // Missions sur lesquelles l'intérimaire est retenu, avec leurs annexes : ce que sert
      // `listForWorker`. Une seule mission ici, celle du harnais.
      findMany: () =>
        Promise.resolve(
          options.retenu === false
            ? []
            : [
                {
                  id: MISSION_ID,
                  siteLabel: 'Entrepôt du Nord — réception',
                  poste: { label: 'Agent de manutention' },
                  attachments: rows.map((row) => ({ ...row, createdAt: new Date() })),
                },
              ],
        ),
      findUnique: () =>
        Promise.resolve(
          options.mission === false
            ? null
            : {
                company: { userId: 'user-entreprise' },
                assignedWorker: options.retenu === false ? null : { userId: 'user-interimaire' },
              },
        ),
    },
    missionAttachment: {
      create: ({ data }: { data: Row }) => {
        rows.push(data);
        return Promise.resolve({ ...data, createdAt: data.createdAt ?? new Date() });
      },
      findMany: () => Promise.resolve(rows.map((row) => ({ ...row, createdAt: new Date() }))),
      // `findUnique` sert deux appels différents : la lecture (colonnes plates) et la
      // suppression (avec la mission et ses contrats). On rend les deux formes à la fois,
      // c'est le `select` du service qui choisit ce qu'il lit.
      findUnique: ({ where }: { where: { id: string } }) => {
        const row = rows.find((candidate) => candidate.id === where.id);
        return Promise.resolve(
          row
            ? {
                ...row,
                mission: {
                  company: { userId: 'user-entreprise' },
                  contracts: [{ completedAt: options.signe ? new Date() : null }],
                },
              }
            : null,
        );
      },
      delete: ({ where }: { where: { id: string } }) => {
        const index = rows.findIndex((row) => row.id === where.id);
        const [supprimee] = rows.splice(index, 1);
        return Promise.resolve(supprimee);
      },
    },
  } as unknown as PrismaService;

  const chiffrement = encryption();
  return { rows, chiffrement, service: new AttachmentsService(prisma, chiffrement) };
}

describe('AttachmentsService — dépôt', () => {
  it('chiffre le document et enregistre sa taille en clair', async () => {
    const { service, rows, chiffrement } = harnais();

    const vue = await service.add('user-entreprise', MISSION_ID, 'Consignes.pdf', {
      buffer: PDF,
    });

    expect(vue).toMatchObject({ filename: 'Consignes.pdf', sizeBytes: PDF.length });
    const stocke = rows[0];
    // La colonne chiffrée est plus longue que le fichier : en-tête de version, IV et tag GCM.
    // C'est pour ça que `sizeBytes` porte la taille EN CLAIR — l'autre n'aurait aucun sens
    // pour l'utilisateur qui lit « 2,3 Mo ».
    expect(stocke.fileEncrypted.length).toBeGreaterThan(PDF.length);
    expect(Buffer.from(stocke.fileEncrypted).toString('latin1')).not.toContain('consignes');
    expect(chiffrement.decrypt(stocke.fileEncrypted, `mission-attachment:${stocke.id}`)).toEqual(
      PDF,
    );
  });

  // Le contexte lie le chiffré à SON annexe : recopier la colonne d'une annexe sur une autre
  // la rend indéchiffrable au lieu de la révéler.
  it('lie le chiffré à l’annexe elle-même', async () => {
    const { service, rows, chiffrement } = harnais();
    await service.add('user-entreprise', MISSION_ID, 'Consignes.pdf', { buffer: PDF });

    expect(() =>
      chiffrement.decrypt(rows[0].fileEncrypted, 'mission-attachment:une-autre'),
    ).toThrow();
  });

  it('refuse un fichier qui n’est pas un PDF, quel que soit son nom', async () => {
    const { service } = harnais();

    await expect(
      service.add('user-entreprise', MISSION_ID, 'faux.pdf', {
        buffer: Buffer.from('\x89PNG\r\n\x1a\n' + 'contenu'),
      }),
    ).rejects.toBeInstanceOf(UnsupportedMediaTypeException);
  });

  it('refuse un fichier vide ou absent', async () => {
    const { service } = harnais();

    await expect(
      service.add('user-entreprise', MISSION_ID, 'vide.pdf', undefined),
    ).rejects.toBeInstanceOf(BadRequestException);
    await expect(
      service.add('user-entreprise', MISSION_ID, 'vide.pdf', { buffer: Buffer.alloc(0) }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  // Multer coupe déjà, mais selon sa configuration il tronque au lieu de lever : on préfère
  // refuser que stocker un PDF amputé, illisible et dont personne ne saurait pourquoi.
  it('refuse un fichier au-delà de 5 Mo', async () => {
    const { service } = harnais();
    const trop = Buffer.concat([Buffer.from('%PDF-'), Buffer.alloc(MAX_DOCUMENT_SIZE_BYTES + 1)]);

    await expect(
      service.add('user-entreprise', MISSION_ID, 'gros.pdf', { buffer: trop }),
    ).rejects.toBeInstanceOf(PayloadTooLargeException);
  });

  /**
   * Le nom vient de l'utilisateur et finit dans un en-tête `Content-Disposition`. Un guillemet
   * y ouvrirait un second paramètre, un saut de ligne un second en-tête, et `../` n'a rien à
   * faire dans un nom qu'on réaffiche.
   */
  it('assainit le nom du fichier', async () => {
    const { service } = harnais();

    const cas: [string, string][] = [
      ['../../etc/passwd', 'passwd.pdf'],
      ['plan"; filename="virus.exe', 'plan filename=virus.exe.pdf'],
      ['consignes\r\nX-Injecte: 1.pdf', 'consignesX-Injecte: 1.pdf'],
      ['Plan d’accès.PDF', 'Plan d’accès.pdf'],
      ['', 'document.pdf'],
    ];

    for (const [saisi, attendu] of cas) {
      const vue = await service.add('user-entreprise', MISSION_ID, saisi, { buffer: PDF });
      expect(vue.filename).toBe(attendu);
    }
  });

  it('refuse à une entreprise de joindre un document à la mission d’une autre', async () => {
    const { service } = harnais();

    await expect(
      service.add('user-autre-entreprise', MISSION_ID, 'Consignes.pdf', { buffer: PDF }),
    ).rejects.toBeInstanceOf(NotFoundException);
  });
});

describe('AttachmentsService — qui les voit', () => {
  it('sert l’entreprise propriétaire et l’intérimaire retenu', async () => {
    const { service } = harnais();
    const vue = await service.add('user-entreprise', MISSION_ID, 'Consignes.pdf', {
      buffer: PDF,
    });

    expect(await service.list('user-entreprise', Role.COMPANY, MISSION_ID)).toHaveLength(1);
    expect(await service.list('user-interimaire', Role.WORKER, MISSION_ID)).toHaveLength(1);
    expect((await service.read('user-interimaire', Role.WORKER, vue.id)).content).toEqual(PDF);
  });

  /**
   * Un candidat n'est pas un intérimaire retenu : tant qu'il ne l'est pas, les consignes d'un
   * site où il n'ira peut-être jamais ne le concernent pas. 404 et non 403 — la fiche de
   * mission est publique, l'existence de ses annexes n'a pas à l'être.
   */
  it('refuse un intérimaire qui n’est pas retenu, avec 404', async () => {
    const { service } = harnais({ retenu: false });
    await service.add('user-entreprise', MISSION_ID, 'Consignes.pdf', { buffer: PDF });

    await expect(service.list('user-candidat', Role.WORKER, MISSION_ID)).rejects.toBeInstanceOf(
      NotFoundException,
    );
  });

  it('refuse un intérimaire retenu sur une AUTRE mission', async () => {
    const { service } = harnais();
    const vue = await service.add('user-entreprise', MISSION_ID, 'Consignes.pdf', {
      buffer: PDF,
    });

    await expect(service.read('user-inconnu', Role.WORKER, vue.id)).rejects.toBeInstanceOf(
      NotFoundException,
    );
  });

  /**
   * Les annexes ne dépendent PAS des contrats : un intérimaire retenu dont le contrat de
   * mission attend encore ses informations d'embauche doit quand même recevoir le plan
   * d'accès et les consignes du site. Le défaut a été vu à l'écran, pas déduit.
   */
  it('sert à l’intérimaire les annexes de toutes ses missions retenues, contrat ou non', async () => {
    const { service } = harnais();
    await service.add('user-entreprise', MISSION_ID, 'Consignes.pdf', { buffer: PDF });

    const missions = await service.listForWorker('user-interimaire');

    expect(missions).toHaveLength(1);
    expect(missions[0]).toMatchObject({
      missionId: MISSION_ID,
      missionTitre: 'Agent de manutention',
      siteLabel: 'Entrepôt du Nord — réception',
    });
    expect(missions[0].annexes).toHaveLength(1);
  });

  // Une mission sans annexe n'apparaît pas : un bloc « Documents joints » vide ne dit rien.
  it('n’annonce pas une mission retenue sans annexe', async () => {
    const { service } = harnais();

    expect(await service.listForWorker('user-interimaire')).toEqual([]);
  });

  it('signale une annexe introuvable', async () => {
    const { service } = harnais();

    await expect(
      service.read('user-entreprise', Role.COMPANY, 'inexistante'),
    ).rejects.toBeInstanceOf(NotFoundException);
  });
});

describe('AttachmentsService — suppression', () => {
  it('supprime une annexe tant qu’aucun contrat n’est signé', async () => {
    const { service, rows } = harnais();
    const vue = await service.add('user-entreprise', MISSION_ID, 'Consignes.pdf', {
      buffer: PDF,
    });

    await service.remove('user-entreprise', vue.id);

    expect(rows).toHaveLength(0);
  });

  /**
   * Une annexe n'est pas un brouillon : les consignes de sécurité d'un site font partie de ce
   * sur quoi l'intérimaire s'est engagé en signant. Les retirer après coup changerait le
   * dossier sans laisser de trace, et personne ne pourrait dire ce qu'il avait lu.
   *
   * 409 et non 400 : la demande est bien formée, c'est l'état de la mission qui la refuse.
   */
  it('refuse la suppression dès qu’un contrat de la mission est signé', async () => {
    const { service, rows } = harnais({ signe: true });
    const vue = await service.add('user-entreprise', MISSION_ID, 'Consignes.pdf', {
      buffer: PDF,
    });

    await expect(service.remove('user-entreprise', vue.id)).rejects.toBeInstanceOf(
      ConflictException,
    );
    expect(rows).toHaveLength(1);
  });

  it('refuse à une entreprise de supprimer l’annexe d’une autre, avec 404', async () => {
    const { service, rows } = harnais();
    const vue = await service.add('user-entreprise', MISSION_ID, 'Consignes.pdf', {
      buffer: PDF,
    });

    await expect(service.remove('user-autre-entreprise', vue.id)).rejects.toBeInstanceOf(
      NotFoundException,
    );
    expect(rows).toHaveLength(1);
  });

  it('signale une annexe introuvable', async () => {
    const { service } = harnais();

    await expect(service.remove('user-entreprise', 'inexistante')).rejects.toBeInstanceOf(
      NotFoundException,
    );
  });
});
