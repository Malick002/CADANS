import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
  PayloadTooLargeException,
  UnsupportedMediaTypeException,
} from '@nestjs/common';
import { Role } from '@prisma/client';
import { EncryptionService } from '../encryption/encryption.service';
import { PrismaService } from '../prisma/prisma.service';
import { MAX_DOCUMENT_SIZE_BYTES } from '../sensitive-documents/file-type';

export interface AttachmentView {
  id: string;
  missionId: string;
  filename: string;
  sizeBytes: number;
  createdAt: Date;
}

// Les annexes d'une mission, avec de quoi la nommer : l'intérimaire lit « Entrepôt du Nord —
// réception », pas un UUID.
export interface MissionAttachmentsView {
  missionId: string;
  missionTitre: string;
  siteLabel: string;
  annexes: AttachmentView[];
}

export interface DecryptedAttachment {
  content: Buffer;
  filename: string;
}

// Contexte de chiffrement : lié à l'annexe elle-même. Recopier le chiffré d'une annexe sur la
// ligne d'une autre la rend indéchiffrable, comme pour les justificatifs d'habilitation.
const attachmentContext = (id: string): string => `mission-attachment:${id}`;

// Signature binaire du PDF. Les annexes n'acceptent QUE ce format, là où les justificatifs
// acceptent aussi JPEG et PNG : un plan d'accès ou des consignes de sécurité se lisent,
// s'impriment et se paginent — une photo ne fait rien de tout cela.
const SIGNATURE_PDF = [0x25, 0x50, 0x44, 0x46, 0x2d]; // %PDF-

/**
 * Annexes d'une mission : documents PDF joints par l'entreprise utilisatrice.
 *
 * **Qui les voit** : l'entreprise qui les a déposées, et l'intérimaire **retenu** sur la
 * mission. Pas les candidats — tant qu'une personne n'est pas retenue, les consignes d'un
 * site où elle n'ira peut-être jamais ne la concernent pas, et un plan de site nomme des
 * zones, des horaires et parfois des personnes.
 *
 * Elles sont chiffrées au repos avec le mécanisme existant, pour la même raison.
 */
@Injectable()
export class AttachmentsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
  ) {}

  async add(
    userId: string,
    missionId: string,
    filename: string,
    file: { buffer: Buffer } | undefined,
  ): Promise<AttachmentView> {
    await this.assertOwner(userId, missionId);
    const content = valider(file);

    // L'identifiant est tiré AVANT l'écriture : le contexte de chiffrement en dépend, et on
    // ne peut pas chiffrer avec un identifiant que la base n'a pas encore attribué.
    const id = crypto.randomUUID();
    const attachment = await this.prisma.missionAttachment.create({
      data: {
        id,
        missionId,
        filename: assainir(filename),
        mimeType: 'application/pdf',
        sizeBytes: content.length,
        fileEncrypted: this.encryption.encrypt(content, attachmentContext(id)),
      },
    });

    return toView(attachment);
  }

  /**
   * Annexes d'une mission, si le demandeur y a droit. **404 et non 403** quand la mission
   * existe mais ne le concerne pas : la fiche de mission est publique, mais l'existence de
   * ses annexes n'a pas à l'être.
   */
  async list(userId: string, role: Role, missionId: string): Promise<AttachmentView[]> {
    await this.assertDestinataire(userId, role, missionId);
    const attachments = await this.prisma.missionAttachment.findMany({
      where: { missionId },
      orderBy: { createdAt: 'asc' },
    });
    return attachments.map(toView);
  }

  /**
   * Toutes les annexes des missions sur lesquelles l'intérimaire est retenu, groupées par
   * mission.
   *
   * Cette route existe parce que les annexes ne dépendent PAS des contrats : un intérimaire
   * retenu dont le contrat de mission attend encore ses informations d'embauche doit quand
   * même recevoir le plan d'accès et les consignes de sécurité du site. Les accrocher à la
   * liste des contrats laissait précisément ce cas sans rien — constaté à l'écran.
   */
  async listForWorker(userId: string): Promise<MissionAttachmentsView[]> {
    const missions = await this.prisma.mission.findMany({
      where: { assignedWorker: { userId } },
      select: {
        id: true,
        siteLabel: true,
        poste: { select: { label: true } },
        attachments: { orderBy: { createdAt: 'asc' } },
      },
      orderBy: { startDate: 'asc' },
    });

    return missions
      .filter((mission) => mission.attachments.length > 0)
      .map((mission) => ({
        missionId: mission.id,
        missionTitre: mission.poste.label,
        siteLabel: mission.siteLabel,
        annexes: mission.attachments.map(toView),
      }));
  }

  async read(userId: string, role: Role, attachmentId: string): Promise<DecryptedAttachment> {
    const attachment = await this.prisma.missionAttachment.findUnique({
      where: { id: attachmentId },
    });
    if (!attachment) {
      throw new NotFoundException('Document introuvable');
    }
    await this.assertDestinataire(userId, role, attachment.missionId, 'Document introuvable');

    return {
      content: this.encryption.decrypt(attachment.fileEncrypted, attachmentContext(attachment.id)),
      filename: attachment.filename,
    };
  }

  /**
   * Suppression d'une annexe par l'entreprise qui l'a déposée.
   *
   * **Refusée dès qu'un contrat de la mission est signé.** Une annexe n'est pas un brouillon :
   * les consignes de sécurité d'un site font partie de ce sur quoi l'intérimaire s'est engagé
   * en signant. Les retirer après coup changerait le dossier sans laisser de trace, et
   * personne ne pourrait dire ce qu'il avait lu. Tant que rien n'est signé, en revanche, il
   * n'y a aucune raison de figer une pièce jointe déposée par erreur.
   *
   * L'intérimaire, lui, ne supprime jamais : les annexes ne sont pas à lui, il les reçoit.
   * C'est la route qui le dit — elle est réservée au rôle COMPANY.
   */
  async remove(userId: string, attachmentId: string): Promise<void> {
    const attachment = await this.prisma.missionAttachment.findUnique({
      where: { id: attachmentId },
      select: {
        id: true,
        missionId: true,
        mission: {
          select: {
            company: { select: { userId: true } },
            contracts: { select: { completedAt: true } },
          },
        },
      },
    });

    // 404 et non 403 : une entreprise n'a pas à apprendre qu'une annexe existe chez une autre
    // en essayant de la supprimer. Même raisonnement que partout ailleurs sur ces routes.
    if (!attachment || attachment.mission.company.userId !== userId) {
      throw new NotFoundException('Document introuvable');
    }

    if (attachment.mission.contracts.some((contrat) => contrat.completedAt !== null)) {
      // 409 et non 400 : la demande est bien formée, c'est l'état de la mission qui la
      // refuse. Même choix que la signature d'un contrat déjà signé.
      throw new ConflictException(
        'Un contrat de cette mission est signé : ses documents joints ne peuvent plus être ' +
          'retirés.',
      );
    }

    await this.prisma.missionAttachment.delete({ where: { id: attachmentId } });
  }

  private async assertOwner(userId: string, missionId: string): Promise<void> {
    const mission = await this.prisma.mission.findUnique({
      where: { id: missionId },
      select: { company: { select: { userId: true } } },
    });
    if (!mission || mission.company.userId !== userId) {
      // 404 et non 403 : une entreprise n'a pas à apprendre qu'une mission existe chez une
      // autre en essayant d'y joindre un document.
      throw new NotFoundException('Mission introuvable');
    }
  }

  private async assertDestinataire(
    userId: string,
    role: Role,
    missionId: string,
    message = 'Mission introuvable',
  ): Promise<void> {
    const mission = await this.prisma.mission.findUnique({
      where: { id: missionId },
      select: {
        company: { select: { userId: true } },
        assignedWorker: { select: { userId: true } },
      },
    });
    if (!mission) {
      throw new NotFoundException(message);
    }

    const autorise =
      (role === Role.COMPANY && mission.company.userId === userId) ||
      (role === Role.WORKER && mission.assignedWorker?.userId === userId);

    if (!autorise) {
      throw new NotFoundException(message);
    }
  }
}

function valider(file: { buffer: Buffer } | undefined): Buffer {
  if (!file || file.buffer.length === 0) {
    throw new BadRequestException('Le fichier est obligatoire (champ « file »)');
  }
  // Multer coupe déjà au-delà de la limite, mais il tronque au lieu de lever selon la
  // configuration : on revérifie plutôt que de stocker un PDF amputé.
  if (file.buffer.length > MAX_DOCUMENT_SIZE_BYTES) {
    throw new PayloadTooLargeException('Le document ne doit pas dépasser 5 Mo');
  }
  // Le contenu réel, jamais le type annoncé par le navigateur, qui est falsifiable.
  if (!SIGNATURE_PDF.every((byte, index) => file.buffer[index] === byte)) {
    throw new UnsupportedMediaTypeException('Seuls les fichiers PDF sont acceptés');
  }
  return file.buffer;
}

/**
 * Le nom du fichier vient de l'utilisateur et se retrouve dans un en-tête HTTP
 * `Content-Disposition`. On en retire tout ce qui pourrait y injecter un paramètre — guillemets,
 * points-virgules, sauts de ligne — et toute trace de chemin : `../` n'a rien à faire dans un
 * nom qu'on réaffiche.
 */
function assainir(filename: string): string {
  const base = filename.split(/[/\\]/).pop() ?? 'document.pdf';
  const propre = base.replace(/["';\r\n]/g, '').trim();
  const sansExtension = propre.replace(/\.pdf$/i, '');
  return `${(sansExtension || 'document').slice(0, 250)}.pdf`;
}

function toView(attachment: {
  id: string;
  missionId: string;
  filename: string;
  sizeBytes: number;
  createdAt: Date;
}): AttachmentView {
  return {
    id: attachment.id,
    missionId: attachment.missionId,
    filename: attachment.filename,
    sizeBytes: attachment.sizeBytes,
    createdAt: attachment.createdAt,
  };
}
