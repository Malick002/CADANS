import {
  Body,
  Controller,
  Delete,
  Get,
  Header,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Post,
  StreamableFile,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { Role } from '@prisma/client';
import { CurrentUser, Roles } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import { MAX_DOCUMENT_SIZE_BYTES } from '../sensitive-documents/file-type';
import { AttachmentsService, AttachmentView, MissionAttachmentsView } from './attachments.service';
import { UploadAnnexeDto } from './dto/upload-annexe.dto';

// Fichier gardé en mémoire le temps d'être chiffré : jamais écrit en clair sur le disque.
// Même interceptor que les justificatifs d'habilitation, même limite de 5 Mo.
const annexeUpload = FileInterceptor('file', {
  limits: { fileSize: MAX_DOCUMENT_SIZE_BYTES, files: 1, fields: 5 },
});

/**
 * Annexes d'une mission. Deux rôles, deux droits, et c'est le service qui tranche :
 * l'entreprise propriétaire dépose et consulte, l'intérimaire **retenu** consulte.
 *
 * Aucun `@Roles` de classe, donc : la route de lecture est ouverte aux deux rôles, et elle
 * répond 404 — pas 403 — à qui n'est pas destinataire. La fiche de mission est publique,
 * l'existence de ses annexes n'a pas à l'être.
 */
@Controller()
export class AttachmentsController {
  constructor(private readonly attachments: AttachmentsService) {}

  @Roles(Role.COMPANY)
  @Post('missions/:id/annexes')
  @UseInterceptors(annexeUpload)
  add(
    @CurrentUser() user: SessionUser,
    @Param('id', ParseUUIDPipe) missionId: string,
    @Body() dto: UploadAnnexeDto,
    @UploadedFile() file: Express.Multer.File | undefined,
  ): Promise<AttachmentView> {
    return this.attachments.add(user.id, missionId, dto.filename, file);
  }

  // Déclarée sous `workers/me`, comme le reste de ce qui appartient à l'intérimaire : les
  // annexes de toutes ses missions retenues, en une requête.
  @Roles(Role.WORKER)
  @Get('workers/me/annexes')
  listForWorker(@CurrentUser() user: SessionUser): Promise<MissionAttachmentsView[]> {
    return this.attachments.listForWorker(user.id);
  }

  @Get('missions/:id/annexes')
  list(
    @CurrentUser() user: SessionUser,
    @Param('id', ParseUUIDPipe) missionId: string,
  ): Promise<AttachmentView[]> {
    return this.attachments.list(user.id, user.role, missionId);
  }

  /**
   * Suppression, réservée à l'entreprise propriétaire — `@Roles(Role.COMPANY)` : un
   * intérimaire reçoit les annexes, elles ne sont pas à lui. Le service refuse en plus dès
   * qu'un contrat de la mission est signé.
   */
  @Roles(Role.COMPANY)
  @Delete('annexes/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@CurrentUser() user: SessionUser, @Param('id', ParseUUIDPipe) id: string): Promise<void> {
    return this.attachments.remove(user.id, id);
  }

  /**
   * Document déchiffré à la volée. `no-store` interdit au navigateur comme aux
   * intermédiaires d'en garder une copie, `nosniff` empêche de le réinterpréter comme du
   * HTML. Même traitement que les justificatifs et les contrats.
   */
  @Get('annexes/:id/document')
  @Header('Cache-Control', 'no-store')
  @Header('X-Content-Type-Options', 'nosniff')
  async download(
    @CurrentUser() user: SessionUser,
    @Param('id', ParseUUIDPipe) id: string,
  ): Promise<StreamableFile> {
    const file = await this.attachments.read(user.id, user.role, id);
    return new StreamableFile(file.content, {
      type: 'application/pdf',
      disposition: `inline; filename="${file.filename}"`,
      length: file.content.length,
    });
  }
}
