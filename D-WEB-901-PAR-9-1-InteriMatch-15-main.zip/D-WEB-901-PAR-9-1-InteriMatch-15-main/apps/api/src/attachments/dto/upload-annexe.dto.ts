import { IsNotEmpty, IsString, MaxLength } from 'class-validator';
import { Trim } from '../../auth/dto/validation';

export class UploadAnnexeDto {
  // Nom lisible du document, saisi par l'entreprise et non déduit du fichier : « Consignes de
  // sécurité du site » vaut mieux que « scan_0043.pdf » pour l'intérimaire qui le reçoit.
  // Assaini par le service avant stockage — il finit dans un en-tête HTTP.
  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Donnez un nom au document' })
  @MaxLength(255)
  filename: string;
}
