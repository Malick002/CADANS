import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  CertificationStatus,
  CertificationType,
  MissionStatus,
  Prisma,
  Shift,
} from '@prisma/client';
import {
  MatchScoreDetail,
  MatchingService,
  scoreCandidat,
  validCertificationTypes,
} from '../matching/matching.service';
import { PrismaService } from '../prisma/prisma.service';

export interface CandidatureView {
  id: string;
  status: string;
  createdAt: Date;
  missionId: string;
  posteLabel: string;
  siteLabel: string;
  companyName: string;
  startDate: string;
  endDate: string;
}

// Ce que l'entreprise apprend d'un candidat, et rien de plus. Trois éléments, chacun
// nécessaire à la décision de retenir quelqu'un sur une mission :
//   · l'identité, sans quoi l'écran affiche « 1 candidature » sans dire de qui ;
//   · les habilitations VALIDES, parce que c'est le filtre bloquant du matching et le
//     premier critère réglementaire d'une affectation en entrepôt ;
//   · la zone (ville + code postal), second critère du score.
// Volontairement absents, au titre de la minimisation (RGPD, art. 5.1.c) : email, téléphone,
// pièce d'identité, numéros de certificat. La prise de contact passe par la plateforme ;
// ces données ne deviennent nécessaires qu'une fois l'intérimaire retenu.
export interface CandidatView {
  // Identifiant du PROFIL intérimaire (Worker.id), celui qu'attend PATCH /missions/:id/status
  // pour désigner la personne retenue. Ce n'est pas l'identifiant du compte.
  workerId: string;
  firstName: string;
  lastName: string;
  city: string;
  postalCode: string;
  // Compétences déclarées par l'intérimaire. Déclaratif, jamais vérifié — contrairement aux
  // habilitations, qui passent devant un agent. L'écran doit le dire.
  competences: { code: string; label: string }[];
  // Créneaux acceptés. Une mission ne remonte pas au matching si son créneau n'y est pas :
  // un candidat qui a postulé accepte donc forcément celui de la mission.
  shifts: Shift[];
  // Score de CE candidat sur CETTE mission, calculé par `scoreCandidat` — la fonction que le
  // matching utilise pour l'intérimaire. Les deux parties voient le même chiffre.
  score: number;
  detail: MatchScoreDetail;
  certifications: CertificationType[];
  // Habilitations dont un agent CADANS a vérifié le justificatif. Sous-ensemble de
  // `certifications` : une habilitation vérifiée est nécessairement valide, l'inverse est
  // faux. L'entreprise voit ainsi ce qui a été contrôlé et ce qui est seulement déclaré.
  //
  // Le justificatif lui-même ne quitte jamais CADANS : l'entreprise n'a ni le document, ni
  // le numéro de certificat, ni le nom de l'agent qui a tranché.
  certificationsVerifiees: CertificationType[];
}

// Vue réservée à l'entreprise propriétaire de la mission. Type distinct de CandidatureView :
// l'intérimaire qui consulte « mes candidatures » ne doit jamais recevoir ce bloc, et c'est
// le compilateur qui le garantit plutôt qu'un champ optionnel qu'on oublierait de remplir.
export interface CandidatureEntrepriseView extends CandidatureView {
  candidat: CandidatView;
}

const CANDIDATURE_INCLUDE = {
  mission: {
    select: {
      siteLabel: true,
      startDate: true,
      endDate: true,
      poste: { select: { label: true } },
      company: { select: { legalName: true } },
    },
  },
} as const;

// Même include, plus l'intérimaire : seule la requête de l'entreprise le charge, de sorte
// qu'aucune donnée de candidat ne transite par le chemin de l'intérimaire.
const CANDIDATURE_INCLUDE_ENTREPRISE = {
  ...CANDIDATURE_INCLUDE,
  // La mission est rechargée avec ce que le score exige : ses compétences souhaitées, son
  // code postal et son créneau. Sans eux, l'entreprise verrait une liste de candidats sans
  // savoir lequel correspond le mieux à CETTE mission.
  mission: {
    select: {
      ...CANDIDATURE_INCLUDE.mission.select,
      postalCode: true,
      shift: true,
      competences: { select: { competenceCode: true } },
    },
  },
  worker: {
    select: {
      // Exposé à l'entreprise pour qu'elle puisse RETENIR le candidat : sans lui, l'écran
      // listait des gens sans qu'aucune action soit possible. C'est l'identifiant du profil
      // intérimaire, pas celui du compte — il ne permet pas de se connecter.
      id: true,
      firstName: true,
      lastName: true,
      city: true,
      postalCode: true,
      certifications: { select: { type: true, expiresAt: true, verificationStatus: true } },
      // Compétences déclarées : elles pèsent 60 % du score, et l'entreprise ne les voyait
      // pas. Elle ne jugeait que sur les CACES, qui sont un filtre d'accès valant 0 point.
      skills: { select: { competence: { select: { code: true, label: true } } } },
      // Créneaux acceptés : critère d'élimination du matching, invisible jusqu'ici.
      shifts: true,
    },
  },
} as const;

type CandidatureWithMission = Prisma.CandidatureGetPayload<{ include: typeof CANDIDATURE_INCLUDE }>;
type CandidatureWithWorker = Prisma.CandidatureGetPayload<{
  include: typeof CANDIDATURE_INCLUDE_ENTREPRISE;
}>;

@Injectable()
export class CandidaturesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly matching: MatchingService,
  ) {}

  async apply(userId: string, missionId: string): Promise<CandidatureView> {
    const workerId = await this.workerId(userId);

    // La fiche d'une mission pourvue reste lisible — une URL indexée ou partagée ne doit pas
    // devenir 404 (arbitrage du 21/09). C'est donc ICI que se joue la protection : on refuse
    // la candidature, plutôt que de faire disparaître la page.
    const mission = await this.prisma.mission.findUnique({
      where: { id: missionId },
      select: { status: true },
    });
    if (!mission) {
      throw new NotFoundException('Mission introuvable');
    }
    if (mission.status !== MissionStatus.OUVERTE) {
      throw new ConflictException(
        'Cette mission n’est plus ouverte aux candidatures : elle a été pourvue ou terminée',
      );
    }

    const missing = await this.matching.missingCertificationsFor(workerId, missionId);
    if (missing.length > 0) {
      throw new BadRequestException(
        'Une ou plusieurs habilitations exigées ne sont pas dans votre profil, ou ont expiré',
      );
    }

    try {
      const candidature = await this.prisma.candidature.create({
        data: { missionId, workerId },
        include: CANDIDATURE_INCLUDE,
      });
      return toView(candidature);
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException('Vous avez déjà postulé à cette mission');
      }
      throw error;
    }
  }

  async findAllForWorker(userId: string): Promise<CandidatureView[]> {
    const workerId = await this.workerId(userId);
    const candidatures = await this.prisma.candidature.findMany({
      where: { workerId },
      include: CANDIDATURE_INCLUDE,
      orderBy: { createdAt: 'desc' },
    });
    return candidatures.map(toView);
  }

  // La mission doit appartenir à l'entreprise connectée : 404 plutôt que 403, pour ne jamais
  // confirmer qu'une mission d'une autre entreprise existe.
  async findAllForMission(userId: string, missionId: string): Promise<CandidatureEntrepriseView[]> {
    const companyId = await this.companyId(userId);
    const mission = await this.prisma.mission.findUnique({
      where: { id: missionId },
      select: { companyId: true },
    });
    if (!mission || mission.companyId !== companyId) {
      throw new NotFoundException('Mission introuvable');
    }

    const candidatures = await this.prisma.candidature.findMany({
      where: { missionId },
      include: CANDIDATURE_INCLUDE_ENTREPRISE,
      orderBy: { createdAt: 'desc' },
    });
    return candidatures.map(toEntrepriseView);
  }

  private async workerId(userId: string): Promise<string> {
    const worker = await this.prisma.worker.findUnique({ where: { userId }, select: { id: true } });
    if (!worker) {
      throw new NotFoundException('Profil intérimaire introuvable');
    }
    return worker.id;
  }

  private async companyId(userId: string): Promise<string> {
    const company = await this.prisma.company.findUnique({
      where: { userId },
      select: { id: true },
    });
    if (!company) {
      throw new NotFoundException('Profil entreprise introuvable');
    }
    return company.id;
  }
}

function toView(candidature: CandidatureWithMission): CandidatureView {
  return {
    id: candidature.id,
    status: candidature.status,
    createdAt: candidature.createdAt,
    missionId: candidature.missionId,
    posteLabel: candidature.mission.poste.label,
    siteLabel: candidature.mission.siteLabel,
    companyName: candidature.mission.company.legalName,
    startDate: candidature.mission.startDate.toISOString().slice(0, 10),
    endDate: candidature.mission.endDate.toISOString().slice(0, 10),
  };
}

function toEntrepriseView(candidature: CandidatureWithWorker): CandidatureEntrepriseView {
  const competences = candidature.worker.skills.map((skill) => skill.competence);
  const { score, detail } = scoreCandidat(
    candidature.mission.competences.map((competence) => competence.competenceCode),
    new Set(competences.map((competence) => competence.code)),
    candidature.worker.postalCode,
    candidature.mission.postalCode,
  );

  return {
    ...toView(candidature),
    candidat: {
      workerId: candidature.worker.id,
      firstName: candidature.worker.firstName,
      lastName: candidature.worker.lastName,
      city: candidature.worker.city,
      postalCode: candidature.worker.postalCode,
      competences: [...competences].sort((a, b) => a.label.localeCompare(b.label, 'fr')),
      shifts: candidature.worker.shifts,
      score,
      detail,
      // Les habilitations expirées ne sont pas listées : les afficher laisserait croire que
      // le candidat est couvert. Même règle que le filtrage bloquant du matching.
      certifications: validCertificationTypes(candidature.worker.certifications).sort(),
      certificationsVerifiees: validCertificationTypes(
        candidature.worker.certifications.filter(
          (certification) => certification.verificationStatus === CertificationStatus.VERIFIE,
        ),
      ).sort(),
    },
  };
}
