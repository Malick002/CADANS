import { BadRequestException, ConflictException, NotFoundException } from '@nestjs/common';
import { CertificationStatus, CertificationType, Prisma } from '@prisma/client';
import { MatchingService } from '../matching/matching.service';
import { PrismaService } from '../prisma/prisma.service';
import { CandidaturesService } from './candidatures.service';

const now = new Date('2026-09-21T08:00:00Z');

const missionRow = {
  siteLabel: 'LogiNord - Roissy (95)',
  startDate: new Date('2026-09-18'),
  endDate: new Date('2026-09-22'),
  poste: { label: 'Cariste' },
  company: { legalName: 'LogiNord SAS' },
  // Ce que le score exige de la mission : deux compétences souhaitées et un code postal.
  // Même département que la candidate (95) : la zone vaut donc 40 points sur 40.
  postalCode: '95700',
  shift: 'MATIN',
  competences: [{ competenceCode: '400110' }, { competenceCode: '122623' }],
};

// Candidature telle que Prisma la rend à la requête de l'entreprise (include worker). Les
// habilitations arrivent brutes : c'est le service qui écarte les expirées.
function candidatureRow(
  worker: {
    certifications?: {
      type: CertificationType;
      expiresAt: Date | null;
      verificationStatus: CertificationStatus;
    }[];
  } = {},
) {
  return {
    id: 'candidature-1',
    status: 'ENVOYEE',
    createdAt: now,
    missionId: 'mission-1',
    workerId: 'worker-1',
    mission: missionRow,
    worker: {
      id: 'worker-1',
      firstName: 'Leïla',
      lastName: 'Amrani',
      city: 'Roissy-en-France',
      postalCode: '95700',
      // Une compétence sur les deux souhaitées : 30 points sur 60.
      skills: [{ competence: { code: '400110', label: 'Conduire un chariot élévateur' } }],
      shifts: ['MATIN', 'JOURNEE'],
      certifications: worker.certifications ?? [
        {
          type: CertificationType.CACES_R489_3,
          expiresAt: null,
          verificationStatus: CertificationStatus.VERIFIE,
        },
      ],
    },
  };
}

function uniqueViolation(): Prisma.PrismaClientKnownRequestError {
  return new Prisma.PrismaClientKnownRequestError('Unique constraint failed', {
    code: 'P2002',
    clientVersion: Prisma.prismaVersion.client,
    meta: { target: ['mission_id', 'worker_id'] },
  });
}

describe('CandidaturesService', () => {
  let prisma: {
    worker: { findUnique: jest.Mock };
    company: { findUnique: jest.Mock };
    mission: { findUnique: jest.Mock };
    candidature: { create: jest.Mock; findMany: jest.Mock };
  };
  let matching: { missingCertificationsFor: jest.Mock };
  let service: CandidaturesService;

  beforeEach(() => {
    prisma = {
      worker: { findUnique: jest.fn().mockResolvedValue({ id: 'worker-1' }) },
      company: { findUnique: jest.fn().mockResolvedValue({ id: 'company-1' }) },
      mission: {
        findUnique: jest.fn().mockResolvedValue({ companyId: 'company-1', status: 'OUVERTE' }),
      },
      candidature: { create: jest.fn(), findMany: jest.fn() },
    };
    matching = { missingCertificationsFor: jest.fn().mockResolvedValue([]) };
    prisma.candidature.create.mockImplementation(({ data }) =>
      Promise.resolve({
        id: 'candidature-1',
        status: 'ENVOYEE',
        createdAt: now,
        missionId: data.missionId,
        workerId: data.workerId,
        mission: missionRow,
      }),
    );
    service = new CandidaturesService(
      prisma as unknown as PrismaService,
      matching as unknown as MatchingService,
    );
  });

  describe('apply', () => {
    // Remplace le test « refuse le détail d'une mission pourvue (404) » de version-khadija :
    // la fiche reste lisible (une URL indexée ne doit pas disparaître), c'est la candidature
    // qui est refusée. Arbitrage du 21/09.
    it('refuse la candidature sur une mission qui n’est plus ouverte', async () => {
      prisma.mission.findUnique.mockResolvedValueOnce({
        companyId: 'company-1',
        status: 'POURVUE',
      });

      await expect(service.apply('user-1', 'mission-1')).rejects.toThrow(ConflictException);
      expect(prisma.candidature.create).not.toHaveBeenCalled();
    });

    it('refuse la candidature sur une mission introuvable', async () => {
      prisma.mission.findUnique.mockResolvedValueOnce(null);

      await expect(service.apply('user-1', 'inconnue')).rejects.toThrow(NotFoundException);
      expect(prisma.candidature.create).not.toHaveBeenCalled();
    });

    it('crée la candidature quand le profil couvre les habilitations exigées', async () => {
      const view = await service.apply('user-1', 'mission-1');

      expect(matching.missingCertificationsFor).toHaveBeenCalledWith('worker-1', 'mission-1');
      expect(prisma.candidature.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: { missionId: 'mission-1', workerId: 'worker-1' } }),
      );
      expect(view).toMatchObject({
        id: 'candidature-1',
        status: 'ENVOYEE',
        posteLabel: 'Cariste',
        companyName: 'LogiNord SAS',
      });
    });

    it('refuse si une habilitation exigée manque', async () => {
      matching.missingCertificationsFor.mockResolvedValueOnce([CertificationType.CACES_R489_3]);

      await expect(service.apply('user-1', 'mission-1')).rejects.toThrow(BadRequestException);
      expect(prisma.candidature.create).not.toHaveBeenCalled();
    });

    it('refuse une seconde candidature à la même mission', async () => {
      prisma.candidature.create.mockRejectedValueOnce(uniqueViolation());

      await expect(service.apply('user-1', 'mission-1')).rejects.toThrow(ConflictException);
    });

    it('refuse un compte sans profil intérimaire', async () => {
      prisma.worker.findUnique.mockResolvedValueOnce(null);

      await expect(service.apply('user-1', 'mission-1')).rejects.toThrow(NotFoundException);
      expect(prisma.candidature.create).not.toHaveBeenCalled();
    });
  });

  describe('findAllForMission', () => {
    it("liste les candidatures d'une mission qui appartient à l'entreprise connectée", async () => {
      prisma.candidature.findMany.mockResolvedValue([]);

      await service.findAllForMission('user-1', 'mission-1');

      expect(prisma.candidature.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { missionId: 'mission-1' } }),
      );
    });

    it("refuse (404) l'accès à une mission d'une autre entreprise", async () => {
      prisma.mission.findUnique.mockResolvedValueOnce({ companyId: 'company-autre' });

      await expect(service.findAllForMission('user-1', 'mission-1')).rejects.toThrow(
        NotFoundException,
      );
      expect(prisma.candidature.findMany).not.toHaveBeenCalled();
    });

    it("expose l'identité, la zone et les habilitations valides du candidat", async () => {
      prisma.candidature.findMany.mockResolvedValue([candidatureRow()]);

      const [vue] = await service.findAllForMission('user-1', 'mission-1');

      expect(vue.candidat).toEqual({
        // Identifiant du profil, sans lequel l'entreprise ne pouvait RIEN faire du candidat.
        workerId: 'worker-1',
        firstName: 'Leïla',
        lastName: 'Amrani',
        city: 'Roissy-en-France',
        postalCode: '95700',
        competences: [{ code: '400110', label: 'Conduire un chariot élévateur' }],
        shifts: ['MATIN', 'JOURNEE'],
        // Une compétence sur deux (30/60) + même département (40/40) = 70.
        score: 70,
        detail: {
          competences: { points: 30, max: 60 },
          zone: { points: 40, max: 40 },
        },
        certifications: [CertificationType.CACES_R489_3],
        certificationsVerifiees: [CertificationType.CACES_R489_3],
      });
      // Le reste de la vue ne change pas : l'écran entreprise affichait déjà mission et date.
      expect(vue).toMatchObject({ posteLabel: 'Cariste', status: 'ENVOYEE' });
    });

    // Une habilitation périmée ne couvre plus rien : l'afficher ferait croire à l'entreprise
    // que le candidat est en règle. Même règle que le filtrage bloquant du matching.
    it('écarte une habilitation expirée du bloc candidat', async () => {
      prisma.candidature.findMany.mockResolvedValue([
        candidatureRow({
          certifications: [
            {
              type: CertificationType.CACES_R489_3,
              expiresAt: new Date('2020-01-01'),
              verificationStatus: CertificationStatus.VERIFIE,
            },
            {
              type: CertificationType.CACES_R489_5,
              expiresAt: null,
              verificationStatus: CertificationStatus.EN_ATTENTE,
            },
          ],
        }),
      ]);

      const [vue] = await service.findAllForMission('user-1', 'mission-1');

      expect(vue.candidat.certifications).toEqual([CertificationType.CACES_R489_5]);
    });

    // Minimisation (RGPD) : ces champs existent en base et sont volontairement hors de la vue.
    // Le test est là pour qu'un `select` élargi par inadvertance fasse rougir la CI.
    it('ne divulgue ni email ni téléphone ni pièce d’identité', async () => {
      prisma.candidature.findMany.mockResolvedValue([candidatureRow()]);

      const [vue] = await service.findAllForMission('user-1', 'mission-1');

      const serialise = JSON.stringify(vue);
      expect(serialise).not.toContain('@');
      expect(serialise).not.toContain('0612345678');
      expect(Object.keys(vue.candidat).sort()).toEqual([
        'certifications',
        'certificationsVerifiees',
        'city',
        'competences',
        'detail',
        'firstName',
        'lastName',
        'postalCode',
        'score',
        'shifts',
        'workerId',
      ]);
    });

    // Vérifié = un agent CADANS a examiné le justificatif. C'est un sous-ensemble des
    // habilitations valides : ici la R489-5 est valide mais encore en attente d'examen.
    it('distingue les habilitations vérifiées des habilitations seulement déclarées', async () => {
      prisma.candidature.findMany.mockResolvedValue([
        candidatureRow({
          certifications: [
            {
              type: CertificationType.CACES_R489_3,
              expiresAt: null,
              verificationStatus: CertificationStatus.VERIFIE,
            },
            {
              type: CertificationType.CACES_R489_5,
              expiresAt: null,
              verificationStatus: CertificationStatus.EN_ATTENTE,
            },
          ],
        }),
      ]);

      const [vue] = await service.findAllForMission('user-1', 'mission-1');

      expect(vue.candidat.certifications).toEqual([
        CertificationType.CACES_R489_3,
        CertificationType.CACES_R489_5,
      ]);
      expect(vue.candidat.certificationsVerifiees).toEqual([CertificationType.CACES_R489_3]);
    });

    it("charge l'intérimaire, ce que la vue de l'intérimaire ne fait pas", async () => {
      prisma.candidature.findMany.mockResolvedValue([]);

      await service.findAllForMission('user-1', 'mission-1');
      const includeEntreprise = prisma.candidature.findMany.mock.calls[0][0].include;

      await service.findAllForWorker('user-1');
      const includeWorker = prisma.candidature.findMany.mock.calls[1][0].include;

      expect(includeEntreprise.worker).toBeDefined();
      expect(includeWorker.worker).toBeUndefined();
    });
  });
});
