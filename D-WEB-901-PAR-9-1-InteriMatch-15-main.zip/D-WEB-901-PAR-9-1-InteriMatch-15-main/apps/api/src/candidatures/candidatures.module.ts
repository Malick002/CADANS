import { Module } from '@nestjs/common';
import { MatchingModule } from '../matching/matching.module';
import { CandidaturesController } from './candidatures.controller';
import { CandidaturesService } from './candidatures.service';

@Module({
  imports: [MatchingModule],
  controllers: [CandidaturesController],
  providers: [CandidaturesService],
})
export class CandidaturesModule {}
