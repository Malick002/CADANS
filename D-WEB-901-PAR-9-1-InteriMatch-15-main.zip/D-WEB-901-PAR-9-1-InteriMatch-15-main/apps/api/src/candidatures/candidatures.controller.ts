import { Controller, Get, HttpCode, HttpStatus, Param, Post } from '@nestjs/common';
import { Role } from '@prisma/client';
import { CurrentUser, Roles } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import {
  CandidatureEntrepriseView,
  CandidaturesService,
  CandidatureView,
} from './candidatures.service';

// Chemins rattachés à /missions et /workers/me plutôt qu'un préfixe dédié : la ressource est
// toujours consultée depuis son point de vue naturel (une mission, ou le compte connecté).
@Controller()
export class CandidaturesController {
  constructor(private readonly candidatures: CandidaturesService) {}

  @Roles(Role.WORKER)
  @Post('missions/:missionId/candidatures')
  @HttpCode(HttpStatus.CREATED)
  apply(
    @CurrentUser() user: SessionUser,
    @Param('missionId') missionId: string,
  ): Promise<CandidatureView> {
    return this.candidatures.apply(user.id, missionId);
  }

  @Roles(Role.WORKER)
  @Get('workers/me/candidatures')
  mine(@CurrentUser() user: SessionUser): Promise<CandidatureView[]> {
    return this.candidatures.findAllForWorker(user.id);
  }

  @Roles(Role.COMPANY)
  @Get('missions/:missionId/candidatures')
  forMission(
    @CurrentUser() user: SessionUser,
    @Param('missionId') missionId: string,
  ): Promise<CandidatureEntrepriseView[]> {
    return this.candidatures.findAllForMission(user.id, missionId);
  }
}
