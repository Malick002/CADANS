import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { Db, MongoClient } from 'mongodb';

/**
 * Connexion à MongoDB, qui porte le non transactionnel : logs de matching,
 * cache des offres France Travail, recherche full-text.
 *
 * Le relationnel et le contractuel (comptes, profils, habilitations, missions,
 * contrats) restent sur PostgreSQL via Prisma — voir PrismaService.
 */
@Injectable()
export class MongoService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(MongoService.name);
  private client: MongoClient | null = null;
  private database: Db | null = null;

  async onModuleInit(): Promise<void> {
    const url = process.env.MONGO_URL;

    if (!url) {
      this.logger.error('MONGO_URL absente du .env. Copie .env.example en .env.');
      return;
    }

    // Comme pour PostgreSQL, l'absence de base ne doit pas empêcher l'API de
    // démarrer : l'état réel est exposé par GET /health.
    try {
      const client = new MongoClient(url, {
        serverSelectionTimeoutMS: 3000,
        connectTimeoutMS: 3000,
      });
      await client.connect();

      this.client = client;
      this.database = client.db(process.env.MONGO_DB ?? 'cadans');
      this.logger.log('Connexion MongoDB établie');
    } catch (error) {
      this.logger.error(
        `Connexion MongoDB impossible : ${error instanceof Error ? error.message : String(error)}. ` +
          'Lance les bases avec `npm run db:up`.',
      );
    }
  }

  async onModuleDestroy(): Promise<void> {
    await this.client?.close();
    this.client = null;
    this.database = null;
  }

  /** Accès à la base. Lève si la connexion n'a pas pu être établie. */
  getDb(): Db {
    if (!this.database) {
      throw new Error('MongoDB non connecté. Vérifie MONGO_URL et `npm run db:up`.');
    }
    return this.database;
  }

  async ping(): Promise<boolean> {
    if (!this.database) {
      return false;
    }
    try {
      await this.database.command({ ping: 1 });
      return true;
    } catch {
      return false;
    }
  }
}
