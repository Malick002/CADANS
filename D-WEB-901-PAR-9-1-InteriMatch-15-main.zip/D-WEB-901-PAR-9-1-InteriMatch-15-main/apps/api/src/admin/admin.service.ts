import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { CertificationStatus, CertificationType } from '@prisma/client';
import { EncryptionService } from '../encryption/encryption.service';
import { certificationValide } from '../matching/matching.service';
import { PrismaService } from '../prisma/prisma.service';
import { DOCUMENT_EXTENSIONS, DocumentMimeType } from '../sensitive-documents/file-type';
import { DecryptedFile } from '../sensitive-documents/sensitive-documents.service';

/**
 * Un justificatif d'habilitation à examiner, vu par un agent CADANS.
 *
 * L'agent a besoin de savoir **de qui** vient le document — c'est une vérification d'identité
 * professionnelle, elle ne peut pas être anonyme. Il n'a en revanche aucun besoin de l'adresse
 * ni du téléphone de l'intérimaire : ils ne sont pas ici.
 */
export interface JustificatifView {
  certificationId: string;
  workerId: string;
  type: CertificationType;
  expiresAt: string | null;
  verificationStatus: CertificationStatus;
  refusalMotif: string | null;
  deposeLe: Date;
  interimaire: { prenom: string; nom: string; ville: string };
  // Faux quand l'intérimaire a retiré sa pièce APRÈS une décision. L'habilitation garde son
  // statut — la décision a bien été prise — mais il n'y a plus rien à rouvrir. Sans ce
  // drapeau, elle disparaissait purement et simplement de l'écran agent.
  documentPresent: boolean;
  // Décisions successives, de la plus récente à la plus ancienne. Vide tant qu'aucun agent
  // n'a tranché, et pour les décisions antérieures à la traçabilité.
  decisions: DecisionView[];
}

export interface DecisionView {
  decision: CertificationStatus;
  motif: string | null;
  decidedAt: Date;
  // Nul si le compte de l'agent a été supprimé depuis : on perd l'auteur, jamais la décision.
  agent: string | null;
}

// Filtres de l'écran agent. `EXPIREES` et `TOUS` ne sont pas des statuts de vérification :
// une habilitation expirée peut être VERIFIE, EN_ATTENTE ou refusée. Le type les distingue
// pour que le service ne puisse pas les confondre avec un `CertificationStatus`.
export type FiltreJustificatifs = CertificationStatus | 'EXPIREES' | 'TOUS';

// Même contexte de chiffrement que SensitiveDocumentsService : le chiffré est lié à son
// intérimaire et à son usage, pas au rôle de celui qui le lit.
const documentContext = (workerId: string, type: CertificationType): string =>
  `certification-document:${workerId}:${type}`;

@Injectable()
export class AdminService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
  ) {}

  /**
   * File d'attente de vérification. Par défaut les justificatifs `EN_ATTENTE`, du plus ancien
   * au plus récent : une file se traite dans l'ordre d'arrivée, pas dans l'ordre inverse.
   */
  async listJustificatifs(filtre: FiltreJustificatifs = CertificationStatus.EN_ATTENTE) {
    const certifications = await this.prisma.certification.findMany({
      where: filtreWhere(filtre),
      orderBy: { updatedAt: 'asc' },
      include: {
        worker: { select: { id: true, firstName: true, lastName: true, city: true } },
        // Historique complet, du plus récent au plus ancien : c'est l'ordre dans lequel
        // l'agent veut lire « ce qui s'est passé », pas l'ordre chronologique d'un journal.
        //
        // `decidedAt` est à la milliseconde (TIMESTAMPTZ(3)). Deux décisions dans la même
        // milliseconde ne seraient pas départagées — il faudrait deux appels HTTP dans cet
        // intervalle, ce qui ne se produit pas en pratique. À revoir seulement le jour où
        // des décisions seraient posées par lot.
        decisions: {
          orderBy: { decidedAt: 'desc' },
          include: { agent: { select: { email: true } } },
        },
      },
    });

    const vues = certifications.map(toJustificatifView);
    // Le filtre « expirées » se calcule en JavaScript et non en SQL : la règle de validité
    // vit dans `certificationValide` (heure de Paris, changement d'heure compris), et la
    // réécrire en SQL créerait une deuxième définition qui dériverait de la première.
    return filtre === 'EXPIREES' ? vues.filter((vue) => estExpiree(vue.expiresAt)) : vues;
  }

  /**
   * Document déchiffré, servi en flux à l'agent.
   *
   * Il n'existe **aucune URL publique** vers ce fichier : il n'est écrit nulle part sur
   * disque, il n'a pas de nom devinable, et cette route est derrière `@Roles(ADMIN)`. Le
   * déchiffrement a lieu à la volée, pour cette requête, et le résultat n'est pas mis en
   * cache.
   */
  async readJustificatif(certificationId: string): Promise<DecryptedFile> {
    const certification = await this.prisma.certification.findUnique({
      where: { id: certificationId },
    });

    if (!certification?.documentEncrypted || !certification.documentMimeType) {
      throw new NotFoundException('Aucun justificatif pour cette habilitation');
    }

    return {
      content: this.encryption.decrypt(
        certification.documentEncrypted,
        documentContext(certification.workerId, certification.type),
      ),
      mimeType: certification.documentMimeType,
      filename: `${certification.type.toLowerCase()}.${extensionFor(certification.documentMimeType)}`,
    };
  }

  async valider(certificationId: string, agentUserId: string): Promise<JustificatifView> {
    return this.decider(certificationId, agentUserId, CertificationStatus.VERIFIE, null);
  }

  async refuser(
    certificationId: string,
    agentUserId: string,
    motif: string,
  ): Promise<JustificatifView> {
    // Le DTO impose déjà un motif non vide ; cette garde protège les appels internes.
    if (!motif.trim()) {
      throw new BadRequestException('Un refus doit être motivé');
    }
    return this.decider(certificationId, agentUserId, CertificationStatus.REFUSE, motif.trim());
  }

  private async decider(
    certificationId: string,
    agentUserId: string,
    statut: CertificationStatus,
    motif: string | null,
  ): Promise<JustificatifView> {
    const certification = await this.prisma.certification.findUnique({
      where: { id: certificationId },
      // `type` et `workerId` sont recopiés dans la ligne d'historique : c'est ce qui la rend
      // relisible seule le jour où l'habilitation aura été supprimée.
      select: { id: true, documentEncrypted: true, type: true, workerId: true },
    });
    if (!certification) {
      throw new NotFoundException('Habilitation introuvable');
    }
    // Trancher sur une habilitation sans justificatif n'a pas de sens : l'agent validerait
    // une déclaration, pas une pièce.
    if (!certification.documentEncrypted) {
      throw new BadRequestException(
        'Cette habilitation n’a pas de justificatif : il n’y a rien à vérifier',
      );
    }

    // La décision courante et son historique dans la MÊME transaction : une ligne d'historique
    // sans la décision qu'elle relate, ou l'inverse, serait pire que pas d'historique du tout.
    //
    // `verifiedAt` et `verifiedByUserId` restent écrits : ils portent la décision courante,
    // que tout le reste du code lit déjà. L'historique les complète, il ne les remplace pas.
    const [, misAJour] = await this.prisma.$transaction([
      this.prisma.certificationDecision.create({
        data: {
          certificationId,
          decision: statut,
          motif,
          agentUserId,
          // Figés au moment de la décision : ils ne suivent pas l'original, et survivent à
          // sa disparition.
          certificationType: certification.type,
          workerId: certification.workerId,
        },
      }),
      this.prisma.certification.update({
        where: { id: certificationId },
        data: {
          verificationStatus: statut,
          refusalMotif: motif,
          verifiedAt: new Date(),
          verifiedByUserId: agentUserId,
        },
        include: {
          worker: { select: { id: true, firstName: true, lastName: true, city: true } },
          decisions: {
            orderBy: { decidedAt: 'desc' },
            include: { agent: { select: { email: true } } },
          },
        },
      }),
    ]);

    return toJustificatifView(misAJour);
  }
}

/**
 * Clause `where` de chaque filtre.
 *
 * `documentEncrypted: { not: null }` n'est PAS appliqué partout, et c'est le changement de
 * fond : une habilitation déjà tranchée dont l'intérimaire a retiré la pièce disparaissait de
 * tous les écrans tout en restant VERIFIE. Elle reste visible sous « Tous », avec la mention
 * « document supprimé ». La file d'attente, elle, garde le filtre : sans pièce, il n'y a rien
 * à examiner et elle n'a pas à encombrer le travail du jour.
 */
function filtreWhere(filtre: FiltreJustificatifs) {
  if (filtre === 'TOUS') {
    return {};
  }
  if (filtre === 'EXPIREES') {
    // Le tri sur la date se fait après lecture (voir listJustificatifs) : seule contrainte
    // ici, avoir une date à comparer.
    return { expiresAt: { not: null } };
  }
  if (filtre === CertificationStatus.EN_ATTENTE) {
    return { verificationStatus: filtre, documentEncrypted: { not: null } };
  }
  return { verificationStatus: filtre };
}

// Miroir de `estExpiree` côté site, mais sur la vue déjà sérialisée (« AAAA-MM-JJ »). Elle
// délègue à `certificationValide`, la règle unique côté API.
function estExpiree(expiresAt: string | null): boolean {
  return expiresAt !== null && !certificationValide(new Date(`${expiresAt}T00:00:00Z`));
}

// Forme commune aux deux chemins : la file d'attente et la décision rendent la même vue.
function toJustificatifView(certification: {
  id: string;
  workerId: string;
  type: CertificationType;
  expiresAt: Date | null;
  verificationStatus: CertificationStatus;
  refusalMotif: string | null;
  documentEncrypted: Uint8Array | null;
  updatedAt: Date;
  worker: { firstName: string; lastName: string; city: string };
  decisions: {
    decision: CertificationStatus;
    motif: string | null;
    decidedAt: Date;
    agent: { email: string } | null;
  }[];
}): JustificatifView {
  return {
    certificationId: certification.id,
    workerId: certification.workerId,
    type: certification.type,
    expiresAt: certification.expiresAt?.toISOString().slice(0, 10) ?? null,
    verificationStatus: certification.verificationStatus,
    refusalMotif: certification.refusalMotif,
    deposeLe: certification.updatedAt,
    interimaire: {
      prenom: certification.worker.firstName,
      nom: certification.worker.lastName,
      ville: certification.worker.city,
    },
    documentPresent: certification.documentEncrypted !== null,
    decisions: certification.decisions.map((decision) => ({
      decision: decision.decision,
      motif: decision.motif,
      decidedAt: decision.decidedAt,
      // L'email de l'agent, pas son identifiant : c'est ce qui permet de savoir à qui parler.
      // Les agents sont des collègues, pas des utilisateurs dont il faudrait protéger
      // l'identité vis-à-vis d'un autre agent.
      agent: decision.agent?.email ?? null,
    })),
  };
}

function extensionFor(mimeType: string): string {
  return DOCUMENT_EXTENSIONS[mimeType as DocumentMimeType] ?? 'bin';
}
