import { Injectable, NotFoundException } from '@nestjs/common';
import { CertificationStatus, CertificationType, MissionStatus, Shift } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Annuaire des comptes, vu par un agent CADANS : de quoi identifier une personne ou une
 * société et ouvrir sa fiche. Les résumés de liste et les fiches détaillées sont deux formes
 * distinctes, comme `JustificatifResume`/`JustificatifView` dans le tableau de bord — la liste
 * n'a pas besoin de tout ce que la fiche affiche.
 *
 * Ni l'un ni l'autre ne renvoie de donnée chiffrée (pièce d'identité, NIR, IBAN) : ce n'est
 * pas ce qu'un annuaire sert à consulter, et aucun déchiffrement n'a été demandé pour cet
 * écran.
 */
export interface InterimaireResume {
  id: string;
  prenom: string;
  nom: string;
  ville: string;
  codePostal: string;
  inscritLe: Date;
}

export interface InterimaireDetail extends InterimaireResume {
  email: string;
  telephone: string | null;
  disponibleDu: string | null;
  disponibleAu: string | null;
  creneaux: Shift[];
  competences: { code: string; label: string }[];
  habilitations: {
    type: CertificationType;
    expiresAt: string | null;
    verificationStatus: CertificationStatus;
  }[];
}

export interface EntrepriseResume {
  id: string;
  raisonSociale: string;
  siret: string;
  ville: string;
  inscritLe: Date;
}

export interface EntrepriseDetail extends EntrepriseResume {
  email: string;
  codeNaf: string;
  contactPrenom: string;
  contactNom: string;
  telephone: string | null;
  adresse: string;
  codePostal: string;
  missions: {
    id: string;
    posteLabel: string;
    status: MissionStatus;
    startDate: string;
    endDate: string;
  }[];
}

@Injectable()
export class AdminAnnuaireService {
  constructor(private readonly prisma: PrismaService) {}

  // Ordre alphabétique (nom puis prénom) : un annuaire se parcourt par nom, pas par date
  // d'inscription.
  async listInterimaires(): Promise<InterimaireResume[]> {
    const workers = await this.prisma.worker.findMany({
      orderBy: [{ lastName: 'asc' }, { firstName: 'asc' }],
      select: {
        id: true,
        firstName: true,
        lastName: true,
        city: true,
        postalCode: true,
        createdAt: true,
      },
    });

    return workers.map((worker) => ({
      id: worker.id,
      prenom: worker.firstName,
      nom: worker.lastName,
      ville: worker.city,
      codePostal: worker.postalCode,
      inscritLe: worker.createdAt,
    }));
  }

  async getInterimaire(workerId: string): Promise<InterimaireDetail> {
    const worker = await this.prisma.worker.findUnique({
      where: { id: workerId },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        city: true,
        postalCode: true,
        phone: true,
        createdAt: true,
        availableFrom: true,
        availableUntil: true,
        shifts: true,
        user: { select: { email: true } },
        skills: { select: { competence: { select: { code: true, label: true } } } },
        certifications: {
          select: { type: true, expiresAt: true, verificationStatus: true },
          orderBy: { type: 'asc' },
        },
      },
    });

    if (!worker) {
      throw new NotFoundException('Intérimaire introuvable');
    }

    return {
      id: worker.id,
      prenom: worker.firstName,
      nom: worker.lastName,
      email: worker.user.email,
      telephone: worker.phone,
      ville: worker.city,
      codePostal: worker.postalCode,
      inscritLe: worker.createdAt,
      disponibleDu: worker.availableFrom?.toISOString().slice(0, 10) ?? null,
      disponibleAu: worker.availableUntil?.toISOString().slice(0, 10) ?? null,
      creneaux: worker.shifts,
      competences: worker.skills.map((skill) => skill.competence),
      habilitations: worker.certifications.map((certification) => ({
        type: certification.type,
        expiresAt: certification.expiresAt?.toISOString().slice(0, 10) ?? null,
        verificationStatus: certification.verificationStatus,
      })),
    };
  }

  async listEntreprises(): Promise<EntrepriseResume[]> {
    const companies = await this.prisma.company.findMany({
      orderBy: { legalName: 'asc' },
      select: { id: true, legalName: true, siret: true, city: true, createdAt: true },
    });

    return companies.map((company) => ({
      id: company.id,
      raisonSociale: company.legalName,
      siret: company.siret,
      ville: company.city,
      inscritLe: company.createdAt,
    }));
  }

  async getEntreprise(companyId: string): Promise<EntrepriseDetail> {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      select: {
        id: true,
        legalName: true,
        siret: true,
        nafCode: true,
        contactFirstName: true,
        contactLastName: true,
        phone: true,
        addressLine: true,
        postalCode: true,
        city: true,
        createdAt: true,
        user: { select: { email: true } },
        // Les plus récentes d'abord : c'est l'activité qui intéresse un agent qui ouvre la
        // fiche, pas l'historique complet depuis l'inscription.
        missions: {
          select: {
            id: true,
            status: true,
            startDate: true,
            endDate: true,
            poste: { select: { label: true } },
          },
          orderBy: { startDate: 'desc' },
        },
      },
    });

    if (!company) {
      throw new NotFoundException('Entreprise introuvable');
    }

    return {
      id: company.id,
      raisonSociale: company.legalName,
      siret: company.siret,
      codeNaf: company.nafCode,
      contactPrenom: company.contactFirstName,
      contactNom: company.contactLastName,
      email: company.user.email,
      telephone: company.phone,
      adresse: company.addressLine,
      codePostal: company.postalCode,
      ville: company.city,
      inscritLe: company.createdAt,
      missions: company.missions.map((mission) => ({
        id: mission.id,
        posteLabel: mission.poste.label,
        status: mission.status,
        startDate: mission.startDate.toISOString().slice(0, 10),
        endDate: mission.endDate.toISOString().slice(0, 10),
      })),
    };
  }
}
