import {
  Body,
  Controller,
  Get,
  Header,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
  StreamableFile,
} from '@nestjs/common';
import { CertificationStatus, MissionStatus, Role } from '@prisma/client';
import { CurrentUser, Roles } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import {
  AdminAnnuaireService,
  EntrepriseDetail,
  EntrepriseResume,
  InterimaireDetail,
  InterimaireResume,
} from './admin-annuaire.service';
import {
  AdminContratsService,
  ContratDetail,
  ContratResume,
  FiltreContrats,
} from './admin-contrats.service';
import { AdminDashboardService, TableauDeBordView } from './admin-dashboard.service';
import {
  AdminMissionsService,
  FiltreMissions,
  MissionDetail,
  MissionResume,
} from './admin-missions.service';
import { AdminService, FiltreJustificatifs, JustificatifView } from './admin.service';
import { RefuserJustificatifDto } from './dto/refuser-justificatif.dto';

/**
 * Espace des agents CADANS.
 *
 * `@Roles(Role.ADMIN)` est posé **sur la classe** : toute route ajoutée ici est protégée par
 * construction, sans qu'on ait à y penser. C'est l'inverse du choix fait sur
 * `MissionsController`, où chaque méthode porte son rôle parce que certaines sont publiques
 * — ici, aucune ne l'est et aucune ne le sera.
 *
 * Un intérimaire ou une entreprise qui atteint une de ces routes reçoit **403**, pas 404 :
 * l'existence de l'espace d'administration n'est pas un secret, seul son contenu l'est.
 */
@Roles(Role.ADMIN)
@Controller('admin')
export class AdminController {
  constructor(
    private readonly admin: AdminService,
    private readonly dashboard: AdminDashboardService,
    private readonly annuaire: AdminAnnuaireService,
    private readonly missions: AdminMissionsService,
    private readonly contrats: AdminContratsService,
  ) {}

  // Agrégats de l'espace agent. Protégée par le @Roles(ADMIN) porté par la classe : une
  // entreprise ou un intérimaire reçoit 403, comme sur toutes les routes de ce contrôleur.
  @Get('tableau-de-bord')
  tableauDeBord(): Promise<TableauDeBordView> {
    return this.dashboard.tableauDeBord();
  }

  /**
   * `?statut=` accepte les quatre statuts de vérification, plus `EXPIREES` et `TOUS` — qui
   * n'en sont pas : une habilitation expirée peut être vérifiée, en attente ou refusée.
   *
   * Valeur inconnue ignorée plutôt que rejetée : la file d'attente par défaut vaut mieux
   * qu'une erreur pour un paramètre d'affichage.
   */
  @Get('justificatifs')
  listJustificatifs(@Query('statut') statut?: string): Promise<JustificatifView[]> {
    return this.admin.listJustificatifs(filtreValide(statut));
  }

  /**
   * Document déchiffré à la volée. `no-store` interdit au navigateur comme aux
   * intermédiaires d'en garder une copie, `nosniff` empêche de le réinterpréter comme du
   * HTML. Il n'existe aucune URL publique vers ce fichier.
   */
  @Get('justificatifs/:id/document')
  @Header('Cache-Control', 'no-store')
  @Header('X-Content-Type-Options', 'nosniff')
  async lireJustificatif(
    @Param('id', ParseUUIDPipe) certificationId: string,
  ): Promise<StreamableFile> {
    const file = await this.admin.readJustificatif(certificationId);
    return new StreamableFile(file.content, {
      type: file.mimeType,
      disposition: `inline; filename="${file.filename}"`,
      length: file.content.length,
    });
  }

  @Post('justificatifs/:id/valider')
  valider(
    @CurrentUser() user: SessionUser,
    @Param('id', ParseUUIDPipe) certificationId: string,
  ): Promise<JustificatifView> {
    return this.admin.valider(certificationId, user.id);
  }

  @Post('justificatifs/:id/refuser')
  refuser(
    @CurrentUser() user: SessionUser,
    @Param('id', ParseUUIDPipe) certificationId: string,
    @Body() dto: RefuserJustificatifDto,
  ): Promise<JustificatifView> {
    return this.admin.refuser(certificationId, user.id, dto.motif);
  }

  // Annuaire des comptes. Deux ressources symétriques, comme les modèles Worker/Company
  // eux-mêmes : une liste triée pour identifier une fiche, une fiche détaillée derrière.
  @Get('interimaires')
  listInterimaires(): Promise<InterimaireResume[]> {
    return this.annuaire.listInterimaires();
  }

  @Get('interimaires/:id')
  getInterimaire(@Param('id', ParseUUIDPipe) id: string): Promise<InterimaireDetail> {
    return this.annuaire.getInterimaire(id);
  }

  @Get('entreprises')
  listEntreprises(): Promise<EntrepriseResume[]> {
    return this.annuaire.listEntreprises();
  }

  @Get('entreprises/:id')
  getEntreprise(@Param('id', ParseUUIDPipe) id: string): Promise<EntrepriseDetail> {
    return this.annuaire.getEntreprise(id);
  }

  /**
   * Missions toutes entreprises confondues. `?statut=` accepte un statut de mission ou
   * `TOUTES` ; une valeur inconnue retombe sur `TOUTES` plutôt que d'être rejetée, comme les
   * filtres des justificatifs.
   */
  @Get('missions')
  listMissions(@Query('statut') statut?: string): Promise<MissionResume[]> {
    return this.missions.listMissions(filtreMissionValide(statut));
  }

  @Get('missions/:id')
  getMission(@Param('id', ParseUUIDPipe) id: string): Promise<MissionDetail> {
    return this.missions.getMission(id);
  }

  /**
   * Contrats toutes missions confondues. `?statut=A_SIGNER` (défaut) ou `TOUS` ; une valeur
   * inconnue retombe sur la file d'attente.
   */
  @Get('contrats')
  listContrats(@Query('statut') statut?: string): Promise<ContratResume[]> {
    return this.contrats.listContrats(filtreContratValide(statut));
  }

  @Get('contrats/:id')
  getContrat(@Param('id', ParseUUIDPipe) id: string): Promise<ContratDetail> {
    return this.contrats.getContrat(id);
  }
}

// Liste blanche explicite : ce qui n'y figure pas retombe sur la file d'attente.
const FILTRES: readonly FiltreJustificatifs[] = [
  ...Object.values(CertificationStatus),
  'EXPIREES',
  'TOUS',
];

function filtreValide(valeur?: string): FiltreJustificatifs | undefined {
  return FILTRES.find((filtre) => filtre === valeur);
}

const FILTRES_MISSIONS: readonly FiltreMissions[] = [...Object.values(MissionStatus), 'TOUTES'];

function filtreMissionValide(valeur?: string): FiltreMissions {
  return FILTRES_MISSIONS.find((filtre) => filtre === valeur) ?? 'TOUTES';
}

const FILTRES_CONTRATS: readonly FiltreContrats[] = ['A_SIGNER', 'TOUS'];

function filtreContratValide(valeur?: string): FiltreContrats {
  return FILTRES_CONTRATS.find((filtre) => filtre === valeur) ?? 'A_SIGNER';
}
