import { Injectable } from '@nestjs/common';
import { CertificationStatus, CertificationType, MissionStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Une ligne de la file d'attente, réduite à ce qu'un tableau de bord montre.
 *
 * Volontairement PLUS PAUVRE que `JustificatifView` : pas de ville, pas de statut de
 * vérification (elles sont toutes `EN_ATTENTE` ici), pas de motif de refus. L'agent a besoin
 * de savoir quel document, de qui, et depuis quand — c'est tout ce qu'il faut pour décider
 * d'ouvrir la fiche. Le reste est sur l'écran des justificatifs, qui est fait pour ça.
 */
export interface JustificatifResume {
  certificationId: string;
  type: CertificationType;
  deposeLe: Date;
  interimaire: { prenom: string; nom: string };
}

// Que des nombres : aucune donnée personnelle ne transite par ces six champs.
export interface CompteursAdmin {
  justificatifsEnAttente: number;
  missionsOuvertes: number;
  missionsPourvues: number;
  contratsASigner: number;
  interimaires: number;
  entreprises: number;
}

export interface TableauDeBordView {
  compteurs: CompteursAdmin;
  derniersJustificatifs: JustificatifResume[];
}

// Cinq lignes : de quoi voir ce qui arrive sans refaire la page des justificatifs, qui reste
// la seule vue complète de la file.
export const DERNIERS_JUSTIFICATIFS = 5;

/**
 * Agrégats de l'espace agent. Service à part d'`AdminService` : celui-ci porte la
 * VÉRIFICATION des justificatifs (déchiffrement, validation, refus), une responsabilité à
 * laquelle un tableau de bord n'a pas à toucher.
 */
@Injectable()
export class AdminDashboardService {
  constructor(private readonly prisma: PrismaService) {}

  async tableauDeBord(): Promise<TableauDeBordView> {
    const [
      justificatifsEnAttente,
      missionsOuvertes,
      missionsPourvues,
      contratsASigner,
      interimaires,
      entreprises,
      derniers,
    ] = await Promise.all([
      // Même filtre que la file d'attente : un justificatif sans document n'est pas
      // examinable, il ne doit donc pas gonfler le compteur que l'agent vient réduire.
      this.prisma.certification.count({
        where: {
          verificationStatus: CertificationStatus.EN_ATTENTE,
          documentEncrypted: { not: null },
        },
      }),
      this.prisma.mission.count({ where: { status: MissionStatus.OUVERTE } }),
      this.prisma.mission.count({ where: { status: MissionStatus.POURVUE } }),
      // « En attente de signature » = pas encore complet. `completedAt` n'est posé qu'une
      // fois les DEUX parties signataires passées et le PDF final produit (schema.prisma) :
      // c'est le seul champ qui dise l'état du contrat sans recompter ses signatures.
      this.prisma.contract.count({ where: { completedAt: null } }),
      this.prisma.worker.count(),
      this.prisma.company.count(),
      this.prisma.certification.findMany({
        where: {
          verificationStatus: CertificationStatus.EN_ATTENTE,
          documentEncrypted: { not: null },
        },
        // Les plus RÉCENTS, contrairement à la file d'attente qui se traite du plus ancien
        // au plus récent : un tableau de bord dit ce qui vient d'arriver.
        orderBy: { updatedAt: 'desc' },
        take: DERNIERS_JUSTIFICATIFS,
        select: {
          id: true,
          type: true,
          updatedAt: true,
          worker: { select: { firstName: true, lastName: true } },
        },
      }),
    ]);

    return {
      compteurs: {
        justificatifsEnAttente,
        missionsOuvertes,
        missionsPourvues,
        contratsASigner,
        interimaires,
        entreprises,
      },
      derniersJustificatifs: derniers.map((certification) => ({
        certificationId: certification.id,
        type: certification.type,
        deposeLe: certification.updatedAt,
        interimaire: {
          prenom: certification.worker.firstName,
          nom: certification.worker.lastName,
        },
      })),
    };
  }
}
