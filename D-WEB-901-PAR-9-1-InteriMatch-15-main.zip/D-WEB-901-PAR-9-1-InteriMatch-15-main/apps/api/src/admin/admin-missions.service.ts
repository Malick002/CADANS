import { Injectable, NotFoundException } from '@nestjs/common';
import { MissionStatus, Shift } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Missions vues par un agent CADANS : toutes les entreprises, pas seulement celle qui les a
 * publiées. C'est ce qui distingue cet écran de `GET /missions` (`@Roles(Role.COMPANY)`,
 * scopé à l'entreprise connectée) — il n'a jamais été prévu pour un usage transverse.
 */
export interface MissionResume {
  id: string;
  posteLabel: string;
  companyName: string;
  siteLabel: string;
  status: MissionStatus;
  startDate: string;
  endDate: string;
}

export interface MissionDetail extends MissionResume {
  postalCode: string;
  shift: Shift;
  hourlyRate: string;
  assignedWorker: { prenom: string; nom: string } | null;
  candidaturesCount: number;
  contrats: { type: string; completedAt: string | null }[];
}

export type FiltreMissions = MissionStatus | 'TOUTES';

@Injectable()
export class AdminMissionsService {
  constructor(private readonly prisma: PrismaService) {}

  // Les plus récentes d'abord : un agent qui ouvre cet écran regarde l'activité en cours,
  // pas une file à traiter dans l'ordre d'arrivée (contrairement aux justificatifs).
  async listMissions(filtre: FiltreMissions = 'TOUTES'): Promise<MissionResume[]> {
    const missions = await this.prisma.mission.findMany({
      where: filtre === 'TOUTES' ? {} : { status: filtre },
      orderBy: { startDate: 'desc' },
      select: {
        id: true,
        siteLabel: true,
        status: true,
        startDate: true,
        endDate: true,
        poste: { select: { label: true } },
        company: { select: { legalName: true } },
      },
    });

    return missions.map(toMissionResume);
  }

  async getMission(missionId: string): Promise<MissionDetail> {
    const mission = await this.prisma.mission.findUnique({
      where: { id: missionId },
      select: {
        id: true,
        siteLabel: true,
        postalCode: true,
        shift: true,
        hourlyRate: true,
        status: true,
        startDate: true,
        endDate: true,
        poste: { select: { label: true } },
        company: { select: { legalName: true } },
        assignedWorker: { select: { firstName: true, lastName: true } },
        contracts: { select: { type: true, completedAt: true } },
        _count: { select: { candidatures: true } },
      },
    });

    if (!mission) {
      throw new NotFoundException('Mission introuvable');
    }

    return {
      ...toMissionResume(mission),
      postalCode: mission.postalCode,
      shift: mission.shift,
      hourlyRate: mission.hourlyRate.toString(),
      assignedWorker: mission.assignedWorker
        ? { prenom: mission.assignedWorker.firstName, nom: mission.assignedWorker.lastName }
        : null,
      candidaturesCount: mission._count.candidatures,
      contrats: mission.contracts.map((contrat) => ({
        type: contrat.type,
        completedAt: contrat.completedAt?.toISOString() ?? null,
      })),
    };
  }
}

function toMissionResume(mission: {
  id: string;
  siteLabel: string;
  status: MissionStatus;
  startDate: Date;
  endDate: Date;
  poste: { label: string };
  company: { legalName: string };
}): MissionResume {
  return {
    id: mission.id,
    posteLabel: mission.poste.label,
    companyName: mission.company.legalName,
    siteLabel: mission.siteLabel,
    status: mission.status,
    startDate: mission.startDate.toISOString().slice(0, 10),
    endDate: mission.endDate.toISOString().slice(0, 10),
  };
}
