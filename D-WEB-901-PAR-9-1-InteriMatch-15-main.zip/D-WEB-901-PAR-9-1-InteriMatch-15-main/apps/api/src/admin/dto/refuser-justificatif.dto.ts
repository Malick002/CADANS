import { IsString, Length } from 'class-validator';

export class RefuserJustificatifDto {
  // Motif obligatoire et substantiel : l'intérimaire le lit sur son profil, et un « non »
  // sec ne lui apprend pas quoi corriger. Borné à 500 caractères, comme la colonne.
  @IsString()
  @Length(10, 500, { message: 'Le motif du refus doit faire entre 10 et 500 caractères' })
  motif!: string;
}
