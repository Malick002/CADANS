import { Module } from '@nestjs/common';
import { AdminAnnuaireService } from './admin-annuaire.service';
import { AdminContratsService } from './admin-contrats.service';
import { AdminDashboardService } from './admin-dashboard.service';
import { AdminMissionsService } from './admin-missions.service';
import { AdminController } from './admin.controller';
import { AdminService } from './admin.service';

@Module({
  controllers: [AdminController],
  providers: [
    AdminService,
    AdminDashboardService,
    AdminAnnuaireService,
    AdminMissionsService,
    AdminContratsService,
  ],
})
export class AdminModule {}
