import { ContractType, MissionStatus, Shift } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AdminMissionsService } from './admin-missions.service';

describe('AdminMissionsService', () => {
  let prisma: { mission: { findMany: jest.Mock; findUnique: jest.Mock } };
  let service: AdminMissionsService;

  beforeEach(() => {
    prisma = { mission: { findMany: jest.fn(), findUnique: jest.fn() } };
    service = new AdminMissionsService(prisma as unknown as PrismaService);
  });

  describe('listMissions', () => {
    it('sans filtre, ne restreint pas la clause where', async () => {
      prisma.mission.findMany.mockResolvedValue([]);

      await service.listMissions('TOUTES');

      expect(prisma.mission.findMany).toHaveBeenCalledWith(expect.objectContaining({ where: {} }));
    });

    it('avec un statut, filtre dessus', async () => {
      prisma.mission.findMany.mockResolvedValue([]);

      await service.listMissions(MissionStatus.OUVERTE);

      expect(prisma.mission.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { status: MissionStatus.OUVERTE } }),
      );
    });

    it('rend un résumé toutes entreprises confondues', async () => {
      prisma.mission.findMany.mockResolvedValue([
        {
          id: 'mission-1',
          siteLabel: 'LogiNord - Roissy',
          status: MissionStatus.OUVERTE,
          startDate: new Date('2026-10-01T00:00:00.000Z'),
          endDate: new Date('2026-10-31T00:00:00.000Z'),
          poste: { label: 'Cariste' },
          company: { legalName: 'Entrepôt du Nord' },
        },
      ]);

      expect(await service.listMissions()).toEqual([
        {
          id: 'mission-1',
          posteLabel: 'Cariste',
          companyName: 'Entrepôt du Nord',
          siteLabel: 'LogiNord - Roissy',
          status: MissionStatus.OUVERTE,
          startDate: '2026-10-01',
          endDate: '2026-10-31',
        },
      ]);
    });
  });

  describe('getMission', () => {
    it('lève 404 quand la mission est introuvable', async () => {
      prisma.mission.findUnique.mockResolvedValue(null);

      await expect(service.getMission('inconnue')).rejects.toThrow('Mission introuvable');
    });

    it('rend le détail avec l’intérimaire retenu, les candidatures et les contrats', async () => {
      prisma.mission.findUnique.mockResolvedValue({
        id: 'mission-1',
        siteLabel: 'LogiNord - Roissy',
        postalCode: '95700',
        shift: Shift.MATIN,
        hourlyRate: { toString: () => '12.50' },
        status: MissionStatus.POURVUE,
        startDate: new Date('2026-10-01T00:00:00.000Z'),
        endDate: new Date('2026-10-31T00:00:00.000Z'),
        poste: { label: 'Cariste' },
        company: { legalName: 'Entrepôt du Nord' },
        assignedWorker: { firstName: 'Samir', lastName: 'Diallo' },
        contracts: [
          { type: ContractType.MISSION, completedAt: new Date('2026-09-20T00:00:00.000Z') },
          { type: ContractType.MISE_A_DISPOSITION, completedAt: null },
        ],
        _count: { candidatures: 3 },
      });

      expect(await service.getMission('mission-1')).toEqual({
        id: 'mission-1',
        posteLabel: 'Cariste',
        companyName: 'Entrepôt du Nord',
        siteLabel: 'LogiNord - Roissy',
        status: MissionStatus.POURVUE,
        startDate: '2026-10-01',
        endDate: '2026-10-31',
        postalCode: '95700',
        shift: Shift.MATIN,
        hourlyRate: '12.50',
        assignedWorker: { prenom: 'Samir', nom: 'Diallo' },
        candidaturesCount: 3,
        contrats: [
          { type: ContractType.MISSION, completedAt: '2026-09-20T00:00:00.000Z' },
          { type: ContractType.MISE_A_DISPOSITION, completedAt: null },
        ],
      });
    });

    it('rend un intérimaire retenu nul quand la mission n’est pas encore pourvue', async () => {
      prisma.mission.findUnique.mockResolvedValue({
        id: 'mission-1',
        siteLabel: 'LogiNord - Roissy',
        postalCode: '95700',
        shift: Shift.MATIN,
        hourlyRate: { toString: () => '12.50' },
        status: MissionStatus.OUVERTE,
        startDate: new Date('2026-10-01T00:00:00.000Z'),
        endDate: new Date('2026-10-31T00:00:00.000Z'),
        poste: { label: 'Cariste' },
        company: { legalName: 'Entrepôt du Nord' },
        assignedWorker: null,
        contracts: [],
        _count: { candidatures: 0 },
      });

      const detail = await service.getMission('mission-1');

      expect(detail.assignedWorker).toBeNull();
      expect(detail.contrats).toEqual([]);
    });
  });
});
