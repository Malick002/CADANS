import { Injectable, NotFoundException } from '@nestjs/common';
import { ContractType, SignatureParty } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Contrats vus par un agent CADANS, toutes missions confondues. `GET /contrats`
 * (`ContractsController`) est scopé au compte connecté (entreprise ou intérimaire) ; cet
 * annuaire n'a pas d'équivalent transverse avant cet écran.
 */
export interface ContratResume {
  id: string;
  type: ContractType;
  posteLabel: string;
  companyName: string;
  workerName: string | null;
  generatedAt: string;
  completedAt: string | null;
}

export interface ContratDetail extends ContratResume {
  signatures: { party: SignatureParty; typedName: string; signedAt: string }[];
}

export type FiltreContrats = 'A_SIGNER' | 'TOUS';

@Injectable()
export class AdminContratsService {
  constructor(private readonly prisma: PrismaService) {}

  // Du plus ancien au plus récent par défaut : comme la file des justificatifs, « à signer »
  // est une file à traiter, pas un flux d'activité — le contrat qui attend depuis le plus
  // longtemps passe en tête.
  async listContrats(filtre: FiltreContrats = 'A_SIGNER'): Promise<ContratResume[]> {
    const contrats = await this.prisma.contract.findMany({
      where: filtre === 'A_SIGNER' ? { completedAt: null } : {},
      orderBy: { generatedAt: filtre === 'A_SIGNER' ? 'asc' : 'desc' },
      select: {
        id: true,
        type: true,
        generatedAt: true,
        completedAt: true,
        mission: {
          select: {
            poste: { select: { label: true } },
            company: { select: { legalName: true } },
            assignedWorker: { select: { firstName: true, lastName: true } },
          },
        },
      },
    });

    return contrats.map(toContratResume);
  }

  async getContrat(contractId: string): Promise<ContratDetail> {
    const contrat = await this.prisma.contract.findUnique({
      where: { id: contractId },
      select: {
        id: true,
        type: true,
        generatedAt: true,
        completedAt: true,
        mission: {
          select: {
            poste: { select: { label: true } },
            company: { select: { legalName: true } },
            assignedWorker: { select: { firstName: true, lastName: true } },
          },
        },
        // Ni l'IP ni l'agent utilisateur : un agent CADANS vérifie QUI a signé et QUAND,
        // pas les éléments de preuve technique d'une contestation — hors périmètre ici.
        signatures: {
          select: { party: true, typedName: true, signedAt: true },
          orderBy: { signedAt: 'asc' },
        },
      },
    });

    if (!contrat) {
      throw new NotFoundException('Contrat introuvable');
    }

    return {
      ...toContratResume(contrat),
      signatures: contrat.signatures.map((signature) => ({
        party: signature.party,
        typedName: signature.typedName,
        signedAt: signature.signedAt.toISOString(),
      })),
    };
  }
}

function toContratResume(contrat: {
  id: string;
  type: ContractType;
  generatedAt: Date;
  completedAt: Date | null;
  mission: {
    poste: { label: string };
    company: { legalName: string };
    assignedWorker: { firstName: string; lastName: string } | null;
  };
}): ContratResume {
  return {
    id: contrat.id,
    type: contrat.type,
    posteLabel: contrat.mission.poste.label,
    companyName: contrat.mission.company.legalName,
    workerName: contrat.mission.assignedWorker
      ? `${contrat.mission.assignedWorker.firstName} ${contrat.mission.assignedWorker.lastName}`
      : null,
    generatedAt: contrat.generatedAt.toISOString(),
    completedAt: contrat.completedAt?.toISOString() ?? null,
  };
}
