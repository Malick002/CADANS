import { CertificationStatus, CertificationType, MissionStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AdminDashboardService, DERNIERS_JUSTIFICATIFS } from './admin-dashboard.service';

const DEPOSE_LE = new Date('2026-09-22T09:00:00.000Z');

describe('AdminDashboardService', () => {
  let prisma: {
    certification: { count: jest.Mock; findMany: jest.Mock };
    mission: { count: jest.Mock };
    contract: { count: jest.Mock };
    worker: { count: jest.Mock };
    company: { count: jest.Mock };
  };
  let service: AdminDashboardService;

  beforeEach(() => {
    prisma = {
      certification: {
        count: jest.fn().mockResolvedValue(3),
        findMany: jest.fn().mockResolvedValue([
          {
            id: 'cert-1',
            type: CertificationType.CACES_R489_3,
            updatedAt: DEPOSE_LE,
            worker: { firstName: 'Samir', lastName: 'Diallo' },
          },
        ]),
      },
      // Deux appels successifs : missions ouvertes, puis pourvues.
      mission: { count: jest.fn().mockResolvedValueOnce(7).mockResolvedValueOnce(2) },
      contract: { count: jest.fn().mockResolvedValue(4) },
      worker: { count: jest.fn().mockResolvedValue(12) },
      company: { count: jest.fn().mockResolvedValue(5) },
    };
    service = new AdminDashboardService(prisma as unknown as PrismaService);
  });

  it('rend les six compteurs', async () => {
    const { compteurs } = await service.tableauDeBord();

    expect(compteurs).toEqual({
      justificatifsEnAttente: 3,
      missionsOuvertes: 7,
      missionsPourvues: 2,
      contratsASigner: 4,
      interimaires: 12,
      entreprises: 5,
    });
  });

  // Même filtre que la file d'attente : un justificatif sans document n'est pas examinable.
  // S'il gonflait le compteur, l'agent verrait un nombre qu'il ne peut pas faire descendre.
  it('ne compte que les justificatifs réellement examinables', async () => {
    await service.tableauDeBord();

    expect(prisma.certification.count).toHaveBeenCalledWith({
      where: {
        verificationStatus: CertificationStatus.EN_ATTENTE,
        documentEncrypted: { not: null },
      },
    });
  });

  it('compte les missions par statut, ouvertes puis pourvues', async () => {
    await service.tableauDeBord();

    expect(prisma.mission.count).toHaveBeenNthCalledWith(1, {
      where: { status: MissionStatus.OUVERTE },
    });
    expect(prisma.mission.count).toHaveBeenNthCalledWith(2, {
      where: { status: MissionStatus.POURVUE },
    });
  });

  // `completedAt` n'est posé qu'une fois les deux parties signataires passées : c'est le seul
  // champ qui dise l'état d'un contrat sans recompter ses signatures.
  it('compte comme « à signer » les contrats non complétés', async () => {
    await service.tableauDeBord();

    expect(prisma.contract.count).toHaveBeenCalledWith({ where: { completedAt: null } });
  });

  describe('derniers justificatifs', () => {
    it('rend une ligne réduite à ce que le tableau de bord affiche', async () => {
      const { derniersJustificatifs } = await service.tableauDeBord();

      expect(derniersJustificatifs).toEqual([
        {
          certificationId: 'cert-1',
          type: CertificationType.CACES_R489_3,
          deposeLe: DEPOSE_LE,
          interimaire: { prenom: 'Samir', nom: 'Diallo' },
        },
      ]);
    });

    // La minimisation ne se plaide pas, elle se vérifie : le `select` doit ne demander que
    // les colonnes affichées. Ville, statut et motif de refus n'ont rien à faire ici.
    it('ne demande à la base que les colonnes affichées', async () => {
      await service.tableauDeBord();

      const [{ select }] = prisma.certification.findMany.mock.calls[0] as [
        { select: Record<string, unknown> },
      ];
      expect(Object.keys(select).sort()).toEqual(['id', 'type', 'updatedAt', 'worker']);
      expect(select.worker).toEqual({ select: { firstName: true, lastName: true } });
    });

    // La file d'attente se traite du plus ANCIEN au plus récent ; un tableau de bord dit ce
    // qui vient d'arriver. Les deux ordres sont volontairement inverses.
    it('prend les cinq plus récents, et non les plus anciens', async () => {
      await service.tableauDeBord();

      const [args] = prisma.certification.findMany.mock.calls[0] as [
        { orderBy: unknown; take: number },
      ];
      expect(args.orderBy).toEqual({ updatedAt: 'desc' });
      expect(args.take).toBe(DERNIERS_JUSTIFICATIFS);
      expect(DERNIERS_JUSTIFICATIFS).toBe(5);
    });

    it('rend une liste vide quand la file est vide', async () => {
      prisma.certification.findMany.mockResolvedValue([]);

      expect((await service.tableauDeBord()).derniersJustificatifs).toEqual([]);
    });
  });
});
