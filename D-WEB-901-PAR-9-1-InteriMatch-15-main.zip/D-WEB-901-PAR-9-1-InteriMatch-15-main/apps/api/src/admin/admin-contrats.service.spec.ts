import { ContractType, SignatureParty } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AdminContratsService } from './admin-contrats.service';

describe('AdminContratsService', () => {
  let prisma: { contract: { findMany: jest.Mock; findUnique: jest.Mock } };
  let service: AdminContratsService;

  beforeEach(() => {
    prisma = { contract: { findMany: jest.fn(), findUnique: jest.fn() } };
    service = new AdminContratsService(prisma as unknown as PrismaService);
  });

  describe('listContrats', () => {
    it('par défaut, ne retient que les contrats non complétés, du plus ancien au plus récent', async () => {
      prisma.contract.findMany.mockResolvedValue([]);

      await service.listContrats();

      expect(prisma.contract.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { completedAt: null },
          orderBy: { generatedAt: 'asc' },
        }),
      );
    });

    it('sur TOUS, ne filtre pas et trie du plus récent au plus ancien', async () => {
      prisma.contract.findMany.mockResolvedValue([]);

      await service.listContrats('TOUS');

      expect(prisma.contract.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: {}, orderBy: { generatedAt: 'desc' } }),
      );
    });

    it('rend un résumé avec la mission, l’entreprise et l’intérimaire retenu', async () => {
      prisma.contract.findMany.mockResolvedValue([
        {
          id: 'contrat-1',
          type: ContractType.MISSION,
          generatedAt: new Date('2026-09-20T09:00:00.000Z'),
          completedAt: null,
          mission: {
            poste: { label: 'Cariste' },
            company: { legalName: 'Entrepôt du Nord' },
            assignedWorker: { firstName: 'Samir', lastName: 'Diallo' },
          },
        },
      ]);

      expect(await service.listContrats()).toEqual([
        {
          id: 'contrat-1',
          type: ContractType.MISSION,
          posteLabel: 'Cariste',
          companyName: 'Entrepôt du Nord',
          workerName: 'Samir Diallo',
          generatedAt: '2026-09-20T09:00:00.000Z',
          completedAt: null,
        },
      ]);
    });

    it('rend un intérimaire nul quand la mission n’a pas encore de retenu', async () => {
      prisma.contract.findMany.mockResolvedValue([
        {
          id: 'contrat-1',
          type: ContractType.MISE_A_DISPOSITION,
          generatedAt: new Date('2026-09-20T09:00:00.000Z'),
          completedAt: null,
          mission: {
            poste: { label: 'Cariste' },
            company: { legalName: 'Entrepôt du Nord' },
            assignedWorker: null,
          },
        },
      ]);

      const [contrat] = await service.listContrats();
      expect(contrat.workerName).toBeNull();
    });
  });

  describe('getContrat', () => {
    it('lève 404 quand le contrat est introuvable', async () => {
      prisma.contract.findUnique.mockResolvedValue(null);

      await expect(service.getContrat('inconnu')).rejects.toThrow('Contrat introuvable');
    });

    it('rend le détail avec les signatures, du plus ancien au plus récent', async () => {
      prisma.contract.findUnique.mockResolvedValue({
        id: 'contrat-1',
        type: ContractType.MISSION,
        generatedAt: new Date('2026-09-20T09:00:00.000Z'),
        completedAt: new Date('2026-09-22T10:00:00.000Z'),
        mission: {
          poste: { label: 'Cariste' },
          company: { legalName: 'Entrepôt du Nord' },
          assignedWorker: { firstName: 'Samir', lastName: 'Diallo' },
        },
        signatures: [
          {
            party: SignatureParty.CADANS,
            typedName: 'CADANS',
            signedAt: new Date('2026-09-20T09:00:00.000Z'),
          },
          {
            party: SignatureParty.INTERIMAIRE,
            typedName: 'Samir Diallo',
            signedAt: new Date('2026-09-22T10:00:00.000Z'),
          },
        ],
      });

      expect(await service.getContrat('contrat-1')).toEqual({
        id: 'contrat-1',
        type: ContractType.MISSION,
        posteLabel: 'Cariste',
        companyName: 'Entrepôt du Nord',
        workerName: 'Samir Diallo',
        generatedAt: '2026-09-20T09:00:00.000Z',
        completedAt: '2026-09-22T10:00:00.000Z',
        signatures: [
          {
            party: SignatureParty.CADANS,
            typedName: 'CADANS',
            signedAt: '2026-09-20T09:00:00.000Z',
          },
          {
            party: SignatureParty.INTERIMAIRE,
            typedName: 'Samir Diallo',
            signedAt: '2026-09-22T10:00:00.000Z',
          },
        ],
      });
    });
  });
});
