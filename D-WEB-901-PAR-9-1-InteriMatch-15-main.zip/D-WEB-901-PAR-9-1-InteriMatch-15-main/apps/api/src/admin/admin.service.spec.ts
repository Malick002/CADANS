import { BadRequestException, NotFoundException } from '@nestjs/common';
import { CertificationStatus, CertificationType } from '@prisma/client';
import { EncryptionService } from '../encryption/encryption.service';
import { PrismaService } from '../prisma/prisma.service';
import { AdminService } from './admin.service';

const ligne = (surcharges: Record<string, unknown> = {}) => ({
  id: 'cert-1',
  workerId: 'worker-1',
  type: CertificationType.CACES_R489_3,
  expiresAt: new Date('2029-03-10'),
  verificationStatus: CertificationStatus.EN_ATTENTE,
  refusalMotif: null,
  updatedAt: new Date('2026-09-22T08:00:00Z'),
  documentEncrypted: Buffer.from('chiffré'),
  documentMimeType: 'application/pdf',
  worker: { id: 'worker-1', firstName: 'Leïla', lastName: 'Moreau', city: 'Roissy-en-France' },
  decisions: [],
  ...surcharges,
});

describe('AdminService', () => {
  let prisma: {
    certification: { findMany: jest.Mock; findUnique: jest.Mock; update: jest.Mock };
    certificationDecision: { create: jest.Mock };
    $transaction: jest.Mock;
  };
  let encryption: { decrypt: jest.Mock };
  let service: AdminService;

  beforeEach(() => {
    prisma = {
      certification: {
        findMany: jest.fn().mockResolvedValue([ligne()]),
        findUnique: jest.fn().mockResolvedValue(ligne()),
        update: jest
          .fn()
          .mockImplementation(({ data }) =>
            Promise.resolve(ligne({ ...data, worker: ligne().worker })),
          ),
      },
      certificationDecision: { create: jest.fn().mockResolvedValue({ id: 'decision-1' }) },
      // `$transaction` reçoit un tableau de promesses déjà lancées par Prisma : les résoudre
      // dans l'ordre suffit à reproduire ce que le service en attend.
      $transaction: jest
        .fn()
        .mockImplementation((operations: Promise<unknown>[]) => Promise.all(operations)),
    };
    encryption = { decrypt: jest.fn().mockReturnValue(Buffer.from('%PDF-1.4')) };
    service = new AdminService(
      prisma as unknown as PrismaService,
      encryption as unknown as EncryptionService,
    );
  });

  describe('listJustificatifs', () => {
    // Une file d'attente se traite dans l'ordre d'arrivée. Et une habilitation sans document
    // n'a rien à y faire : il n'y a rien à examiner.
    it('ne remonte que les justificatifs en attente et pourvus d’un document, du plus ancien au plus récent', async () => {
      await service.listJustificatifs();

      expect(prisma.certification.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            verificationStatus: CertificationStatus.EN_ATTENTE,
            documentEncrypted: { not: null },
          },
          orderBy: { updatedAt: 'asc' },
        }),
      );
    });

    it('accepte un autre statut pour consulter l’historique', async () => {
      await service.listJustificatifs(CertificationStatus.REFUSE);

      expect(prisma.certification.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ verificationStatus: CertificationStatus.REFUSE }),
        }),
      );
    });

    // L'agent doit savoir de qui vient la pièce — une vérification d'identité professionnelle
    // ne peut pas être anonyme. Mais ni l'adresse ni le téléphone ne lui servent.
    it('nomme l’intérimaire sans divulguer ses coordonnées', async () => {
      const [vue] = await service.listJustificatifs();

      expect(vue.interimaire).toEqual({
        prenom: 'Leïla',
        nom: 'Moreau',
        ville: 'Roissy-en-France',
      });
      expect(JSON.stringify(vue)).not.toContain('@');
      expect(Object.keys(vue)).not.toContain('documentEncrypted');
    });
  });

  describe('readJustificatif', () => {
    it('déchiffre avec le contexte de l’intérimaire et du type', async () => {
      const file = await service.readJustificatif('cert-1');

      expect(encryption.decrypt).toHaveBeenCalledWith(
        expect.any(Buffer),
        'certification-document:worker-1:CACES_R489_3',
      );
      expect(file.mimeType).toBe('application/pdf');
      expect(file.filename).toBe('caces_r489_3.pdf');
    });

    it('refuse une habilitation sans document', async () => {
      prisma.certification.findUnique.mockResolvedValueOnce(
        ligne({ documentEncrypted: null, documentMimeType: null }),
      );

      await expect(service.readJustificatif('cert-1')).rejects.toThrow(NotFoundException);
    });

    it('refuse une habilitation inconnue', async () => {
      prisma.certification.findUnique.mockResolvedValueOnce(null);

      await expect(service.readJustificatif('inconnue')).rejects.toThrow(NotFoundException);
    });
  });

  describe('décisions', () => {
    it('valide en traçant l’agent et la date', async () => {
      const vue = await service.valider('cert-1', 'agent-1');

      const { data } = prisma.certification.update.mock.calls[0][0];
      expect(data.verificationStatus).toBe(CertificationStatus.VERIFIE);
      expect(data.verifiedByUserId).toBe('agent-1');
      expect(data.verifiedAt).toBeInstanceOf(Date);
      // Une validation efface un motif de refus antérieur : le laisser afficherait « refusé
      // parce que… » sous une habilitation validée.
      expect(data.refusalMotif).toBeNull();
      expect(vue.verificationStatus).toBe(CertificationStatus.VERIFIE);
    });

    it('refuse en enregistrant le motif, débarrassé de ses espaces', async () => {
      const vue = await service.refuser('cert-1', 'agent-1', '  Scan illisible, à reprendre.  ');

      const { data } = prisma.certification.update.mock.calls[0][0];
      expect(data.refusalMotif).toBe('Scan illisible, à reprendre.');
      expect(vue.verificationStatus).toBe(CertificationStatus.REFUSE);
    });

    // Garde-fou pour les appels internes : le DTO couvre déjà l'entrée HTTP.
    it('refuse un refus non motivé', async () => {
      await expect(service.refuser('cert-1', 'agent-1', '   ')).rejects.toThrow(
        BadRequestException,
      );
      expect(prisma.certification.update).not.toHaveBeenCalled();
    });

    // Trancher sur une habilitation sans pièce, c'est valider une déclaration.
    it('refuse de décider sans justificatif', async () => {
      prisma.certification.findUnique.mockResolvedValueOnce(ligne({ documentEncrypted: null }));

      await expect(service.valider('cert-1', 'agent-1')).rejects.toThrow(BadRequestException);
      expect(prisma.certification.update).not.toHaveBeenCalled();
    });

    it('refuse de décider sur une habilitation inconnue', async () => {
      prisma.certification.findUnique.mockResolvedValueOnce(null);

      await expect(service.valider('inconnue', 'agent-1')).rejects.toThrow(NotFoundException);
    });
  });

  describe('historique des décisions', () => {
    it('écrit une ligne d’historique ET la décision courante, dans la même transaction', async () => {
      await service.valider('cert-1', 'agent-1');

      expect(prisma.certificationDecision.create).toHaveBeenCalledWith({
        data: {
          certificationId: 'cert-1',
          decision: CertificationStatus.VERIFIE,
          motif: null,
          agentUserId: 'agent-1',
          // Recopiés pour que la ligne se relise seule après suppression de l'habilitation.
          certificationType: CertificationType.CACES_R489_3,
          workerId: 'worker-1',
        },
      });
      // La décision courante n'est PAS remplacée par l'historique : tout ce qui la lit
      // aujourd'hui continue de fonctionner sans requête supplémentaire.
      expect(prisma.certification.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            verificationStatus: CertificationStatus.VERIFIE,
            verifiedByUserId: 'agent-1',
          }),
        }),
      );
      expect(prisma.$transaction).toHaveBeenCalledTimes(1);
    });

    // Le motif est porté par la LIGNE, pas relu sur la certification : un refus levé puis
    // reposé sur un autre motif doit se relire dans l'historique.
    it('conserve le motif dans la ligne d’historique', async () => {
      await service.refuser('cert-1', 'agent-1', 'Document illisible');

      expect(prisma.certificationDecision.create).toHaveBeenCalledWith({
        data: {
          certificationId: 'cert-1',
          decision: CertificationStatus.REFUSE,
          motif: 'Document illisible',
          agentUserId: 'agent-1',
          certificationType: CertificationType.CACES_R489_3,
          workerId: 'worker-1',
        },
      });
    });

    it('n’écrit rien quand la décision est refusée faute de justificatif', async () => {
      prisma.certification.findUnique.mockResolvedValue(ligne({ documentEncrypted: null }));

      await expect(service.valider('cert-1', 'agent-1')).rejects.toBeInstanceOf(
        BadRequestException,
      );
      expect(prisma.certificationDecision.create).not.toHaveBeenCalled();
      expect(prisma.certification.update).not.toHaveBeenCalled();
    });

    it('rend l’historique du plus récent au plus ancien, avec l’agent', async () => {
      prisma.certification.findMany.mockResolvedValue([
        ligne({
          decisions: [
            {
              decision: CertificationStatus.REFUSE,
              motif: 'Scan tronqué',
              decidedAt: new Date('2026-09-22T10:00:00Z'),
              agent: { email: 'agent@cadans.fr' },
            },
            {
              decision: CertificationStatus.VERIFIE,
              motif: null,
              decidedAt: new Date('2026-09-20T10:00:00Z'),
              agent: null,
            },
          ],
        }),
      ]);

      const [vue] = await service.listJustificatifs(CertificationStatus.EN_ATTENTE);

      expect(vue.decisions).toEqual([
        {
          decision: CertificationStatus.REFUSE,
          motif: 'Scan tronqué',
          decidedAt: new Date('2026-09-22T10:00:00Z'),
          agent: 'agent@cadans.fr',
        },
        {
          decision: CertificationStatus.VERIFIE,
          motif: null,
          decidedAt: new Date('2026-09-20T10:00:00Z'),
          // Compte d'agent supprimé : on perd l'auteur, jamais la décision.
          agent: null,
        },
      ]);
      const [args] = prisma.certification.findMany.mock.calls[0] as [
        { include: { decisions: { orderBy: unknown } } },
      ];
      expect(args.include.decisions.orderBy).toEqual({ decidedAt: 'desc' });
    });
  });

  describe('filtres', () => {
    const whereDu = () =>
      (prisma.certification.findMany.mock.calls[0] as [{ where: Record<string, unknown> }])[0]
        .where;

    // La file d'attente garde le filtre sur le document : sans pièce, il n'y a rien à
    // examiner, et elle n'a pas à encombrer le travail du jour.
    it('la file d’attente exige un justificatif présent', async () => {
      await service.listJustificatifs(CertificationStatus.EN_ATTENTE);

      expect(whereDu()).toEqual({
        verificationStatus: CertificationStatus.EN_ATTENTE,
        documentEncrypted: { not: null },
      });
    });

    // LE changement de fond : une habilitation déjà tranchée dont l'intérimaire a retiré la
    // pièce disparaissait de tous les écrans tout en restant VERIFIE.
    it.each([CertificationStatus.VERIFIE, CertificationStatus.REFUSE])(
      'le filtre %s n’exige pas de justificatif présent',
      async (statut) => {
        await service.listJustificatifs(statut);

        expect(whereDu()).toEqual({ verificationStatus: statut });
      },
    );

    it('« Tous » ne filtre rien', async () => {
      await service.listJustificatifs('TOUS');

      expect(whereDu()).toEqual({});
    });

    it('signale une habilitation dont le document a été supprimé', async () => {
      prisma.certification.findMany.mockResolvedValue([
        ligne({ verificationStatus: CertificationStatus.VERIFIE, documentEncrypted: null }),
      ]);

      const [vue] = await service.listJustificatifs('TOUS');

      expect(vue.documentPresent).toBe(false);
      expect(vue.verificationStatus).toBe(CertificationStatus.VERIFIE);
    });

    describe('expirées', () => {
      it('ne retient que les dates passées', async () => {
        prisma.certification.findMany.mockResolvedValue([
          ligne({ id: 'passee', expiresAt: new Date('2020-01-01') }),
          ligne({ id: 'future', expiresAt: new Date('2099-01-01') }),
          ligne({ id: 'sans-date', expiresAt: null }),
        ]);

        const vues = await service.listJustificatifs('EXPIREES');

        expect(vues.map((vue) => vue.certificationId)).toEqual(['passee']);
      });

      // Le filtre se calcule après lecture, pas en SQL : la règle de validité (heure de
      // Paris, changement d'heure compris) vit dans `certificationValide`, et la réécrire en
      // SQL créerait une seconde définition qui dériverait de la première.
      it('n’exige de la base qu’une date à comparer', async () => {
        await service.listJustificatifs('EXPIREES');

        expect(whereDu()).toEqual({ expiresAt: { not: null } });
      });
    });
  });
});
