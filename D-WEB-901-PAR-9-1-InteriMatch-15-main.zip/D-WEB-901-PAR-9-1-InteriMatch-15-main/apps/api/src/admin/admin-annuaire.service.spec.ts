import { CertificationStatus, CertificationType, MissionStatus, Shift } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AdminAnnuaireService } from './admin-annuaire.service';

describe('AdminAnnuaireService', () => {
  let prisma: {
    worker: { findMany: jest.Mock; findUnique: jest.Mock };
    company: { findMany: jest.Mock; findUnique: jest.Mock };
  };
  let service: AdminAnnuaireService;

  beforeEach(() => {
    prisma = {
      worker: { findMany: jest.fn(), findUnique: jest.fn() },
      company: { findMany: jest.fn(), findUnique: jest.fn() },
    };
    service = new AdminAnnuaireService(prisma as unknown as PrismaService);
  });

  describe('listInterimaires', () => {
    it('trie par nom puis prénom', async () => {
      prisma.worker.findMany.mockResolvedValue([]);

      await service.listInterimaires();

      expect(prisma.worker.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ orderBy: [{ lastName: 'asc' }, { firstName: 'asc' }] }),
      );
    });

    it('rend un résumé sans donnée sensible', async () => {
      prisma.worker.findMany.mockResolvedValue([
        {
          id: 'worker-1',
          firstName: 'Samir',
          lastName: 'Diallo',
          city: 'Lyon',
          postalCode: '69007',
          createdAt: new Date('2026-09-01T00:00:00.000Z'),
        },
      ]);

      expect(await service.listInterimaires()).toEqual([
        {
          id: 'worker-1',
          prenom: 'Samir',
          nom: 'Diallo',
          ville: 'Lyon',
          codePostal: '69007',
          inscritLe: new Date('2026-09-01T00:00:00.000Z'),
        },
      ]);
    });
  });

  describe('getInterimaire', () => {
    const WORKER = {
      id: 'worker-1',
      firstName: 'Samir',
      lastName: 'Diallo',
      city: 'Lyon',
      postalCode: '69007',
      phone: '0612345678',
      createdAt: new Date('2026-09-01T00:00:00.000Z'),
      availableFrom: new Date('2026-09-10T00:00:00.000Z'),
      availableUntil: new Date('2026-12-31T00:00:00.000Z'),
      shifts: [Shift.MATIN],
      user: { email: 'samir@example.fr' },
      skills: [{ competence: { code: 'C1', label: 'Conduire un chariot' } }],
      certifications: [
        {
          type: CertificationType.CACES_R489_3,
          expiresAt: new Date('2027-01-01T00:00:00.000Z'),
          verificationStatus: CertificationStatus.VERIFIE,
        },
      ],
    };

    it('lève 404 quand le profil est introuvable', async () => {
      prisma.worker.findUnique.mockResolvedValue(null);

      await expect(service.getInterimaire('inconnu')).rejects.toThrow('Intérimaire introuvable');
    });

    it('rend la fiche complète, dates au format AAAA-MM-JJ', async () => {
      prisma.worker.findUnique.mockResolvedValue(WORKER);

      expect(await service.getInterimaire('worker-1')).toEqual({
        id: 'worker-1',
        prenom: 'Samir',
        nom: 'Diallo',
        email: 'samir@example.fr',
        telephone: '0612345678',
        ville: 'Lyon',
        codePostal: '69007',
        inscritLe: WORKER.createdAt,
        disponibleDu: '2026-09-10',
        disponibleAu: '2026-12-31',
        creneaux: [Shift.MATIN],
        competences: [{ code: 'C1', label: 'Conduire un chariot' }],
        habilitations: [
          {
            type: CertificationType.CACES_R489_3,
            expiresAt: '2027-01-01',
            verificationStatus: CertificationStatus.VERIFIE,
          },
        ],
      });
    });

    it('rend des disponibilités nulles quand elles ne sont pas renseignées', async () => {
      prisma.worker.findUnique.mockResolvedValue({
        ...WORKER,
        availableFrom: null,
        availableUntil: null,
      });

      const detail = await service.getInterimaire('worker-1');

      expect(detail.disponibleDu).toBeNull();
      expect(detail.disponibleAu).toBeNull();
    });
  });

  describe('listEntreprises', () => {
    it('trie par raison sociale', async () => {
      prisma.company.findMany.mockResolvedValue([]);

      await service.listEntreprises();

      expect(prisma.company.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ orderBy: { legalName: 'asc' } }),
      );
    });

    it('rend un résumé sans donnée sensible', async () => {
      prisma.company.findMany.mockResolvedValue([
        {
          id: 'company-1',
          legalName: 'Entrepôt du Nord',
          siret: '73282932000074',
          city: 'Roissy',
          createdAt: new Date('2026-08-01T00:00:00.000Z'),
        },
      ]);

      expect(await service.listEntreprises()).toEqual([
        {
          id: 'company-1',
          raisonSociale: 'Entrepôt du Nord',
          siret: '73282932000074',
          ville: 'Roissy',
          inscritLe: new Date('2026-08-01T00:00:00.000Z'),
        },
      ]);
    });
  });

  describe('getEntreprise', () => {
    const COMPANY = {
      id: 'company-1',
      legalName: 'Entrepôt du Nord',
      siret: '73282932000074',
      nafCode: '5210B',
      contactFirstName: 'Julie',
      contactLastName: 'Martin',
      phone: '0198765432',
      addressLine: '1 rue des Docks',
      postalCode: '95700',
      city: 'Roissy',
      createdAt: new Date('2026-08-01T00:00:00.000Z'),
      user: { email: 'contact@entrepot-nord.fr' },
      missions: [
        {
          id: 'mission-1',
          status: MissionStatus.OUVERTE,
          startDate: new Date('2026-10-01T00:00:00.000Z'),
          endDate: new Date('2026-10-31T00:00:00.000Z'),
          poste: { label: 'Cariste' },
        },
      ],
    };

    it('lève 404 quand la société est introuvable', async () => {
      prisma.company.findUnique.mockResolvedValue(null);

      await expect(service.getEntreprise('inconnue')).rejects.toThrow('Entreprise introuvable');
    });

    it('rend la fiche complète avec ses missions, dates au format AAAA-MM-JJ', async () => {
      prisma.company.findUnique.mockResolvedValue(COMPANY);

      expect(await service.getEntreprise('company-1')).toEqual({
        id: 'company-1',
        raisonSociale: 'Entrepôt du Nord',
        siret: '73282932000074',
        codeNaf: '5210B',
        contactPrenom: 'Julie',
        contactNom: 'Martin',
        email: 'contact@entrepot-nord.fr',
        telephone: '0198765432',
        adresse: '1 rue des Docks',
        codePostal: '95700',
        ville: 'Roissy',
        inscritLe: COMPANY.createdAt,
        missions: [
          {
            id: 'mission-1',
            posteLabel: 'Cariste',
            status: MissionStatus.OUVERTE,
            startDate: '2026-10-01',
            endDate: '2026-10-31',
          },
        ],
      });
    });
  });
});
