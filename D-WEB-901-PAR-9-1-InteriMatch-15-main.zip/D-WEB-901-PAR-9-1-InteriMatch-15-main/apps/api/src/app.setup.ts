import { INestApplication, ValidationPipe } from '@nestjs/common';

// Configuration partagée par main.ts et les tests fonctionnels : les tests e2e
// valident ainsi les payloads exactement comme l'API en production.
export function configureApp(app: INestApplication): void {
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );
}
