import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(PrismaService.name);
  private connected = false;

  async onModuleInit(): Promise<void> {
    // On ne fait pas planter le démarrage si PostgreSQL n'est pas lancé :
    // le socle doit rester utilisable sans conteneur (voir `npm run db:up`).
    // L'état réel est exposé par GET /health.
    try {
      await this.$connect();
      this.connected = true;
      this.logger.log('Connexion PostgreSQL établie');
    } catch (error) {
      this.connected = false;
      this.logger.error(
        `Connexion PostgreSQL impossible : ${error instanceof Error ? error.message : String(error)}. ` +
          'Lance les bases avec `npm run db:up`.',
      );
    }
  }

  async onModuleDestroy(): Promise<void> {
    if (this.connected) {
      await this.$disconnect();
    }
  }

  isConnected(): boolean {
    return this.connected;
  }
}
