import { ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { Company, Prisma, Role, User, Worker } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { LoginDto } from './dto/login.dto';
import { RegisterCompanyDto } from './dto/register-company.dto';
import { RegisterWorkerDto } from './dto/register-worker.dto';
import { PasswordService } from './password.service';

// Compte renvoyé au client : jamais le hash du mot de passe.
export type PublicAccount = Omit<User, 'passwordHash'> & {
  company: Company | null;
  worker: Worker | null;
};

type UserWithProfile = User & { company: Company | null; worker: Worker | null };

export const INVALID_CREDENTIALS_MESSAGE = 'Email ou mot de passe incorrect';

const PROFILE_INCLUDE = { company: true, worker: true } as const;

@Injectable()
export class AuthService {
  // Hash factice vérifié quand l'email est inconnu : la réponse prend le même temps
  // qu'avec un compte existant, ce qui empêche de deviner les emails inscrits.
  private readonly dummyHash: Promise<string>;

  constructor(
    private readonly prisma: PrismaService,
    private readonly passwords: PasswordService,
  ) {
    this.dummyHash = this.passwords.hash('cadans-compte-inexistant');
  }

  async registerCompany(dto: RegisterCompanyDto): Promise<PublicAccount> {
    // acceptConditions est retiré du profil : c'est une acceptation, pas une donnée
    // d'entreprise. Elle est enregistrée sur le compte, sous forme de date.
    const { email, password, acceptConditions: _accepted, ...company } = dto;
    const passwordHash = await this.passwords.hash(password);

    // Compte et profil sont créés dans la même requête, donc de façon atomique.
    const user = await this.createUser(() =>
      this.prisma.user.create({
        data: {
          email,
          passwordHash,
          role: Role.COMPANY,
          conditionsAcceptedAt: new Date(),
          company: { create: company },
        },
        include: PROFILE_INCLUDE,
      }),
    );

    return toPublicAccount(user);
  }

  async registerWorker(dto: RegisterWorkerDto): Promise<PublicAccount> {
    const { email, password, acceptConditions: _accepted, ...worker } = dto;
    const passwordHash = await this.passwords.hash(password);

    const user = await this.createUser(() =>
      this.prisma.user.create({
        data: {
          email,
          passwordHash,
          role: Role.WORKER,
          conditionsAcceptedAt: new Date(),
          worker: { create: worker },
        },
        include: PROFILE_INCLUDE,
      }),
    );

    return toPublicAccount(user);
  }

  // Vérifie les identifiants. Le token de session est posé par le contrôleur.
  async login(dto: LoginDto): Promise<PublicAccount> {
    const user = await this.prisma.user.findUnique({
      where: { email: dto.email },
      include: PROFILE_INCLUDE,
    });

    const valid = await this.passwords.verify(
      user?.passwordHash ?? (await this.dummyHash),
      dto.password,
    );

    if (!user || !valid) {
      throw new UnauthorizedException(INVALID_CREDENTIALS_MESSAGE);
    }

    return toPublicAccount(user);
  }

  // Compte de l'utilisateur connecté. Le token reste valide jusqu'à expiration même si
  // le compte a été supprimé entre-temps : on le détecte ici.
  async getAccount(userId: string): Promise<PublicAccount> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: PROFILE_INCLUDE,
    });

    if (!user) {
      throw new UnauthorizedException('Session invalide');
    }

    return toPublicAccount(user);
  }

  private async createUser(create: () => Promise<UserWithProfile>): Promise<UserWithProfile> {
    try {
      return await create();
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException(conflictMessage(error.meta?.target));
      }
      throw error;
    }
  }
}

function conflictMessage(target: unknown): string {
  const fields = Array.isArray(target) ? target.map(String) : [String(target)];
  return fields.some((field) => field.includes('siret'))
    ? 'Une entreprise est déjà inscrite avec ce SIRET'
    : 'Un compte existe déjà avec cette adresse email';
}

function toPublicAccount(user: UserWithProfile): PublicAccount {
  const { passwordHash, ...account } = user;
  return account;
}
