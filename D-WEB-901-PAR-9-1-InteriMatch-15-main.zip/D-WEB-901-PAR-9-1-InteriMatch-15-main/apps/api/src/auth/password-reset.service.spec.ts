import { BadRequestException } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { createHash } from 'node:crypto';
import { MailService } from '../mail/mail.service';
import { PrismaService } from '../prisma/prisma.service';
import {
  INVALID_RESET_TOKEN_MESSAGE,
  PasswordResetService,
  RESET_TOKEN_TTL_MINUTES,
} from './password-reset.service';
import { PasswordService } from './password.service';

const user = { id: 'user-1', email: 'samir@example.fr' };

// Le jeton n'apparaît que dans le lien envoyé : les tests le récupèrent là, comme le ferait
// la personne qui reçoit l'email.
function tokenFromLink(link: string): string {
  return decodeURIComponent(new URL(link).searchParams.get('token') ?? '');
}

const sha256 = (value: string): string => createHash('sha256').update(value).digest('hex');

describe('PasswordResetService', () => {
  let service: PasswordResetService;
  let prisma: {
    user: { findUnique: jest.Mock; update: jest.Mock };
    passwordResetToken: { create: jest.Mock; findUnique: jest.Mock; updateMany: jest.Mock };
  };
  let mail: { send: jest.Mock };

  beforeEach(async () => {
    prisma = {
      user: { findUnique: jest.fn().mockResolvedValue(user), update: jest.fn() },
      passwordResetToken: {
        create: jest.fn(),
        findUnique: jest.fn(),
        updateMany: jest.fn().mockResolvedValue({ count: 1 }),
      },
    };
    mail = { send: jest.fn().mockResolvedValue(undefined) };

    const moduleRef = await Test.createTestingModule({
      providers: [
        PasswordResetService,
        { provide: PrismaService, useValue: prisma },
        {
          provide: PasswordService,
          useValue: { hash: jest.fn((password: string) => Promise.resolve(`hash:${password}`)) },
        },
        { provide: MailService, useValue: mail },
      ],
    }).compile();

    service = moduleRef.get(PasswordResetService);
  });

  describe('request', () => {
    it(`envoie un lien valable ${RESET_TOKEN_TTL_MINUTES} minutes et ne stocke que l'empreinte`, async () => {
      await service.request(user.email);

      expect(mail.send).toHaveBeenCalledTimes(1);
      const { to, text } = mail.send.mock.calls[0][0] as { to: string; text: string };
      expect(to).toBe(user.email);

      const link = /https?:\/\/\S+/.exec(text)?.[0] ?? '';
      const token = tokenFromLink(link);
      expect(token).not.toBe('');

      const { data } = prisma.passwordResetToken.create.mock.calls[0][0] as {
        data: { userId: string; tokenHash: string; expiresAt: Date };
      };
      expect(data.userId).toBe(user.id);
      // Le jeton en clair ne doit jamais atteindre la base.
      expect(data.tokenHash).toBe(sha256(token));
      expect(data.tokenHash).not.toContain(token);

      const minutes = (data.expiresAt.getTime() - Date.now()) / 60_000;
      expect(minutes).toBeGreaterThan(RESET_TOKEN_TTL_MINUTES - 1);
      expect(minutes).toBeLessThanOrEqual(RESET_TOKEN_TTL_MINUTES);
    });

    it('révoque les liens déjà en circulation avant d’en émettre un nouveau', async () => {
      await service.request(user.email);

      expect(prisma.passwordResetToken.updateMany).toHaveBeenCalledWith({
        where: { userId: user.id, usedAt: null },
        data: { usedAt: expect.any(Date) },
      });
    });

    it("n'écrit rien et n'envoie rien pour une adresse inconnue", async () => {
      prisma.user.findUnique.mockResolvedValue(null);

      await expect(service.request('inconnu@example.fr')).resolves.toBeUndefined();

      expect(prisma.passwordResetToken.create).not.toHaveBeenCalled();
      expect(mail.send).not.toHaveBeenCalled();
    });

    it('tire un jeton différent à chaque demande', async () => {
      await service.request(user.email);
      await service.request(user.email);

      const [first, second] = prisma.passwordResetToken.create.mock.calls.map(
        (call: [{ data: { tokenHash: string } }]) => call[0].data.tokenHash,
      );
      expect(first).not.toBe(second);
    });
  });

  describe('confirm', () => {
    const future = (): Date => new Date(Date.now() + 10 * 60 * 1000);

    it('change le mot de passe puis consomme le lien', async () => {
      prisma.passwordResetToken.findUnique.mockResolvedValue({
        id: 'token-1',
        userId: user.id,
        expiresAt: future(),
        usedAt: null,
      });

      await service.confirm('jeton-en-clair', 'Nouveau!MotDePasse1');

      expect(prisma.passwordResetToken.updateMany).toHaveBeenCalledWith({
        where: { id: 'token-1', usedAt: null },
        data: { usedAt: expect.any(Date) },
      });
      expect(prisma.user.update).toHaveBeenCalledWith({
        where: { id: user.id },
        data: { passwordHash: 'hash:Nouveau!MotDePasse1' },
      });
    });

    it('cherche le jeton par son empreinte, jamais par sa valeur', async () => {
      prisma.passwordResetToken.findUnique.mockResolvedValue({
        id: 'token-1',
        userId: user.id,
        expiresAt: future(),
        usedAt: null,
      });

      await service.confirm('jeton-en-clair', 'Nouveau!MotDePasse1');

      expect(prisma.passwordResetToken.findUnique).toHaveBeenCalledWith({
        where: { tokenHash: sha256('jeton-en-clair') },
      });
    });

    it('refuse un jeton inconnu', async () => {
      prisma.passwordResetToken.findUnique.mockResolvedValue(null);

      await expect(service.confirm('inconnu', 'Nouveau!MotDePasse1')).rejects.toThrow(
        new BadRequestException(INVALID_RESET_TOKEN_MESSAGE),
      );
      expect(prisma.user.update).not.toHaveBeenCalled();
    });

    it('refuse un jeton expiré', async () => {
      prisma.passwordResetToken.findUnique.mockResolvedValue({
        id: 'token-1',
        userId: user.id,
        expiresAt: new Date(Date.now() - 1000),
        usedAt: null,
      });

      await expect(service.confirm('expire', 'Nouveau!MotDePasse1')).rejects.toThrow(
        INVALID_RESET_TOKEN_MESSAGE,
      );
      expect(prisma.user.update).not.toHaveBeenCalled();
    });

    // Deux requêtes simultanées avec le même lien : PostgreSQL n'en laisse aboutir qu'une,
    // la seconde voit `count: 0` et doit être refusée.
    it('refuse un jeton déjà consommé par une requête concurrente', async () => {
      prisma.passwordResetToken.findUnique.mockResolvedValue({
        id: 'token-1',
        userId: user.id,
        expiresAt: future(),
        usedAt: null,
      });
      prisma.passwordResetToken.updateMany.mockResolvedValue({ count: 0 });

      await expect(service.confirm('deja-utilise', 'Nouveau!MotDePasse1')).rejects.toThrow(
        INVALID_RESET_TOKEN_MESSAGE,
      );
      expect(prisma.user.update).not.toHaveBeenCalled();
    });
  });
});
