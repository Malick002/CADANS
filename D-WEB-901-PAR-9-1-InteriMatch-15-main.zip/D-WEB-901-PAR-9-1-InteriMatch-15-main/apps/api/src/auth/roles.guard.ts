import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Role } from '@prisma/client';
import { AuthenticatedRequest, ROLES_KEY } from './decorators';

// Garde globale : applique @Roles(...). Sans décorateur, la route est ouverte à tout
// utilisateur connecté. S'exécute après SessionGuard, qui a déjà posé request.user.
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const roles = this.reflector.getAllAndOverride<Role[] | undefined>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!roles || roles.length === 0) {
      return true;
    }

    const { user } = context.switchToHttp().getRequest<AuthenticatedRequest>();
    if (!user) {
      throw new UnauthorizedException('Authentification requise');
    }
    if (!roles.includes(user.role)) {
      throw new ForbiddenException("Cette action n'est pas autorisée pour votre type de compte");
    }

    return true;
  }
}
