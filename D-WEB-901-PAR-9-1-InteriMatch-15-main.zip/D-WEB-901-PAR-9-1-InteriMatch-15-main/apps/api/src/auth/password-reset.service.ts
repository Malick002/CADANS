import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { createHash, randomBytes } from 'node:crypto';
import { MailService } from '../mail/mail.service';
import { PrismaService } from '../prisma/prisma.service';
import { PasswordService } from './password.service';

// Durée de vie du lien. Assez court pour qu'une boîte mail consultée plus tard ne rouvre
// pas le compte, assez long pour laisser le temps de relever ses messages.
export const RESET_TOKEN_TTL_MINUTES = 30;

// 32 octets tirés au sort : 256 bits d'entropie, hors de portée d'une recherche exhaustive.
const TOKEN_BYTES = 32;

// Message unique pour tous les refus de jeton : inconnu, déjà utilisé ou expiré. Distinguer
// les trois cas renseignerait sur l'existence d'un compte et sur l'état de ses liens.
export const INVALID_RESET_TOKEN_MESSAGE =
  'Ce lien de réinitialisation est invalide ou a expiré. Demandez-en un nouveau.';

/**
 * Réinitialisation de mot de passe par lien à usage unique envoyé par email.
 *
 * Deux principes tiennent tout le service :
 *
 * 1. **La demande ne dit jamais si le compte existe.** Elle répond la même chose, de la
 *    même façon, qu'une adresse soit inscrite ou non : sans quoi le formulaire deviendrait
 *    un moyen de tester quelles adresses sont sur la plateforme.
 * 2. **Le jeton n'est jamais stocké en clair.** Seule son empreinte SHA-256 est en base,
 *    comme un mot de passe n'y est que sous forme de hash.
 */
@Injectable()
export class PasswordResetService {
  private readonly logger = new Logger(PasswordResetService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly passwords: PasswordService,
    private readonly mail: MailService,
  ) {}

  async request(email: string): Promise<void> {
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (!user) {
      // Adresse inconnue : on ne crée rien et on n'envoie rien, mais le contrôleur
      // répondra exactement comme pour un compte existant.
      return;
    }

    // Un seul lien actif à la fois : demander un nouveau lien invalide le précédent.
    await this.revokeTokensOf(user.id);

    const token = randomBytes(TOKEN_BYTES).toString('base64url');
    await this.prisma.passwordResetToken.create({
      data: {
        userId: user.id,
        tokenHash: hashToken(token),
        expiresAt: new Date(Date.now() + RESET_TOKEN_TTL_MINUTES * 60 * 1000),
      },
    });

    // Envoi non attendu : la réponse HTTP part sans dépendre du fournisseur d'emails.
    // Cela garde aussi le même temps de réponse qu'avec une adresse inconnue — attendre
    // l'appel réseau rendrait les comptes existants reconnaissables au chronomètre.
    void this.mail.send(resetEmail(user.email, resetLink(token), user.id));
  }

  async confirm(token: string, password: string): Promise<void> {
    const record = await this.prisma.passwordResetToken.findUnique({
      where: { tokenHash: hashToken(token) },
    });

    if (!record || record.expiresAt <= new Date()) {
      throw new BadRequestException(INVALID_RESET_TOKEN_MESSAGE);
    }

    // Consommation atomique : la condition `usedAt: null` est évaluée par PostgreSQL au
    // moment de l'écriture. Deux requêtes simultanées avec le même lien n'en voient
    // qu'une aboutir, là où un test suivi d'une écriture laisserait passer les deux.
    const claimed = await this.prisma.passwordResetToken.updateMany({
      where: { id: record.id, usedAt: null },
      data: { usedAt: new Date() },
    });
    if (claimed.count === 0) {
      throw new BadRequestException(INVALID_RESET_TOKEN_MESSAGE);
    }

    await this.prisma.user.update({
      where: { id: record.userId },
      data: { passwordHash: await this.passwords.hash(password) },
    });

    // Les autres liens éventuellement en circulation tombent avec le changement.
    await this.revokeTokensOf(record.userId);

    // Les sessions JWT déjà émises restent valides jusqu'à leur expiration : sans
    // stockage des sessions, l'API ne sait pas les révoquer. À traiter le jour où une
    // liste de révocation existera.
    this.logger.log(`Mot de passe réinitialisé pour le compte ${record.userId}`);
  }

  private async revokeTokensOf(userId: string): Promise<void> {
    await this.prisma.passwordResetToken.updateMany({
      where: { userId, usedAt: null },
      data: { usedAt: new Date() },
    });
  }
}

// SHA-256 suffit ici, là où les mots de passe exigent argon2 : le jeton est tiré au sort
// sur 256 bits, il n'y a pas de dictionnaire à lui opposer.
function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

function resetLink(token: string): string {
  const base = (process.env.WEB_URL ?? 'http://localhost:3000').replace(/\/$/, '');
  return `${base}/reinitialiser-mot-de-passe?token=${encodeURIComponent(token)}`;
}

function resetEmail(to: string, link: string, userId: string) {
  const subject = 'Réinitialiser votre mot de passe CADANS';
  const intro =
    'Vous avez demandé à réinitialiser le mot de passe de votre compte CADANS. ' +
    `Ce lien est valable ${RESET_TOKEN_TTL_MINUTES} minutes et ne peut servir qu'une fois.`;
  const outro =
    "Si vous n'êtes pas à l'origine de cette demande, ignorez ce message : votre mot de " +
    'passe reste inchangé.';

  return {
    to,
    subject,
    text: `${intro}\n\n${link}\n\n${outro}`,
    html:
      `<p>${intro}</p>` +
      `<p><a href="${link}">Choisir un nouveau mot de passe</a></p>` +
      `<p>${outro}</p>`,
    // Un jeton par demande, donc une clé par demande : une relance réseau ne renvoie
    // pas deux fois le même message.
    idempotencyKey: `password-reset/${userId}-${hashToken(link).slice(0, 16)}`,
  };
}
