import { Transform, TransformFnParams } from 'class-transformer';
import { registerDecorator, ValidationOptions } from 'class-validator';

// Supprime les espaces en début et fin de chaîne avant validation.
export const Trim = (): PropertyDecorator =>
  Transform(({ value }: TransformFnParams): unknown =>
    typeof value === 'string' ? value.trim() : value,
  );

// Supprime tous les espaces : SIRET et téléphone sont souvent saisis par blocs.
export const StripSpaces = (): PropertyDecorator =>
  Transform(({ value }: TransformFnParams): unknown =>
    typeof value === 'string' ? value.replace(/\s+/g, '') : value,
  );

export const NormalizeEmail = (): PropertyDecorator =>
  Transform(({ value }: TransformFnParams): unknown =>
    typeof value === 'string' ? value.trim().toLowerCase() : value,
  );

// Recommandation CNIL (délibération 2022-100) : au moins 12 caractères mêlant
// majuscules, minuscules, chiffres et caractères spéciaux.
export const PASSWORD_MIN_LENGTH = 12;
// Borne haute : évite de faire hacher des chaînes démesurées (argon2 est coûteux).
export const PASSWORD_MAX_LENGTH = 128;
export const PASSWORD_PATTERN = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).+$/;
export const PASSWORD_MESSAGE =
  'Le mot de passe doit contenir au moins une minuscule, une majuscule, un chiffre et un caractère spécial';

export const POSTAL_CODE_PATTERN = /^\d{5}$/;
// Numéro français : 0X XX XX XX XX ou +33 X XX XX XX XX (espaces retirés avant test).
export const PHONE_PATTERN = /^(?:0|\+33)[1-9]\d{8}$/;
// Code NAF/APE : deux chiffres, point, deux chiffres, une lettre (ex. 52.10B).
export const NAF_CODE_PATTERN = /^\d{2}\.\d{2}[A-Z]$/;

// La Poste a un SIRET dérogatoire à la clé de Luhn : la somme de ses chiffres est
// un multiple de 5.
const LA_POSTE_SIREN = '356000000';

export function isValidSiret(value: string): boolean {
  if (!/^\d{14}$/.test(value)) {
    return false;
  }

  if (value.startsWith(LA_POSTE_SIREN)) {
    const sum = [...value].reduce((total, digit) => total + Number(digit), 0);
    return sum % 5 === 0;
  }

  // Clé de Luhn : un chiffre sur deux est doublé en partant de la droite.
  const sum = [...value].reverse().reduce((total, char, index) => {
    let digit = Number(char);
    if (index % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    return total + digit;
  }, 0);

  return sum % 10 === 0;
}

export function IsSiret(options?: ValidationOptions): PropertyDecorator {
  return (target: object, propertyName: string | symbol): void => {
    registerDecorator({
      name: 'isSiret',
      target: target.constructor,
      propertyName: propertyName.toString(),
      options: { message: 'Le SIRET doit comporter 14 chiffres valides', ...options },
      validator: {
        validate: (value: unknown): boolean => typeof value === 'string' && isValidSiret(value),
      },
    });
  };
}
