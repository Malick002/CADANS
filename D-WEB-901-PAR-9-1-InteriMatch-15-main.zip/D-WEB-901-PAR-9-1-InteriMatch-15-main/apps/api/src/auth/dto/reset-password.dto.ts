import { IsNotEmpty, IsString, Matches, MaxLength, MinLength } from 'class-validator';
import {
  PASSWORD_MAX_LENGTH,
  PASSWORD_MESSAGE,
  PASSWORD_MIN_LENGTH,
  PASSWORD_PATTERN,
} from './validation';

// Choix du nouveau mot de passe, avec le jeton reçu par email. Les règles de complexité
// sont celles de l'inscription (CredentialsDto) : on ne réinitialise pas vers un mot de
// passe que la plateforme aurait refusé à la création.
export class ResetPasswordDto {
  @IsString()
  @IsNotEmpty()
  // 32 octets en base64url font 43 caractères ; la borne évite de hacher une chaîne
  // démesurée avant même de constater que le jeton est inconnu.
  @MaxLength(64)
  token: string;

  @IsString()
  @MinLength(PASSWORD_MIN_LENGTH, {
    message: `Le mot de passe doit contenir au moins ${PASSWORD_MIN_LENGTH} caractères`,
  })
  @MaxLength(PASSWORD_MAX_LENGTH)
  @Matches(PASSWORD_PATTERN, { message: PASSWORD_MESSAGE })
  password: string;
}
