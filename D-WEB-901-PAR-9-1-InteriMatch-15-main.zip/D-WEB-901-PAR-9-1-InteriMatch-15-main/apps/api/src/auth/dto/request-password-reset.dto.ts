import { IsEmail, MaxLength } from 'class-validator';
import { NormalizeEmail } from './validation';

// Demande d'un lien de réinitialisation. Seule l'adresse est demandée ; la réponse est la
// même que le compte existe ou non (voir PasswordResetService).
export class RequestPasswordResetDto {
  @NormalizeEmail()
  @IsEmail({}, { message: "L'adresse email n'est pas valide" })
  @MaxLength(255)
  email: string;
}
