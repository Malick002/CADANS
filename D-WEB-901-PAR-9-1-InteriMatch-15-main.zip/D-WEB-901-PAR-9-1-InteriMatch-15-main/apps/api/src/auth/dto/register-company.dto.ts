import { IsNotEmpty, IsOptional, IsString, Matches, MaxLength } from 'class-validator';
import { CredentialsDto } from './credentials.dto';
import {
  IsSiret,
  NAF_CODE_PATTERN,
  PHONE_PATTERN,
  POSTAL_CODE_PATTERN,
  StripSpaces,
  Trim,
} from './validation';

export class RegisterCompanyDto extends CredentialsDto {
  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  legalName: string;

  @StripSpaces()
  @IsSiret()
  siret: string;

  // Format seulement, volontairement : une entreprise hors entreposage (codes 52.10A,
  // 52.10B, 52.24B) peut avoir besoin de missions logistiques. Le code NAF sert au
  // ciblage, il ne bloque pas l'inscription.
  @Trim()
  @Matches(NAF_CODE_PATTERN, { message: 'Le code NAF doit être au format 52.10B' })
  nafCode: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  contactFirstName: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  contactLastName: string;

  @IsOptional()
  @StripSpaces()
  @Matches(PHONE_PATTERN, { message: "Le numéro de téléphone n'est pas valide" })
  phone?: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  addressLine: string;

  @Trim()
  @Matches(POSTAL_CODE_PATTERN, { message: 'Le code postal doit comporter 5 chiffres' })
  postalCode: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  city: string;
}
