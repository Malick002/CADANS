import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { LoginDto } from './login.dto';
import { RegisterCompanyDto } from './register-company.dto';
import { RegisterWorkerDto } from './register-worker.dto';
import { isValidSiret } from './validation';

const validCompany = {
  acceptConditions: true,
  email: 'Contact@Entrepot-Nord.fr ',
  password: 'Cariste#2026ok',
  legalName: ' Entrepôt du Nord ',
  siret: '732 829 320 00074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  phone: '06 12 34 56 78',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

const validWorker = {
  acceptConditions: true,
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '01000',
  city: 'Bourg-en-Bresse',
};

async function errorsFor<T extends object>(
  dto: new () => T,
  payload: object,
): Promise<{ instance: T; fields: string[] }> {
  const instance = plainToInstance(dto, payload);
  const errors = await validate(instance, { whitelist: true, forbidNonWhitelisted: true });
  return { instance, fields: errors.map((error) => error.property) };
}

describe('isValidSiret', () => {
  it('accepte un SIRET dont la clé de Luhn est correcte', () => {
    expect(isValidSiret('73282932000074')).toBe(true);
  });

  it('refuse un SIRET dont la clé de Luhn est fausse', () => {
    expect(isValidSiret('73282932000075')).toBe(false);
  });

  it('refuse un SIRET qui ne fait pas 14 chiffres', () => {
    expect(isValidSiret('7328293200007')).toBe(false);
    expect(isValidSiret('7328293200007A')).toBe(false);
  });

  it('applique la règle dérogatoire de La Poste', () => {
    // Somme des chiffres = 15, multiple de 5, alors que la clé de Luhn est fausse.
    expect(isValidSiret('35600000000001')).toBe(true);
    // Clé de Luhn correcte mais somme = 19 : refusé pour La Poste.
    expect(isValidSiret('35600000000014')).toBe(false);
  });
});

describe('RegisterCompanyDto', () => {
  it('accepte une inscription valide et normalise les champs', async () => {
    const { instance, fields } = await errorsFor(RegisterCompanyDto, validCompany);

    expect(fields).toEqual([]);
    expect(instance.email).toBe('contact@entrepot-nord.fr');
    expect(instance.legalName).toBe('Entrepôt du Nord');
    expect(instance.siret).toBe('73282932000074');
    expect(instance.phone).toBe('0612345678');
  });

  it.each([
    ['email', { email: 'pas-un-email' }],
    ['password', { password: 'court1A!' }],
    ['password', { password: 'sanschiffreNiSpecial' }],
    ['siret', { siret: '12345678901234' }],
    ['nafCode', { nafCode: '5210B' }],
    ['postalCode', { postalCode: '5900' }],
    ['phone', { phone: '12345' }],
    ['legalName', { legalName: '   ' }],
    ['acceptConditions', { acceptConditions: false }],
    ['acceptConditions', { acceptConditions: undefined }],
  ])('refuse un champ %s invalide', async (field, override) => {
    const { fields } = await errorsFor(RegisterCompanyDto, { ...validCompany, ...override });

    expect(fields).toContain(field);
  });

  it('refuse un champ inconnu (ex. tentative de choisir son rôle)', async () => {
    const { fields } = await errorsFor(RegisterCompanyDto, { ...validCompany, role: 'WORKER' });

    expect(fields).toContain('role');
  });
});

describe('RegisterWorkerDto', () => {
  it('accepte une inscription valide sans téléphone et garde le zéro du code postal', async () => {
    const { instance, fields } = await errorsFor(RegisterWorkerDto, validWorker);

    expect(fields).toEqual([]);
    expect(instance.postalCode).toBe('01000');
  });

  it('exige la ville et le code postal', async () => {
    const { fields } = await errorsFor(RegisterWorkerDto, {
      ...validWorker,
      city: undefined,
      postalCode: undefined,
    });

    expect(fields).toEqual(expect.arrayContaining(['city', 'postalCode']));
  });
});

describe('LoginDto', () => {
  it("n'applique pas la règle de complexité à la connexion", async () => {
    const { fields } = await errorsFor(LoginDto, { email: 'a@b.fr', password: 'simple' });

    expect(fields).toEqual([]);
  });
});
