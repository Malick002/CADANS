import { IsEmail, IsString, MaxLength, MinLength } from 'class-validator';
import { NormalizeEmail, PASSWORD_MAX_LENGTH } from './validation';

// Pas de règle de complexité à la connexion : elle révélerait la politique de mot
// de passe et bloquerait inutilement. On borne seulement la taille.
export class LoginDto {
  @NormalizeEmail()
  @IsEmail({}, { message: "L'adresse email n'est pas valide" })
  @MaxLength(255)
  email: string;

  @IsString()
  @MinLength(1)
  @MaxLength(PASSWORD_MAX_LENGTH)
  password: string;
}
