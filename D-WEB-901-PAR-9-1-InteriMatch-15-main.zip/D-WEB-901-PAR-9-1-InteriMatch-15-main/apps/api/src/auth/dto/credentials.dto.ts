import { Equals, IsEmail, IsString, Matches, MaxLength, MinLength } from 'class-validator';
import {
  NormalizeEmail,
  PASSWORD_MAX_LENGTH,
  PASSWORD_MESSAGE,
  PASSWORD_MIN_LENGTH,
  PASSWORD_PATTERN,
} from './validation';

// Identifiants communs aux deux parcours d'inscription.
export class CredentialsDto {
  @NormalizeEmail()
  @IsEmail({}, { message: "L'adresse email n'est pas valide" })
  @MaxLength(255)
  email: string;

  @IsString()
  @MinLength(PASSWORD_MIN_LENGTH, {
    message: `Le mot de passe doit contenir au moins ${PASSWORD_MIN_LENGTH} caractères`,
  })
  @MaxLength(PASSWORD_MAX_LENGTH)
  @Matches(PASSWORD_PATTERN, { message: PASSWORD_MESSAGE })
  password: string;

  // Acceptation de la politique de confidentialité, obligatoire pour créer un compte.
  // Vérifiée ici et pas seulement dans le navigateur : une inscription envoyée directement
  // à l'API contournerait sinon la case à cocher. La date est enregistrée par AuthService.
  @Equals(true, {
    message: 'Vous devez accepter la politique de confidentialité pour créer un compte',
  })
  acceptConditions: boolean;
}
