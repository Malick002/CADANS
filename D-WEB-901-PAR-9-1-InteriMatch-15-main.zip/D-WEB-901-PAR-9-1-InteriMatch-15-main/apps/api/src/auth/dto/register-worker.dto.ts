import { IsNotEmpty, IsOptional, IsString, Matches, MaxLength } from 'class-validator';
import { CredentialsDto } from './credentials.dto';
import { PHONE_PATTERN, POSTAL_CODE_PATTERN, StripSpaces, Trim } from './validation';

export class RegisterWorkerDto extends CredentialsDto {
  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  firstName: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  lastName: string;

  @IsOptional()
  @StripSpaces()
  @Matches(PHONE_PATTERN, { message: "Le numéro de téléphone n'est pas valide" })
  phone?: string;

  @Trim()
  @Matches(POSTAL_CODE_PATTERN, { message: 'Le code postal doit comporter 5 chiffres' })
  postalCode: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  city: string;
}
