import { Injectable } from '@nestjs/common';
import { Role } from '@prisma/client';
import { createHmac, timingSafeEqual } from 'node:crypto';

// Utilisateur authentifié, tel que porté par le token.
export interface SessionUser {
  id: string;
  role: Role;
}

interface TokenPayload {
  sub: string;
  role: Role;
  iat: number;
  exp: number;
}

// Durée d'une session. Pas de token de rafraîchissement dans le POC : l'utilisateur se
// reconnecte à l'expiration.
//
// UNE HEURE, et c'est un choix de sécurité, pas de confort. Les sessions sont SANS ÉTAT :
// l'API ne stocke rien et ne relit pas le compte à chaque requête (SessionGuard est
// volontairement synchrone), elle ne sait donc pas révoquer un jeton déjà émis. Un
// changement de mot de passe ne ferme pas les sessions en cours — cette durée est donc,
// littéralement, la fenêtre pendant laquelle un jeton volé reste utilisable. Elle était de
// 8 h ; la ramener à 1 h divise cette fenêtre par huit pour le seul prix d'une reconnexion.
//
// Les trois options étudiées, et pourquoi celle-ci : docs/perspectives.md, « Sessions ».
//
// Source unique : `sign()` la pose en `exp`, et session-cookie.ts en fait le `maxAge` du
// cookie. Les deux expirent donc ensemble — ne pas dupliquer cette valeur ailleurs.
export const SESSION_TTL_SECONDS = 60 * 60;

// 32 octets minimum pour une clé HMAC-SHA256 (RFC 7518, section 3.2).
const MIN_SECRET_LENGTH = 32;

// Valeur d'exemple de .env.example : publique (commitée dans le dépôt), elle permettrait de
// forger des sessions. Tolérée en local, refusée en production. À garder synchronisée.
export const EXAMPLE_JWT_SECRET = 'change-moi-en-local-comme-en-prod';

// En-tête fixe : on n'émet et n'accepte que HS256. Comparer l'en-tête à cette valeur
// exacte ferme les attaques par changement d'algorithme (« alg: none »).
const HEADER = base64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));

const ROLES = new Set<string>(Object.values(Role));

/**
 * JWT HS256 implémenté à la main avec node:crypto, sans librairie : le sujet impose
 * que l'authentification classique soit développée par l'équipe.
 */
@Injectable()
export class TokenService {
  private readonly secret: Buffer;

  constructor() {
    const secret = process.env.JWT_SECRET;
    if (!secret || secret.length < MIN_SECRET_LENGTH) {
      // On refuse de démarrer plutôt que de signer avec une clé faible ou vide.
      throw new Error(
        `JWT_SECRET absente ou trop courte (${MIN_SECRET_LENGTH} caractères minimum). ` +
          'Copie .env.example en .env.',
      );
    }
    if (process.env.NODE_ENV === 'production' && secret === EXAMPLE_JWT_SECRET) {
      throw new Error(
        "JWT_SECRET vaut la valeur d'exemple de .env.example, publique : interdit en production. " +
          'Générer un secret : openssl rand -base64 48',
      );
    }
    this.secret = Buffer.from(secret, 'utf8');
  }

  sign(user: SessionUser): string {
    const now = Math.floor(Date.now() / 1000);
    const payload: TokenPayload = {
      sub: user.id,
      role: user.role,
      iat: now,
      exp: now + SESSION_TTL_SECONDS,
    };
    const unsigned = `${HEADER}.${base64url(JSON.stringify(payload))}`;
    return `${unsigned}.${this.signature(unsigned)}`;
  }

  // Renvoie l'utilisateur si le token est intègre et non expiré, null sinon.
  verify(token: string): SessionUser | null {
    const parts = token.split('.');
    if (parts.length !== 3) {
      return null;
    }

    const [header, body, signature] = parts;
    if (header !== HEADER) {
      return null;
    }

    // Signature vérifiée avant toute lecture du contenu, en temps constant.
    const expected = Buffer.from(this.signature(`${header}.${body}`));
    const received = Buffer.from(signature);
    if (expected.length !== received.length || !timingSafeEqual(expected, received)) {
      return null;
    }

    const payload = parsePayload(body);
    if (!payload || payload.exp <= Math.floor(Date.now() / 1000)) {
      return null;
    }

    return { id: payload.sub, role: payload.role };
  }

  private signature(unsigned: string): string {
    return createHmac('sha256', this.secret).update(unsigned).digest('base64url');
  }
}

function base64url(value: string): string {
  return Buffer.from(value, 'utf8').toString('base64url');
}

function parsePayload(body: string): TokenPayload | null {
  try {
    const payload: unknown = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (
      typeof payload === 'object' &&
      payload !== null &&
      'sub' in payload &&
      'role' in payload &&
      'exp' in payload &&
      typeof payload.sub === 'string' &&
      typeof payload.role === 'string' &&
      ROLES.has(payload.role) &&
      typeof payload.exp === 'number'
    ) {
      return payload as TokenPayload;
    }
    return null;
  } catch {
    return null;
  }
}
