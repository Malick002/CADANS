import { CookieOptions } from 'express';
import { SESSION_TTL_SECONDS } from './token.service';

export const SESSION_COOKIE = 'cadans_session';

// Origine du site autorisée à appeler l'API avec la session (CORS et contrôle CSRF).
export function allowedWebOrigin(): string {
  return process.env.WEB_URL ?? 'http://localhost:3000';
}

// Cookie httpOnly : illisible par le JavaScript de la page, donc hors de portée d'un
// script injecté (XSS). En production, le site et l'API sont deux services Render, sur des
// domaines différents : le cookie doit être SameSite=None, ce qui impose Secure (HTTPS).
// La protection CSRF est alors assurée par le contrôle d'origine (voir SessionGuard).
export function sessionCookieOptions(): CookieOptions {
  const production = process.env.NODE_ENV === 'production';
  return {
    httpOnly: true,
    secure: production,
    sameSite: production ? 'none' : 'lax',
    path: '/',
  };
}

export function sessionCookieWithLifetime(): CookieOptions {
  return { ...sessionCookieOptions(), maxAge: SESSION_TTL_SECONDS * 1000 };
}

// Lecture d'un cookie dans l'en-tête Cookie, sans dépendance.
export function readCookie(header: string | undefined, name: string): string | undefined {
  if (!header) {
    return undefined;
  }

  for (const pair of header.split(';')) {
    const separator = pair.indexOf('=');
    if (separator === -1 || pair.slice(0, separator).trim() !== name) {
      continue;
    }
    const value = pair.slice(separator + 1).trim();
    try {
      return decodeURIComponent(value);
    } catch {
      return undefined;
    }
  }

  return undefined;
}
