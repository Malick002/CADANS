import { Injectable } from '@nestjs/common';
import * as argon2 from 'argon2';

// Paramètres argon2id : une des configurations équivalentes recommandées par l'OWASP
// (Password Storage Cheat Sheet) : m = 19 Mio, t = 2, p = 1.
// Plus sobre en mémoire que les réglages par défaut de la librairie (64 Mio, t = 3, p = 4)
// pour un niveau de protection jugé équivalent : chaque connexion hache un mot de passe,
// et des connexions simultanées sur une petite instance d'hébergement ne doivent pas
// saturer sa mémoire.
export const ARGON2_OPTIONS = {
  type: argon2.argon2id,
  memoryCost: 19456,
  timeCost: 2,
  parallelism: 1,
} as const;

// Le sel est généré par argon2 et stocké dans le hash lui-même, avec les paramètres :
// un hash produit avec d'anciens réglages reste vérifiable.
@Injectable()
export class PasswordService {
  hash(password: string): Promise<string> {
    return argon2.hash(password, ARGON2_OPTIONS);
  }

  async verify(hash: string, password: string): Promise<boolean> {
    try {
      return await argon2.verify(hash, password);
    } catch {
      // Hash illisible en base : on refuse plutôt que de faire échouer la requête.
      return false;
    }
  }
}
