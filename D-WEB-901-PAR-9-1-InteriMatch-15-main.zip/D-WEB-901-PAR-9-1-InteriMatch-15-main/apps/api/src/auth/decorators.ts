import { createParamDecorator, ExecutionContext, SetMetadata } from '@nestjs/common';
import { Role } from '@prisma/client';
import { Request } from 'express';
import { SessionUser } from './token.service';

export interface AuthenticatedRequest extends Request {
  user?: SessionUser;
}

export const IS_PUBLIC_KEY = 'isPublic';
export const ROLES_KEY = 'roles';

// Toutes les routes exigent une session par défaut : @Public() lève cette exigence.
export const Public = (): MethodDecorator & ClassDecorator => SetMetadata(IS_PUBLIC_KEY, true);

// Restreint une route à un ou plusieurs rôles, ex. @Roles(Role.COMPANY).
export const Roles = (...roles: Role[]): MethodDecorator & ClassDecorator =>
  SetMetadata(ROLES_KEY, roles);

// Injecte l'utilisateur de la session dans un handler : @CurrentUser() user: SessionUser.
export const CurrentUser = createParamDecorator(
  (_data: unknown, context: ExecutionContext): SessionUser | undefined =>
    context.switchToHttp().getRequest<AuthenticatedRequest>().user,
);
