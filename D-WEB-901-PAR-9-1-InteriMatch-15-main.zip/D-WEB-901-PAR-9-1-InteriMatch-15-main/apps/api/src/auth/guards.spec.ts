import { ExecutionContext, ForbiddenException, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Role } from '@prisma/client';
import { AuthenticatedRequest, IS_PUBLIC_KEY, ROLES_KEY } from './decorators';
import { RolesGuard } from './roles.guard';
import { SessionGuard } from './session.guard';
import { TokenService } from './token.service';

const worker = { id: 'u1', role: Role.WORKER };

function contextFor(request: Partial<AuthenticatedRequest>): ExecutionContext {
  return {
    switchToHttp: () => ({ getRequest: () => request }),
    getHandler: () => undefined,
    getClass: () => undefined,
  } as unknown as ExecutionContext;
}

function reflectorWith(metadata: Record<string, unknown>): Reflector {
  return {
    getAllAndOverride: (key: string) => metadata[key],
  } as unknown as Reflector;
}

describe('SessionGuard', () => {
  const tokens = {
    verify: jest.fn((token: string) => (token === 'valide' ? worker : null)),
  } as unknown as TokenService;

  const request = (overrides: Partial<AuthenticatedRequest> = {}): Partial<AuthenticatedRequest> =>
    ({ method: 'GET', headers: {}, ...overrides }) as Partial<AuthenticatedRequest>;

  it('pose l’utilisateur sur la requête quand le cookie est valide', () => {
    const guard = new SessionGuard(reflectorWith({}), tokens);
    const req = request({ headers: { cookie: 'cadans_session=valide' } });

    expect(guard.canActivate(contextFor(req))).toBe(true);
    expect(req.user).toEqual(worker);
  });

  it('bloque une route protégée sans session ou avec un token invalide', () => {
    const guard = new SessionGuard(reflectorWith({}), tokens);

    expect(() => guard.canActivate(contextFor(request()))).toThrow(UnauthorizedException);
    expect(() =>
      guard.canActivate(contextFor(request({ headers: { cookie: 'cadans_session=forge' } }))),
    ).toThrow(UnauthorizedException);
  });

  it('laisse passer une route publique sans session', () => {
    const guard = new SessionGuard(reflectorWith({ [IS_PUBLIC_KEY]: true }), tokens);

    expect(guard.canActivate(contextFor(request()))).toBe(true);
  });

  it("refuse une requête d'écriture venant d'un autre site (CSRF), même publique", () => {
    const guard = new SessionGuard(reflectorWith({ [IS_PUBLIC_KEY]: true }), tokens);
    const req = request({ method: 'POST', headers: { origin: 'https://site-pirate.example' } });

    expect(() => guard.canActivate(contextFor(req))).toThrow(ForbiddenException);
  });

  it('accepte une écriture depuis le site CADANS ou sans en-tête Origin', () => {
    const guard = new SessionGuard(reflectorWith({ [IS_PUBLIC_KEY]: true }), tokens);

    expect(
      guard.canActivate(
        contextFor(request({ method: 'POST', headers: { origin: 'http://localhost:3000' } })),
      ),
    ).toBe(true);
    expect(guard.canActivate(contextFor(request({ method: 'POST' })))).toBe(true);
  });
});

describe('RolesGuard', () => {
  it('laisse passer une route sans @Roles', () => {
    const guard = new RolesGuard(reflectorWith({}));

    expect(guard.canActivate(contextFor({ user: worker }))).toBe(true);
  });

  it('laisse passer un utilisateur qui a le rôle requis', () => {
    const guard = new RolesGuard(reflectorWith({ [ROLES_KEY]: [Role.WORKER] }));

    expect(guard.canActivate(contextFor({ user: worker }))).toBe(true);
  });

  it("refuse un utilisateur connecté qui n'a pas le rôle requis", () => {
    const guard = new RolesGuard(reflectorWith({ [ROLES_KEY]: [Role.COMPANY] }));

    expect(() => guard.canActivate(contextFor({ user: worker }))).toThrow(ForbiddenException);
  });

  it('refuse sans utilisateur sur une route à rôle', () => {
    const guard = new RolesGuard(reflectorWith({ [ROLES_KEY]: [Role.COMPANY] }));

    expect(() => guard.canActivate(contextFor({}))).toThrow(UnauthorizedException);
  });
});
