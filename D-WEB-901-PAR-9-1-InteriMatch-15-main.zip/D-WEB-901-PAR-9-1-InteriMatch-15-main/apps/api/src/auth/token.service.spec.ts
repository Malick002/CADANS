import { Role } from '@prisma/client';
import { createHmac } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { EXAMPLE_JWT_SECRET, SESSION_TTL_SECONDS, TokenService } from './token.service';

const SECRET = 'secret-de-test-assez-long-pour-hs256';
const user = { id: '8bd646b8-69fe-45fe-8a7b-178efea4967c', role: Role.WORKER };

const encode = (value: object): string => Buffer.from(JSON.stringify(value)).toString('base64url');

const signWith = (secret: string, header: object, payload: object): string => {
  const unsigned = `${encode(header)}.${encode(payload)}`;
  return `${unsigned}.${createHmac('sha256', secret).update(unsigned).digest('base64url')}`;
};

describe('TokenService', () => {
  const originalSecret = process.env.JWT_SECRET;
  let service: TokenService;

  beforeEach(() => {
    process.env.JWT_SECRET = SECRET;
    service = new TokenService();
  });

  afterEach(() => {
    process.env.JWT_SECRET = originalSecret;
    jest.useRealTimers();
  });

  it('refuse de démarrer sans secret ou avec un secret trop court', () => {
    delete process.env.JWT_SECRET;
    expect(() => new TokenService()).toThrow(/JWT_SECRET/);

    process.env.JWT_SECRET = 'trop-court';
    expect(() => new TokenService()).toThrow(/JWT_SECRET/);
  });

  describe("secret d'exemple de .env.example", () => {
    const originalNodeEnv = process.env.NODE_ENV;

    afterEach(() => {
      process.env.NODE_ENV = originalNodeEnv;
    });

    it('est refusé en production', () => {
      process.env.NODE_ENV = 'production';
      process.env.JWT_SECRET = EXAMPLE_JWT_SECRET;

      expect(() => new TokenService()).toThrow(/valeur d'exemple/);
    });

    it('reste accepté en local', () => {
      process.env.NODE_ENV = 'development';
      process.env.JWT_SECRET = EXAMPLE_JWT_SECRET;

      expect(() => new TokenService()).not.toThrow();
    });

    it('correspond bien à la valeur écrite dans .env.example', () => {
      const envExample = readFileSync(join(__dirname, '../../../../.env.example'), 'utf8');

      expect(envExample).toContain(`JWT_SECRET=${EXAMPLE_JWT_SECRET}\n`);
    });
  });

  it('produit un JWT HS256 standard vérifiable', () => {
    const token = service.sign(user);
    const [header, payload] = token.split('.');

    expect(JSON.parse(Buffer.from(header, 'base64url').toString())).toEqual({
      alg: 'HS256',
      typ: 'JWT',
    });
    expect(JSON.parse(Buffer.from(payload, 'base64url').toString())).toMatchObject({
      sub: user.id,
      role: 'WORKER',
    });
    expect(service.verify(token)).toEqual(user);
  });

  it('refuse un token dont le contenu a été modifié (élévation de rôle)', () => {
    const [header, payload, signature] = service.sign(user).split('.');
    const claims = JSON.parse(Buffer.from(payload, 'base64url').toString());
    const forged = `${header}.${encode({ ...claims, role: 'COMPANY' })}.${signature}`;

    expect(service.verify(forged)).toBeNull();
  });

  it('refuse un token signé avec une autre clé', () => {
    const now = Math.floor(Date.now() / 1000);
    const token = signWith(
      'une-autre-cle-tout-aussi-longue-que-la-vraie',
      { alg: 'HS256', typ: 'JWT' },
      { sub: user.id, role: user.role, iat: now, exp: now + 60 },
    );

    expect(service.verify(token)).toBeNull();
  });

  it('refuse un token « alg: none » sans signature', () => {
    const now = Math.floor(Date.now() / 1000);
    const token = `${encode({ alg: 'none', typ: 'JWT' })}.${encode({
      sub: user.id,
      role: user.role,
      exp: now + 60,
    })}.`;

    expect(service.verify(token)).toBeNull();
  });

  it('refuse un token expiré', () => {
    jest.useFakeTimers();
    jest.setSystemTime(new Date('2026-09-17T08:00:00Z'));
    const token = service.sign(user);

    jest.setSystemTime(new Date(Date.now() + (SESSION_TTL_SECONDS - 1) * 1000));
    expect(service.verify(token)).toEqual(user);

    jest.setSystemTime(new Date(Date.now() + 1000));
    expect(service.verify(token)).toBeNull();
  });

  // Le rôle d'exemple était « ADMIN » jusqu'au 22/09 — il est devenu un rôle VALIDE avec
  // l'espace agent CADANS, et ce test l'a signalé en échouant. On prend désormais un rôle
  // qui n'existe pas et n'a aucune raison d'exister.
  it('refuse un rôle inconnu même correctement signé', () => {
    const now = Math.floor(Date.now() / 1000);
    const token = signWith(
      SECRET,
      { alg: 'HS256', typ: 'JWT' },
      { sub: user.id, role: 'SUPERVISEUR', iat: now, exp: now + 60 },
    );

    expect(service.verify(token)).toBeNull();
  });

  // Le rôle agent est accepté : un token ADMIN correctement signé ouvre bien une session.
  it('accepte le rôle agent CADANS', () => {
    const now = Math.floor(Date.now() / 1000);
    const token = signWith(
      SECRET,
      { alg: 'HS256', typ: 'JWT' },
      { sub: user.id, role: 'ADMIN', iat: now, exp: now + 60 },
    );

    expect(service.verify(token)).toEqual({ id: user.id, role: 'ADMIN' });
  });

  it.each(['', 'abc', 'a.b', 'a.b.c.d', 'pas.un.jwt'])(
    'refuse le token malformé « %s »',
    (token) => {
      expect(service.verify(token)).toBeNull();
    },
  );
});
