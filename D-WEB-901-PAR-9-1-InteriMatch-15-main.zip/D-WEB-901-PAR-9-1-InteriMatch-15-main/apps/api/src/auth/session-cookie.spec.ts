import { readCookie, sessionCookieOptions } from './session-cookie';

describe('readCookie', () => {
  it('extrait le cookie demandé parmi plusieurs', () => {
    expect(readCookie('theme=sombre; cadans_session=abc.def.ghi; lang=fr', 'cadans_session')).toBe(
      'abc.def.ghi',
    );
  });

  it('ne confond pas un cookie dont le nom en contient un autre', () => {
    expect(readCookie('old_cadans_session=x', 'cadans_session')).toBeUndefined();
  });

  it('renvoie undefined sans en-tête, sans le cookie ou si la valeur est mal encodée', () => {
    expect(readCookie(undefined, 'cadans_session')).toBeUndefined();
    expect(readCookie('theme=sombre', 'cadans_session')).toBeUndefined();
    expect(readCookie('cadans_session=%E0%A4%A', 'cadans_session')).toBeUndefined();
  });
});

describe('sessionCookieOptions', () => {
  const originalEnv = process.env.NODE_ENV;

  afterEach(() => {
    process.env.NODE_ENV = originalEnv;
  });

  it('reste httpOnly et SameSite=Lax en développement', () => {
    process.env.NODE_ENV = 'development';

    expect(sessionCookieOptions()).toMatchObject({
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
    });
  });

  it('passe en Secure et SameSite=None en production (site et API sur deux domaines)', () => {
    process.env.NODE_ENV = 'production';

    expect(sessionCookieOptions()).toMatchObject({
      httpOnly: true,
      secure: true,
      sameSite: 'none',
    });
  });
});
