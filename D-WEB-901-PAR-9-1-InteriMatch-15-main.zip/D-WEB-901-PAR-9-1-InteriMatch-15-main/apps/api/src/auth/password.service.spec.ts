import * as argon2 from 'argon2';
import { PasswordService } from './password.service';

describe('PasswordService', () => {
  const service = new PasswordService();

  it('produit un hash argon2id qui ne contient pas le mot de passe', async () => {
    const hash = await service.hash('Cariste#2026ok');

    expect(hash).toMatch(/^\$argon2id\$/);
    expect(hash).not.toContain('Cariste#2026ok');
  });

  it('sale chaque hash : deux hachages du même mot de passe diffèrent', async () => {
    const [first, second] = await Promise.all([
      service.hash('Cariste#2026ok'),
      service.hash('Cariste#2026ok'),
    ]);

    expect(first).not.toBe(second);
  });

  it('vérifie le bon mot de passe et refuse un mauvais', async () => {
    const hash = await service.hash('Cariste#2026ok');

    expect(await service.verify(hash, 'Cariste#2026ok')).toBe(true);
    expect(await service.verify(hash, 'Cariste#2026ko')).toBe(false);
  });

  it('applique les paramètres OWASP m = 19 Mio, t = 2, p = 1', async () => {
    const hash = await service.hash('Cariste#2026ok');

    const params = hash.split('$')[3]?.split(',').sort();
    expect(params).toEqual(['m=19456', 'p=1', 't=2']);
  });

  it('vérifie encore un hash produit avec les anciens réglages par défaut', async () => {
    const ancienHash = await argon2.hash('Cariste#2026ok', { type: argon2.argon2id });

    expect(ancienHash.split('$')[3]?.split(',').sort()).toEqual(['m=65536', 'p=4', 't=3']);
    expect(await service.verify(ancienHash, 'Cariste#2026ok')).toBe(true);
  });

  it('refuse sans lever d’erreur si le hash stocké est illisible', async () => {
    expect(await service.verify('pas-un-hash', 'Cariste#2026ok')).toBe(false);
  });
});
