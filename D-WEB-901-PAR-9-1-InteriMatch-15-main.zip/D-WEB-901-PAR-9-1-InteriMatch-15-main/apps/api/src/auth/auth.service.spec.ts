import { ConflictException, UnauthorizedException } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { Prisma, Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuthService, INVALID_CREDENTIALS_MESSAGE } from './auth.service';
import { RegisterCompanyDto } from './dto/register-company.dto';
import { RegisterWorkerDto } from './dto/register-worker.dto';
import { PasswordService } from './password.service';

const now = new Date('2026-09-17T08:00:00Z');

const companyDto: RegisterCompanyDto = {
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

const workerDto: RegisterWorkerDto = {
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  acceptConditions: true,
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '01000',
  city: 'Bourg-en-Bresse',
};

const uniqueViolation = (target: string[]): Prisma.PrismaClientKnownRequestError =>
  new Prisma.PrismaClientKnownRequestError('Unique constraint failed', {
    code: 'P2002',
    clientVersion: Prisma.prismaVersion.client,
    meta: { target },
  });

describe('AuthService', () => {
  let service: AuthService;
  let prisma: { user: { create: jest.Mock; findUnique: jest.Mock } };
  let passwords: { hash: jest.Mock; verify: jest.Mock };

  beforeEach(async () => {
    prisma = { user: { create: jest.fn(), findUnique: jest.fn() } };
    passwords = {
      hash: jest.fn().mockImplementation((password: string) => Promise.resolve(`hash:${password}`)),
      verify: jest
        .fn()
        .mockImplementation((hash: string, password: string) =>
          Promise.resolve(hash === `hash:${password}`),
        ),
    };

    const moduleRef = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: PrismaService, useValue: prisma },
        { provide: PasswordService, useValue: passwords },
      ],
    }).compile();

    service = moduleRef.get(AuthService);
  });

  describe('registerCompany', () => {
    it('crée le compte et son profil entreprise avec le mot de passe haché', async () => {
      prisma.user.create.mockImplementation(({ data }) =>
        Promise.resolve({
          id: 'u1',
          email: data.email,
          passwordHash: data.passwordHash,
          role: data.role,
          createdAt: now,
          updatedAt: now,
          company: { id: 'c1', userId: 'u1', ...data.company.create },
          worker: null,
        }),
      );

      const account = await service.registerCompany(companyDto);

      const { data } = prisma.user.create.mock.calls[0][0];
      expect(data).toMatchObject({
        email: 'contact@entrepot-nord.fr',
        passwordHash: 'hash:Cariste#2026ok',
        role: Role.COMPANY,
        company: { create: { siret: '73282932000074', legalName: 'Entrepôt du Nord' } },
      });
      expect(data.company.create).not.toHaveProperty('password');
      // L'acceptation est une date sur le compte, jamais un champ du profil entreprise.
      expect(data.company.create).not.toHaveProperty('acceptConditions');
      expect(data.conditionsAcceptedAt).toBeInstanceOf(Date);
      expect(account).toMatchObject({ role: Role.COMPANY, company: { siret: '73282932000074' } });
      expect(account).not.toHaveProperty('passwordHash');
    });

    it('renvoie un conflit explicite si le SIRET est déjà inscrit', async () => {
      prisma.user.create.mockRejectedValue(uniqueViolation(['siret']));

      await expect(service.registerCompany(companyDto)).rejects.toThrow(
        new ConflictException('Une entreprise est déjà inscrite avec ce SIRET'),
      );
    });
  });

  describe('registerWorker', () => {
    it('crée un compte intérimaire', async () => {
      prisma.user.create.mockImplementation(({ data }) =>
        Promise.resolve({
          id: 'u2',
          email: data.email,
          passwordHash: data.passwordHash,
          role: data.role,
          createdAt: now,
          updatedAt: now,
          company: null,
          worker: { id: 'w1', userId: 'u2', phone: null, ...data.worker.create },
        }),
      );

      const account = await service.registerWorker(workerDto);

      expect(prisma.user.create.mock.calls[0][0].data.role).toBe(Role.WORKER);
      expect(prisma.user.create.mock.calls[0][0].data.conditionsAcceptedAt).toBeInstanceOf(Date);
      expect(prisma.user.create.mock.calls[0][0].data.worker.create).not.toHaveProperty(
        'acceptConditions',
      );
      expect(account).toMatchObject({ role: Role.WORKER, worker: { city: 'Bourg-en-Bresse' } });
      expect(account).not.toHaveProperty('passwordHash');
    });

    it("renvoie un conflit si l'email est déjà utilisé", async () => {
      prisma.user.create.mockRejectedValue(uniqueViolation(['email']));

      await expect(service.registerWorker(workerDto)).rejects.toThrow(
        new ConflictException('Un compte existe déjà avec cette adresse email'),
      );
    });

    it('laisse remonter les autres erreurs de base', async () => {
      prisma.user.create.mockRejectedValue(new Error('connexion perdue'));

      await expect(service.registerWorker(workerDto)).rejects.toThrow('connexion perdue');
    });
  });

  describe('login', () => {
    const storedUser = {
      id: 'u2',
      email: 'samir@example.fr',
      passwordHash: 'hash:Preparateur!42x',
      role: Role.WORKER,
      createdAt: now,
      updatedAt: now,
      company: null,
      worker: null,
    };

    it('renvoie le compte sans le hash quand les identifiants sont bons', async () => {
      prisma.user.findUnique.mockResolvedValue(storedUser);

      const account = await service.login({
        email: 'samir@example.fr',
        password: 'Preparateur!42x',
      });

      expect(account).toMatchObject({ id: 'u2', role: Role.WORKER });
      expect(account).not.toHaveProperty('passwordHash');
    });

    it('refuse un mauvais mot de passe', async () => {
      prisma.user.findUnique.mockResolvedValue(storedUser);

      await expect(
        service.login({ email: 'samir@example.fr', password: 'mauvais' }),
      ).rejects.toThrow(new UnauthorizedException(INVALID_CREDENTIALS_MESSAGE));
    });

    it('refuse un email inconnu avec le même message et vérifie quand même un hash', async () => {
      prisma.user.findUnique.mockResolvedValue(null);

      await expect(
        service.login({ email: 'inconnu@example.fr', password: 'Preparateur!42x' }),
      ).rejects.toThrow(new UnauthorizedException(INVALID_CREDENTIALS_MESSAGE));
      // Le coût argon2 est payé même sans compte : pas d'écart de temps exploitable.
      expect(passwords.verify).toHaveBeenCalledTimes(1);
    });
  });
});
