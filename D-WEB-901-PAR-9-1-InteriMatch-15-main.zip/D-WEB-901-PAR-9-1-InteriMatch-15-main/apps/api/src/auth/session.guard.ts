import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthenticatedRequest, IS_PUBLIC_KEY } from './decorators';
import { allowedWebOrigin, readCookie, SESSION_COOKIE } from './session-cookie';
import { TokenService } from './token.service';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

// Garde globale : lit la session dans le cookie et bloque les routes non publiques
// sans session valide. Enregistrée avant RolesGuard (voir AuthModule).
@Injectable()
export class SessionGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly tokens: TokenService,
  ) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<AuthenticatedRequest>();

    // Protection CSRF : le cookie part avec toute requête vers l'API, y compris depuis
    // un site tiers. Les navigateurs envoient l'en-tête Origin sur les requêtes qui
    // modifient des données : on refuse celles qui ne viennent pas du site CADANS.
    // Sans Origin (curl, rendu serveur Next.js), la requête ne vient pas d'un navigateur
    // piégé et reste autorisée.
    const origin = request.headers.origin;
    if (!SAFE_METHODS.has(request.method) && origin && origin !== allowedWebOrigin()) {
      throw new ForbiddenException('Origine de la requête non autorisée');
    }

    const token = readCookie(request.headers.cookie, SESSION_COOKIE);
    const user = token ? this.tokens.verify(token) : null;
    if (user) {
      request.user = user;
    }

    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!isPublic && !user) {
      throw new UnauthorizedException('Authentification requise');
    }

    return true;
  }
}
