import { Body, Controller, Get, HttpCode, HttpStatus, Post, Res } from '@nestjs/common';
import { Response } from 'express';
import { AuthService, PublicAccount } from './auth.service';
import { CurrentUser, Public } from './decorators';
import { LoginDto } from './dto/login.dto';
import { RegisterCompanyDto } from './dto/register-company.dto';
import { RegisterWorkerDto } from './dto/register-worker.dto';
import { RequestPasswordResetDto } from './dto/request-password-reset.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { PasswordResetService } from './password-reset.service';
import { SESSION_COOKIE, sessionCookieOptions, sessionCookieWithLifetime } from './session-cookie';
import { SessionUser, TokenService } from './token.service';

// Deux routes d'inscription distinctes : les parcours entreprise et intérimaire
// n'ont pas les mêmes champs obligatoires. L'inscription ouvre directement la session.
@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly tokens: TokenService,
    private readonly passwordReset: PasswordResetService,
  ) {}

  @Public()
  @Post('register/company')
  async registerCompany(
    @Body() dto: RegisterCompanyDto,
    @Res({ passthrough: true }) response: Response,
  ): Promise<PublicAccount> {
    return this.openSession(response, await this.authService.registerCompany(dto));
  }

  @Public()
  @Post('register/worker')
  async registerWorker(
    @Body() dto: RegisterWorkerDto,
    @Res({ passthrough: true }) response: Response,
  ): Promise<PublicAccount> {
    return this.openSession(response, await this.authService.registerWorker(dto));
  }

  @Public()
  @Post('login')
  @HttpCode(HttpStatus.OK)
  async login(
    @Body() dto: LoginDto,
    @Res({ passthrough: true }) response: Response,
  ): Promise<PublicAccount> {
    return this.openSession(response, await this.authService.login(dto));
  }

  // Publique : une session expirée doit pouvoir être fermée côté navigateur.
  @Public()
  @Post('logout')
  @HttpCode(HttpStatus.NO_CONTENT)
  logout(@Res({ passthrough: true }) response: Response): void {
    response.clearCookie(SESSION_COOKIE, sessionCookieOptions());
  }

  // 204 quoi qu'il arrive, y compris pour une adresse inconnue : la réponse ne doit pas
  // permettre de savoir quelles adresses ont un compte sur la plateforme.
  @Public()
  @Post('password-reset/request')
  @HttpCode(HttpStatus.NO_CONTENT)
  async requestPasswordReset(@Body() dto: RequestPasswordResetDto): Promise<void> {
    await this.passwordReset.request(dto.email);
  }

  // 400 si le lien est inconnu, déjà utilisé ou expiré, avec le même message dans les
  // trois cas. La session n'est pas ouverte : l'utilisateur se reconnecte ensuite.
  @Public()
  @Post('password-reset/confirm')
  @HttpCode(HttpStatus.NO_CONTENT)
  async confirmPasswordReset(@Body() dto: ResetPasswordDto): Promise<void> {
    await this.passwordReset.confirm(dto.token, dto.password);
  }

  @Get('me')
  me(@CurrentUser() user: SessionUser): Promise<PublicAccount> {
    return this.authService.getAccount(user.id);
  }

  private openSession(response: Response, account: PublicAccount): PublicAccount {
    const token = this.tokens.sign({ id: account.id, role: account.role });
    response.cookie(SESSION_COOKIE, token, sessionCookieWithLifetime());
    return account;
  }
}
