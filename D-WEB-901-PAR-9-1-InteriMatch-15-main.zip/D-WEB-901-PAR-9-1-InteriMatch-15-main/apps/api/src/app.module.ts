import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AccountModule } from './account/account.module';
import { AuthModule } from './auth/auth.module';
import { AdminModule } from './admin/admin.module';
import { AttachmentsModule } from './attachments/attachments.module';
import { CandidaturesModule } from './candidatures/candidatures.module';
import { CompaniesModule } from './companies/companies.module';
import { ContractsModule } from './contracts/contracts.module';
import { EncryptionModule } from './encryption/encryption.module';
import { HealthModule } from './health/health.module';
import { MatchingModule } from './matching/matching.module';
import { MissionsModule } from './missions/missions.module';
import { MongoModule } from './mongo/mongo.module';
import { PrismaModule } from './prisma/prisma.module';
import { ReferentielModule } from './referentiel/referentiel.module';
import { SensitiveDocumentsModule } from './sensitive-documents/sensitive-documents.module';
import { WorkerProfileModule } from './worker-profile/worker-profile.module';

@Module({
  imports: [
    // Le .env est à la racine du monorepo, partagé par l'API et le front.
    ConfigModule.forRoot({ isGlobal: true, envFilePath: ['../../.env', '.env'] }),
    PrismaModule,
    MongoModule,
    HealthModule,
    EncryptionModule,
    AuthModule,
    SensitiveDocumentsModule,
    ReferentielModule,
    MissionsModule,
    WorkerProfileModule,
    MatchingModule,
    CandidaturesModule,
    ContractsModule,
    AttachmentsModule,
    AdminModule,
    CompaniesModule,
    AccountModule,
  ],
})
export class AppModule {}
