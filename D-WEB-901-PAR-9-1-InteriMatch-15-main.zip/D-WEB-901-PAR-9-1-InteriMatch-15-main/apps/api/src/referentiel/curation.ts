import { CertificationType } from '@prisma/client';

// Curation du référentiel : ce que la donnée publique ne dit pas, et que l'équipe décide.
// Conception et justification : docs/referentiel-matching.md.
//
// Ces listes sont des données, pas du code métier : elles se relisent ligne par ligne, et
// un test vérifie que chaque code existe bien dans les fichiers de seed (pas de faute de
// frappe silencieuse).

// Périmètre fermé. N1303 (exploitation logistique, orienté transport) écarté.
export const ROME_CODES = ['N1101', 'N1103', 'N1105'] as const;

// Appellations proposées aux entreprises. Un code ROME contient aussi des métiers hors
// entrepôt (nacelle, armée, ferroutage, bagagiste, messagerie) : ils restent en base,
// inactifs pour la saisie, pour ne pas dévier de la source.
export const EXPOSED_POSTES: ReadonlySet<string> = new Set([
  // N1101 — Cariste
  '11679', // Cariste (principale)
  '11684', // Cariste d'entrepôt
  '11685', // Cariste en préparation logistique
  '11686', // Cariste manutentionnaire
  '11688', // Cariste réceptionnaire
  '11683', // Cariste chargeur-déchargeur
  '11687', // Cariste pointeur
  '11680', // Cariste agent de magasinage
  '11681', // Agent de quai cariste
  '510881', // Conducteur d'engins de manutention
  '13250', // Conducteur d'engins de manutention motorisé à conducteur porté
  // N1103 — Préparateur de commandes : les trois
  '17993', // Préparateur de commandes (principale)
  '520521', // Agent de préparation de commandes
  '18032', // Préparateur logistique en entrepôt
  // N1105 — Manutentionnaire
  '16361', // Manutentionnaire (principale)
  '10523', // Agent de manutention de charges lourdes
  '13897', // Déchargeur manutentionnaire
  '11951', // Chargeur manutentionnaire
  '11950', // Chargeur déchargeur manutentionnaire
  '16366', // Manutentionnaire expéditeur
  '18318', // Réceptionnaire-pointeur
  '18319', // Réceptionnaire-vérificateur de marchandises
  '10579', // Agent de quai manutentionnaire
  '10580', // Agent de quai réceptionnaire
  '14809', // Employé logistique de réception de marchandises
  '16355', // Manœuvre manutentionnaire
]);

// Suggestion d'habilitation par poste, pré-remplie sur la mission et ajustable par
// l'entreprise. Seulement là où la fiche ROME dit l'habilitation obligatoire (N1101 :
// « accessible avec l'un des CACES pour chariots de manutention »). Pour N1103 elle est
// « selon l'offre », pour N1105 absente : aucune suggestion, l'entreprise choisit.
//
// PROPOSITION À VALIDER EN ÉQUIPE : le R489 catégorie 3 (chariot frontal) est le plus
// demandé en entrepôt ; les postes de quai et de chargement relèvent plutôt du 1A.
const R489_3: readonly CertificationType[] = [CertificationType.CACES_R489_3];
const R489_1A: readonly CertificationType[] = [CertificationType.CACES_R489_1A];

export const HABILITATION_SUGGESTIONS: ReadonlyMap<string, readonly CertificationType[]> = new Map<
  string,
  readonly CertificationType[]
>([
  ['11679', R489_3],
  ['11684', R489_3],
  ['11685', R489_3],
  ['11686', R489_3],
  ['11688', R489_3],
  ['11687', R489_3],
  ['11680', R489_3],
  ['510881', R489_3],
  ['13250', R489_3],
  ['11683', R489_1A],
  ['11681', R489_1A],
]);
