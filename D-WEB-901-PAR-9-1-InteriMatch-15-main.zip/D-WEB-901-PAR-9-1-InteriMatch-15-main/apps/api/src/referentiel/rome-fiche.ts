// Forme d'une fiche métier ROME 4.0 telle que la renvoie France Travail
// (GET /partenaire/rome-metiers/v1/metiers/metier/{code}), réduite aux champs utilisés.
// Les fichiers `prisma/seed/rome/*.json` sont ces réponses, figées telles quelles.

export type FranceTravailCompetenceType =
  'COMPETENCE-DETAILLEE' | 'SAVOIR' | 'MACRO-SAVOIR-FAIRE' | 'MACRO-SAVOIR-ETRE-PROFESSIONNEL';

export interface RomeFicheCompetence {
  type: FranceTravailCompetenceType | string;
  code: string;
  libelle: string;
}

export interface RomeFicheAppellation {
  code: string;
  libelle: string;
  // PRINCIPALE : le libellé de référence du code ROME ; SYNONYME : les autres.
  classification: 'PRINCIPALE' | 'SYNONYME' | string;
}

export interface RomeFiche {
  code: string;
  libelle: string;
  appellations: RomeFicheAppellation[];
  competencesMobilisees: RomeFicheCompetence[];
  competencesMobiliseesPrincipales: RomeFicheCompetence[];
}

// Vérification de surface : on refuse une réponse dont la structure a changé plutôt que
// d'importer des tables vides sans s'en apercevoir.
export function assertRomeFiche(value: unknown, source: string): RomeFiche {
  const fiche = value as Partial<RomeFiche> | null;
  const valid =
    typeof fiche === 'object' &&
    fiche !== null &&
    typeof fiche.code === 'string' &&
    typeof fiche.libelle === 'string' &&
    Array.isArray(fiche.appellations) &&
    Array.isArray(fiche.competencesMobilisees) &&
    Array.isArray(fiche.competencesMobiliseesPrincipales);

  if (!valid) {
    throw new Error(
      `${source} : structure de fiche ROME inattendue (code, libelle, appellations, ` +
        'competencesMobilisees et competencesMobiliseesPrincipales attendus)',
    );
  }
  return fiche as RomeFiche;
}
