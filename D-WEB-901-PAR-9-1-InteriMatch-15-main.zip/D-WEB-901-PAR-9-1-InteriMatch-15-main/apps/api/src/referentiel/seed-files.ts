import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { assertRomeFiche, RomeFiche } from './rome-fiche';

// Les fiches ROME sont figées dans le dépôt : l'application et ses tests fonctionnent
// sans identifiants France Travail ni réseau, et l'import est reproductible. La CLI
// rafraîchit ces fichiers depuis l'API sur demande (`--fetch`).
//
// Le chemin est résolu depuis ce fichier : valable depuis `src/` (ts-node) comme depuis
// `dist/` (build), les deux étant à la même profondeur sous apps/api.
export const SEED_DIR = join(__dirname, '..', '..', 'prisma', 'seed', 'rome');

export function seedPath(code: string): string {
  return join(SEED_DIR, `${code}.json`);
}

export function readSeed(code: string): RomeFiche {
  const path = seedPath(code);
  return assertRomeFiche(JSON.parse(readFileSync(path, 'utf8')), path);
}

export function writeSeed(fiche: RomeFiche): string {
  mkdirSync(SEED_DIR, { recursive: true });
  const path = seedPath(fiche.code);
  writeFileSync(path, `${JSON.stringify(fiche, null, 2)}\n`, 'utf8');
  return path;
}
