import {
  FranceTravailClient,
  OffreFranceTravailError,
  SCOPE_OFFRES,
  SCOPE_ROME_METIERS,
} from './france-travail.client';

const fiche = {
  code: 'N1101',
  libelle: 'Cariste',
  appellations: [],
  competencesMobilisees: [],
  competencesMobiliseesPrincipales: [],
};

describe('FranceTravailClient', () => {
  const env = process.env;
  let fetchMock: jest.Mock;

  beforeEach(() => {
    process.env = {
      ...env,
      FRANCE_TRAVAIL_CLIENT_ID: 'id-test',
      FRANCE_TRAVAIL_CLIENT_SECRET: 'secret-test',
    };
    fetchMock = jest.fn();
    global.fetch = fetchMock as unknown as typeof fetch;
  });

  afterAll(() => {
    process.env = env;
  });

  it('refuse de démarrer sans identifiants, avec un message qui dit quoi faire', async () => {
    delete process.env.FRANCE_TRAVAIL_CLIENT_ID;
    const client = new FranceTravailClient();

    expect(client.configured).toBe(false);
    await expect(client.token(SCOPE_ROME_METIERS)).rejects.toThrow('FRANCE_TRAVAIL_CLIENT_ID');
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('demande un jeton client_credentials avec le scope de l’API', async () => {
    fetchMock.mockResolvedValue(Response.json({ access_token: 'jeton', expires_in: 1499 }));

    const token = await new FranceTravailClient().token(SCOPE_ROME_METIERS);

    expect(token).toBe('jeton');
    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toContain('realm=%2Fpartenaire');
    const body = new URLSearchParams(String(init.body));
    expect(body.get('grant_type')).toBe('client_credentials');
    expect(body.get('client_id')).toBe('id-test');
    expect(body.get('scope')).toBe(SCOPE_ROME_METIERS);
  });

  it('explique un refus de jeton par le scope, cause la plus fréquente', async () => {
    fetchMock.mockResolvedValue(new Response('invalid_scope', { status: 400 }));

    await expect(new FranceTravailClient().token('mauvais-scope')).rejects.toThrow(
      /HTTP 400.*mauvais-scope.*invalid_scope/,
    );
  });

  it('lit une fiche métier et en vérifie la structure', async () => {
    fetchMock.mockResolvedValue(Response.json(fiche));

    const result = await new FranceTravailClient().romeMetier('N1101', 'jeton');

    expect(result.code).toBe('N1101');
    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
    expect(url).toBe(
      'https://api.francetravail.io/partenaire/rome-metiers/v1/metiers/metier/N1101',
    );
    expect(init.headers).toMatchObject({ Authorization: 'Bearer jeton' });
  });

  it('refuse une fiche dont la structure a changé plutôt que d’importer des tables vides', async () => {
    fetchMock.mockResolvedValue(Response.json({ code: 'N1101', libelle: 'Cariste' }));

    await expect(new FranceTravailClient().romeMetier('N1101', 'jeton')).rejects.toThrow(
      'structure de fiche ROME inattendue',
    );
  });

  // Lecture d'une offre. Aucun de ces tests n'atteint le réseau : `fetch` est simulé, et le
  // premier appel est toujours celui du jeton.
  describe('offreEmploi', () => {
    const jeton = () => Response.json({ access_token: 'jeton' });
    const offre = { id: '214GWTK', intitule: 'Cariste (H/F)', romeCode: 'N1101' };

    // Raccourci : première réponse = le jeton, seconde = celle de l'API des offres.
    const repond = (reponse: Response) =>
      fetchMock.mockResolvedValueOnce(jeton()).mockResolvedValueOnce(reponse);

    it('demande un jeton du scope des offres, puis lit l’offre', async () => {
      repond(Response.json(offre));

      const resultat = await new FranceTravailClient().offreEmploi('214GWTK');

      expect(resultat).toEqual(offre);
      const corpsJeton = new URLSearchParams(
        String((fetchMock.mock.calls[0] as [string, RequestInit])[1].body),
      );
      expect(corpsJeton.get('scope')).toBe(SCOPE_OFFRES);
      const [url, init] = fetchMock.mock.calls[1] as [string, RequestInit];
      expect(url).toBe('https://api.francetravail.io/partenaire/offresdemploi/v2/offres/214GWTK');
      expect(init.headers).toMatchObject({ Authorization: 'Bearer jeton' });
    });

    // LE piège de cette API, vérifié contre le service réel le 23/09/2026 : une offre inconnue
    // ou expirée répond 204 No Content, pas 404. `response.ok` vaut `true` sur un 204 : sans ce
    // cas explicite, on préremplirait le formulaire avec une réponse vide.
    it('traite le 204 comme une offre introuvable, et non comme un succès', async () => {
      repond(new Response(null, { status: 204 }));

      await expect(new FranceTravailClient().offreEmploi('1111111')).rejects.toMatchObject({
        raison: 'introuvable',
      });
    });

    it('traite le 400 (format refusé par France Travail) comme une offre introuvable', async () => {
      repond(Response.json({ message: 'format incorrect' }, { status: 400 }));

      await expect(new FranceTravailClient().offreEmploi('ABCDEFG')).rejects.toMatchObject({
        raison: 'introuvable',
      });
    });

    it('distingue le quota atteint (429) d’une panne', async () => {
      repond(new Response(null, { status: 429 }));

      await expect(new FranceTravailClient().offreEmploi('214GWTK')).rejects.toMatchObject({
        raison: 'quota',
      });
    });

    it('signale une panne du service (500)', async () => {
      repond(new Response(null, { status: 500 }));

      await expect(new FranceTravailClient().offreEmploi('214GWTK')).rejects.toMatchObject({
        raison: 'indisponible',
      });
    });

    it('signale une API injoignable (aucune réponse HTTP)', async () => {
      fetchMock.mockResolvedValueOnce(jeton()).mockRejectedValueOnce(new Error('ECONNREFUSED'));

      await expect(new FranceTravailClient().offreEmploi('214GWTK')).rejects.toMatchObject({
        raison: 'indisponible',
      });
    });

    // Identifiants absents ou refusés : l'entreprise n'y peut rien, c'est une panne — pas une
    // offre introuvable, qui l'enverrait vérifier un lien pourtant correct.
    it('signale un jeton refusé comme une indisponibilité, sans appeler l’API des offres', async () => {
      fetchMock.mockResolvedValueOnce(new Response('invalid_client', { status: 401 }));

      await expect(new FranceTravailClient().offreEmploi('214GWTK')).rejects.toMatchObject({
        raison: 'indisponible',
      });
      expect(fetchMock).toHaveBeenCalledTimes(1);
    });

    it('refuse une réponse dont la structure a changé', async () => {
      repond(Response.json({ pasUneOffre: true }));

      await expect(new FranceTravailClient().offreEmploi('214GWTK')).rejects.toBeInstanceOf(
        OffreFranceTravailError,
      );
    });
  });
});
