import { Test } from '@nestjs/testing';
import { CertificationType, CompetenceType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { ReferentielService } from './referentiel.service';

describe('ReferentielService', () => {
  let service: ReferentielService;
  let prisma: { poste: { findMany: jest.Mock }; romeCompetence: { findMany: jest.Mock } };

  beforeEach(async () => {
    prisma = { poste: { findMany: jest.fn() }, romeCompetence: { findMany: jest.fn() } };
    const moduleRef = await Test.createTestingModule({
      providers: [ReferentielService, { provide: PrismaService, useValue: prisma }],
    }).compile();
    service = moduleRef.get(ReferentielService);
  });

  describe('postesExposes', () => {
    it('ne demande que les postes exposés et actifs, principale en tête', async () => {
      prisma.poste.findMany.mockResolvedValue([]);

      await service.postesExposes();

      expect(prisma.poste.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { exposed: true, active: true, rome: { active: true } },
          orderBy: [{ romeCode: 'asc' }, { classification: 'asc' }, { label: 'asc' }],
        }),
      );
    });

    it('aplatit les suggestions d’habilitation en liste de types', async () => {
      prisma.poste.findMany.mockResolvedValue([
        {
          code: '11679',
          label: 'Cariste',
          classification: 'PRINCIPALE',
          rome: { code: 'N1101', label: 'Cariste' },
          habilitations: [{ type: CertificationType.CACES_R489_3 }],
        },
        {
          code: '17993',
          label: 'Préparateur de commandes',
          classification: 'PRINCIPALE',
          rome: { code: 'N1103', label: 'Préparateur de commandes' },
          habilitations: [],
        },
      ]);

      const postes = await service.postesExposes();

      expect(postes).toEqual([
        {
          code: '11679',
          label: 'Cariste',
          classification: 'PRINCIPALE',
          rome: { code: 'N1101', label: 'Cariste' },
          habilitationsSuggerees: [CertificationType.CACES_R489_3],
        },
        {
          code: '17993',
          label: 'Préparateur de commandes',
          classification: 'PRINCIPALE',
          rome: { code: 'N1103', label: 'Préparateur de commandes' },
          habilitationsSuggerees: [],
        },
      ]);
    });
  });

  describe('competencesPrincipales', () => {
    const liens = [
      {
        romeCode: 'N1101',
        competence: { code: '100016', label: 'Gestes et postures', type: CompetenceType.SAVOIR },
      },
      {
        romeCode: 'N1101',
        competence: {
          code: '484039',
          label: 'Conduire un chariot élévateur',
          type: CompetenceType.COMPETENCE_DETAILLEE,
        },
      },
      {
        romeCode: 'N1105',
        competence: { code: '100016', label: 'Gestes et postures', type: CompetenceType.SAVOIR },
      },
    ];

    it('ne demande que les principales actives, sans les savoir-être', async () => {
      prisma.romeCompetence.findMany.mockResolvedValue([]);

      await service.competencesPrincipales();

      expect(prisma.romeCompetence.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: {
            principale: true,
            rome: { active: true },
            competence: { active: true, type: { not: CompetenceType.MACRO_SAVOIR_ETRE } },
          },
        }),
      );
    });

    it('restreint à un code ROME quand il est fourni', async () => {
      prisma.romeCompetence.findMany.mockResolvedValue([]);

      await service.competencesPrincipales('N1103');

      expect(prisma.romeCompetence.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: expect.objectContaining({ romeCode: 'N1103' }) }),
      );
    });

    it('dédoublonne une compétence partagée entre métiers et trie par libellé', async () => {
      prisma.romeCompetence.findMany.mockResolvedValue(liens);

      const competences = await service.competencesPrincipales();

      expect(competences).toEqual([
        {
          code: '484039',
          label: 'Conduire un chariot élévateur',
          type: CompetenceType.COMPETENCE_DETAILLEE,
          romeCodes: ['N1101'],
        },
        {
          code: '100016',
          label: 'Gestes et postures',
          type: CompetenceType.SAVOIR,
          romeCodes: ['N1101', 'N1105'],
        },
      ]);
    });
  });
});
