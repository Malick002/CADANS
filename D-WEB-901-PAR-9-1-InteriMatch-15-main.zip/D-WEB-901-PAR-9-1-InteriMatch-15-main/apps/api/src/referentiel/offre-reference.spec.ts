import { extraireReferenceOffre, urlOffrePublique } from './offre-reference';

describe('extraireReferenceOffre', () => {
  describe('identifiant collé seul', () => {
    it('accepte les sept caractères tels quels', () => {
      expect(extraireReferenceOffre('214GWTK')).toBe('214GWTK');
    });

    it('tolère les espaces autour et la minuscule, et normalise en majuscules', () => {
      expect(extraireReferenceOffre('  214gwtk \n')).toBe('214GWTK');
    });

    // Un utilisateur qui recopie « n° 214GWTK » depuis une fiche imprimée.
    it('tolère le préfixe « n° »', () => {
      expect(extraireReferenceOffre('n° 214GWTK')).toBe('214GWTK');
      expect(extraireReferenceOffre('N°214GWTK')).toBe('214GWTK');
    });
  });

  describe('URL de la fiche publique', () => {
    it('lit le dernier segment du chemin', () => {
      expect(
        extraireReferenceOffre('https://candidat.francetravail.fr/offres/recherche/detail/214GWTK'),
      ).toBe('214GWTK');
    });

    it('ignore les paramètres de suivi et l’ancre', () => {
      expect(
        extraireReferenceOffre(
          'https://candidat.francetravail.fr/offres/recherche/detail/214GWTK?at_medium=email&at_campaign=x#resultats',
        ),
      ).toBe('214GWTK');
    });

    it('accepte une barre finale', () => {
      expect(
        extraireReferenceOffre(
          'https://candidat.francetravail.fr/offres/recherche/detail/214GWTK/',
        ),
      ).toBe('214GWTK');
    });

    it('accepte une URL collée sans schéma', () => {
      expect(
        extraireReferenceOffre('candidat.francetravail.fr/offres/recherche/detail/214GWTK'),
      ).toBe('214GWTK');
    });

    it('lit l’identifiant depuis un paramètre des anciens liens', () => {
      expect(extraireReferenceOffre('https://www.pole-emploi.fr/offre?offreId=214gwtk')).toBe(
        '214GWTK',
      );
    });

    it('accepte un sous-domaine de France Travail', () => {
      expect(extraireReferenceOffre('https://api.francetravail.io/offres/214GWTK')).toBe('214GWTK');
    });
  });

  describe('saisies refusées', () => {
    // Chacune rend `null`, jamais d'exception : l'appelant a toujours un message à afficher.
    it.each([
      ['une chaîne vide', ''],
      ['des espaces seuls', '   '],
      ['un identifiant trop court', '214GWT'],
      ['un identifiant trop long', '214GWTK9'],
      ['un identifiant avec un caractère interdit', '214-GWT'],
      ['une URL qui n’est pas une URL', 'https://'],
      [
        'une URL France Travail sans identifiant',
        'https://candidat.francetravail.fr/offres/recherche',
      ],
      ['une phrase entière', 'Regarde cette offre, elle est bien'],
    ])('refuse %s', (_cas, saisie) => {
      expect(extraireReferenceOffre(saisie)).toBeNull();
    });

    // Un mot de sept lettres EST un candidat valable, et c'est voulu : sur les 150
    // identifiants observés le 23/09 tous mêlent chiffres et lettres, mais rien ne garantit
    // que France Travail n'en émettra jamais un tout en lettres. Exiger un chiffre
    // rejetterait alors une référence valide — bien pire qu'un appel inutile, qui se solde
    // par un 204 et le message « offre introuvable ou expirée ».
    it('laisse passer un mot de sept lettres, que l’API tranchera', () => {
      expect(extraireReferenceOffre('cariste')).toBe('CARISTE');
    });

    // Le point qui compte : sept caractères alphanumériques se trouvent dans beaucoup d'URL.
    // Sans filtre de domaine, on appellerait l'API France Travail avec l'identifiant d'un
    // site tiers, et on présenterait le résultat comme « l'offre que vous avez collée ».
    it('refuse une URL d’un autre domaine, même si elle contient sept caractères', () => {
      expect(extraireReferenceOffre('https://exemple.fr/offres/detail/214GWTK')).toBeNull();
      expect(
        extraireReferenceOffre('https://francetravail.fr.exemple.com/detail/214GWTK'),
      ).toBeNull();
    });
  });
});

describe('urlOffrePublique', () => {
  it('rend la fiche publique, celle que l’API donne elle-même comme origine', () => {
    expect(urlOffrePublique('214GWTK')).toBe(
      'https://candidat.francetravail.fr/offres/recherche/detail/214GWTK',
    );
  });
});
