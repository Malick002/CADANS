import { Injectable, Logger } from '@nestjs/common';
import { CompetenceType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { EXPOSED_POSTES, HABILITATION_SUGGESTIONS } from './curation';
import { RomeFiche } from './rome-fiche';

export interface ImportReport {
  romes: number;
  postes: number;
  postesExposed: number;
  competences: number;
  liens: number;
  suggestions: number;
  // Compétences dont le type France Travail est inconnu : ignorées, jamais inventées.
  competencesIgnorees: number;
  desactives: { romes: number; postes: number; competences: number; liensSupprimes: number };
}

// Typologie France Travail → enum Prisma. Un type absent d'ici est ignoré avec un
// avertissement : la source peut évoluer, l'import ne doit pas inventer de catégorie.
const COMPETENCE_TYPES: Record<string, CompetenceType> = {
  'COMPETENCE-DETAILLEE': CompetenceType.COMPETENCE_DETAILLEE,
  SAVOIR: CompetenceType.SAVOIR,
  'MACRO-SAVOIR-FAIRE': CompetenceType.MACRO_SAVOIR_FAIRE,
  'MACRO-SAVOIR-ETRE-PROFESSIONNEL': CompetenceType.MACRO_SAVOIR_ETRE,
};

/**
 * Import du référentiel ROME dans PostgreSQL. Deux règles, sans lesquelles un ré-import
 * viderait les profils des intérimaires :
 *
 * 1. **La clé de chaque entrée est le code France Travail.** Jamais un identifiant à nous :
 *    les compétences cochées par un intérimaire pointent vers ce code, et il ne change pas.
 * 2. **On met à jour ou on insère, on ne supprime jamais une entrée.** Ce qui a disparu de
 *    la source passe à `active = false` ; le profil qui le référence est conservé et
 *    l'intérimaire en est informé. Seuls les liens ROME ↔ compétence, qui ne sont
 *    référencés par aucune donnée utilisateur, sont réellement supprimés.
 *
 * L'import est idempotent : le relancer sur les mêmes fichiers ne change rien.
 */
@Injectable()
export class RomeImportService {
  private readonly logger = new Logger(RomeImportService.name);

  constructor(private readonly prisma: PrismaService) {}

  async importAll(fiches: readonly RomeFiche[]): Promise<ImportReport> {
    const report: ImportReport = {
      romes: 0,
      postes: 0,
      postesExposed: 0,
      competences: 0,
      liens: 0,
      suggestions: 0,
      competencesIgnorees: 0,
      desactives: { romes: 0, postes: 0, competences: 0, liensSupprimes: 0 },
    };
    const competencesVues = new Set<string>();

    for (const fiche of fiches) {
      await this.importFiche(fiche, report, competencesVues);
    }

    // Désactivation de ce qui n'est plus dans le périmètre ni dans les fiches importées.
    const romes = await this.prisma.rome.updateMany({
      where: { code: { notIn: fiches.map((f) => f.code) }, active: true },
      data: { active: false },
    });
    const competences = await this.prisma.competence.updateMany({
      where: { code: { notIn: [...competencesVues] }, active: true },
      data: { active: false },
    });
    report.desactives.romes = romes.count;
    report.desactives.competences = competences.count;

    return report;
  }

  private async importFiche(
    fiche: RomeFiche,
    report: ImportReport,
    competencesVues: Set<string>,
  ): Promise<void> {
    await this.prisma.rome.upsert({
      where: { code: fiche.code },
      create: { code: fiche.code, label: fiche.libelle },
      update: { label: fiche.libelle, active: true },
    });
    report.romes += 1;

    // --- Compétences : l'union des deux listes, les principales marquées ---
    // France Travail sépare « mobilisées » et « mobilisées principales » sans que la seconde
    // soit incluse dans la première : n'importer que l'une perdrait l'autre.
    const principales = new Set(fiche.competencesMobiliseesPrincipales.map((c) => c.code));
    const toutes = new Map(
      [...fiche.competencesMobilisees, ...fiche.competencesMobiliseesPrincipales].map((c) => [
        c.code,
        c,
      ]),
    );
    const liensVus = new Set<string>();

    for (const competence of toutes.values()) {
      const type = COMPETENCE_TYPES[competence.type];
      if (!type) {
        this.logger.warn(
          `Compétence ${competence.code} ignorée : type France Travail inconnu « ${competence.type} »`,
        );
        report.competencesIgnorees += 1;
        continue;
      }

      await this.prisma.competence.upsert({
        where: { code: competence.code },
        create: { code: competence.code, label: competence.libelle, type },
        update: { label: competence.libelle, type, active: true },
      });
      const principale = principales.has(competence.code);
      await this.prisma.romeCompetence.upsert({
        where: {
          romeCode_competenceCode: { romeCode: fiche.code, competenceCode: competence.code },
        },
        create: { romeCode: fiche.code, competenceCode: competence.code, principale },
        update: { principale },
      });

      competencesVues.add(competence.code);
      liensVus.add(competence.code);
      report.competences += 1;
      report.liens += 1;
    }

    // Les liens ne portent aucune donnée utilisateur : ceux qui ont disparu sont supprimés.
    const liens = await this.prisma.romeCompetence.deleteMany({
      where: { romeCode: fiche.code, competenceCode: { notIn: [...liensVus] } },
    });
    report.desactives.liensSupprimes += liens.count;

    // --- Appellations (postes) et curation ---
    const postesVus: string[] = [];
    for (const appellation of fiche.appellations) {
      const exposed = EXPOSED_POSTES.has(appellation.code);
      await this.prisma.poste.upsert({
        where: { code: appellation.code },
        create: {
          code: appellation.code,
          label: appellation.libelle,
          romeCode: fiche.code,
          classification: appellation.classification,
          exposed,
        },
        update: {
          label: appellation.libelle,
          romeCode: fiche.code,
          classification: appellation.classification,
          exposed,
          active: true,
        },
      });
      postesVus.push(appellation.code);
      report.postes += 1;
      if (exposed) {
        report.postesExposed += 1;
      }

      // Suggestions : de la configuration, pas des données utilisateur — remplacées en bloc.
      const suggestions = HABILITATION_SUGGESTIONS.get(appellation.code) ?? [];
      await this.prisma.posteHabilitation.deleteMany({ where: { posteCode: appellation.code } });
      if (suggestions.length > 0) {
        await this.prisma.posteHabilitation.createMany({
          data: suggestions.map((type) => ({ posteCode: appellation.code, type })),
        });
        report.suggestions += suggestions.length;
      }
    }

    const postes = await this.prisma.poste.updateMany({
      where: { romeCode: fiche.code, code: { notIn: postesVus }, active: true },
      data: { active: false },
    });
    report.desactives.postes += postes.count;
  }
}
