import { Controller, Get, Header, Query } from '@nestjs/common';
import { Public } from '../auth/decorators';
import { CompetencesQueryDto } from './dto/competences-query.dto';
import { CompetencePrincipale, PosteExpose, ReferentielService } from './referentiel.service';

// Le référentiel ne change qu'au ré-import : une heure de cache, côté navigateur comme côté
// serveur de rendu, évite de resservir les mêmes 26 postes à chaque affichage de formulaire.
// Pratique d'éco-conception (RGESN) documentée dans docs/api.md. Un ré-import met donc
// jusqu'à une heure à être visible par un client qui avait déjà la liste : acceptable.
export const REFERENTIEL_CACHE_CONTROL = 'public, max-age=3600';

// Lecture seule et publique : le référentiel est une donnée ouverte (ROME 4.0, licence
// Etalab) sans rien d'utilisateur, et les pages publiques rendues côté serveur doivent
// pouvoir le lire sans session.
@Controller('referentiel')
export class ReferentielController {
  constructor(private readonly referentiel: ReferentielService) {}

  // Postes proposés aux entreprises, avec leur code ROME et les CACES suggérés.
  @Public()
  @Get('postes')
  @Header('Cache-Control', REFERENTIEL_CACHE_CONTROL)
  postes(): Promise<PosteExpose[]> {
    return this.referentiel.postesExposes();
  }

  // Compétences proposées aux intérimaires (principales, hors savoir-être).
  // `?rome=N1101` restreint à un métier.
  @Public()
  @Get('competences')
  @Header('Cache-Control', REFERENTIEL_CACHE_CONTROL)
  competences(@Query() query: CompetencesQueryDto): Promise<CompetencePrincipale[]> {
    return this.referentiel.competencesPrincipales(query.rome);
  }
}
