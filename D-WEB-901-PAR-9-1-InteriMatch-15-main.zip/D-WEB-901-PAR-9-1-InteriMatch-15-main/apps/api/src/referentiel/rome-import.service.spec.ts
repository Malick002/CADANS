import { Test } from '@nestjs/testing';
import { CertificationType, CompetenceType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { RomeFiche } from './rome-fiche';
import { RomeImportService } from './rome-import.service';

// Fiche réduite au strict nécessaire : deux appellations (une exposée, une hors entrepôt),
// trois compétences dont une principale et une de type inconnu.
const fiche: RomeFiche = {
  code: 'N1101',
  libelle: 'Cariste',
  appellations: [
    { code: '11679', libelle: 'Cariste', classification: 'PRINCIPALE' },
    { code: '38979', libelle: 'Conducteur / Conductrice de nacelle', classification: 'SYNONYME' },
  ],
  competencesMobilisees: [
    { type: 'COMPETENCE-DETAILLEE', code: '484039', libelle: 'Conduire un chariot élévateur' },
    { type: 'SAVOIR', code: '100016', libelle: 'Gestes et postures de manutention' },
    { type: 'TYPE-INVENTE', code: '999999', libelle: 'Inconnue' },
  ],
  // Comme chez France Travail, une principale peut être absente de la liste des mobilisées.
  competencesMobiliseesPrincipales: [
    { type: 'COMPETENCE-DETAILLEE', code: '484039', libelle: 'Conduire un chariot élévateur' },
    { type: 'SAVOIR', code: '103308', libelle: 'Surveiller et contrôler les charges' },
  ],
};

type Table = Record<string, jest.Mock>;

describe('RomeImportService', () => {
  let service: RomeImportService;
  let prisma: {
    rome: Table;
    poste: Table;
    competence: Table;
    romeCompetence: Table;
    posteHabilitation: Table;
  };

  beforeEach(async () => {
    const count = jest.fn().mockResolvedValue({ count: 0 });
    prisma = {
      rome: { upsert: jest.fn(), updateMany: count },
      poste: { upsert: jest.fn(), updateMany: count },
      competence: { upsert: jest.fn(), updateMany: count },
      romeCompetence: { upsert: jest.fn(), deleteMany: count },
      posteHabilitation: { deleteMany: count, createMany: jest.fn() },
    };

    const moduleRef = await Test.createTestingModule({
      providers: [RomeImportService, { provide: PrismaService, useValue: prisma }],
    }).compile();
    service = moduleRef.get(RomeImportService);
  });

  it('utilise le code France Travail comme clé, jamais un identifiant généré', async () => {
    await service.importAll([fiche]);

    expect(prisma.rome.upsert).toHaveBeenCalledWith(
      expect.objectContaining({ where: { code: 'N1101' } }),
    );
    expect(prisma.poste.upsert).toHaveBeenCalledWith(
      expect.objectContaining({ where: { code: '11679' } }),
    );
    expect(prisma.competence.upsert).toHaveBeenCalledWith(
      expect.objectContaining({ where: { code: '484039' } }),
    );
  });

  it('marque les compétences principales et traduit le type France Travail', async () => {
    await service.importAll([fiche]);

    expect(prisma.competence.upsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: {
          code: '484039',
          label: 'Conduire un chariot élévateur',
          type: CompetenceType.COMPETENCE_DETAILLEE,
        },
      }),
    );
    expect(prisma.romeCompetence.upsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: { romeCode: 'N1101', competenceCode: '484039', principale: true },
      }),
    );
    expect(prisma.romeCompetence.upsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: { romeCode: 'N1101', competenceCode: '100016', principale: false },
      }),
    );
  });

  // Chez France Travail, « mobilisées » et « mobilisées principales » sont deux listes
  // disjointes : une principale absente des mobilisées doit quand même être importée.
  it('importe une principale absente de la liste des mobilisées', async () => {
    const report = await service.importAll([fiche]);

    expect(prisma.competence.upsert).toHaveBeenCalledWith(
      expect.objectContaining({ where: { code: '103308' } }),
    );
    expect(prisma.romeCompetence.upsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: { romeCode: 'N1101', competenceCode: '103308', principale: true },
      }),
    );
    expect(report.competences).toBe(3);
  });

  it("ignore une compétence d'un type inconnu au lieu d'inventer une catégorie", async () => {
    const report = await service.importAll([fiche]);

    expect(report.competencesIgnorees).toBe(1);
    expect(report.competences).toBe(3);
    expect(prisma.competence.upsert).not.toHaveBeenCalledWith(
      expect.objectContaining({ where: { code: '999999' } }),
    );
  });

  it('applique la curation : exposé ou non, suggestions d’habilitation', async () => {
    const report = await service.importAll([fiche]);

    expect(prisma.poste.upsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: expect.objectContaining({ code: '11679', exposed: true }),
      }),
    );
    expect(prisma.poste.upsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: expect.objectContaining({ code: '38979', exposed: false }),
      }),
    );
    expect(report.postesExposed).toBe(1);
    expect(prisma.posteHabilitation.createMany).toHaveBeenCalledWith({
      data: [{ posteCode: '11679', type: CertificationType.CACES_R489_3 }],
    });
    expect(prisma.posteHabilitation.createMany).toHaveBeenCalledTimes(1);
  });

  it('désactive ce qui a disparu de la source, sans jamais supprimer poste ou compétence', async () => {
    await service.importAll([fiche]);

    expect(prisma.poste.updateMany).toHaveBeenCalledWith({
      where: { romeCode: 'N1101', code: { notIn: ['11679', '38979'] }, active: true },
      data: { active: false },
    });
    expect(prisma.competence.updateMany).toHaveBeenCalledWith({
      where: { code: { notIn: ['484039', '100016', '103308'] }, active: true },
      data: { active: false },
    });
    expect(prisma.rome.updateMany).toHaveBeenCalledWith({
      where: { code: { notIn: ['N1101'] }, active: true },
      data: { active: false },
    });
    expect(prisma.poste.deleteMany).toBeUndefined();
    expect(prisma.competence.deleteMany).toBeUndefined();
  });

  it('réactive une entrée revenue dans la source', async () => {
    await service.importAll([fiche]);

    expect(prisma.poste.upsert).toHaveBeenCalledWith(
      expect.objectContaining({ update: expect.objectContaining({ active: true }) }),
    );
    expect(prisma.competence.upsert).toHaveBeenCalledWith(
      expect.objectContaining({ update: expect.objectContaining({ active: true }) }),
    );
  });

  it('supprime seulement les liens ROME ↔ compétence disparus', async () => {
    await service.importAll([fiche]);

    expect(prisma.romeCompetence.deleteMany).toHaveBeenCalledWith({
      where: { romeCode: 'N1101', competenceCode: { notIn: ['484039', '100016', '103308'] } },
    });
  });
});
