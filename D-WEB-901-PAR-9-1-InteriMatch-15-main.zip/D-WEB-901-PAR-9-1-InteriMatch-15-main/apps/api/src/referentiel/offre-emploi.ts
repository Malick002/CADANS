// Forme d'une offre France Travail telle que la renvoie
// GET /partenaire/offresdemploi/v2/offres/{id}, RÉDUITE AUX CHAMPS QUE L'ON REPREND.
//
// Ce qui n'est pas déclaré ici n'est pas lu, et donc jamais stocké : `contact`, `agence` et
// `entreprise` portent les coordonnées du recruteur d'origine (téléphone, courriel, URL de
// candidature) — les omettre du type est la première barrière, avant même le nettoyage de la
// description. Voir docs/referentiel-matching.md, « Préremplir une mission depuis une offre France Travail ».

export interface OffreEmploiLieu {
  libelle?: string;
  codePostal?: string;
}

export interface OffreEmploiSalaire {
  libelle?: string;
}

export interface OffreEmploi {
  id: string;
  intitule: string;
  description?: string;
  romeCode?: string;
  appellationlibelle?: string;
  lieuTravail?: OffreEmploiLieu;
  salaire?: OffreEmploiSalaire;
  dureeTravailLibelle?: string;
}

// Vérification de surface, même logique que `assertRomeFiche` : on préfère un échec explicite
// à un préremplissage silencieusement vide si la structure de la réponse change.
export function estOffreEmploi(valeur: unknown): valeur is OffreEmploi {
  const offre = valeur as Partial<OffreEmploi> | null;
  return (
    typeof offre === 'object' &&
    offre !== null &&
    typeof offre.id === 'string' &&
    typeof offre.intitule === 'string'
  );
}
