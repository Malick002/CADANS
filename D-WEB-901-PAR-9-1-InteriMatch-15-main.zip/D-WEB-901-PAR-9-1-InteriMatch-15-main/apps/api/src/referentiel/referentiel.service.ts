import { Injectable } from '@nestjs/common';
import { CertificationType, CompetenceType } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

// Poste proposé à une entreprise dans le formulaire de mission.
export interface PosteExpose {
  code: string;
  label: string;
  classification: string;
  rome: { code: string; label: string };
  // Pré-remplissage des habilitations exigées par la mission ; l'entreprise ajuste.
  habilitationsSuggerees: CertificationType[];
}

// Compétence proposée à un intérimaire dans son profil.
export interface CompetencePrincipale {
  code: string;
  label: string;
  type: CompetenceType;
  // Codes ROME pour lesquels France Travail la met en avant.
  romeCodes: string[];
}

/**
 * Lecture du référentiel métier. Deux vues, une par public :
 * - les postes **exposés** (curation) pour l'entreprise qui décrit une mission ;
 * - les compétences **principales** pour l'intérimaire qui décrit son profil.
 *
 * Ce qui est désactivé par un ré-import n'est plus proposé, mais reste en base : un profil
 * ou une mission qui y fait référence continue de se lire.
 */
@Injectable()
export class ReferentielService {
  constructor(private readonly prisma: PrismaService) {}

  async postesExposes(): Promise<PosteExpose[]> {
    const postes = await this.prisma.poste.findMany({
      where: { exposed: true, active: true, rome: { active: true } },
      // Par code ROME, l'appellation PRINCIPALE en tête (l'ordre alphabétique des
      // classifications le donne), puis les synonymes par libellé.
      orderBy: [{ romeCode: 'asc' }, { classification: 'asc' }, { label: 'asc' }],
      select: {
        code: true,
        label: true,
        classification: true,
        rome: { select: { code: true, label: true } },
        habilitations: { select: { type: true } },
      },
    });

    return postes.map((poste) => ({
      code: poste.code,
      label: poste.label,
      classification: poste.classification,
      rome: poste.rome,
      habilitationsSuggerees: poste.habilitations.map((h) => h.type),
    }));
  }

  // `romeCode` restreint aux compétences principales d'un seul métier.
  async competencesPrincipales(romeCode?: string): Promise<CompetencePrincipale[]> {
    const liens = await this.prisma.romeCompetence.findMany({
      where: {
        principale: true,
        ...(romeCode ? { romeCode } : {}),
        rome: { active: true },
        // Les savoir-être (« faire preuve de rigueur ») ne sont jamais proposés :
        // inexploitables pour un matching.
        competence: { active: true, type: { not: CompetenceType.MACRO_SAVOIR_ETRE } },
      },
      orderBy: { romeCode: 'asc' },
      select: {
        romeCode: true,
        competence: { select: { code: true, label: true, type: true } },
      },
    });

    // Une compétence principale dans plusieurs métiers (« gestes et postures ») n'apparaît
    // qu'une fois, avec la liste des codes ROME concernés.
    const parCode = new Map<string, CompetencePrincipale>();
    for (const lien of liens) {
      const existing = parCode.get(lien.competence.code);
      if (existing) {
        existing.romeCodes.push(lien.romeCode);
      } else {
        parCode.set(lien.competence.code, { ...lien.competence, romeCodes: [lien.romeCode] });
      }
    }

    return [...parCode.values()].sort((a, b) => a.label.localeCompare(b.label, 'fr'));
  }
}
