import { Injectable, Logger } from '@nestjs/common';
import { setTimeout as sleep } from 'node:timers/promises';
import { estOffreEmploi, OffreEmploi } from './offre-emploi';
import { assertRomeFiche, RomeFiche } from './rome-fiche';

// Authentification OAuth2 « client credentials » de France Travail : un jeton par scope,
// chaque API ayant le sien. Le realm /partenaire est celui des API publiques.
const TOKEN_URL =
  'https://entreprise.francetravail.fr/connexion/oauth2/access_token?realm=%2Fpartenaire';
const ROME_METIERS_URL = 'https://api.francetravail.io/partenaire/rome-metiers/v1/metiers/metier';
export const SCOPE_ROME_METIERS = 'api_rome-metiersv1 nomenclatureRome';

const OFFRES_URL = 'https://api.francetravail.io/partenaire/offresdemploi/v2/offres';
export const SCOPE_OFFRES = 'api_offresdemploiv2 o2dsoffre';

// Limite documentée de l'API ROME : un appel par seconde.
export const ROME_MIN_INTERVAL_MS = 1100;

// Les trois seules façons dont la lecture d'une offre peut échouer, du point de vue de
// l'entreprise qui colle un lien. Le service les traduit en réponses HTTP, l'écran en phrases.
export type RaisonEchecOffre = 'introuvable' | 'quota' | 'indisponible';

export class OffreFranceTravailError extends Error {
  constructor(
    readonly raison: RaisonEchecOffre,
    message: string,
  ) {
    super(message);
    this.name = 'OffreFranceTravailError';
  }
}

/**
 * Client des API France Travail, appelées avec le fetch natif de Node — aucune dépendance.
 * Les identifiants viennent du .env (FRANCE_TRAVAIL_CLIENT_ID / _CLIENT_SECRET) et ne sont
 * lus qu'au moment d'un appel : l'API démarre sans eux, seule la CLI en a besoin.
 */
@Injectable()
export class FranceTravailClient {
  private readonly logger = new Logger(FranceTravailClient.name);

  get configured(): boolean {
    return Boolean(
      process.env.FRANCE_TRAVAIL_CLIENT_ID && process.env.FRANCE_TRAVAIL_CLIENT_SECRET,
    );
  }

  async token(scope: string): Promise<string> {
    if (!this.configured) {
      throw new Error(
        'FRANCE_TRAVAIL_CLIENT_ID et FRANCE_TRAVAIL_CLIENT_SECRET sont requis dans le .env ' +
          '(compte sur francetravail.io, application souscrite aux API ROME 4.0).',
      );
    }

    const response = await fetch(TOKEN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'client_credentials',
        client_id: process.env.FRANCE_TRAVAIL_CLIENT_ID as string,
        client_secret: process.env.FRANCE_TRAVAIL_CLIENT_SECRET as string,
        scope,
      }),
    });

    if (!response.ok) {
      // Cause la plus fréquente : le scope ne correspond à aucune API souscrite.
      throw new Error(
        `Jeton France Travail refusé (HTTP ${response.status}) pour le scope « ${scope} » : ` +
          (await response.text().catch(() => '')),
      );
    }

    const payload = (await response.json()) as { access_token?: string };
    if (!payload.access_token) {
      throw new Error('Réponse de jeton France Travail sans access_token');
    }
    return payload.access_token;
  }

  async romeMetier(code: string, token: string): Promise<RomeFiche> {
    const url = `${ROME_METIERS_URL}/${encodeURIComponent(code)}`;
    const response = await fetch(url, {
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
    });
    if (!response.ok) {
      throw new Error(`Fiche ROME ${code} : HTTP ${response.status}`);
    }
    return assertRomeFiche(await response.json(), `fiche ROME ${code}`);
  }

  /**
   * Lit une offre par son identifiant. Un appel utilisateur = un jeton + un appel : pas de
   * cache de jeton, le préremplissage est une action ponctuelle et rare (quelques appels par
   * mission créée), très loin des quotas de l'API.
   *
   * Lève toujours `OffreFranceTravailError`, jamais une erreur nue : l'appelant doit pouvoir
   * distinguer « cette offre n'existe plus » de « le service est en panne ».
   *
   * CODES VÉRIFIÉS le 23/09/2026 contre l'API réelle :
   * - 200 → l'offre ;
   * - **204 No Content** → identifiant bien formé mais inconnu ou expiré. C'est LE piège :
   *   `response.ok` vaut `true` sur un 204, et un test naïf préremplirait un formulaire vide ;
   * - 400 → format d'identifiant refusé par France Travail ;
   * - 429 → quota atteint ;
   * - tout le reste, et l'absence de réponse → service indisponible.
   */
  async offreEmploi(reference: string): Promise<OffreEmploi> {
    let token: string;
    try {
      token = await this.token(SCOPE_OFFRES);
    } catch (error) {
      // Identifiants absents ou refusés : rien à faire côté entreprise, c'est une panne.
      throw new OffreFranceTravailError(
        'indisponible',
        `Jeton France Travail indisponible : ${(error as Error).message}`,
      );
    }

    let response: Response;
    try {
      response = await fetch(`${OFFRES_URL}/${encodeURIComponent(reference)}`, {
        headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
      });
    } catch (error) {
      throw new OffreFranceTravailError(
        'indisponible',
        `API France Travail injoignable : ${(error as Error).message}`,
      );
    }

    if (response.status === 204) {
      throw new OffreFranceTravailError(
        'introuvable',
        `Offre ${reference} inconnue ou expirée (204)`,
      );
    }
    if (response.status === 400) {
      throw new OffreFranceTravailError(
        'introuvable',
        `Offre ${reference} : identifiant refusé par France Travail (400)`,
      );
    }
    if (response.status === 429) {
      throw new OffreFranceTravailError('quota', 'Quota France Travail atteint (429)');
    }
    if (!response.ok) {
      throw new OffreFranceTravailError(
        'indisponible',
        `Offre ${reference} : HTTP ${response.status}`,
      );
    }

    const payload: unknown = await response.json().catch(() => null);
    if (!estOffreEmploi(payload)) {
      throw new OffreFranceTravailError(
        'indisponible',
        `Offre ${reference} : structure de réponse inattendue`,
      );
    }
    return payload;
  }

  // Un seul jeton pour la série, et un délai entre les appels pour respecter la limite.
  async romeMetiers(codes: readonly string[]): Promise<RomeFiche[]> {
    const token = await this.token(SCOPE_ROME_METIERS);
    const fiches: RomeFiche[] = [];
    for (const [index, code] of codes.entries()) {
      if (index > 0) {
        await sleep(ROME_MIN_INTERVAL_MS);
      }
      fiches.push(await this.romeMetier(code, token));
      this.logger.log(`Fiche ROME ${code} reçue`);
    }
    return fiches;
  }
}
