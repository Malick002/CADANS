import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { FranceTravailClient } from './france-travail.client';
import { ReferentielController } from './referentiel.controller';
import { ReferentielService } from './referentiel.service';
import { RomeImportService } from './rome-import.service';

// Référentiel métier ROME : import (CLI) et lecture par l'API — postes exposés pour les
// missions, compétences principales pour les profils.
@Module({
  imports: [PrismaModule],
  controllers: [ReferentielController],
  providers: [FranceTravailClient, RomeImportService, ReferentielService],
  exports: [FranceTravailClient, RomeImportService, ReferentielService],
})
export class ReferentielModule {}
