import { EXPOSED_POSTES, HABILITATION_SUGGESTIONS, ROME_CODES } from './curation';
import { readSeed } from './seed-files';

// La curation est écrite à la main : ce test garantit qu'elle ne cite que des codes qui
// existent réellement dans les fiches figées, et qu'une faute de frappe ne passe pas.
describe('curation du référentiel', () => {
  const fiches = ROME_CODES.map((code) => readSeed(code));
  const appellations = new Map(
    fiches.flatMap((f) =>
      f.appellations.map((a) => [a.code, { fiche: f.code, libelle: a.libelle }]),
    ),
  );

  it('les fichiers de seed couvrent exactement le périmètre', () => {
    expect(fiches.map((f) => f.code)).toEqual([...ROME_CODES]);
  });

  it('chaque appellation exposée existe dans une fiche', () => {
    const inconnues = [...EXPOSED_POSTES].filter((code) => !appellations.has(code));
    expect(inconnues).toEqual([]);
  });

  it('chaque code ROME a au moins son appellation principale exposée', () => {
    for (const fiche of fiches) {
      const principale = fiche.appellations.find((a) => a.classification === 'PRINCIPALE');
      expect(principale).toBeDefined();
      expect(EXPOSED_POSTES.has(principale!.code)).toBe(true);
    }
  });

  it('les suggestions d’habilitation ne visent que des postes exposés', () => {
    const horsExposition = [...HABILITATION_SUGGESTIONS.keys()].filter(
      (code) => !EXPOSED_POSTES.has(code),
    );
    expect(horsExposition).toEqual([]);
  });

  it('les métiers hors entrepôt cités dans docs/referentiel-matching.md ne sont pas exposés', () => {
    const ecartes = [...appellations.entries()]
      .filter(([, a]) =>
        /nacelle|armée|ferroviaire|ferroutage|bagagiste|messagerie|carnés/i.test(a.libelle),
      )
      .map(([code]) => code);
    expect(ecartes.length).toBeGreaterThan(0);
    expect(ecartes.filter((code) => EXPOSED_POSTES.has(code))).toEqual([]);
  });
});
