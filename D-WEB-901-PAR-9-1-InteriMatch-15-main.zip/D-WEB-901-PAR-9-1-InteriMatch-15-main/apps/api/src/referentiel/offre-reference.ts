// Reconnaissance d'une référence d'offre France Travail dans ce que l'utilisateur colle :
// une URL de la fiche publique, ou l'identifiant seul. Fonction pure, testée sans réseau.
//
// FAIT MESURÉ le 23/09/2026 sur 150 offres des trois codes ROME du périmètre : l'identifiant
// fait SEPT caractères alphanumériques majuscules, sans exception (« 214GWTK »). L'API le
// confirme en creux, puisqu'elle refuse tout autre format par un 400 explicite.
//
// Le motif n'exige PAS de chiffre, bien que les 150 identifiants observés en contiennent
// tous : un mot de sept lettres est donc accepté ici et tranché par l'API (204 → « offre
// introuvable »). Resserrer le motif économiserait un appel inutile, au risque de refuser
// une référence valide le jour où France Travail en émet une tout en lettres. Le mauvais
// côté de l'arbitrage.
export const OFFRE_ID_PATTERN = /^[A-Z0-9]{7}$/;

// Seuls les domaines de France Travail sont acceptés. Une URL d'agrégateur ou de site
// d'annonces peut contenir sept caractères qui ressemblent à un identifiant sans en être un :
// mieux vaut refuser et demander l'identifiant que d'appeler l'API avec n'importe quoi.
const HOSTS_AUTORISES = ['francetravail.fr', 'francetravail.io', 'pole-emploi.fr'];

// Les deux formes rencontrées : le segment final de la fiche publique
// (candidat.francetravail.fr/offres/recherche/detail/214GWTK) et le paramètre `offreId`
// que portent d'anciens liens.
const PARAMS_ID = ['offreId', 'idOffre', 'id'];

/**
 * Rend l'identifiant d'offre trouvé dans `saisie`, ou `null` si elle n'en contient pas.
 * Jamais d'exception : l'appelant décide du message, et il y en a toujours un.
 */
export function extraireReferenceOffre(saisie: string): string | null {
  const texte = saisie.trim();
  if (texte === '') {
    return null;
  }

  // Identifiant collé seul. La casse est tolérée à la saisie et normalisée : l'API, elle,
  // n'accepte que les majuscules.
  const brut = texte.replace(/^n[°o]\s*/i, '').trim();
  if (OFFRE_ID_PATTERN.test(brut.toUpperCase())) {
    return brut.toUpperCase();
  }

  return depuisUrl(texte);
}

function depuisUrl(texte: string): string | null {
  let url: URL;
  try {
    // Une URL collée sans schéma (« candidat.francetravail.fr/… ») reste une URL pour
    // l'utilisateur : on lui en ajoute un plutôt que de la refuser.
    url = new URL(/^https?:\/\//i.test(texte) ? texte : `https://${texte}`);
  } catch {
    return null;
  }

  const hote = url.hostname.toLowerCase();
  if (!HOSTS_AUTORISES.some((domaine) => hote === domaine || hote.endsWith(`.${domaine}`))) {
    return null;
  }

  for (const nom of PARAMS_ID) {
    const valeur = url.searchParams.get(nom)?.trim().toUpperCase();
    if (valeur && OFFRE_ID_PATTERN.test(valeur)) {
      return valeur;
    }
  }

  // Dernier segment non vide du chemin : couvre /offres/recherche/detail/214GWTK comme
  // les variantes qui intercalent un libellé, sans figer un chemin exact qui changerait.
  const segments = url.pathname.split('/').filter((segment) => segment !== '');
  const dernier = segments.at(-1)?.toUpperCase();
  if (dernier && OFFRE_ID_PATTERN.test(dernier)) {
    return dernier;
  }

  return null;
}

// Fiche publique de l'offre, pour que l'entreprise puisse vérifier la source de ce qu'on lui
// a prérempli. C'est l'URL que l'API elle-même renvoie dans `origineOffre.urlOrigine`.
export function urlOffrePublique(reference: string): string {
  return `https://candidat.francetravail.fr/offres/recherche/detail/${reference}`;
}
