import { IsOptional, Matches } from 'class-validator';

// Filtre facultatif : un code ROME (lettre + quatre chiffres, ex. N1101).
export class CompetencesQueryDto {
  @IsOptional()
  @Matches(/^[A-Z]\d{4}$/, {
    message: 'Le code ROME doit être une lettre suivie de quatre chiffres',
  })
  rome?: string;
}
