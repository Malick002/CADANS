import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { Shift } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateProfilMatchingDto } from './dto/update-profil-matching.dto';
import { UpdateWorkerIdentityDto } from './dto/update-worker-identity.dto';

export interface ProfilMatchingView {
  shifts: Shift[];
  competences: { code: string; label: string }[];
}

// Coordonnées de l'intérimaire, pendant de CompanyProfileView côté entreprise.
export interface WorkerIdentityView {
  firstName: string;
  lastName: string;
  phone: string | null;
  postalCode: string;
  city: string;
}

const IDENTITY_SELECT = {
  firstName: true,
  lastName: true,
  phone: true,
  postalCode: true,
  city: true,
} as const;

@Injectable()
export class WorkerProfileService {
  constructor(private readonly prisma: PrismaService) {}

  // Identité et localisation : ce que l'intérimaire a saisi à l'inscription, et qu'il doit
  // pouvoir corriger — un déménagement change le critère « zone » du matching.
  async getIdentity(userId: string): Promise<WorkerIdentityView> {
    const workerId = await this.workerId(userId);
    return this.prisma.worker.findUniqueOrThrow({
      where: { id: workerId },
      select: IDENTITY_SELECT,
    });
  }

  async updateIdentity(userId: string, dto: UpdateWorkerIdentityDto): Promise<WorkerIdentityView> {
    const workerId = await this.workerId(userId);
    return this.prisma.worker.update({
      where: { id: workerId },
      data: {
        firstName: dto.firstName,
        lastName: dto.lastName,
        // Champ facultatif : absent du corps, il est EFFACÉ et non laissé tel quel. L'écran
        // renvoie le formulaire entier, un téléphone vidé doit donc l'être en base.
        phone: dto.phone ?? null,
        postalCode: dto.postalCode,
        city: dto.city,
      },
      select: IDENTITY_SELECT,
    });
  }

  async getProfilMatching(userId: string): Promise<ProfilMatchingView> {
    const workerId = await this.workerId(userId);
    const worker = await this.prisma.worker.findUniqueOrThrow({
      where: { id: workerId },
      select: {
        shifts: true,
        skills: { select: { competence: { select: { code: true, label: true } } } },
      },
    });

    return {
      shifts: worker.shifts,
      competences: worker.skills.map((skill) => skill.competence),
    };
  }

  async updateProfilMatching(
    userId: string,
    dto: UpdateProfilMatchingDto,
  ): Promise<ProfilMatchingView> {
    const workerId = await this.workerId(userId);
    const competenceCodes = [...new Set(dto.competenceCodes)];
    await this.assertCompetencesExist(competenceCodes);

    await this.prisma.$transaction([
      this.prisma.workerSkill.deleteMany({ where: { workerId } }),
      this.prisma.workerSkill.createMany({
        data: competenceCodes.map((competenceCode) => ({ workerId, competenceCode })),
      }),
      this.prisma.worker.update({
        where: { id: workerId },
        data: { shifts: dto.shifts },
      }),
    ]);

    return this.getProfilMatching(userId);
  }

  private async workerId(userId: string): Promise<string> {
    const worker = await this.prisma.worker.findUnique({ where: { userId }, select: { id: true } });
    if (!worker) {
      throw new NotFoundException('Profil intérimaire introuvable');
    }
    return worker.id;
  }

  private async assertCompetencesExist(codes: string[]): Promise<void> {
    if (codes.length === 0) {
      return;
    }
    const found = await this.prisma.competence.findMany({
      where: { code: { in: codes } },
      select: { code: true },
    });
    if (found.length !== codes.length) {
      throw new BadRequestException('Une ou plusieurs compétences sont inconnues du référentiel');
    }
  }
}
