import { Body, Controller, Get, Put } from '@nestjs/common';
import { Role } from '@prisma/client';
import { CurrentUser, Roles } from '../auth/decorators';
import { SessionUser } from '../auth/token.service';
import { SaveInformationsEmbaucheDto } from './dto/save-informations-embauche.dto';
import { UpdateProfilMatchingDto } from './dto/update-profil-matching.dto';
import { UpdateWorkerIdentityDto } from './dto/update-worker-identity.dto';
import { HiringInfoService, InformationsEmbaucheView } from './hiring-info.service';
import {
  ProfilMatchingView,
  WorkerIdentityView,
  WorkerProfileService,
} from './worker-profile.service';

// Partage le préfixe workers/me avec SensitiveDocumentsController : l'identité vient toujours
// de la session, jamais de l'URL.
@Roles(Role.WORKER)
@Controller('workers/me')
export class WorkerProfileController {
  constructor(
    private readonly profile: WorkerProfileService,
    private readonly hiringInfo: HiringInfoService,
  ) {}

  // Coordonnées de l'intérimaire, pendant de GET/PUT /companies/me côté entreprise.
  @Get('identite')
  getIdentity(@CurrentUser() user: SessionUser): Promise<WorkerIdentityView> {
    return this.profile.getIdentity(user.id);
  }

  @Put('identite')
  updateIdentity(
    @CurrentUser() user: SessionUser,
    @Body() dto: UpdateWorkerIdentityDto,
  ): Promise<WorkerIdentityView> {
    return this.profile.updateIdentity(user.id, dto);
  }

  @Get('profil-matching')
  get(@CurrentUser() user: SessionUser): Promise<ProfilMatchingView> {
    return this.profile.getProfilMatching(user.id);
  }

  @Put('profil-matching')
  update(
    @CurrentUser() user: SessionUser,
    @Body() dto: UpdateProfilMatchingDto,
  ): Promise<ProfilMatchingView> {
    return this.profile.updateProfilMatching(user.id, dto);
  }

  // Informations d'embauche : état civil, adresse, NIR et IBAN. Réservées au rôle WORKER
  // par le décorateur de classe — une entreprise qui appelle ces routes reçoit 403, et ce
  // n'est pas un effet de bord : c'est la raison pour laquelle elles vivent sous ce préfixe.
  @Get('informations-embauche')
  getInformationsEmbauche(@CurrentUser() user: SessionUser): Promise<InformationsEmbaucheView> {
    return this.hiringInfo.get(user.id);
  }

  @Put('informations-embauche')
  saveInformationsEmbauche(
    @CurrentUser() user: SessionUser,
    @Body() dto: SaveInformationsEmbaucheDto,
  ): Promise<InformationsEmbaucheView> {
    return this.hiringInfo.save(user.id, dto);
  }
}
