import { compacter, isValidIban, isValidNir, masquer } from './identifiants';

// Clés recalculées avec la formule 97 − (numéro mod 97), pas recopiées d'un exemple trouvé
// en ligne : un jeu d'essai faux valide une implémentation fausse.
describe('isValidNir', () => {
  it('accepte un NIR dont la clé est juste', () => {
    expect(isValidNir('180127511600128')).toBe(true);
    expect(isValidNir('278057512345675')).toBe(true);
  });

  it('refuse un NIR dont la clé est fausse', () => {
    expect(isValidNir('180127511600129')).toBe(false);
    // Deux chiffres transposés dans le numéro : c'est exactement la faute de frappe que la
    // clé existe pour attraper.
    expect(isValidNir('180127511600028')).toBe(false);
  });

  it('accepte les départements corses, dont les lettres se substituent à 19 et 18', () => {
    expect(isValidNir('195052A12345628')).toBe(true);
    expect(isValidNir('295122B98765492')).toBe(true);
  });

  it('refuse une lettre ailleurs que dans le département', () => {
    expect(isValidNir('1A0127511600128')).toBe(false);
    expect(isValidNir('18012751160012A')).toBe(false);
  });

  it('accepte les numéros temporaires (7 et 8 en première position)', () => {
    expect(isValidNir('790017512345646')).toBe(true);
  });

  it('refuse un premier chiffre impossible', () => {
    // Même numéro que ci-dessus, sexe 0 : la clé reste juste, la forme ne l'est pas.
    expect(isValidNir('090017512345646')).toBe(false);
  });

  it('refuse une longueur autre que 15', () => {
    expect(isValidNir('18012751160012')).toBe(false);
    expect(isValidNir('1801275116001280')).toBe(false);
    expect(isValidNir('')).toBe(false);
  });

  // Le mois n'est volontairement pas borné à 01-12 : l'INSEE utilise des valeurs
  // conventionnelles au-delà — 20 pour un mois inconnu, et la plage haute pour les
  // immatriculations de personnes nées à l'étranger. Les borner rejetterait des numéros réels.
  it('accepte un mois conventionnel supérieur à 12', () => {
    expect(isValidNir('278627512345617')).toBe(true);
    expect(isValidNir('180207511600159')).toBe(true);
  });

  it('refuse des espaces non retirés', () => {
    expect(isValidNir('1 80 12 75 116 001 28')).toBe(false);
  });
});

describe('isValidIban', () => {
  // IBAN d'exemple public de la norme, contrôle mod 97 vérifié à part.
  it('accepte un IBAN français valide', () => {
    expect(isValidIban('FR1420041010050500013M02606')).toBe(true);
  });

  it('refuse un IBAN français de la bonne forme mais de mauvaise longueur', () => {
    expect(isValidIban('FR142004101005050001302606')).toBe(false);
  });

  it('refuse un chiffre modifié', () => {
    expect(isValidIban('FR1420041010050500013M02607')).toBe(false);
  });

  it('refuse un IBAN en minuscules ou espacé : on attend la forme compacte', () => {
    expect(isValidIban('fr1420041010050500013m02606')).toBe(false);
    expect(isValidIban('FR14 2004 1010 0505 0001 3M02 606')).toBe(false);
  });

  it('refuse une forme qui n’est pas un IBAN', () => {
    expect(isValidIban('')).toBe(false);
    expect(isValidIban('1420041010050500013M02606')).toBe(false);
    expect(isValidIban('FRAB20041010050500013M02606')).toBe(false);
  });
});

describe('compacter', () => {
  it('retire espaces et tirets et passe en majuscules', () => {
    expect(compacter('fr14 2004-1010 0505 0001 3m02 606')).toBe('FR1420041010050500013M02606');
    expect(compacter('1 80 12 75 116 001 28')).toBe('180127511600128');
  });

  // C'est tout l'intérêt de compacter avant de valider : la forme lue sur une carte Vitale
  // ou un RIB est espacée, et elle doit être acceptée.
  it('rend valides les formes espacées telles qu’on les recopie', () => {
    expect(isValidNir(compacter('1 80 12 75 116 001 28'))).toBe(true);
    expect(isValidIban(compacter('FR14 2004 1010 0505 0001 3M02 606'))).toBe(true);
  });
});

describe('masquer', () => {
  it('ne laisse lisibles que les quatre derniers caractères', () => {
    expect(masquer('180127511600128')).toBe('•••••••••••0128');
    expect(masquer('FR1420041010050500013M02606')).toBe(`${'•'.repeat(23)}2606`);
  });

  it('ne masque rien de plus court que la fenêtre visible', () => {
    expect(masquer('12')).toBe('12');
  });
});
