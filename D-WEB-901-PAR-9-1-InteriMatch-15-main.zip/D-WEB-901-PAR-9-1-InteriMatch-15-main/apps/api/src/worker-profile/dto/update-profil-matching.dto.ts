import { Shift } from '@prisma/client';
import { ArrayMaxSize, IsArray, IsEnum, IsString } from 'class-validator';

// Pas de fenêtre de disponibilité : un intérimaire qui consulte la plateforme est considéré
// disponible (décision produit du 21/09). Le créneau reste, lui : travailler de nuit ou le
// matin n'est pas interchangeable, c'est le premier critère d'élimination après le CACES.
export class UpdateProfilMatchingDto {
  @IsArray()
  @ArrayMaxSize(4)
  @IsEnum(Shift, { each: true, message: 'Créneau inconnu' })
  shifts: Shift[];

  @IsArray()
  @ArrayMaxSize(50)
  @IsString({ each: true })
  competenceCodes: string[];
}
