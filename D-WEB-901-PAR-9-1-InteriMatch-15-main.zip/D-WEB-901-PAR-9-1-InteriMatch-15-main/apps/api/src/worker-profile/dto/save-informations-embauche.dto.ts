import { IsNotEmpty, IsString, Matches, MaxLength, registerDecorator } from 'class-validator';
import { POSTAL_CODE_PATTERN, Trim } from '../../auth/dto/validation';
import { Compacter, IsIban, IsNir } from '../identifiants';

// Un intérimaire est un salarié : le Code du travail interdit d'employer un mineur de moins
// de 16 ans (art. L. 4153-1), et la conduite d'engins en entrepôt suppose de toute façon
// une habilitation qu'on n'obtient pas avant. La borne haute n'est qu'un garde-fou de
// saisie : elle attrape un siècle tapé de travers, pas une personne réelle.
const AGE_MINIMUM = 16;
const AGE_MAXIMUM = 100;

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Informations d'embauche : tout ou rien.
 *
 * Aucun champ n'est facultatif, parce que le contrat de mission les exige tous. Un
 * formulaire à moitié rempli ne produirait pas un contrat à moitié valable, il ne
 * produirait rien — autant le dire à la saisie.
 *
 * **Le NIR et l'IBAN ne doivent jamais ressortir d'ici.** Ils sont chiffrés par le service
 * avant d'atteindre la base, et l'API n'en renvoie que les quatre derniers caractères. Les
 * messages de validation ci-dessous ne reprennent jamais la valeur saisie : une erreur 400
 * journalisée par un intermédiaire ne doit pas contenir un numéro de sécurité sociale.
 */
export class SaveInformationsEmbaucheDto {
  @Trim()
  @Matches(DATE_PATTERN, { message: 'La date de naissance doit être au format AAAA-MM-JJ' })
  @IsDateDeNaissancePlausible()
  birthDate: string;

  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Renseignez votre commune de naissance' })
  @MaxLength(100)
  birthPlace: string;

  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Renseignez votre pays de naissance' })
  @MaxLength(100)
  birthCountry: string;

  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Renseignez votre nationalité' })
  @MaxLength(100)
  nationality: string;

  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Renseignez votre adresse' })
  @MaxLength(255)
  addressLine: string;

  @Trim()
  @Matches(POSTAL_CODE_PATTERN, { message: 'Le code postal doit comporter 5 chiffres' })
  addressPostalCode: string;

  @Trim()
  @IsString()
  @IsNotEmpty({ message: 'Renseignez votre commune' })
  @MaxLength(100)
  addressCity: string;

  @Compacter()
  @IsNir()
  nir: string;

  @Compacter()
  @IsIban()
  iban: string;
}

// Déclaré après la classe pour rester lisible : une date réelle (le 31 février est refusé
// par la conversion, pas par le motif) et un âge compatible avec un contrat de travail.
function IsDateDeNaissancePlausible(): PropertyDecorator {
  return (target: object, propertyName: string | symbol): void => {
    registerDecorator({
      name: 'isDateDeNaissancePlausible',
      target: target.constructor,
      propertyName: propertyName.toString(),
      options: {
        message: `La date de naissance doit être réelle et correspondre à un âge entre ${AGE_MINIMUM} et ${AGE_MAXIMUM} ans`,
      },
      validator: {
        validate: (value: unknown): boolean =>
          typeof value === 'string' && estDateDeNaissancePlausible(value),
      },
    });
  };
}

export function estDateDeNaissancePlausible(value: string, aujourdhui = new Date()): boolean {
  if (!DATE_PATTERN.test(value)) {
    return false;
  }

  const date = new Date(`${value}T00:00:00Z`);
  // `new Date('2026-02-31')` ne lève pas : il glisse au 3 mars. On compare donc la date
  // reconstruite à celle qui a été saisie.
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) {
    return false;
  }

  const age = ageEnAnnees(date, aujourdhui);
  return age >= AGE_MINIMUM && age <= AGE_MAXIMUM;
}

function ageEnAnnees(naissance: Date, aujourdhui: Date): number {
  let age = aujourdhui.getUTCFullYear() - naissance.getUTCFullYear();
  const moisEcoule =
    aujourdhui.getUTCMonth() > naissance.getUTCMonth() ||
    (aujourdhui.getUTCMonth() === naissance.getUTCMonth() &&
      aujourdhui.getUTCDate() >= naissance.getUTCDate());
  if (!moisEcoule) {
    age -= 1;
  }
  return age;
}
