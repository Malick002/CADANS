import { IsNotEmpty, IsOptional, IsString, Matches, MaxLength } from 'class-validator';
import { PHONE_PATTERN, POSTAL_CODE_PATTERN, StripSpaces, Trim } from '../../auth/dto/validation';

// Mêmes champs et mêmes règles que RegisterWorkerDto, hors identifiants de connexion : ce
// sont les coordonnées saisies à l'inscription, que l'intérimaire doit pouvoir corriger.
// Le pendant côté entreprise est UpdateCompanyProfileDto.
//
// Le code postal et la ville ne sont pas décoratifs : ils portent le critère « zone » du
// matching (docs/referentiel-matching.md). Un déménagement non répercuté écarte l'intérimaire des missions
// proches de chez lui sans qu'il comprenne pourquoi.
export class UpdateWorkerIdentityDto {
  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  firstName: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  lastName: string;

  @IsOptional()
  @StripSpaces()
  @Matches(PHONE_PATTERN, { message: "Le numéro de téléphone n'est pas valide" })
  phone?: string;

  @Trim()
  @Matches(POSTAL_CODE_PATTERN, { message: 'Le code postal doit comporter 5 chiffres' })
  postalCode: string;

  @Trim()
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  city: string;
}
