import { BadRequestException, NotFoundException } from '@nestjs/common';
import { Shift } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateProfilMatchingDto } from './dto/update-profil-matching.dto';
import { WorkerProfileService } from './worker-profile.service';

const dto: UpdateProfilMatchingDto = {
  shifts: [Shift.MATIN, Shift.JOURNEE],
  competenceCodes: ['C1', 'C2'],
};

describe('WorkerProfileService', () => {
  let prisma: {
    worker: { findUnique: jest.Mock; findUniqueOrThrow: jest.Mock; update: jest.Mock };
    competence: { findMany: jest.Mock };
    workerSkill: { deleteMany: jest.Mock; createMany: jest.Mock };
    $transaction: jest.Mock;
  };
  let service: WorkerProfileService;

  beforeEach(() => {
    prisma = {
      worker: {
        findUnique: jest.fn().mockResolvedValue({ id: 'worker-1' }),
        findUniqueOrThrow: jest.fn().mockResolvedValue({
          shifts: [Shift.MATIN, Shift.JOURNEE],
          skills: [{ competence: { code: 'C1', label: 'Compétence 1' } }],
        }),
        update: jest.fn(),
      },
      competence: {
        findMany: jest.fn().mockResolvedValue([{ code: 'C1' }, { code: 'C2' }]),
      },
      workerSkill: { deleteMany: jest.fn(), createMany: jest.fn() },
      $transaction: jest.fn((operations: unknown[]) => Promise.all(operations)),
    };
    service = new WorkerProfileService(prisma as unknown as PrismaService);
  });

  it('renvoie le profil de matching du compte connecté', async () => {
    const view = await service.getProfilMatching('user-1');

    expect(prisma.worker.findUnique).toHaveBeenCalledWith({
      where: { userId: 'user-1' },
      select: { id: true },
    });
    expect(view).toEqual({
      shifts: [Shift.MATIN, Shift.JOURNEE],
      competences: [{ code: 'C1', label: 'Compétence 1' }],
    });
  });

  it('refuse un compte sans profil intérimaire', async () => {
    prisma.worker.findUnique.mockResolvedValueOnce(null);

    await expect(service.getProfilMatching('user-1')).rejects.toThrow(NotFoundException);
  });

  it('remplace les compétences et met à jour les créneaux en une transaction', async () => {
    await service.updateProfilMatching('user-1', dto);

    expect(prisma.workerSkill.deleteMany).toHaveBeenCalledWith({ where: { workerId: 'worker-1' } });
    expect(prisma.workerSkill.createMany).toHaveBeenCalledWith({
      data: [
        { workerId: 'worker-1', competenceCode: 'C1' },
        { workerId: 'worker-1', competenceCode: 'C2' },
      ],
    });
    expect(prisma.worker.update).toHaveBeenCalledWith({
      where: { id: 'worker-1' },
      data: { shifts: [Shift.MATIN, Shift.JOURNEE] },
    });
  });

  it('refuse une compétence inconnue du référentiel', async () => {
    prisma.competence.findMany.mockResolvedValueOnce([{ code: 'C1' }]);

    await expect(service.updateProfilMatching('user-1', dto)).rejects.toThrow(BadRequestException);
    expect(prisma.$transaction).not.toHaveBeenCalled();
  });
});
