import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { MissionStatus } from '@prisma/client';
import { ContractsService } from '../contracts/contracts.service';
import { EncryptionService } from '../encryption/encryption.service';
import { PrismaService } from '../prisma/prisma.service';
import { SaveInformationsEmbaucheDto } from './dto/save-informations-embauche.dto';
import { masquer } from './identifiants';

/**
 * Informations d'embauche de l'intérimaire : ce que CADANS doit connaître de son salarié
 * pour établir le contrat de mission, et rien de plus.
 *
 * **Ce que cette vue ne contient pas, et pourquoi.** Ni le NIR ni l'IBAN en clair. Ils sont
 * chiffrés au repos (AES-256-GCM, contexte lié à l'intérimaire) et l'API n'en rend que les
 * quatre derniers caractères, assez pour reconnaître ce qu'on a saisi. Les déchiffrer pour
 * les renvoyer entièrement les exposerait dans chaque réponse HTTP, chaque cache de
 * navigateur et chaque capture d'écran de démonstration — pour un bénéfice nul.
 *
 * L'entreprise utilisatrice n'accède à aucun de ces champs : les routes vivent sous
 * `workers/me`, dont le contrôleur est réservé au rôle WORKER, et la vue candidat servie à
 * l'entreprise (`CandidatureEntrepriseView`) est un type distinct qui ne charge même pas
 * cette relation.
 */
export interface InformationsEmbaucheView {
  // Vrai dès qu'une ligne existe : les huit champs sont obligatoires ensemble, il n'y a pas
  // d'état intermédiaire à recalculer. C'est cette complétude que le contrat de mission
  // exigera avant d'être généré.
  complet: boolean;
  // Règle métier, calculée par l'API et non par l'écran : les informations ne sont dues
  // qu'à partir du moment où l'intérimaire est retenu sur une mission.
  requis: boolean;
  missionsRetenues: number;
  birthDate: string | null;
  birthPlace: string | null;
  birthCountry: string | null;
  nationality: string | null;
  addressLine: string | null;
  addressPostalCode: string | null;
  addressCity: string | null;
  nirMasque: string | null;
  ibanMasque: string | null;
}

// Contextes de chiffrement : chaque chiffré est lié à son intérimaire et à son usage.
// Recopier la colonne d'un intérimaire sur la ligne d'un autre la rend indéchiffrable.
const nirContext = (workerId: string): string => `hiring-nir:${workerId}`;
const ibanContext = (workerId: string): string => `hiring-iban:${workerId}`;

@Injectable()
export class HiringInfoService {
  private readonly logger = new Logger(HiringInfoService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
    private readonly contracts: ContractsService,
  ) {}

  async get(userId: string): Promise<InformationsEmbaucheView> {
    const workerId = await this.workerId(userId);
    const [info, missionsRetenues] = await Promise.all([
      this.prisma.hiringInfo.findUnique({ where: { workerId } }),
      this.countMissionsRetenues(workerId),
    ]);

    return this.toView(workerId, info, missionsRetenues);
  }

  async save(userId: string, dto: SaveInformationsEmbaucheDto): Promise<InformationsEmbaucheView> {
    const workerId = await this.workerId(userId);
    const champs = {
      birthDate: new Date(`${dto.birthDate}T00:00:00Z`),
      birthPlace: dto.birthPlace,
      birthCountry: dto.birthCountry,
      nationality: dto.nationality,
      addressLine: dto.addressLine,
      addressPostalCode: dto.addressPostalCode,
      addressCity: dto.addressCity,
      nirEncrypted: this.encryption.encryptText(dto.nir, nirContext(workerId)),
      ibanEncrypted: this.encryption.encryptText(dto.iban, ibanContext(workerId)),
    };

    // Une seule ligne par intérimaire : un nouvel envoi remplace la précédente, comme pour
    // la pièce d'identité. Corriger un IBAN ne doit pas créer un second jeu d'informations.
    const info = await this.prisma.hiringInfo.upsert({
      where: { workerId },
      create: { workerId, ...champs },
      update: champs,
    });

    // C'est ici que le contrat de mission devient possible : l'intérimaire peut avoir été
    // retenu avant d'avoir rempli ce formulaire, auquel cas seule la mise à disposition a été
    // générée. Sans ce rattrapage, son contrat n'arriverait jamais.
    //
    // Après la réponse, pas avant : une génération de PDF ne doit pas retarder ni faire
    // échouer l'enregistrement de ses informations. Même logique que la notification n8n.
    void this.contracts.generateForWorker(workerId).catch((error: unknown) => {
      this.logger.warn(
        `Contrats non régénérés pour l'intérimaire ${workerId} : ${(error as Error).message}`,
      );
    });

    return this.toView(workerId, info, await this.countMissionsRetenues(workerId));
  }

  // Missions dont cet intérimaire est le titulaire retenu. TERMINEE est exclu : un contrat
  // passé n'oblige plus à rien, c'est la mission en cours ou à venir qui réclame le contrat.
  private countMissionsRetenues(workerId: string): Promise<number> {
    return this.prisma.mission.count({
      where: { assignedWorkerId: workerId, status: MissionStatus.POURVUE },
    });
  }

  private async workerId(userId: string): Promise<string> {
    const worker = await this.prisma.worker.findUnique({ where: { userId }, select: { id: true } });
    if (!worker) {
      throw new NotFoundException('Profil intérimaire introuvable');
    }
    return worker.id;
  }

  private toView(
    workerId: string,
    info: {
      birthDate: Date;
      birthPlace: string;
      birthCountry: string;
      nationality: string;
      addressLine: string;
      addressPostalCode: string;
      addressCity: string;
      nirEncrypted: Uint8Array;
      ibanEncrypted: Uint8Array;
    } | null,
    missionsRetenues: number,
  ): InformationsEmbaucheView {
    const commun = { requis: missionsRetenues > 0, missionsRetenues };

    if (!info) {
      return {
        ...commun,
        complet: false,
        birthDate: null,
        birthPlace: null,
        birthCountry: null,
        nationality: null,
        addressLine: null,
        addressPostalCode: null,
        addressCity: null,
        nirMasque: null,
        ibanMasque: null,
      };
    }

    return {
      ...commun,
      complet: true,
      birthDate: info.birthDate.toISOString().slice(0, 10),
      birthPlace: info.birthPlace,
      birthCountry: info.birthCountry,
      nationality: info.nationality,
      addressLine: info.addressLine,
      addressPostalCode: info.addressPostalCode,
      addressCity: info.addressCity,
      // Déchiffrés ici pour être aussitôt masqués : la valeur en clair ne quitte jamais
      // cette expression.
      nirMasque: masquer(this.encryption.decryptText(info.nirEncrypted, nirContext(workerId))),
      ibanMasque: masquer(this.encryption.decryptText(info.ibanEncrypted, ibanContext(workerId))),
    };
  }
}
