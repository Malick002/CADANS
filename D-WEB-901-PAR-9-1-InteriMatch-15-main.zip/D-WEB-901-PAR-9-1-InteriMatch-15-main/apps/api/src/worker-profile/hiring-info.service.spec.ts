import { NotFoundException } from '@nestjs/common';
import { ContractsService } from '../contracts/contracts.service';
import { EncryptionService } from '../encryption/encryption.service';
import { PrismaService } from '../prisma/prisma.service';
import { SaveInformationsEmbaucheDto } from './dto/save-informations-embauche.dto';
import { HiringInfoService } from './hiring-info.service';

const WORKER_ID = '11111111-1111-1111-1111-111111111111';
const USER_ID = '22222222-2222-2222-2222-222222222222';

const NIR = '180127511600128';
const IBAN = 'FR1420041010050500013M02606';

const DTO: SaveInformationsEmbaucheDto = {
  birthDate: '1980-12-04',
  birthPlace: 'Paris',
  birthCountry: 'France',
  nationality: 'Française',
  addressLine: '8 rue des Peupliers',
  addressPostalCode: '95700',
  addressCity: 'Roissy-en-France',
  nir: NIR,
  iban: IBAN,
};

// Génération des contrats : elle part en tâche de fond après l'enregistrement, et n'est pas
// le sujet de ce fichier. La doublure permet quand même de vérifier qu'elle est déclenchée —
// c'est elle qui rattrape le contrat de mission d'un intérimaire retenu avant d'avoir rempli
// le formulaire.
function contrats() {
  return {
    generateForWorker: jest.fn().mockResolvedValue(undefined),
  } as unknown as ContractsService & { generateForWorker: jest.Mock };
}

// Vrai service de chiffrement, avec une vraie clé : le test vérifie que ce qui part en base
// est bien illisible, ce qu'une doublure qui renvoie la chaîne telle quelle ne prouverait pas.
function encryption(): EncryptionService {
  process.env.ENCRYPTION_KEY = Buffer.alloc(32, 7).toString('base64');
  return new EncryptionService();
}

interface Stored {
  birthDate: Date;
  birthPlace: string;
  birthCountry: string;
  nationality: string;
  addressLine: string;
  addressPostalCode: string;
  addressCity: string;
  nirEncrypted: Uint8Array;
  ibanEncrypted: Uint8Array;
}

function prisma(options: { worker?: boolean; missionsRetenues?: number } = {}) {
  const rows = new Map<string, Stored>();

  return {
    rows,
    service: {
      worker: {
        findUnique: () => Promise.resolve(options.worker === false ? null : { id: WORKER_ID }),
      },
      hiringInfo: {
        findUnique: ({ where }: { where: { workerId: string } }) =>
          Promise.resolve(rows.get(where.workerId) ?? null),
        upsert: ({
          where,
          create,
          update,
        }: {
          where: { workerId: string };
          create: Stored & { workerId: string };
          update: Stored;
        }) => {
          const existant = rows.get(where.workerId);
          const row = existant ? { ...existant, ...update } : { ...create };
          rows.set(where.workerId, row);
          return Promise.resolve(row);
        },
      },
      mission: {
        count: () => Promise.resolve(options.missionsRetenues ?? 0),
      },
    } as unknown as PrismaService,
  };
}

describe('HiringInfoService', () => {
  it('renvoie une vue vide et incomplète tant que rien n’est saisi', async () => {
    const service = new HiringInfoService(prisma().service, encryption(), contrats());

    const view = await service.get(USER_ID);

    expect(view.complet).toBe(false);
    expect(view.nirMasque).toBeNull();
    expect(view.ibanMasque).toBeNull();
    expect(view.birthDate).toBeNull();
  });

  it('enregistre puis relit les informations, masquées', async () => {
    const { service: db } = prisma();
    const service = new HiringInfoService(db, encryption(), contrats());

    await service.save(USER_ID, DTO);
    const view = await service.get(USER_ID);

    expect(view.complet).toBe(true);
    expect(view.birthDate).toBe('1980-12-04');
    expect(view.addressCity).toBe('Roissy-en-France');
    expect(view.nirMasque).toBe('•••••••••••0128');
    expect(view.ibanMasque).toBe(`${'•'.repeat(23)}2606`);
  });

  // Le cœur de la tâche : quelle que soit la forme de la réponse, le NIR et l'IBAN en clair
  // ne doivent apparaître nulle part. Le test balaie la vue entière, pas deux champs choisis
  // à la main — un champ ajouté demain qui les recopierait le ferait échouer.
  it('ne renvoie jamais le NIR ni l’IBAN en clair', async () => {
    const { service: db } = prisma();
    const service = new HiringInfoService(db, encryption(), contrats());

    const apresEcriture = await service.save(USER_ID, DTO);
    const apresLecture = await service.get(USER_ID);

    for (const view of [apresEcriture, apresLecture]) {
      const serialisee = JSON.stringify(view);
      expect(serialisee).not.toContain(NIR);
      expect(serialisee).not.toContain(IBAN);
      // Même partiellement : les 11 premiers caractères du NIR ne doivent pas fuiter non plus.
      expect(serialisee).not.toContain(NIR.slice(0, 11));
      expect(serialisee).not.toContain(IBAN.slice(0, 23));
    }
  });

  it('stocke le NIR et l’IBAN chiffrés, pas en clair', async () => {
    const { rows, service: db } = prisma();
    const service = new HiringInfoService(db, encryption(), contrats());

    await service.save(USER_ID, DTO);
    const stocke = rows.get(WORKER_ID)!;

    expect(Buffer.from(stocke.nirEncrypted).toString('utf8')).not.toContain(NIR);
    expect(Buffer.from(stocke.ibanEncrypted).toString('utf8')).not.toContain(IBAN);
    // Les deux colonnes ne sont pas le même chiffré : le contexte les distingue, et l'IV
    // est tiré au hasard à chaque appel.
    expect(Buffer.from(stocke.nirEncrypted).equals(Buffer.from(stocke.ibanEncrypted))).toBe(false);
  });

  // Le chiffrement lie chaque valeur à son intérimaire ET à son usage : déplacer la colonne
  // `nir_encrypted` dans `iban_encrypted` rend la donnée indéchiffrable au lieu de la révéler.
  it('refuse de déchiffrer un chiffré recopié dans l’autre colonne', async () => {
    const { rows, service: db } = prisma();
    const chiffrement = encryption();
    const service = new HiringInfoService(db, chiffrement, contrats());

    await service.save(USER_ID, DTO);
    const stocke = rows.get(WORKER_ID)!;
    rows.set(WORKER_ID, { ...stocke, ibanEncrypted: stocke.nirEncrypted });

    await expect(service.get(USER_ID)).rejects.toThrow();
  });

  it('remplace la ligne existante au lieu d’en créer une seconde', async () => {
    const { rows, service: db } = prisma();
    const service = new HiringInfoService(db, encryption(), contrats());

    await service.save(USER_ID, DTO);
    const view = await service.save(USER_ID, { ...DTO, addressCity: 'Sarcelles' });

    expect(rows.size).toBe(1);
    expect(view.addressCity).toBe('Sarcelles');
  });

  it('dit que les informations sont requises dès qu’une mission est pourvue', async () => {
    const sans = new HiringInfoService(prisma().service, encryption(), contrats());
    const avec = new HiringInfoService(
      prisma({ missionsRetenues: 2 }).service,
      encryption(),
      contrats(),
    );

    expect(await sans.get(USER_ID)).toMatchObject({ requis: false, missionsRetenues: 0 });
    expect(await avec.get(USER_ID)).toMatchObject({ requis: true, missionsRetenues: 2 });
  });

  // Sans ce déclenchement, un intérimaire retenu AVANT d'avoir rempli ce formulaire
  // n'obtiendrait jamais son contrat de mission : rien d'autre ne le régénère.
  it('déclenche la génération des contrats après l’enregistrement', async () => {
    const generateur = contrats();
    const service = new HiringInfoService(prisma().service, encryption(), generateur);

    await service.save(USER_ID, DTO);
    await new Promise((resolve) => setImmediate(resolve));

    expect(generateur.generateForWorker).toHaveBeenCalledWith(WORKER_ID);
  });

  // La génération est un aval de l'enregistrement, jamais une condition : une erreur de
  // pdf-lib ne doit pas empêcher l'intérimaire de sauvegarder ses informations.
  it('enregistre même si la génération des contrats échoue', async () => {
    const generateur = contrats();
    generateur.generateForWorker.mockRejectedValueOnce(new Error('pdf-lib indisponible'));
    const service = new HiringInfoService(prisma().service, encryption(), generateur);

    await expect(service.save(USER_ID, DTO)).resolves.toMatchObject({ complet: true });
    await new Promise((resolve) => setImmediate(resolve));
  });

  it('refuse un compte sans profil intérimaire', async () => {
    const service = new HiringInfoService(
      prisma({ worker: false }).service,
      encryption(),
      contrats(),
    );

    await expect(service.get(USER_ID)).rejects.toBeInstanceOf(NotFoundException);
    await expect(service.save(USER_ID, DTO)).rejects.toBeInstanceOf(NotFoundException);
  });
});
