import { Transform, TransformFnParams } from 'class-transformer';
import { registerDecorator, ValidationOptions } from 'class-validator';

/**
 * Validation et masquage des deux identifiants sensibles des informations d'embauche :
 * le NIR (numéro de sécurité sociale) et l'IBAN.
 *
 * Fonctions pures, sans dépendance à Nest : elles sont testées seules, et `apps/web`
 * les reproduit dans `src/lib/validation.ts` pour afficher l'erreur sous le bon champ —
 * même convention assumée que pour les DTO d'inscription (CLAUDE.md, « Pièges »).
 *
 * **Une clé de contrôle n'authentifie rien.** Elle détecte une faute de frappe, pas un
 * numéro inventé : un NIR bien formé peut n'appartenir à personne. C'est exactement ce
 * qu'on attend d'elle ici — éviter qu'un contrat parte avec un chiffre transposé.
 */

// Sexe : 1 homme, 2 femme, 7 et 8 pour les numéros d'immatriculation temporaires, courants
// chez les personnes en cours de régularisation — un secteur comme la logistique en emploie.
// Le mois n'est PAS borné à 01-12 : l'INSEE utilise des valeurs conventionnelles au-delà
// (mois de naissance inconnu, immatriculation d'une personne née à l'étranger). Le borner
// rejetterait des numéros réels, ce qui est pire que de laisser passer une saisie absurde
// que la clé de contrôle attrapera le plus souvent.
// Le département accepte 2A et 2B (Corse) : ce sont les deux seules lettres possibles dans
// un NIR, et elles se substituent à 19 et 18 avant le calcul de la clé.
const NIR_PATTERN = /^[1278]\d{4}(?:\d{2}|2[AB])\d{6}(\d{2})$/;

const CORSE = new Map([
  ['2A', '19'],
  ['2B', '18'],
]);

/**
 * NIR : 15 caractères, dont 13 de numéro et 2 de clé.
 * Clé = 97 − (numéro modulo 97), sur le numéro à 13 chiffres.
 */
export function isValidNir(value: string): boolean {
  const match = NIR_PATTERN.exec(value);
  if (!match) {
    return false;
  }

  const numero = value.slice(0, 13).replace(/2[AB]/, (corse) => CORSE.get(corse)!);
  // 13 chiffres dépassent Number.MAX_SAFE_INTEGER : BigInt, sinon le reste est faux.
  const cle = 97n - (BigInt(numero) % 97n);

  return cle === BigInt(match[1]);
}

// Deux lettres de pays, deux chiffres de clé, puis 11 à 30 caractères alphanumériques —
// bornes de la norme ISO 13616.
const IBAN_PATTERN = /^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/;

// Longueur exacte par pays, pour les seuls pays où une erreur est plausible ici. Un IBAN
// français mal recopié a la bonne forme et une longueur fausse : le test mod 97 le rattrape
// souvent, pas toujours. Les autres pays ne sont pas tabulés — la liste complète des 36
// longueurs SEPA se saisit vite et se vérifie lentement, et une erreur y serait invisible.
const LONGUEURS = new Map([['FR', 27]]);

/**
 * IBAN : contrôle mod 97 de la norme ISO 7064 (les quatre premiers caractères passent à la
 * fin, chaque lettre devient sa position dans l'alphabet + 9, le tout modulo 97 doit valoir 1).
 */
export function isValidIban(value: string): boolean {
  if (!IBAN_PATTERN.test(value)) {
    return false;
  }

  const attendue = LONGUEURS.get(value.slice(0, 2));
  if (attendue !== undefined && value.length !== attendue) {
    return false;
  }

  const reordonne = value.slice(4) + value.slice(0, 4);
  const numerique = [...reordonne]
    .map((caractere) =>
      /[A-Z]/.test(caractere) ? String(caractere.charCodeAt(0) - 55) : caractere,
    )
    .join('');

  return BigInt(numerique) % 97n === 1n;
}

// Espaces et tirets de mise en forme : l'IBAN se recopie par blocs de quatre, le NIR par
// blocs aussi. On les retire avant de valider, et on stocke la forme compacte.
export function compacter(value: string): string {
  return value.replace(/[\s-]/g, '').toUpperCase();
}

/**
 * Forme masquée renvoyée par l'API : seuls les quatre derniers caractères restent lisibles.
 * C'est assez pour que l'intérimaire reconnaisse ce qu'il a saisi, et trop peu pour qu'une
 * fuite de la réponse HTTP livre quoi que ce soit d'exploitable.
 */
export function masquer(value: string, visibles = 4): string {
  const fin = value.slice(-visibles);
  return `${'•'.repeat(Math.max(value.length - visibles, 0))}${fin}`;
}

// --- Décorateurs class-validator ------------------------------------------------------
//
// Même convention que `apps/api/src/auth/dto/validation.ts`, qui colocalise `isValidSiret`
// et `IsSiret` : la règle est une fonction pure testable, le décorateur n'est que sa mise en
// forme pour les DTO.

// Retire les espaces et tirets de mise en forme AVANT validation : un RIB se recopie par
// blocs de quatre, un NIR aussi. Sans ça, une saisie correcte serait refusée.
export const Compacter = (): PropertyDecorator =>
  Transform(({ value }: TransformFnParams): unknown =>
    typeof value === 'string' ? compacter(value) : value,
  );

export function IsNir(options?: ValidationOptions): PropertyDecorator {
  return (target: object, propertyName: string | symbol): void => {
    registerDecorator({
      name: 'isNir',
      target: target.constructor,
      propertyName: propertyName.toString(),
      options: {
        message:
          'Le numéro de sécurité sociale doit comporter 15 chiffres et sa clé de contrôle doit être juste',
        ...options,
      },
      validator: {
        validate: (value: unknown): boolean => typeof value === 'string' && isValidNir(value),
      },
    });
  };
}

export function IsIban(options?: ValidationOptions): PropertyDecorator {
  return (target: object, propertyName: string | symbol): void => {
    registerDecorator({
      name: 'isIban',
      target: target.constructor,
      propertyName: propertyName.toString(),
      options: { message: 'Cet IBAN n’est pas valide', ...options },
      validator: {
        validate: (value: unknown): boolean => typeof value === 'string' && isValidIban(value),
      },
    });
  };
}
