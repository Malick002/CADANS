import { Module } from '@nestjs/common';
import { ContractsModule } from '../contracts/contracts.module';
import { HiringInfoService } from './hiring-info.service';
import { WorkerProfileController } from './worker-profile.controller';
import { WorkerProfileService } from './worker-profile.service';

@Module({
  imports: [ContractsModule],
  controllers: [WorkerProfileController],
  providers: [WorkerProfileService, HiringInfoService],
})
export class WorkerProfileModule {}
