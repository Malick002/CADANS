import { Injectable, Logger } from '@nestjs/common';

export interface Email {
  to: string;
  subject: string;
  // Version texte et version HTML du même message : un client qui refuse le HTML
  // (ou un lecteur d'écran en mode texte) doit recevoir le lien quand même.
  text: string;
  html: string;
  // Clé d'idempotence, au format `<type-d-evenement>/<identifiant>` : si la requête est
  // rejouée (relance réseau), Resend renvoie la réponse initiale sans envoyer un second
  // message. Valable 24 heures.
  idempotencyKey: string;
}

// API HTTP de Resend, appelée avec le fetch natif de Node 22 : aucune dépendance ajoutée
// au projet, et changer de fournisseur ne touche que ce fichier.
const RESEND_ENDPOINT = 'https://api.resend.com/emails';

/**
 * Envoi des emails transactionnels (aujourd'hui : réinitialisation de mot de passe).
 *
 * Tant que `RESEND_API_KEY` et `MAIL_FROM` ne sont pas renseignées, le message est
 * journalisé au lieu d'être envoyé : l'équipe travaille en local sans compte fournisseur,
 * et le lien de réinitialisation reste lisible dans la console de l'API.
 */
@Injectable()
export class MailService {
  private readonly logger = new Logger(MailService.name);
  private readonly apiKey = process.env.RESEND_API_KEY?.trim() ?? '';
  private readonly from = process.env.MAIL_FROM?.trim() ?? '';

  get configured(): boolean {
    return this.apiKey !== '' && this.from !== '';
  }

  // Ne lève jamais : un envoi raté ne doit pas changer la réponse HTTP reçue par le
  // visiteur, sans quoi la différence entre « compte connu » et « compte inconnu »
  // deviendrait observable. L'échec est journalisé, l'appelant continue.
  async send(email: Email): Promise<void> {
    if (!this.configured) {
      this.logger.warn(
        `Envoi désactivé (RESEND_API_KEY ou MAIL_FROM absente). Message destiné à ` +
          `${email.to} — « ${email.subject} » :\n${email.text}`,
      );
      return;
    }

    try {
      const response = await fetch(RESEND_ENDPOINT, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          'Idempotency-Key': email.idempotencyKey,
        },
        body: JSON.stringify({
          from: this.from,
          to: [email.to],
          subject: email.subject,
          text: email.text,
          html: email.html,
        }),
      });

      if (!response.ok) {
        // Le corps porte le motif exact (domaine non vérifié, clé restreinte, quota).
        const detail = await response.text().catch(() => '');
        this.logger.error(`Envoi refusé par Resend (HTTP ${response.status}) : ${detail}`);
        return;
      }

      // Identifiant renvoyé par Resend : il permet de retrouver le message dans son
      // tableau de bord et d'y lire son sort réel (remis, rejeté, signalé en indésirable).
      // « Accepté » n'est pas « arrivé » : sans cette trace, on ne saurait pas lequel des
      // deux on a obtenu.
      const accepted = (await response.json().catch(() => null)) as { id?: string } | null;
      this.logger.log(`Email remis à Resend pour ${email.to} (identifiant ${accepted?.id ?? '?'})`);
    } catch (error) {
      this.logger.error(`Envoi impossible : ${error instanceof Error ? error.message : error}`);
    }
  }
}
