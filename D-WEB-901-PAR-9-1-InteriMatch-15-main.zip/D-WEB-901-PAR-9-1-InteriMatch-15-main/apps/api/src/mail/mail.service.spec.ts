import { MailService } from './mail.service';

const email = {
  to: 'samir@example.fr',
  subject: 'Réinitialiser votre mot de passe CADANS',
  text: 'https://cadans.example/reinitialiser-mot-de-passe?token=abc',
  html: '<p>lien</p>',
  idempotencyKey: 'password-reset/user-1',
};

describe('MailService', () => {
  const env = process.env;
  let fetchMock: jest.Mock;

  beforeEach(() => {
    process.env = { ...env };
    fetchMock = jest.fn().mockResolvedValue(new Response(null, { status: 200 }));
    global.fetch = fetchMock as unknown as typeof fetch;
  });

  afterAll(() => {
    process.env = env;
  });

  describe('sans fournisseur configuré', () => {
    it("n'appelle pas l'API et se contente de journaliser", async () => {
      delete process.env.RESEND_API_KEY;
      delete process.env.MAIL_FROM;
      const service = new MailService();

      expect(service.configured).toBe(false);
      await service.send(email);
      expect(fetchMock).not.toHaveBeenCalled();
    });

    it('reste inactif si seule une des deux variables est renseignée', () => {
      process.env.RESEND_API_KEY = 're_test';
      delete process.env.MAIL_FROM;

      expect(new MailService().configured).toBe(false);
    });
  });

  describe('avec fournisseur configuré', () => {
    beforeEach(() => {
      process.env.RESEND_API_KEY = 're_test';
      process.env.MAIL_FROM = 'CADANS <contact@cadans.example>';
    });

    it("poste le message à l'API avec la clé d'idempotence", async () => {
      await new MailService().send(email);

      expect(fetchMock).toHaveBeenCalledTimes(1);
      const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
      expect(url).toBe('https://api.resend.com/emails');
      expect(init.headers).toMatchObject({
        Authorization: 'Bearer re_test',
        'Idempotency-Key': 'password-reset/user-1',
      });
      expect(JSON.parse(String(init.body))).toEqual({
        from: 'CADANS <contact@cadans.example>',
        to: ['samir@example.fr'],
        subject: email.subject,
        text: email.text,
        html: email.html,
      });
    });

    // Un envoi raté ne doit pas changer la réponse HTTP du parcours : sinon la différence
    // entre compte connu et compte inconnu redevient observable.
    it('ne lève pas quand le fournisseur refuse la requête', async () => {
      fetchMock.mockResolvedValue(new Response('domaine non vérifié', { status: 403 }));

      await expect(new MailService().send(email)).resolves.toBeUndefined();
    });

    it('ne lève pas quand le réseau échoue', async () => {
      fetchMock.mockRejectedValue(new Error('ECONNREFUSED'));

      await expect(new MailService().send(email)).resolves.toBeUndefined();
    });
  });
});
