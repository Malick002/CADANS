-- AlterTable
ALTER TABLE "workers" ADD COLUMN     "available_from" DATE,
ADD COLUMN     "available_until" DATE,
ADD COLUMN     "latitude" DOUBLE PRECISION,
ADD COLUMN     "longitude" DOUBLE PRECISION,
ADD COLUMN     "shifts" "Shift"[] DEFAULT ARRAY[]::"Shift"[];

-- CreateTable
CREATE TABLE "worker_skills" (
    "worker_id" UUID NOT NULL,
    "competence_code" VARCHAR(20) NOT NULL,

    CONSTRAINT "worker_skills_pkey" PRIMARY KEY ("worker_id","competence_code")
);

-- AddForeignKey
ALTER TABLE "worker_skills" ADD CONSTRAINT "worker_skills_worker_id_fkey" FOREIGN KEY ("worker_id") REFERENCES "workers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "worker_skills" ADD CONSTRAINT "worker_skills_competence_code_fkey" FOREIGN KEY ("competence_code") REFERENCES "competences"("code") ON DELETE RESTRICT ON UPDATE CASCADE;
