-- CreateEnum
CREATE TYPE "CertificationType" AS ENUM ('CACES_R489_1A', 'CACES_R489_1B', 'CACES_R489_2A', 'CACES_R489_2B', 'CACES_R489_3', 'CACES_R489_4', 'CACES_R489_5', 'CACES_R489_6', 'CACES_R489_7', 'CACES_R485_1', 'CACES_R485_2', 'HABILITATION_ELECTRIQUE');

-- CreateEnum
CREATE TYPE "IdentityDocumentType" AS ENUM ('CNI', 'PASSEPORT', 'TITRE_SEJOUR');

-- CreateTable
CREATE TABLE "certifications" (
    "id" UUID NOT NULL,
    "worker_id" UUID NOT NULL,
    "type" "CertificationType" NOT NULL,
    "expires_at" DATE,
    "number_encrypted" BYTEA,
    "document_encrypted" BYTEA,
    "document_mime_type" VARCHAR(50),
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "certifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "identity_documents" (
    "id" UUID NOT NULL,
    "worker_id" UUID NOT NULL,
    "type" "IdentityDocumentType" NOT NULL,
    "file_encrypted" BYTEA NOT NULL,
    "mime_type" VARCHAR(50) NOT NULL,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "identity_documents_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "certifications_worker_id_type_key" ON "certifications"("worker_id", "type");

-- CreateIndex
CREATE UNIQUE INDEX "identity_documents_worker_id_key" ON "identity_documents"("worker_id");

-- AddForeignKey
ALTER TABLE "certifications" ADD CONSTRAINT "certifications_worker_id_fkey" FOREIGN KEY ("worker_id") REFERENCES "workers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "identity_documents" ADD CONSTRAINT "identity_documents_worker_id_fkey" FOREIGN KEY ("worker_id") REFERENCES "workers"("id") ON DELETE CASCADE ON UPDATE CASCADE;
