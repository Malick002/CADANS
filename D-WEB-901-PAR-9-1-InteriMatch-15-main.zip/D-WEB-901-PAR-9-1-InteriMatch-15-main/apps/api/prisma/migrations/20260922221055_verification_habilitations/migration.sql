-- CreateEnum
CREATE TYPE "CertificationStatus" AS ENUM ('NON_VERIFIE', 'EN_ATTENTE', 'VERIFIE', 'REFUSE');

-- AlterEnum
ALTER TYPE "Role" ADD VALUE 'ADMIN';

-- AlterTable
ALTER TABLE "certifications" ADD COLUMN     "refusal_motif" VARCHAR(500),
ADD COLUMN     "verification_status" "CertificationStatus" NOT NULL DEFAULT 'NON_VERIFIE',
ADD COLUMN     "verified_at" TIMESTAMPTZ(3),
ADD COLUMN     "verified_by_user_id" UUID;
