-- CreateEnum
CREATE TYPE "SignatureParty" AS ENUM ('CADANS', 'INTERIMAIRE', 'ENTREPRISE');

-- AlterTable
ALTER TABLE "contracts" ADD COLUMN     "completed_at" TIMESTAMPTZ(3),
ADD COLUMN     "final_pdf_encrypted" BYTEA,
ADD COLUMN     "final_sha256" CHAR(64);

-- CreateTable
CREATE TABLE "contract_signatures" (
    "id" UUID NOT NULL,
    "contract_id" UUID NOT NULL,
    "party" "SignatureParty" NOT NULL,
    "user_id" UUID,
    "typed_name" VARCHAR(200) NOT NULL,
    "signed_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ip" VARCHAR(64),
    "user_agent" VARCHAR(500),
    "document_sha256" CHAR(64) NOT NULL,

    CONSTRAINT "contract_signatures_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "contract_signatures_contract_id_party_key" ON "contract_signatures"("contract_id", "party");

-- AddForeignKey
ALTER TABLE "contract_signatures" ADD CONSTRAINT "contract_signatures_contract_id_fkey" FOREIGN KEY ("contract_id") REFERENCES "contracts"("id") ON DELETE CASCADE ON UPDATE CASCADE;
