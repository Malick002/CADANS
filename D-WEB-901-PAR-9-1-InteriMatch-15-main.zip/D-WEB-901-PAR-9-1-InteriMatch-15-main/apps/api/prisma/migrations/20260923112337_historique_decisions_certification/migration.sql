-- CreateTable
CREATE TABLE "certification_decisions" (
    "id" UUID NOT NULL,
    "certification_id" UUID NOT NULL,
    "decision" "CertificationStatus" NOT NULL,
    "motif" VARCHAR(500),
    "agent_user_id" UUID,
    "decided_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "certification_decisions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "certification_decisions_certification_id_decided_at_idx" ON "certification_decisions"("certification_id", "decided_at");

-- AddForeignKey
ALTER TABLE "certification_decisions" ADD CONSTRAINT "certification_decisions_certification_id_fkey" FOREIGN KEY ("certification_id") REFERENCES "certifications"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "certification_decisions" ADD CONSTRAINT "certification_decisions_agent_user_id_fkey" FOREIGN KEY ("agent_user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
