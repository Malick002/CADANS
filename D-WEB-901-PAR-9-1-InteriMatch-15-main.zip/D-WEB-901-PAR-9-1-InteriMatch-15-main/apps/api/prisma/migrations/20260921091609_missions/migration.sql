-- CreateEnum
CREATE TYPE "Shift" AS ENUM ('MATIN', 'APRES_MIDI', 'NUIT', 'JOURNEE');

-- CreateEnum
CREATE TYPE "MissionStatus" AS ENUM ('OUVERTE', 'POURVUE', 'TERMINEE');

-- CreateTable
CREATE TABLE "missions" (
    "id" UUID NOT NULL,
    "company_id" UUID NOT NULL,
    "poste_code" VARCHAR(20) NOT NULL,
    "site_label" VARCHAR(255) NOT NULL,
    "postal_code" CHAR(5) NOT NULL,
    "start_date" DATE NOT NULL,
    "end_date" DATE NOT NULL,
    "shift" "Shift" NOT NULL,
    "hourly_rate" DECIMAL(5,2) NOT NULL,
    "description" TEXT,
    "status" "MissionStatus" NOT NULL DEFAULT 'OUVERTE',
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "missions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "mission_habilitations" (
    "mission_id" UUID NOT NULL,
    "type" "CertificationType" NOT NULL,

    CONSTRAINT "mission_habilitations_pkey" PRIMARY KEY ("mission_id","type")
);

-- CreateTable
CREATE TABLE "mission_competences" (
    "mission_id" UUID NOT NULL,
    "competence_code" VARCHAR(20) NOT NULL,

    CONSTRAINT "mission_competences_pkey" PRIMARY KEY ("mission_id","competence_code")
);

-- CreateIndex
CREATE INDEX "missions_company_id_idx" ON "missions"("company_id");

-- AddForeignKey
ALTER TABLE "missions" ADD CONSTRAINT "missions_company_id_fkey" FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "missions" ADD CONSTRAINT "missions_poste_code_fkey" FOREIGN KEY ("poste_code") REFERENCES "postes"("code") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "mission_habilitations" ADD CONSTRAINT "mission_habilitations_mission_id_fkey" FOREIGN KEY ("mission_id") REFERENCES "missions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "mission_competences" ADD CONSTRAINT "mission_competences_mission_id_fkey" FOREIGN KEY ("mission_id") REFERENCES "missions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "mission_competences" ADD CONSTRAINT "mission_competences_competence_code_fkey" FOREIGN KEY ("competence_code") REFERENCES "competences"("code") ON DELETE RESTRICT ON UPDATE CASCADE;
