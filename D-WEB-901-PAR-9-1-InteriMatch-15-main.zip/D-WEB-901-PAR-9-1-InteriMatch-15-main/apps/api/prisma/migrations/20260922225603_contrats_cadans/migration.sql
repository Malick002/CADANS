-- CreateEnum
CREATE TYPE "MotifRecours" AS ENUM ('ACCROISSEMENT_TEMPORAIRE', 'REMPLACEMENT', 'SAISONNIER', 'USAGE');

-- CreateEnum
CREATE TYPE "ContractType" AS ENUM ('MISSION', 'MISE_A_DISPOSITION');

-- AlterTable
ALTER TABLE "companies" ADD COLUMN     "signatory_role" VARCHAR(100);

-- AlterTable
ALTER TABLE "missions" ADD COLUMN     "motif_recours" "MotifRecours" NOT NULL DEFAULT 'ACCROISSEMENT_TEMPORAIRE',
ADD COLUMN     "remplace_nom" VARCHAR(200),
ADD COLUMN     "remplace_qualification" VARCHAR(200);

-- CreateTable
CREATE TABLE "contracts" (
    "id" UUID NOT NULL,
    "mission_id" UUID NOT NULL,
    "type" "ContractType" NOT NULL,
    "pdf_encrypted" BYTEA NOT NULL,
    "sha256" CHAR(64) NOT NULL,
    "generated_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "contracts_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "contracts_mission_id_type_key" ON "contracts"("mission_id", "type");

-- AddForeignKey
ALTER TABLE "contracts" ADD CONSTRAINT "contracts_mission_id_fkey" FOREIGN KEY ("mission_id") REFERENCES "missions"("id") ON DELETE CASCADE ON UPDATE CASCADE;
