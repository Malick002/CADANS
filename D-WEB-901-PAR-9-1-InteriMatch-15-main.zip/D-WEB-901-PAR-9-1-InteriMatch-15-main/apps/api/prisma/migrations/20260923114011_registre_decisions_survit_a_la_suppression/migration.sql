/*
  Le registre des décisions doit SURVIVRE à la suppression de l'habilitation : sinon la
  personne contrôlée peut effacer la trace des contrôles. La clé passe donc en SET NULL,
  et deux colonnes recopient ce qu'il faut pour relire la ligne seule.

  L'avertissement Prisma ci-dessous ne s'applique pas : `certification_decisions` est créée
  par la migration 20260923112337, qui part dans la MÊME livraison. La table est donc vide
  partout où celle-ci s'applique. À ne pas reproduire sur une table déjà alimentée — il
  faudrait alors une valeur par défaut, puis un remplissage, puis la contrainte.

  Warnings:

  - Added the required column `certification_type` to the `certification_decisions` table without a default value. This is not possible if the table is not empty.
  - Added the required column `worker_id` to the `certification_decisions` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "certification_decisions" DROP CONSTRAINT "certification_decisions_certification_id_fkey";

-- AlterTable
ALTER TABLE "certification_decisions" ADD COLUMN     "certification_type" "CertificationType" NOT NULL,
ADD COLUMN     "worker_id" UUID NOT NULL,
ALTER COLUMN "certification_id" DROP NOT NULL;

-- CreateIndex
CREATE INDEX "certification_decisions_worker_id_decided_at_idx" ON "certification_decisions"("worker_id", "decided_at");

-- AddForeignKey
ALTER TABLE "certification_decisions" ADD CONSTRAINT "certification_decisions_certification_id_fkey" FOREIGN KEY ("certification_id") REFERENCES "certifications"("id") ON DELETE SET NULL ON UPDATE CASCADE;
