-- AlterTable
ALTER TABLE "missions" ADD COLUMN     "assigned_worker_id" UUID;

-- AddForeignKey
ALTER TABLE "missions" ADD CONSTRAINT "missions_assigned_worker_id_fkey" FOREIGN KEY ("assigned_worker_id") REFERENCES "workers"("id") ON DELETE SET NULL ON UPDATE CASCADE;
