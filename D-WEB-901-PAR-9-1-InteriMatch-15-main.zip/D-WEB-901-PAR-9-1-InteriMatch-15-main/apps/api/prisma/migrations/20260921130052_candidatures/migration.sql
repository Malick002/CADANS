-- CreateEnum
CREATE TYPE "CandidatureStatus" AS ENUM ('ENVOYEE');

-- CreateTable
CREATE TABLE "candidatures" (
    "id" UUID NOT NULL,
    "mission_id" UUID NOT NULL,
    "worker_id" UUID NOT NULL,
    "status" "CandidatureStatus" NOT NULL DEFAULT 'ENVOYEE',
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "candidatures_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "candidatures_mission_id_worker_id_key" ON "candidatures"("mission_id", "worker_id");

-- AddForeignKey
ALTER TABLE "candidatures" ADD CONSTRAINT "candidatures_mission_id_fkey" FOREIGN KEY ("mission_id") REFERENCES "missions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "candidatures" ADD CONSTRAINT "candidatures_worker_id_fkey" FOREIGN KEY ("worker_id") REFERENCES "workers"("id") ON DELETE CASCADE ON UPDATE CASCADE;
