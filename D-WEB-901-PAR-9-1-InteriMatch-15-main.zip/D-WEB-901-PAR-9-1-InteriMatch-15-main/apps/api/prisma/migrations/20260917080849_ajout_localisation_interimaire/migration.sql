/*
  Warnings:

  - Added the required column `city` to the `workers` table without a default value. This is not possible if the table is not empty.
  - Added the required column `postal_code` to the `workers` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "workers" ADD COLUMN     "city" VARCHAR(100) NOT NULL,
ADD COLUMN     "postal_code" CHAR(5) NOT NULL;
