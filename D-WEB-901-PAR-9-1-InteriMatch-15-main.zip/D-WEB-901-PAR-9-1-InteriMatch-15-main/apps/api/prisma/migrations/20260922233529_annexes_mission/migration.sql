-- CreateTable
CREATE TABLE "mission_attachments" (
    "id" UUID NOT NULL,
    "mission_id" UUID NOT NULL,
    "filename" VARCHAR(255) NOT NULL,
    "mime_type" VARCHAR(50) NOT NULL,
    "size_bytes" INTEGER NOT NULL,
    "file_encrypted" BYTEA NOT NULL,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "mission_attachments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "mission_attachments_mission_id_idx" ON "mission_attachments"("mission_id");

-- AddForeignKey
ALTER TABLE "mission_attachments" ADD CONSTRAINT "mission_attachments_mission_id_fkey" FOREIGN KEY ("mission_id") REFERENCES "missions"("id") ON DELETE CASCADE ON UPDATE CASCADE;
