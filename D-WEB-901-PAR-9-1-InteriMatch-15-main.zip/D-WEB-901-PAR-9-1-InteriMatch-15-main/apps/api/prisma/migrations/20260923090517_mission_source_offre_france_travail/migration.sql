-- AlterTable
ALTER TABLE "missions" ADD COLUMN     "source_offre_id" VARCHAR(20);
