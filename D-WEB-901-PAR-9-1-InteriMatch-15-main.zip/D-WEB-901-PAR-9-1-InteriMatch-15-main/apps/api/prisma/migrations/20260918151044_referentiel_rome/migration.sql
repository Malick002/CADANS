-- CreateEnum
CREATE TYPE "CompetenceType" AS ENUM ('COMPETENCE_DETAILLEE', 'SAVOIR', 'MACRO_SAVOIR_FAIRE', 'MACRO_SAVOIR_ETRE');

-- CreateTable
CREATE TABLE "rome_codes" (
    "code" CHAR(5) NOT NULL,
    "label" VARCHAR(255) NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "updated_at" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "rome_codes_pkey" PRIMARY KEY ("code")
);

-- CreateTable
CREATE TABLE "postes" (
    "code" VARCHAR(20) NOT NULL,
    "label" VARCHAR(255) NOT NULL,
    "rome_code" CHAR(5) NOT NULL,
    "classification" VARCHAR(20) NOT NULL,
    "exposed" BOOLEAN NOT NULL DEFAULT false,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "updated_at" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "postes_pkey" PRIMARY KEY ("code")
);

-- CreateTable
CREATE TABLE "competences" (
    "code" VARCHAR(20) NOT NULL,
    "label" VARCHAR(255) NOT NULL,
    "type" "CompetenceType" NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "updated_at" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "competences_pkey" PRIMARY KEY ("code")
);

-- CreateTable
CREATE TABLE "rome_competences" (
    "rome_code" CHAR(5) NOT NULL,
    "competence_code" VARCHAR(20) NOT NULL,
    "principale" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "rome_competences_pkey" PRIMARY KEY ("rome_code","competence_code")
);

-- CreateTable
CREATE TABLE "poste_habilitations" (
    "poste_code" VARCHAR(20) NOT NULL,
    "type" "CertificationType" NOT NULL,

    CONSTRAINT "poste_habilitations_pkey" PRIMARY KEY ("poste_code","type")
);

-- CreateIndex
CREATE INDEX "postes_rome_code_idx" ON "postes"("rome_code");

-- AddForeignKey
ALTER TABLE "postes" ADD CONSTRAINT "postes_rome_code_fkey" FOREIGN KEY ("rome_code") REFERENCES "rome_codes"("code") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "rome_competences" ADD CONSTRAINT "rome_competences_rome_code_fkey" FOREIGN KEY ("rome_code") REFERENCES "rome_codes"("code") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "rome_competences" ADD CONSTRAINT "rome_competences_competence_code_fkey" FOREIGN KEY ("competence_code") REFERENCES "competences"("code") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "poste_habilitations" ADD CONSTRAINT "poste_habilitations_poste_code_fkey" FOREIGN KEY ("poste_code") REFERENCES "postes"("code") ON DELETE RESTRICT ON UPDATE CASCADE;
