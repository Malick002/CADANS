-- CreateTable
CREATE TABLE "hiring_infos" (
    "id" UUID NOT NULL,
    "worker_id" UUID NOT NULL,
    "birth_date" DATE NOT NULL,
    "birth_place" VARCHAR(100) NOT NULL,
    "birth_country" VARCHAR(100) NOT NULL,
    "nationality" VARCHAR(100) NOT NULL,
    "address_line" VARCHAR(255) NOT NULL,
    "address_postal_code" CHAR(5) NOT NULL,
    "address_city" VARCHAR(100) NOT NULL,
    "nir_encrypted" BYTEA NOT NULL,
    "iban_encrypted" BYTEA NOT NULL,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(3) NOT NULL,

    CONSTRAINT "hiring_infos_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "hiring_infos_worker_id_key" ON "hiring_infos"("worker_id");

-- AddForeignKey
ALTER TABLE "hiring_infos" ADD CONSTRAINT "hiring_infos_worker_id_fkey" FOREIGN KEY ("worker_id") REFERENCES "workers"("id") ON DELETE CASCADE ON UPDATE CASCADE;
