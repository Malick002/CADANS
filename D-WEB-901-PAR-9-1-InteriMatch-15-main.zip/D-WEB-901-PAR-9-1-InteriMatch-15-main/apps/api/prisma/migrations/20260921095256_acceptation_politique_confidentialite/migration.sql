-- AlterTable
ALTER TABLE "users" ADD COLUMN     "conditions_accepted_at" TIMESTAMPTZ(3);
