import { randomUUID } from 'node:crypto';

interface StoredToken {
  id: string;
  userId: string;
  tokenHash: string;
  expiresAt: Date;
  usedAt: Date | null;
  createdAt: Date;
}

// Doublure de la table password_reset_tokens, sur le modèle de InMemoryUsers : les tests
// fonctionnels tournent sans PostgreSQL lancé. Reproduit ce dont le service dépend —
// l'unicité de l'empreinte, et surtout la consommation conditionnelle du jeton
// (`updateMany` avec `usedAt: null`), qui est ce qui empêche de le rejouer.
export class InMemoryPasswordResetTokens {
  private readonly tokens: StoredToken[] = [];

  create = ({
    data,
  }: {
    data: { userId: string; tokenHash: string; expiresAt: Date };
  }): Promise<StoredToken> => {
    const token: StoredToken = {
      id: randomUUID(),
      usedAt: null,
      createdAt: new Date(),
      ...data,
    };
    this.tokens.push(token);
    return Promise.resolve(token);
  };

  findUnique = ({ where }: { where: { tokenHash: string } }): Promise<StoredToken | null> =>
    Promise.resolve(this.tokens.find((token) => token.tokenHash === where.tokenHash) ?? null);

  updateMany = ({
    where,
    data,
  }: {
    where: { id?: string; userId?: string; usedAt: null };
    data: { usedAt: Date };
  }): Promise<{ count: number }> => {
    const matching = this.tokens.filter(
      (token) =>
        token.usedAt === null &&
        (where.id === undefined || token.id === where.id) &&
        (where.userId === undefined || token.userId === where.userId),
    );
    for (const token of matching) {
      token.usedAt = data.usedAt;
    }
    return Promise.resolve({ count: matching.length });
  };
}
