import { randomUUID } from 'node:crypto';
import { CertificationStatus, CertificationType, Shift } from '@prisma/client';
import { COMPETENCES, POSTES } from './in-memory-referentiel';
import { InMemoryUsers, uniqueViolation } from './in-memory-users';

interface WorkerFields {
  shifts: Shift[];
}

interface SkillRow {
  workerId: string;
  competenceCode: string;
}

interface CertificationRow {
  workerId: string;
  type: CertificationType;
  expiresAt: Date | null;
  verificationStatus: CertificationStatus;
}

interface MissionRow {
  id: string;
  companyId: string;
  posteCode: string;
  siteLabel: string;
  postalCode: string;
  startDate: Date;
  endDate: Date;
  shift: Shift;
  hourlyRate: number;
  status: string;
  // Intérimaire retenu : lu par le compteur de missions pourvues des informations d'embauche.
  assignedWorkerId?: string;
  habilitations: { type: CertificationType }[];
  competences: { competenceCode: string }[];
}

interface CandidatureRow {
  id: string;
  missionId: string;
  workerId: string;
  status: string;
  createdAt: Date;
}

// Doublure combinée (profil intérimaire, référentiel, missions, MongoDB) pour les tests
// fonctionnels de worker-profile et matching. Complète InMemoryUsers/InMemoryMissions plutôt
// que de les dupliquer : mêmes conventions (existence par code, résolution par la session).
export class InMemoryWorkerWorld {
  private readonly workerFields = new Map<string, WorkerFields>();
  readonly skills: SkillRow[] = [];
  readonly certifications: CertificationRow[] = [];
  readonly missions: MissionRow[] = [];
  readonly candidatures: CandidatureRow[] = [];
  readonly hiringInfos = new Map<string, Record<string, unknown>>();
  readonly mongoInserts: Record<string, unknown>[] = [];

  constructor(private readonly users: InMemoryUsers) {}

  // Aide de test : pose une habilitation directement, sans passer par le chiffrement de
  // sensitive-documents (hors sujet ici).
  // `verificationStatus` par défaut à NON_VERIFIE : une habilitation déclarée sans
  // justificatif examiné, le cas le plus courant.
  addCertification(
    workerId: string,
    type: CertificationType,
    expiresAt: Date | null = null,
    verificationStatus: CertificationStatus = CertificationStatus.NON_VERIFIE,
  ): void {
    this.certifications.push({ workerId, type, expiresAt, verificationStatus });
  }

  addMission(mission: Omit<MissionRow, 'id' | 'status'> & { status?: string }): MissionRow {
    const row: MissionRow = { id: randomUUID(), status: 'OUVERTE', ...mission };
    this.missions.push(row);
    return row;
  }

  private fieldsOf(workerId: string): WorkerFields {
    let fields = this.workerFields.get(workerId);
    if (!fields) {
      fields = { shifts: [] };
      this.workerFields.set(workerId, fields);
    }
    return fields;
  }

  readonly worker = {
    findUnique: ({ where }: { where: { userId?: string; id?: string } }) => {
      const worker =
        where.userId !== undefined
          ? this.users.workerOf(where.userId)
          : this.users.workerById(where.id!);
      if (!worker) {
        return Promise.resolve(null);
      }
      const fields = this.fieldsOf(worker.id);
      return Promise.resolve({
        id: worker.id,
        firstName: worker.firstName as string,
        lastName: worker.lastName as string,
        postalCode: worker.postalCode as string,
        ...fields,
        skills: this.skills
          .filter((s) => s.workerId === worker.id)
          .map((s) => ({ competenceCode: s.competenceCode })),
        certifications: this.certifications
          .filter((c) => c.workerId === worker.id)
          .map((c) => ({
            type: c.type,
            expiresAt: c.expiresAt,
            verificationStatus: c.verificationStatus,
          })),
        // Par l'identifiant du profil et non par `where.userId` : depuis les candidatures,
        // la recherche se fait par `id` et `where.userId` est alors indéfini.
        user: { email: this.users.workerRecordById(worker.id)?.email ?? null },
        candidatures: this.candidatures
          .filter((c) => c.workerId === worker.id)
          .map((c) => ({ missionId: c.missionId })),
      });
    },
    // L'identité (nom, téléphone, ville) est posée à l'inscription et vit donc dans
    // InMemoryUsers ; les champs de matching (créneaux) vivent dans `workerFields`. Les deux
    // sont réunis ici, comme le ferait une seule ligne en base.
    findUniqueOrThrow: ({
      where,
      select,
    }: {
      where: { id: string };
      select?: Record<string, unknown>;
    }) => {
      const identite = this.users.workerById(where.id);
      const complet: Record<string, unknown> = {
        ...(identite ?? {}),
        ...this.fieldsOf(where.id),
        skills: this.skills
          .filter((s) => s.workerId === where.id)
          .map((s) => {
            const { code, label } = COMPETENCES.find((c) => c.code === s.competenceCode)!;
            return { competence: { code, label } };
          }),
      };
      return Promise.resolve(select ? projeter(complet, select) : complet);
    },
    update: ({
      where,
      data,
      select,
    }: {
      where: { id: string };
      data: Partial<WorkerFields> & Record<string, unknown>;
      select?: Record<string, unknown>;
    }) => {
      // Une mise à jour d'identité écrit là où l'inscription a écrit, pas dans les champs de
      // matching : sans cette distinction, le nom modifié ne serait pas relu.
      const IDENTITE = ['firstName', 'lastName', 'phone', 'postalCode', 'city'];
      const identite = Object.fromEntries(
        Object.entries(data).filter(([cle]) => IDENTITE.includes(cle)),
      );
      if (Object.keys(identite).length > 0) {
        this.users.updateWorkerProfile(where.id, identite);
      }

      const fields = this.fieldsOf(where.id);
      Object.assign(
        fields,
        Object.fromEntries(Object.entries(data).filter(([cle]) => !IDENTITE.includes(cle))),
      );
      const complet: Record<string, unknown> = {
        id: where.id,
        ...(this.users.workerById(where.id) ?? {}),
        ...fields,
      };
      return Promise.resolve(select ? projeter(complet, select) : complet);
    },
  };

  readonly workerSkill = {
    deleteMany: ({ where }: { where: { workerId: string } }) => {
      const before = this.skills.length;
      const kept = this.skills.filter((s) => s.workerId !== where.workerId);
      this.skills.length = 0;
      this.skills.push(...kept);
      return Promise.resolve({ count: before - kept.length });
    },
    createMany: ({ data }: { data: SkillRow[] }) => {
      this.skills.push(...data);
      return Promise.resolve({ count: data.length });
    },
  };

  readonly competence = {
    findMany: ({ where }: { where: { code: { in: string[] } } }) =>
      Promise.resolve(
        COMPETENCES.filter((c) => where.code.in.includes(c.code)).map((c) => ({ code: c.code })),
      ),
  };

  // Reproduit le filtre du service : seuls les postes exposés et actifs sont publiables.
  readonly poste = {
    findFirst: ({ where }: { where: { code: string; exposed?: boolean; active?: boolean } }) =>
      Promise.resolve(
        POSTES.some(
          (p) =>
            p.code === where.code &&
            (where.exposed === undefined || p.exposed === where.exposed) &&
            (where.active === undefined || p.active === where.active),
        )
          ? { code: where.code }
          : null,
      ),
  };

  readonly company = {
    findUnique: ({ where }: { where: { userId: string } }) => {
      const id = this.users.companyIdOf(where.userId);
      return Promise.resolve(id ? { id } : null);
    },
  };

  private withMissionRelations(m: MissionRow) {
    return {
      ...m,
      poste: { label: POSTES.find((p) => p.code === m.posteCode)!.label },
      company: {
        legalName: this.users.companyLegalNameOf(m.companyId),
        user: { email: this.users.companyEmailOf(m.companyId) },
      },
    };
  }

  readonly mission = {
    findMany: ({ where }: { where: { status: string } }) =>
      Promise.resolve(
        this.missions
          .filter((m) => m.status === where.status)
          .map((m) => this.withMissionRelations(m)),
      ),
    findUnique: ({ where }: { where: { id: string } }) => {
      const row = this.missions.find((m) => m.id === where.id);
      return Promise.resolve(row ? this.withMissionRelations(row) : null);
    },
    count: ({ where }: { where: { assignedWorkerId?: string; status?: string } }) =>
      Promise.resolve(
        this.missions.filter(
          (m) =>
            (where.assignedWorkerId === undefined ||
              m.assignedWorkerId === where.assignedWorkerId) &&
            (where.status === undefined || m.status === where.status),
        ).length,
      ),
  };

  // Informations d'embauche : une ligne par intérimaire, remplacée en entier à chaque envoi.
  // Le chiffrement, lui, n'est PAS doublé — le vrai EncryptionService tourne dans ces tests,
  // sans quoi la vérification « l'API ne renvoie jamais le NIR en clair » ne vaudrait rien.
  readonly hiringInfo = {
    findUnique: ({ where }: { where: { workerId: string } }) =>
      Promise.resolve(this.hiringInfos.get(where.workerId) ?? null),
    upsert: ({
      where,
      create,
      update,
    }: {
      where: { workerId: string };
      create: Record<string, unknown>;
      update: Record<string, unknown>;
    }) => {
      const existant = this.hiringInfos.get(where.workerId);
      const row = existant ? { ...existant, ...update } : { ...create };
      this.hiringInfos.set(where.workerId, row);
      return Promise.resolve(row);
    },
  };

  readonly candidature = {
    create: ({ data }: { data: { missionId: string; workerId: string } }) => {
      if (
        this.candidatures.some(
          (c) => c.missionId === data.missionId && c.workerId === data.workerId,
        )
      ) {
        return Promise.reject(uniqueViolation('mission_id_worker_id'));
      }
      const row: CandidatureRow = {
        id: randomUUID(),
        missionId: data.missionId,
        workerId: data.workerId,
        status: 'ENVOYEE',
        createdAt: new Date(),
      };
      this.candidatures.push(row);
      const mission = this.missions.find((m) => m.id === data.missionId)!;
      return Promise.resolve({ ...row, mission: this.withMissionRelations(mission) });
    },
    // `include` est honoré, et pas seulement toléré : la vue entreprise charge l'intérimaire,
    // celle de l'intérimaire non. Le test fonctionnel ne vaudrait rien si la doublure servait
    // le candidat dans les deux cas.
    findMany: ({
      where,
      include,
    }: {
      where: { missionId?: string; workerId?: string };
      include?: { worker?: unknown };
    }) =>
      Promise.resolve(
        this.candidatures
          .filter(
            (c) =>
              (where.missionId === undefined || c.missionId === where.missionId) &&
              (where.workerId === undefined || c.workerId === where.workerId),
          )
          .map((c) => {
            const mission = this.missions.find((m) => m.id === c.missionId)!;
            const row: Record<string, unknown> = {
              ...c,
              mission: this.withMissionRelations(mission),
            };
            if (include?.worker) {
              row.worker = this.candidatWorker(c.workerId);
            }
            return row;
          }),
      ),
  };

  // Le bloc « candidat » vu par l'entreprise : identité, zone, habilitations brutes. C'est le
  // service qui écarte les habilitations expirées, pas la doublure — sinon le test ne
  // vérifierait plus rien de cette règle.
  private candidatWorker(workerId: string) {
    const record = this.users.workerRecordById(workerId);
    const fields = this.workerFields.get(workerId);
    return {
      // Exposé depuis que l'entreprise peut RETENIR un candidat.
      id: workerId,
      firstName: record?.firstName as string,
      lastName: record?.lastName as string,
      city: record?.city as string,
      postalCode: record?.postalCode as string,
      // Compétences déclarées et créneaux acceptés : ils pèsent sur le score que l'entreprise
      // voit désormais, la doublure doit donc les rendre comme la relation le ferait.
      skills: this.skills
        .filter((skill) => skill.workerId === workerId)
        .map((skill) => {
          const { code, label } = COMPETENCES.find((c) => c.code === skill.competenceCode)!;
          return { competence: { code, label } };
        }),
      shifts: fields?.shifts ?? [],
      certifications: this.certifications
        .filter((c) => c.workerId === workerId)
        .map((c) => ({
          type: c.type,
          expiresAt: c.expiresAt,
          verificationStatus: c.verificationStatus,
        })),
    };
  }

  // MongoService : insertOne (journal) et find().sort().limit().toArray() (historique du
  // dernier calcul, pour la notification n8n des nouveaux matchs). Historique vide dans ces
  // tests : ce n'est pas ce que matching.e2e-spec.ts vérifie, matching.service.spec.ts couvre
  // ce comportement au niveau unitaire.
  readonly mongo = {
    getDb: () => ({
      collection: () => ({
        insertOne: (doc: Record<string, unknown>) => {
          this.mongoInserts.push(doc);
          return Promise.resolve({ insertedId: randomUUID() });
        },
        find: () => ({
          sort: () => ({
            limit: () => ({
              toArray: () => Promise.resolve([]),
            }),
          }),
        }),
      }),
    }),
  };

  $transaction = (operations: Promise<unknown>[]): Promise<unknown[]> => Promise.all(operations);
}

// Prisma n'envoie QUE les colonnes du `select`, et rend `null` pour une colonne nullable
// qui n'a pas de valeur. Une doublure qui rendrait l'objet entier laisserait passer un
// service qui sélectionne trop — et ferait échouer un test pour une mauvaise raison.
// Une clé de `select` peut valoir `true` ou porter un `select` imbriqué (relations) :
// les deux sont conservées, seul un `false` explicite exclut.
function projeter(
  complet: Record<string, unknown>,
  select: Record<string, unknown>,
): Record<string, unknown> {
  return Object.fromEntries(
    Object.entries(select)
      .filter(([, valeur]) => Boolean(valeur))
      .map(([cle]) => [cle, complet[cle] ?? null]),
  );
}
