import { randomUUID } from 'node:crypto';
import { InMemoryUsers } from './in-memory-users';

type Row = Record<string, unknown> & { id: string; workerId: string };

// Suite du stockage en mémoire (voir in-memory-users.ts) pour les pièces d'identité et
// les habilitations. Les lignes sont exposées pour vérifier ce qui serait écrit en base.
export class InMemorySensitiveDocuments {
  readonly identityRows: Row[] = [];
  readonly certificationRows: Row[] = [];

  constructor(private readonly users: InMemoryUsers) {}

  readonly worker = {
    findUnique: ({ where }: { where: { userId: string } }): Promise<{ id: string } | null> => {
      const id = this.users.workerIdOf(where.userId);
      return Promise.resolve(id ? { id } : null);
    },
  };

  readonly identityDocument = {
    upsert: (args: {
      where: { workerId: string };
      create: Record<string, unknown> & { workerId: string };
      update: Record<string, unknown>;
    }): Promise<Row> =>
      Promise.resolve(
        upsert(this.identityRows, (row) => row.workerId === args.where.workerId, args),
      ),
    findUnique: ({ where }: { where: { workerId: string } }): Promise<Row | null> =>
      Promise.resolve(this.identityRows.find((row) => row.workerId === where.workerId) ?? null),
  };

  readonly certification = {
    upsert: (args: {
      where: { workerId_type: { workerId: string; type: string } };
      create: Record<string, unknown> & { workerId: string };
      update: Record<string, unknown>;
    }): Promise<Row> =>
      Promise.resolve(
        upsert(this.certificationRows, matches(args.where.workerId_type), {
          ...args,
          create: {
            documentEncrypted: null,
            documentMimeType: null,
            verificationStatus: 'NON_VERIFIE',
            refusalMotif: null,
            verifiedAt: null,
            verifiedByUserId: null,
            ...args.create,
          },
        }),
      ),
    // Deux appelants, deux formes de requête : l'intérimaire filtre sur son `workerId`,
    // l'agent CADANS sur le statut de vérification (et joint l'intérimaire).
    findMany: (args: {
      where: {
        workerId?: string;
        verificationStatus?: string;
        documentEncrypted?: unknown;
        expiresAt?: unknown;
      };
      orderBy?: { updatedAt?: 'asc' | 'desc' };
      include?: { worker?: unknown };
      select?: Record<string, unknown>;
      take?: number;
    }): Promise<Row[]> => {
      const { where, include, orderBy, select, take } = args;
      let lignes = this.certificationRows.filter(
        (row) =>
          (where.workerId === undefined || row.workerId === where.workerId) &&
          (where.verificationStatus === undefined ||
            row.verificationStatus === where.verificationStatus) &&
          // `{ not: null }` est la seule forme utilisée ici : un justificatif présent.
          (where.documentEncrypted === undefined || row.documentEncrypted != null) &&
          // Filtre « expirées » : le service ne demande à la base qu'une date à comparer,
          // et tranche ensuite lui-même sur la règle de validité.
          (where.expiresAt === undefined || row.expiresAt != null),
      );
      if (orderBy?.updatedAt) {
        const sens = orderBy.updatedAt === 'asc' ? 1 : -1;
        lignes = [...lignes].sort(
          (a, b) => sens * ((a.updatedAt as Date).getTime() - (b.updatedAt as Date).getTime()),
        );
      }
      if (take !== undefined) {
        lignes = lignes.slice(0, take);
      }
      // `select` (tableau de bord) et `include` (file d'attente) sont deux formes distinctes :
      // la première ne rend QUE les colonnes demandées, la seconde rend tout plus la jointure.
      // Confondre les deux ferait passer un test de minimisation qui ne vérifie rien.
      if (select) {
        return Promise.resolve(lignes.map((row) => projeter(this.avecWorker(row), select) as Row));
      }
      return Promise.resolve(lignes.map((row) => (include?.worker ? this.avecWorker(row) : row)));
    },

    count: ({
      where,
    }: {
      where: { verificationStatus?: string; documentEncrypted?: unknown };
    }): Promise<number> =>
      Promise.resolve(
        this.certificationRows.filter(
          (row) =>
            (where.verificationStatus === undefined ||
              row.verificationStatus === where.verificationStatus) &&
            (where.documentEncrypted === undefined || row.documentEncrypted != null),
        ).length,
      ),
    findUnique: ({
      where,
    }: {
      where: { id?: string; workerId_type?: { workerId: string; type: string } };
      select?: Record<string, unknown>;
    }): Promise<Row | null> =>
      Promise.resolve(
        (where.id
          ? this.certificationRows.find((row) => row.id === where.id)
          : this.certificationRows.find(matches(where.workerId_type!))) ?? null,
      ),
    update: (args: {
      where: { id: string };
      data: Record<string, unknown>;
      include?: { worker?: unknown };
    }): Promise<Row> => {
      const ligne = this.certificationRows.find((row) => row.id === args.where.id);
      if (!ligne) {
        return Promise.reject(new Error('Habilitation introuvable'));
      }
      Object.assign(ligne, args.data, { updatedAt: new Date() });
      return Promise.resolve(args.include?.worker ? this.avecWorker(ligne) : ligne);
    },
    deleteMany: ({ where }: { where: { workerId: string; type: string } }) => {
      const index = this.certificationRows.findIndex(matches(where));
      if (index === -1) {
        return Promise.resolve({ count: 0 });
      }
      // `onDelete: SetNull` : le registre des décisions SURVIT à la suppression, la clé
      // seule est détachée. Reproduit ici, sinon le test de traçabilité ne vérifierait que
      // le comportement de la doublure.
      const supprime = this.certificationRows[index];
      for (const decision of this.decisionRows) {
        if (decision.certificationId === supprime.id) {
          decision.certificationId = null;
        }
      }
      this.certificationRows.splice(index, 1);
      return Promise.resolve({ count: 1 });
    },
  };

  // Historique des décisions, alimenté par le service à chaque validation ou refus.
  readonly decisionRows: Record<string, unknown>[] = [];

  readonly certificationDecision = {
    create: ({ data }: { data: Record<string, unknown> }) => {
      const ligne = { id: randomUUID(), decidedAt: new Date(), ...data };
      this.decisionRows.push(ligne);
      return Promise.resolve(ligne);
    },
  };

  // Prisma lance les opérations avant de les passer à `$transaction` : les résoudre dans
  // l'ordre suffit à reproduire ce que le service en attend.
  readonly $transaction = (operations: Promise<unknown>[]): Promise<unknown[]> =>
    Promise.all(operations);

  // Décisions d'une certification, du plus récent au plus ancien — l'ordre demandé par le
  // service. L'agent est joint par son identifiant, comme le ferait la relation.
  private decisionsDe(certificationId: string): Record<string, unknown>[] {
    // `reverse()` avant le tri : `Array.prototype.sort` est STABLE, donc deux décisions
    // tombées dans la même milliseconde — ce qui arrive ici, tout étant en mémoire — sortent
    // dans l'ordre d'insertion inverse, la plus récente d'abord. C'est ce que rendrait une
    // base réelle départageant par sa séquence, et sans ça le test dépendait du hasard.
    return [...this.decisionRows]
      .filter((ligne) => ligne.certificationId === certificationId)
      .reverse()
      .sort((a, b) => (b.decidedAt as Date).getTime() - (a.decidedAt as Date).getTime())
      .map((ligne) => ({
        decision: ligne.decision,
        motif: ligne.motif ?? null,
        decidedAt: ligne.decidedAt,
        agent: ligne.agentUserId
          ? { email: this.users.emailOf(ligne.agentUserId as string) ?? '' }
          : null,
      }));
  }

  // Jointure attendue par la file d'attente de l'espace d'administration.
  private avecWorker(row: Row): Row {
    const worker = this.users.workerRecordById(row.workerId);
    return {
      ...row,
      worker: {
        id: row.workerId,
        firstName: worker?.firstName ?? '',
        lastName: worker?.lastName ?? '',
        city: worker?.city ?? '',
      },
      decisions: this.decisionsDe(row.id),
    };
  }
}

function matches(key: { workerId: string; type: string }): (row: Row) => boolean {
  return (row) => row.workerId === key.workerId && row.type === key.type;
}

function upsert(
  rows: Row[],
  predicate: (row: Row) => boolean,
  args: { create: Record<string, unknown> & { workerId: string }; update: Record<string, unknown> },
): Row {
  const now = new Date();
  const existing = rows.find(predicate);
  if (existing) {
    Object.assign(existing, args.update, { updatedAt: now });
    return existing;
  }
  const row: Row = { id: randomUUID(), createdAt: now, updatedAt: now, ...args.create };
  rows.push(row);
  return row;
}

// Prisma ne rend QUE les colonnes du `select`, et descend dans les relations qui en portent
// un. Reproduit ici pour que le tableau de bord de l'agent soit testé sur ce qu'il demande
// vraiment à la base, pas sur ce que la doublure veut bien rendre.
function projeter(
  row: Record<string, unknown>,
  select: Record<string, unknown>,
): Record<string, unknown> {
  const resultat: Record<string, unknown> = {};
  for (const [cle, valeur] of Object.entries(select)) {
    if (!valeur) {
      continue;
    }
    const imbrique = (valeur as { select?: Record<string, unknown> }).select;
    resultat[cle] =
      imbrique && row[cle]
        ? projeter(row[cle] as Record<string, unknown>, imbrique)
        : (row[cle] ?? null);
  }
  return resultat;
}
