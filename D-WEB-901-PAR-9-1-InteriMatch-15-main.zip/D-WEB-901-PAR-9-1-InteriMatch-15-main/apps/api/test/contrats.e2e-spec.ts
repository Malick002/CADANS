import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryMissions } from './in-memory-missions';
import { InMemoryUsers } from './in-memory-users';

const POSTE_CODE = '11679';

const entreprisePayload = {
  email: 'rh@loginord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'LogiNord SAS',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

const interimairePayload = {
  email: 'camille@example.fr',
  password: 'Preparateur!42x',
  acceptConditions: true,
  firstName: 'Camille',
  lastName: 'Martin',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

// Un second intérimaire, qui n'est retenu sur rien : c'est lui qui prouve que le
// cloisonnement tient, pas seulement que chacun voit son document.
const tiersPayload = {
  email: 'tiers@example.fr',
  password: 'Manutention!7x',
  acceptConditions: true,
  firstName: 'Sofia',
  lastName: 'Nunes',
  postalCode: '93200',
  city: 'Saint-Denis',
};

const missionPayload = {
  posteCode: POSTE_CODE,
  siteLabel: 'LogiNord - Roissy (95)',
  postalCode: '95700',
  startDate: '2026-10-01',
  endDate: '2026-10-31',
  shift: 'MATIN',
  motifRecours: 'REMPLACEMENT',
  remplaceNom: 'Julien Lefevre',
  remplaceQualification: 'Cariste',
  hourlyRate: 13.5,
  description: 'Chargement et déchargement au quai.',
  requiredCertifications: ['CACES_R489_3'],
};

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

const attendre = () => new Promise((resolve) => setTimeout(resolve, 50));

describe('Contrats (e2e)', () => {
  let app: INestApplication;
  let missions: InMemoryMissions;
  let entreprise: string;
  let interimaire: string;
  let tiers: string;
  let missionId: string;

  beforeAll(async () => {
    const users = new InMemoryUsers();
    missions = new InMemoryMissions(users);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        company: missions.company,
        poste: missions.poste,
        competence: missions.competence,
        worker: missions.worker,
        mission: missions.mission,
        contract: missions.contract,
        contractSignature: missions.contractSignature,
        missionAttachment: missions.missionAttachment,
      })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    const inscriptionEntreprise = await request(server)
      .post('/auth/register/company')
      .send(entreprisePayload);
    const inscriptionInterimaire = await request(server)
      .post('/auth/register/worker')
      .send(interimairePayload);
    entreprise = cookieOf(inscriptionEntreprise);
    interimaire = cookieOf(inscriptionInterimaire);
    tiers = cookieOf(await request(server).post('/auth/register/worker').send(tiersPayload));

    const mission = await request(server)
      .post('/missions')
      .set('Cookie', entreprise)
      .send(missionPayload)
      .expect(201);
    missionId = mission.body.id as string;

    const workerId = (inscriptionInterimaire.body as { worker: { id: string } }).worker.id;
    await request(server)
      .patch(`/missions/${missionId}/status`)
      .set('Cookie', entreprise)
      .send({ status: 'POURVUE', workerId })
      .expect(200);

    // La génération est lancée en tâche de fond derrière la réponse HTTP (elle ne doit ni la
    // retarder ni la faire échouer) : il faut la laisser aboutir avant de l'observer.
    await attendre();
  });

  afterAll(async () => {
    await app.close();
  });

  it('refuse sans session', async () => {
    await request(app.getHttpServer()).get('/contrats').expect(401);
  });

  // Les informations d'embauche de Camille ne sont pas renseignées dans ce test : seul le
  // contrat de mise à disposition doit exister. C'est exactement la règle demandée — le
  // contrat de mission attend, la mise à disposition part.
  it('génère la mise à disposition dès la mise à POURVUE, pas le contrat de mission', () => {
    expect(missions.contracts.map((c) => c.type)).toEqual(['MISE_A_DISPOSITION']);
  });

  it('sert à l’entreprise son contrat de mise à disposition', async () => {
    const response = await request(app.getHttpServer())
      .get('/contrats')
      .set('Cookie', entreprise)
      .expect(200);

    expect(response.body).toHaveLength(1);
    expect(response.body[0]).toMatchObject({
      type: 'MISE_A_DISPOSITION',
      missionId,
      missionTitre: 'Cariste',
      companyName: 'LogiNord SAS',
    });
    // Empreinte SHA-256 du PDF en clair : 64 caractères hexadécimaux. Elle servira de
    // référence à la signature (b2).
    expect(response.body[0].sha256).toMatch(/^[0-9a-f]{64}$/);
  });

  it('ne sert rien à l’intérimaire tant que son contrat de mission n’existe pas', async () => {
    const response = await request(app.getHttpServer())
      .get('/contrats')
      .set('Cookie', interimaire)
      .expect(200);

    expect(response.body).toEqual([]);
  });

  it('télécharge le document, en PDF et sans cache', async () => {
    const liste = await request(app.getHttpServer()).get('/contrats').set('Cookie', entreprise);
    const id = liste.body[0].id as string;

    const response = await request(app.getHttpServer())
      .get(`/contrats/${id}/document`)
      .set('Cookie', entreprise)
      .expect(200);

    expect(response.headers['content-type']).toContain('application/pdf');
    expect(response.headers['cache-control']).toBe('no-store');
    expect(response.headers['x-content-type-options']).toBe('nosniff');
    expect(response.body.subarray(0, 5).toString('latin1')).toBe('%PDF-');
  });

  /**
   * Le cœur du cloisonnement, vérifié au niveau HTTP avec l'identifiant exact : ni un autre
   * intérimaire, ni l'intérimaire de la mission n'obtiennent le contrat de mise à disposition
   * de l'entreprise.
   *
   * **404 et non 403** : un 403 confirmerait qu'un contrat porte cet identifiant.
   */
  it('refuse le document à qui n’en est pas destinataire, avec 404', async () => {
    const liste = await request(app.getHttpServer()).get('/contrats').set('Cookie', entreprise);
    const id = liste.body[0].id as string;

    for (const session of [interimaire, tiers]) {
      await request(app.getHttpServer())
        .get(`/contrats/${id}/document`)
        .set('Cookie', session)
        .expect(404);
    }
  });

  it('refuse un identifiant qui n’est pas un UUID', async () => {
    await request(app.getHttpServer())
      .get('/contrats/pas-un-uuid/document')
      .set('Cookie', entreprise)
      .expect(400);
  });

  // Le motif du recours est la première mention obligatoire du contrat de mise à disposition
  // (art. L. 1251-43 1°) : sans lui, la mission ne se crée pas.
  it('refuse une mission sans motif de recours', async () => {
    const { motifRecours: _motif, ...sansMotif } = missionPayload;

    await request(app.getHttpServer())
      .post('/missions')
      .set('Cookie', entreprise)
      .send(sansMotif)
      .expect(400);
  });

  it('refuse un remplacement sans le salarié remplacé', async () => {
    await request(app.getHttpServer())
      .post('/missions')
      .set('Cookie', entreprise)
      .send({ ...missionPayload, remplaceNom: undefined, remplaceQualification: undefined })
      .expect(400);
  });

  describe('signature', () => {
    let contratId: string;

    beforeAll(async () => {
      const liste = await request(app.getHttpServer()).get('/contrats').set('Cookie', entreprise);
      contratId = liste.body[0].id as string;
    });

    // CADANS signe à la génération : le document arrive déjà porteur d'une signature, et
    // c'est à l'entreprise de poser la seconde.
    it('arrive signé par CADANS, et annoncé « à signer » pour l’entreprise', async () => {
      const liste = await request(app.getHttpServer())
        .get('/contrats')
        .set('Cookie', entreprise)
        .expect(200);

      expect(liste.body[0].signatures).toHaveLength(1);
      expect(liste.body[0].signatures[0].party).toBe('CADANS');
      expect(liste.body[0]).toMatchObject({ signe: false, aSigner: true });
    });

    it('refuse une signature sans la case d’acceptation', async () => {
      await request(app.getHttpServer())
        .post(`/contrats/${contratId}/signer`)
        .set('Cookie', entreprise)
        .send({ nomComplet: 'Nadia Benali', accepte: false })
        .expect(400);
    });

    it('refuse un nom qui n’est pas celui du compte', async () => {
      await request(app.getHttpServer())
        .post(`/contrats/${contratId}/signer`)
        .set('Cookie', entreprise)
        .send({ nomComplet: 'Jean Dupont', accepte: true })
        .expect(400);
    });

    // On ne signe que son propre document. 404, comme en lecture : un 403 confirmerait qu'un
    // contrat porte cet identifiant.
    it('refuse la signature d’un tiers et de l’autre partie', async () => {
      for (const session of [interimaire, tiers]) {
        await request(app.getHttpServer())
          .post(`/contrats/${contratId}/signer`)
          .set('Cookie', session)
          .send({ nomComplet: 'Nadia Benali', accepte: true })
          .expect(404);
      }
    });

    it('signe, conserve la preuve et produit le document final', async () => {
      const reponse = await request(app.getHttpServer())
        .post(`/contrats/${contratId}/signer`)
        .set('Cookie', entreprise)
        .set('User-Agent', 'CADANS-Test/1.0')
        .send({ nomComplet: 'Nadia Benali', accepte: true })
        .expect(201);

      expect(reponse.body).toMatchObject({ signe: true, aSigner: false });
      expect(reponse.body.signatures.map((s: { party: string }) => s.party)).toEqual([
        'CADANS',
        'ENTREPRISE',
      ]);

      // La preuve, telle qu'elle est écrite en base : qui, quoi, quand, d'où, sur quoi.
      const preuve = missions.signatures.find((s) => s.party === 'ENTREPRISE')!;
      expect(preuve.typedName).toBe('Nadia Benali');
      expect(preuve.userAgent).toBe('CADANS-Test/1.0');
      expect(preuve.ip).toBeTruthy();
      expect(preuve.documentSha256).toMatch(/^[0-9a-f]{64}$/);
    });

    it('sert désormais le document final, nommé comme tel', async () => {
      const reponse = await request(app.getHttpServer())
        .get(`/contrats/${contratId}/document`)
        .set('Cookie', entreprise)
        .expect(200);

      expect(reponse.headers['content-disposition']).toContain(
        'contrat-de-mise-a-disposition-signe.pdf',
      );
      expect(reponse.body.subarray(0, 5).toString('latin1')).toBe('%PDF-');
    });

    it('refuse une seconde signature, en 409', async () => {
      await request(app.getHttpServer())
        .post(`/contrats/${contratId}/signer`)
        .set('Cookie', entreprise)
        .send({ nomComplet: 'Nadia Benali', accepte: true })
        .expect(409);
    });
  });

  // --- Annexes (b3) -------------------------------------------------------------------
  describe('annexes', () => {
    const PDF = Buffer.concat([
      Buffer.from('%PDF-1.4\n'),
      Buffer.from('consignes de sécurité du site'),
    ]);

    it('refuse le dépôt à un intérimaire', async () => {
      await request(app.getHttpServer())
        .post(`/missions/${missionId}/annexes`)
        .set('Cookie', interimaire)
        .field('filename', 'Consignes.pdf')
        .attach('file', PDF, 'consignes.pdf')
        .expect(403);
    });

    it('refuse à une entreprise la mission d’une autre, avec 404', async () => {
      // Identifiant valide mais inconnu de cette entreprise : elle n'a pas à apprendre qu'il
      // existe une mission derrière.
      await request(app.getHttpServer())
        .post('/missions/11111111-1111-4111-8111-111111111111/annexes')
        .set('Cookie', entreprise)
        .field('filename', 'Consignes.pdf')
        .attach('file', PDF, 'consignes.pdf')
        .expect(404);
    });

    it('refuse un fichier qui n’est pas un PDF, quel que soit son nom', async () => {
      await request(app.getHttpServer())
        .post(`/missions/${missionId}/annexes`)
        .set('Cookie', entreprise)
        .field('filename', 'faux.pdf')
        .attach('file', Buffer.from('\x89PNG\r\n\x1a\ncontenu'), 'faux.pdf')
        .expect(415);
    });

    it('dépose une annexe, et l’enregistre chiffrée', async () => {
      const reponse = await request(app.getHttpServer())
        .post(`/missions/${missionId}/annexes`)
        .set('Cookie', entreprise)
        .field('filename', 'Consignes de sécurité')
        .attach('file', PDF, 'consignes.pdf')
        .expect(201);

      expect(reponse.body).toMatchObject({
        filename: 'Consignes de sécurité.pdf',
        sizeBytes: PDF.length,
        missionId,
      });

      const stockee = missions.annexes[0];
      expect(Buffer.from(stockee.fileEncrypted as Uint8Array).toString('latin1')).not.toContain(
        'consignes de sécurité du site',
      );
    });

    it('la sert à l’entreprise et à l’intérimaire retenu', async () => {
      for (const session of [entreprise, interimaire]) {
        const liste = await request(app.getHttpServer())
          .get(`/missions/${missionId}/annexes`)
          .set('Cookie', session)
          .expect(200);
        expect(liste.body).toHaveLength(1);

        const document = await request(app.getHttpServer())
          .get(`/annexes/${liste.body[0].id}/document`)
          .set('Cookie', session)
          .expect(200);
        expect(document.headers['content-type']).toContain('application/pdf');
        expect(document.headers['cache-control']).toBe('no-store');
        expect(document.body.equals(PDF)).toBe(true);
      }
    });

    /**
     * Un intérimaire qui n'est pas retenu sur la mission ne voit rien — ni la liste, ni le
     * document, même avec son identifiant exact. 404 et non 403 : la fiche de mission est
     * publique, l'existence de ses annexes n'a pas à l'être.
     */
    it('refuse un intérimaire non retenu, liste comme document', async () => {
      await request(app.getHttpServer())
        .get(`/missions/${missionId}/annexes`)
        .set('Cookie', tiers)
        .expect(404);

      const id = missions.annexes[0].id as string;
      await request(app.getHttpServer())
        .get(`/annexes/${id}/document`)
        .set('Cookie', tiers)
        .expect(404);
    });

    it('refuse sans session', async () => {
      await request(app.getHttpServer()).get(`/missions/${missionId}/annexes`).expect(401);
    });

    /**
     * Les annexes ne dépendent PAS des contrats : ici l'intérimaire n'en a AUCUN — ses
     * informations d'embauche manquent — et il doit pourtant recevoir le plan d'accès et les
     * consignes du site. C'est exactement le cas que le premier essai laissait sans rien.
     */
    it('sert à l’intérimaire les annexes de ses missions retenues, sans contrat', async () => {
      expect(
        (await request(app.getHttpServer()).get('/contrats').set('Cookie', interimaire)).body,
      ).toEqual([]);

      const reponse = await request(app.getHttpServer())
        .get('/workers/me/annexes')
        .set('Cookie', interimaire)
        .expect(200);

      expect(reponse.body).toHaveLength(1);
      expect(reponse.body[0]).toMatchObject({ missionId, missionTitre: 'Cariste' });
      expect(reponse.body[0].annexes).toHaveLength(1);
    });

    it('ne sert rien à un intérimaire retenu sur aucune mission', async () => {
      const reponse = await request(app.getHttpServer())
        .get('/workers/me/annexes')
        .set('Cookie', tiers)
        .expect(200);

      expect(reponse.body).toEqual([]);
    });

    it('refuse cette route à une entreprise', async () => {
      await request(app.getHttpServer())
        .get('/workers/me/annexes')
        .set('Cookie', entreprise)
        .expect(403);
    });

    // --- Suppression -------------------------------------------------------------------
    it('refuse la suppression à un intérimaire, même retenu sur la mission', async () => {
      const id = missions.annexes[0].id as string;

      await request(app.getHttpServer())
        .delete(`/annexes/${id}`)
        .set('Cookie', interimaire)
        .expect(403);
      expect(missions.annexes).toHaveLength(1);
    });

    it('refuse la suppression sans session', async () => {
      const id = missions.annexes[0].id as string;
      await request(app.getHttpServer()).delete(`/annexes/${id}`).expect(401);
    });

    /**
     * Une annexe n'est pas un brouillon : les consignes d'un site font partie de ce sur quoi
     * l'intérimaire s'est engagé en signant. Ici le contrat de mise à disposition a été signé
     * plus haut dans ce fichier, la suppression doit donc être refusée en **409**.
     */
    it('refuse la suppression quand un contrat de la mission est signé', async () => {
      const id = missions.annexes[0].id as string;

      await request(app.getHttpServer())
        .delete(`/annexes/${id}`)
        .set('Cookie', entreprise)
        .expect(409);
      expect(missions.annexes).toHaveLength(1);
    });

    it('supprime l’annexe d’une mission dont aucun contrat n’est signé', async () => {
      // Une seconde mission, sans contrat : c'est le cas nominal de la suppression.
      const autre = await request(app.getHttpServer())
        .post('/missions')
        .set('Cookie', entreprise)
        .send({ ...missionPayload, siteLabel: 'LogiNord - Gonesse (95)' })
        .expect(201);

      const depot = await request(app.getHttpServer())
        .post(`/missions/${autre.body.id}/annexes`)
        .set('Cookie', entreprise)
        .field('filename', 'À retirer')
        .attach('file', PDF, 'a-retirer.pdf')
        .expect(201);

      await request(app.getHttpServer())
        .delete(`/annexes/${depot.body.id}`)
        .set('Cookie', entreprise)
        .expect(204);

      const liste = await request(app.getHttpServer())
        .get(`/missions/${autre.body.id}/annexes`)
        .set('Cookie', entreprise)
        .expect(200);
      expect(liste.body).toEqual([]);
    });
  });
});
