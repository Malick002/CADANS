import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryUsers } from './in-memory-users';
import { InMemoryWorkerWorld } from './in-memory-worker-world';

const worker = {
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  acceptConditions: true,
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '69007',
  city: 'Lyon',
};

const company = {
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

// Compétence principale « Conduire un chariot élévateur… » (N1101), fixée dans
// in-memory-referentiel.ts.
const COMPETENCE_CODE = '484039';

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

describe('Profil intérimaire — matching (e2e)', () => {
  let app: INestApplication;
  let interimaire: string;
  let entreprise: string;

  beforeAll(async () => {
    const users = new InMemoryUsers();
    const world = new InMemoryWorkerWorld(users);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        worker: world.worker,
        workerSkill: world.workerSkill,
        competence: world.competence,
        $transaction: world.$transaction,
      })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    interimaire = cookieOf(await request(server).post('/auth/register/worker').send(worker));
    entreprise = cookieOf(await request(server).post('/auth/register/company').send(company));
  });

  afterAll(async () => {
    await app.close();
  });

  it('refuse sans session', async () => {
    await request(app.getHttpServer()).get('/workers/me/profil-matching').expect(401);
  });

  it('refuse un compte entreprise', async () => {
    await request(app.getHttpServer())
      .get('/workers/me/profil-matching')
      .set('Cookie', entreprise)
      .expect(403);
  });

  it('renvoie un profil vide avant toute mise à jour', async () => {
    const response = await request(app.getHttpServer())
      .get('/workers/me/profil-matching')
      .set('Cookie', interimaire)
      .expect(200);

    expect(response.body).toEqual({ shifts: [], competences: [] });
  });

  it('refuse une compétence inconnue du référentiel', async () => {
    await request(app.getHttpServer())
      .put('/workers/me/profil-matching')
      .set('Cookie', interimaire)
      .send({ shifts: ['MATIN'], competenceCodes: ['inconnue'] })
      .expect(400);
  });

  // La fenêtre de disponibilité est retirée du profil (décision produit du 21/09) : un
  // client qui l'enverrait encore est refusé, `forbidNonWhitelisted` étant actif. Le test
  // garantit qu'on ne la réintroduira pas par inadvertance côté site.
  it('refuse un champ de disponibilité, retiré du profil', async () => {
    await request(app.getHttpServer())
      .put('/workers/me/profil-matching')
      .set('Cookie', interimaire)
      .send({ availableFrom: '2026-09-18', shifts: ['MATIN'], competenceCodes: [] })
      .expect(400);
  });

  it('enregistre compétences et créneaux, puis les relit', async () => {
    await request(app.getHttpServer())
      .put('/workers/me/profil-matching')
      .set('Cookie', interimaire)
      .send({ shifts: ['MATIN', 'JOURNEE'], competenceCodes: [COMPETENCE_CODE] })
      .expect(200);

    const response = await request(app.getHttpServer())
      .get('/workers/me/profil-matching')
      .set('Cookie', interimaire)
      .expect(200);

    expect(response.body.shifts).toEqual(['MATIN', 'JOURNEE']);
    expect(response.body.competences).toEqual([
      {
        code: COMPETENCE_CODE,
        label: 'Conduire un chariot élévateur en respectant les normes de sécurité',
      },
    ]);
  });

  // Identité et localisation : pendant de GET/PUT /companies/me côté entreprise. Le code
  // postal porte le critère « zone » du matching, ce n'est pas un champ décoratif.
  describe('GET et PUT /workers/me/identite', () => {
    it('refuse sans session, et à un compte entreprise', async () => {
      await request(app.getHttpServer()).get('/workers/me/identite').expect(401);
      await request(app.getHttpServer())
        .get('/workers/me/identite')
        .set('Cookie', entreprise)
        .expect(403);
    });

    it('renvoie les coordonnées saisies à l’inscription', async () => {
      const response = await request(app.getHttpServer())
        .get('/workers/me/identite')
        .set('Cookie', interimaire)
        .expect(200);

      expect(response.body).toEqual({
        firstName: 'Samir',
        lastName: 'Diallo',
        phone: null,
        postalCode: '69007',
        city: 'Lyon',
      });
    });

    it('met à jour les coordonnées et les relit', async () => {
      const server = app.getHttpServer();

      await request(server)
        .put('/workers/me/identite')
        .set('Cookie', interimaire)
        .send({
          firstName: 'Samir',
          lastName: 'Diallo',
          phone: '0612345678',
          postalCode: '95700',
          city: 'Roissy-en-France',
        })
        .expect(200);

      const relu = await request(server)
        .get('/workers/me/identite')
        .set('Cookie', interimaire)
        .expect(200);

      expect(relu.body.city).toBe('Roissy-en-France');
      expect(relu.body.postalCode).toBe('95700');
      expect(relu.body.phone).toBe('0612345678');
    });

    // Le téléphone est facultatif : absent du corps, il doit être EFFACÉ, pas laissé tel
    // quel. L'écran renvoie le formulaire entier, un champ vidé doit l'être en base.
    it('efface le téléphone quand il n’est plus envoyé', async () => {
      const server = app.getHttpServer();
      const base = {
        firstName: 'Samir',
        lastName: 'Diallo',
        postalCode: '69007',
        city: 'Lyon',
      };

      await request(server)
        .put('/workers/me/identite')
        .set('Cookie', interimaire)
        .send({ ...base, phone: '0612345678' })
        .expect(200);

      const sansTelephone = await request(server)
        .put('/workers/me/identite')
        .set('Cookie', interimaire)
        .send(base)
        .expect(200);

      expect(sansTelephone.body.phone).toBeNull();
    });

    it('refuse un code postal invalide', async () => {
      await request(app.getHttpServer())
        .put('/workers/me/identite')
        .set('Cookie', interimaire)
        .send({
          firstName: 'Samir',
          lastName: 'Diallo',
          postalCode: '6900',
          city: 'Lyon',
        })
        .expect(400);
    });
  });
});
