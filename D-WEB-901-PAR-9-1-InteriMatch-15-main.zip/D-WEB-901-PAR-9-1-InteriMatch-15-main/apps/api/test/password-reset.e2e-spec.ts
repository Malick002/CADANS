import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { Email, MailService } from '../src/mail/mail.service';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryPasswordResetTokens } from './in-memory-password-reset-tokens';
import { InMemoryUsers } from './in-memory-users';

const worker = {
  acceptConditions: true,
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '69007',
  city: 'Lyon',
};

const NEW_PASSWORD = 'Entrepot!2027xyz';

// Le fournisseur d'emails est remplacé par une boîte aux lettres en mémoire : le test lit
// le lien exactement là où l'utilisateur le lirait, dans le message reçu.
class Mailbox {
  readonly sent: Email[] = [];

  send = (email: Email): Promise<void> => {
    this.sent.push(email);
    return Promise.resolve();
  };

  get last(): Email {
    const email = this.sent.at(-1);
    if (!email) {
      throw new Error('Aucun email envoyé');
    }
    return email;
  }

  tokenFromLastLink(): string {
    const link = /https?:\/\/\S+/.exec(this.last.text)?.[0] ?? '';
    return decodeURIComponent(new URL(link).searchParams.get('token') ?? '');
  }
}

describe('Réinitialisation de mot de passe (e2e)', () => {
  let app: INestApplication;
  let mailbox: Mailbox;

  beforeAll(async () => {
    mailbox = new Mailbox();

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: new InMemoryUsers(),
        passwordResetToken: new InMemoryPasswordResetTokens(),
      })
      .overrideProvider(MailService)
      .useValue(mailbox)
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    await request(app.getHttpServer()).post('/auth/register/worker').send(worker).expect(201);
  });

  afterAll(async () => {
    await app.close();
  });

  const requestReset = (email: string) =>
    request(app.getHttpServer()).post('/auth/password-reset/request').send({ email });

  const confirmReset = (token: string, password: string) =>
    request(app.getHttpServer()).post('/auth/password-reset/confirm').send({ token, password });

  const login = (password: string) =>
    request(app.getHttpServer()).post('/auth/login').send({ email: worker.email, password });

  describe('POST /auth/password-reset/request', () => {
    it('répond 204 pour une adresse inconnue, sans rien envoyer', async () => {
      await requestReset('personne@example.fr').expect(204);

      expect(mailbox.sent).toHaveLength(0);
    });

    it('répond 204 pour un compte existant et envoie un lien', async () => {
      await requestReset(worker.email).expect(204);

      expect(mailbox.sent).toHaveLength(1);
      expect(mailbox.last.to).toBe(worker.email);
      expect(mailbox.tokenFromLastLink()).not.toBe('');
    });

    it("accepte l'adresse quelle que soit la casse et les espaces", async () => {
      await requestReset('  SAMIR@Example.FR  ').expect(204);

      expect(mailbox.last.to).toBe(worker.email);
    });

    it('refuse une adresse mal formée', async () => {
      await requestReset('pas-une-adresse').expect(400);
    });
  });

  describe('POST /auth/password-reset/confirm', () => {
    it('refuse un jeton inconnu', async () => {
      await confirmReset('jeton-inexistant', NEW_PASSWORD).expect(400);
    });

    it('refuse un mot de passe qui ne respecte pas les règles', async () => {
      await requestReset(worker.email).expect(204);

      await confirmReset(mailbox.tokenFromLastLink(), 'motdepasse').expect(400);
    });

    it('rend le lien précédent inutilisable quand un nouveau est demandé', async () => {
      await requestReset(worker.email).expect(204);
      const ancien = mailbox.tokenFromLastLink();

      await requestReset(worker.email).expect(204);

      await confirmReset(ancien, NEW_PASSWORD).expect(400);
    });

    it('change le mot de passe, puis le lien ne resert pas', async () => {
      await requestReset(worker.email).expect(204);
      const token = mailbox.tokenFromLastLink();

      await confirmReset(token, NEW_PASSWORD).expect(204);

      // L'ancien mot de passe ne fonctionne plus, le nouveau ouvre la session.
      await login(worker.password).expect(401);
      const response = await login(NEW_PASSWORD).expect(200);
      expect(response.body).toMatchObject({ email: worker.email, role: 'WORKER' });

      // Usage unique : rejouer le même lien est refusé.
      await confirmReset(token, 'Encore!UnAutre2027').expect(400);
      await login('Encore!UnAutre2027').expect(401);
    });
  });
});
