import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryMissions } from './in-memory-missions';
import { InMemoryUsers } from './in-memory-users';

const worker = {
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  acceptConditions: true,
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '69007',
  city: 'Lyon',
};

const company = {
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

// Poste exposé « Cariste » (N1101) et compétence principale associée, tels que fixés dans
// in-memory-referentiel.ts.
const POSTE_CODE = '11679';
const COMPETENCE_CODE = '484039';

const missionPayload = {
  posteCode: POSTE_CODE,
  siteLabel: 'LogiNord - Roissy (95)',
  postalCode: '95700',
  startDate: '2026-09-18',
  endDate: '2026-09-22',
  shift: 'MATIN',
  motifRecours: 'ACCROISSEMENT_TEMPORAIRE',
  hourlyRate: 13.5,
  description: 'Préparation de commandes en entrepôt frigorifique.',
  requiredCertifications: ['CACES_R489_3'],
  competenceCodes: [COMPETENCE_CODE],
};

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

describe('Missions (e2e)', () => {
  let app: INestApplication;
  let entreprise: string;
  let interimaire: string;
  let interimaireWorkerId: string;

  beforeAll(async () => {
    const users = new InMemoryUsers();
    const missions = new InMemoryMissions(users);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        company: missions.company,
        poste: missions.poste,
        competence: missions.competence,
        worker: missions.worker,
        mission: missions.mission,
        contract: missions.contract,
      })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    entreprise = cookieOf(await request(server).post('/auth/register/company').send(company));
    const registration = await request(server).post('/auth/register/worker').send(worker);
    interimaire = cookieOf(registration);
    interimaireWorkerId = registration.body.worker.id;
  });

  afterAll(async () => {
    await app.close();
  });

  it('refuse une création sans session', async () => {
    await request(app.getHttpServer()).post('/missions').send(missionPayload).expect(401);
  });

  it('refuse la création à un compte intérimaire', async () => {
    await request(app.getHttpServer())
      .post('/missions')
      .set('Cookie', interimaire)
      .send(missionPayload)
      .expect(403);
  });

  it('refuse un poste inconnu du référentiel', async () => {
    await request(app.getHttpServer())
      .post('/missions')
      .set('Cookie', entreprise)
      .send({ ...missionPayload, posteCode: 'inconnu' })
      .expect(400);
  });

  it('refuse une date de fin antérieure à la date de début', async () => {
    await request(app.getHttpServer())
      .post('/missions')
      .set('Cookie', entreprise)
      .send({ ...missionPayload, startDate: '2026-09-22', endDate: '2026-09-18' })
      .expect(400);
  });

  it('crée la mission, puis la retrouve dans la liste de l’entreprise', async () => {
    const created = await request(app.getHttpServer())
      .post('/missions')
      .set('Cookie', entreprise)
      .send(missionPayload)
      .expect(201);

    expect(created.body).toMatchObject({
      posteCode: POSTE_CODE,
      posteLabel: 'Cariste',
      status: 'OUVERTE',
      requiredCertifications: ['CACES_R489_3'],
      competenceCodes: [COMPETENCE_CODE],
    });

    const list = await request(app.getHttpServer())
      .get('/missions')
      .set('Cookie', entreprise)
      .expect(200);

    expect(list.body).toHaveLength(1);
    expect(list.body[0].id).toBe(created.body.id);
  });

  it('filtre la liste par statut', async () => {
    const response = await request(app.getHttpServer())
      .get('/missions')
      .query({ status: 'TERMINEE' })
      .set('Cookie', entreprise)
      .expect(200);

    expect(response.body).toEqual([]);
  });

  it("n'accepte pas une requête de liste sans session", async () => {
    await request(app.getHttpServer()).get('/missions').expect(401);
  });

  // Les deux routes d'annonce sont les seules ouvertes sans session : ce sont les pages que
  // les moteurs indexent (exigence SEO du sujet). Vérifié au niveau HTTP, parce que
  // RolesGuard ne consulte pas IS_PUBLIC_KEY — c'est le décorateur @Roles posé par méthode
  // et non par classe qui le permet.
  it('expose la liste des missions ouvertes sans session', async () => {
    const response = await request(app.getHttpServer()).get('/missions/ouvertes').expect(200);

    expect(response.body).toHaveLength(1);
    expect(response.body[0]).toMatchObject({
      posteLabel: 'Cariste',
      companyName: 'Entrepôt du Nord',
      status: 'OUVERTE',
    });
  });

  it('expose la fiche d’une mission sans session', async () => {
    const [mission] = (await request(app.getHttpServer()).get('/missions/ouvertes')).body;

    const fiche = await request(app.getHttpServer()).get(`/missions/${mission.id}`).expect(200);

    expect(fiche.body.id).toBe(mission.id);
  });

  it('refuse un identifiant de mission qui n’est pas un UUID', async () => {
    await request(app.getHttpServer()).get('/missions/pas-un-uuid').expect(400);
  });

  it('change le statut, ce qui retire la mission de la liste publique', async () => {
    const [mission] = (await request(app.getHttpServer()).get('/missions/ouvertes')).body;

    await request(app.getHttpServer())
      .patch(`/missions/${mission.id}/status`)
      .set('Cookie', entreprise)
      .send({ status: 'POURVUE', workerId: interimaireWorkerId })
      .expect(200);

    const publiques = await request(app.getHttpServer()).get('/missions/ouvertes').expect(200);
    expect(publiques.body).toEqual([]);

    // La fiche reste lisible : une URL indexée ne doit pas devenir 404 le jour où la
    // mission est pourvue.
    const fiche = await request(app.getHttpServer()).get(`/missions/${mission.id}`).expect(200);
    expect(fiche.body.status).toBe('POURVUE');
  });

  // Pas de file de candidature dans ce POC (décision de périmètre, docs/parcours-entreprise.md) : l'entreprise désigne l'intérimaire
  // retenu, et un identifiant inconnu doit être refusé plutôt que silencieusement accepté.
  // La mission créée plus haut est déjà POURVUE à ce stade (test précédent) : peu importe,
  // seul le contrôle de propriété et la validité du workerId sont en jeu ici.
  it('refuse de passer une mission à POURVUE sans intérimaire retenu valide', async () => {
    const [mission] = (
      await request(app.getHttpServer()).get('/missions').set('Cookie', entreprise)
    ).body;

    await request(app.getHttpServer())
      .patch(`/missions/${mission.id}/status`)
      .set('Cookie', entreprise)
      .send({ status: 'POURVUE' })
      .expect(400);

    await request(app.getHttpServer())
      .patch(`/missions/${mission.id}/status`)
      .set('Cookie', entreprise)
      .send({ status: 'POURVUE', workerId: '00000000-0000-4000-8000-000000000000' })
      .expect(400);
  });

  it('refuse un statut inconnu', async () => {
    const fiche = await request(app.getHttpServer())
      .get('/missions')
      .set('Cookie', entreprise)
      .expect(200);

    await request(app.getHttpServer())
      .patch(`/missions/${fiche.body[0].id}/status`)
      .set('Cookie', entreprise)
      .send({ status: 'ARCHIVEE' })
      .expect(400);
  });

  it("refuse de modifier la mission d'une autre entreprise", async () => {
    const autre = cookieOf(
      await request(app.getHttpServer())
        .post('/auth/register/company')
        .send({ ...company, email: 'autre@loginord.fr', siret: '39838393700131' }),
    );
    const fiche = await request(app.getHttpServer())
      .get('/missions')
      .set('Cookie', entreprise)
      .expect(200);

    await request(app.getHttpServer())
      .put(`/missions/${fiche.body[0].id}`)
      .set('Cookie', autre)
      .send(missionPayload)
      .expect(403);
  });
});
