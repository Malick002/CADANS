import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { MAX_DOCUMENT_SIZE_BYTES } from '../src/sensitive-documents/file-type';
import { InMemorySensitiveDocuments } from './in-memory-documents';
import { InMemoryUsers } from './in-memory-users';

const PDF = Buffer.from('%PDF-1.7\nScan de la carte CACES R489 catégorie 3\n%%EOF');
const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x42, 0x42]);

const worker = (email: string) => ({
  acceptConditions: true,
  email,
  password: 'Preparateur!42x',
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '69007',
  city: 'Lyon',
});

const company = {
  acceptConditions: true,
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

// Supertest ne met pas en tampon les réponses binaires par défaut.
const binary = (
  response: request.Response,
  callback: (err: Error | null, body: Buffer) => void,
) => {
  const chunks: Buffer[] = [];
  response.on('data', (chunk: Buffer) => chunks.push(chunk));
  response.on('end', () => callback(null, Buffer.concat(chunks)));
};

describe('Données sensibles chiffrées (e2e)', () => {
  let app: INestApplication;
  let storage: InMemorySensitiveDocuments;
  let samir: string;
  let lea: string;
  let entreprise: string;

  beforeAll(async () => {
    const users = new InMemoryUsers();
    storage = new InMemorySensitiveDocuments(users);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        worker: storage.worker,
        identityDocument: storage.identityDocument,
        certification: storage.certification,
      })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    samir = cookieOf(
      await request(server).post('/auth/register/worker').send(worker('samir@example.fr')),
    );
    lea = cookieOf(
      await request(server).post('/auth/register/worker').send(worker('lea@example.fr')),
    );
    entreprise = cookieOf(await request(server).post('/auth/register/company').send(company));
  });

  afterAll(async () => {
    await app.close();
  });

  describe("pièce d'identité", () => {
    it('enregistre la pièce chiffrée et ne renvoie que ses métadonnées', async () => {
      const response = await request(app.getHttpServer())
        .put('/workers/me/identity-document')
        .set('Cookie', samir)
        .field('type', 'CNI')
        .attach('file', PDF, { filename: 'cni.pdf', contentType: 'application/pdf' })
        .expect(200);

      expect(response.body).toMatchObject({ type: 'CNI', mimeType: 'application/pdf' });
      expect(JSON.stringify(response.body)).not.toContain('file');

      // Ce qui serait écrit en base ne contient pas le document en clair.
      const stored = Buffer.from(storage.identityRows[0].fileEncrypted as Uint8Array);
      expect(stored.includes(PDF)).toBe(false);
      expect(stored.length).toBeGreaterThan(PDF.length);
    });

    it('rend le document déchiffré à son propriétaire, sans mise en cache', async () => {
      const response = await request(app.getHttpServer())
        .get('/workers/me/identity-document/file')
        .set('Cookie', samir)
        .buffer(true)
        .parse(binary)
        .expect(200);

      expect(Buffer.compare(response.body as Buffer, PDF)).toBe(0);
      expect(response.headers['content-type']).toBe('application/pdf');
      expect(response.headers['cache-control']).toBe('no-store');
      expect(response.headers['content-disposition']).toContain('piece-identite.pdf');
      expect(response.headers['x-content-type-options']).toBe('nosniff');
    });

    it("ne donne jamais accès à la pièce d'un autre intérimaire", async () => {
      await request(app.getHttpServer())
        .get('/workers/me/identity-document/file')
        .set('Cookie', lea)
        .expect(404);
    });

    it('refuse un fichier qui n’est ni PDF, ni JPEG, ni PNG, quel que soit son nom', async () => {
      await request(app.getHttpServer())
        .put('/workers/me/identity-document')
        .set('Cookie', lea)
        .field('type', 'PASSEPORT')
        .attach('file', Buffer.from('<html>faux pdf</html>'), {
          filename: 'passeport.pdf',
          contentType: 'application/pdf',
        })
        .expect(415);
    });

    it('refuse un fichier de plus de 5 Mo', async () => {
      const tooBig = Buffer.concat([PDF, Buffer.alloc(MAX_DOCUMENT_SIZE_BYTES)]);

      await request(app.getHttpServer())
        .put('/workers/me/identity-document')
        .set('Cookie', lea)
        .field('type', 'PASSEPORT')
        .attach('file', tooBig, { filename: 'gros.pdf', contentType: 'application/pdf' })
        .expect(413);
    });

    it('exige un type de pièce valide et un fichier', async () => {
      await request(app.getHttpServer())
        .put('/workers/me/identity-document')
        .set('Cookie', lea)
        .field('type', 'PERMIS')
        .attach('file', PNG, { filename: 'permis.png', contentType: 'image/png' })
        .expect(400);

      await request(app.getHttpServer())
        .put('/workers/me/identity-document')
        .set('Cookie', lea)
        .field('type', 'CNI')
        .expect(400);
    });
  });

  describe('habilitations', () => {
    it('enregistre un CACES avec numéro et scan chiffrés, type et date en clair', async () => {
      const response = await request(app.getHttpServer())
        .put('/workers/me/certifications/CACES_R489_3')
        .set('Cookie', samir)
        .field('expiresAt', '2030-06-30')
        .field('number', 'R489-3-000123')
        .attach('file', PDF, { filename: 'caces.pdf', contentType: 'application/pdf' })
        .expect(200);

      expect(response.body).toMatchObject({
        type: 'CACES_R489_3',
        expiresAt: '2030-06-30',
        number: 'R489-3-000123',
        hasDocument: true,
      });

      const row = storage.certificationRows[0];
      expect(row.type).toBe('CACES_R489_3');
      expect(Buffer.from(row.numberEncrypted as Uint8Array).toString('latin1')).not.toContain(
        'R489-3-000123',
      );
      expect(Buffer.from(row.documentEncrypted as Uint8Array).includes(PDF)).toBe(false);
    });

    it('met à jour la date sans perdre le scan', async () => {
      const response = await request(app.getHttpServer())
        .put('/workers/me/certifications/CACES_R489_3')
        .set('Cookie', samir)
        .field('expiresAt', '2031-01-15')
        .field('number', 'R489-3-000123')
        .expect(200);

      expect(response.body).toMatchObject({ expiresAt: '2031-01-15', hasDocument: true });
    });

    it("liste les habilitations de l'intérimaire connecté uniquement", async () => {
      const own = await request(app.getHttpServer())
        .get('/workers/me/certifications')
        .set('Cookie', samir)
        .expect(200);
      const other = await request(app.getHttpServer())
        .get('/workers/me/certifications')
        .set('Cookie', lea)
        .expect(200);

      expect(own.body).toHaveLength(1);
      expect(other.body).toEqual([]);
    });

    it('rend le scan déchiffré', async () => {
      const response = await request(app.getHttpServer())
        .get('/workers/me/certifications/CACES_R489_3/document')
        .set('Cookie', samir)
        .buffer(true)
        .parse(binary)
        .expect(200);

      expect(Buffer.compare(response.body as Buffer, PDF)).toBe(0);
      expect(response.headers['cache-control']).toBe('no-store');
      expect(response.headers['x-content-type-options']).toBe('nosniff');
    });

    it("refuse un type d'habilitation inconnu et une date invalide", async () => {
      await request(app.getHttpServer())
        .put('/workers/me/certifications/CACES_R999')
        .set('Cookie', samir)
        .field('expiresAt', '2030-06-30')
        .expect(400);

      await request(app.getHttpServer())
        .put('/workers/me/certifications/CACES_R485_1')
        .set('Cookie', samir)
        .field('expiresAt', '30/06/2030')
        .expect(400);
    });

    // Formats ISO 8601 valides mais qui ne sont pas une simple date AAAA-MM-JJ : ils
    // produisaient une date invalide côté service, donc une erreur 500.
    it.each(['2030-06-30T10:00', '2030-06-30T10:00:00Z', '2030-W26', '2030-181'])(
      'refuse la date « %s » par une erreur de validation, jamais une erreur serveur',
      async (expiresAt) => {
        await request(app.getHttpServer())
          .put('/workers/me/certifications/CACES_R485_1')
          .set('Cookie', samir)
          .field('expiresAt', expiresAt)
          .expect(400);
      },
    );

    it('refuse une date au bon format mais inexistante', async () => {
      await request(app.getHttpServer())
        .put('/workers/me/certifications/CACES_R485_1')
        .set('Cookie', samir)
        .field('expiresAt', '2030-02-30')
        .expect(400);
    });

    it('supprime une habilitation', async () => {
      await request(app.getHttpServer())
        .delete('/workers/me/certifications/CACES_R489_3')
        .set('Cookie', samir)
        .expect(204);
      await request(app.getHttpServer())
        .delete('/workers/me/certifications/CACES_R489_3')
        .set('Cookie', samir)
        .expect(404);
    });
  });

  it('réserve ces routes aux intérimaires connectés', async () => {
    await request(app.getHttpServer()).get('/workers/me/certifications').expect(401);
    await request(app.getHttpServer())
      .get('/workers/me/certifications')
      .set('Cookie', entreprise)
      .expect(403);
  });
});
