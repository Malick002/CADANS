import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { Shift } from '@prisma/client';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryUsers } from './in-memory-users';
import { InMemoryWorkerWorld } from './in-memory-worker-world';

const company = {
  email: 'contact@loginord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'LogiNord SAS',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

const POSTE_CODE = '11679'; // « Cariste » (N1101), in-memory-referentiel.ts

describe('Missions publiques (e2e)', () => {
  let app: INestApplication;
  let world: InMemoryWorkerWorld;
  let ouverteId: string;
  let pourvueId: string;

  beforeAll(async () => {
    const users = new InMemoryUsers();
    world = new InMemoryWorkerWorld(users);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({ user: users, mission: world.mission })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    const registered = await request(server).post('/auth/register/company').send(company);
    const companyId = users.companyIdOf((registered.body as { id: string }).id)!;

    ouverteId = world.addMission({
      companyId,
      posteCode: POSTE_CODE,
      siteLabel: 'LogiNord - Roissy (95)',
      postalCode: '95700',
      startDate: new Date('2026-09-18'),
      endDate: new Date('2026-09-22'),
      shift: Shift.MATIN,
      hourlyRate: 13.5,
      habilitations: [],
      competences: [],
    }).id;

    pourvueId = world.addMission({
      companyId,
      posteCode: POSTE_CODE,
      siteLabel: 'LogiNord - Lyon',
      postalCode: '69007',
      startDate: new Date('2026-09-18'),
      endDate: new Date('2026-09-22'),
      shift: Shift.MATIN,
      hourlyRate: 12,
      status: 'POURVUE',
      habilitations: [],
      competences: [],
    }).id;
  });

  afterAll(async () => {
    await app.close();
  });

  it('liste les missions ouvertes sans session, avec le nom de l’entreprise', async () => {
    const response = await request(app.getHttpServer()).get('/missions/ouvertes').expect(200);

    expect(response.body).toHaveLength(1);
    expect(response.body[0]).toMatchObject({ id: ouverteId, companyName: 'LogiNord SAS' });
  });

  it('renvoie le détail public d’une mission ouverte', async () => {
    const response = await request(app.getHttpServer()).get(`/missions/${ouverteId}`).expect(200);

    expect(response.body).toMatchObject({ id: ouverteId, siteLabel: 'LogiNord - Roissy (95)' });
  });

  // Ce test disait 404 sur version-khadija. Arbitrage du 21/09 : une URL indexée ou partagée
  // ne doit pas disparaître le jour où la mission est pourvue. La fiche reste lisible, elle
  // porte un bandeau et un noindex côté page, et c'est la CANDIDATURE qui est refusée
  // (voir candidatures.e2e-spec.ts).
  it('sert encore le détail d’une mission pourvue, pour ne pas casser une URL indexée', async () => {
    const response = await request(app.getHttpServer()).get(`/missions/${pourvueId}`).expect(200);

    expect(response.body).toMatchObject({ id: pourvueId, status: 'POURVUE' });
  });

  it('refuse le détail d’une mission inconnue', async () => {
    await request(app.getHttpServer())
      .get('/missions/00000000-0000-0000-0000-000000000000')
      .expect(404);
  });
});
