import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryUsers } from './in-memory-users';

// Identifiants de connexion : la même route sert l'entreprise et l'intérimaire, c'est tout
// l'intérêt de ce module. Les deux rôles sont donc éprouvés ici.

const MDP_ENTREPRISE = 'Cariste#2026ok';
const MDP_INTERIMAIRE = 'Preparateur!42x';

const company = {
  email: 'contact@entrepot-nord.fr',
  password: MDP_ENTREPRISE,
  acceptConditions: true,
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

const worker = {
  email: 'samir@example.fr',
  password: MDP_INTERIMAIRE,
  acceptConditions: true,
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '69007',
  city: 'Lyon',
};

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

describe('Compte : email et mot de passe (e2e)', () => {
  let app: INestApplication;
  let entreprise: string;
  let interimaire: string;

  beforeEach(async () => {
    // Un contexte neuf par test : ces routes modifient les identifiants, un test ne doit pas
    // hériter du mot de passe change par le precedent.
    const users = new InMemoryUsers();
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({ user: users, passwordResetToken: { updateMany: () => Promise.resolve({}) } })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    entreprise = cookieOf(await request(server).post('/auth/register/company').send(company));
    interimaire = cookieOf(await request(server).post('/auth/register/worker').send(worker));
  });

  afterEach(async () => {
    await app.close();
  });

  describe('GET /account/me', () => {
    it('refuse sans session', async () => {
      await request(app.getHttpServer()).get('/account/me').expect(401);
    });

    // Aucun @Roles : c'est voulu, les identifiants de connexion n'ont pas de rôle.
    it('répond aux deux rôles, et ne laisse jamais fuir le hash', async () => {
      for (const [cookie, email] of [
        [entreprise, company.email],
        [interimaire, worker.email],
      ]) {
        const response = await request(app.getHttpServer())
          .get('/account/me')
          .set('Cookie', cookie)
          .expect(200);

        expect(response.body.email).toBe(email);
        expect(JSON.stringify(response.body)).not.toMatch(/hash|\$argon2/);
      }
    });
  });

  describe('PUT /account/me/password', () => {
    it('change le mot de passe, et c’est le nouveau qui ouvre la session', async () => {
      const server = app.getHttpServer();

      await request(server)
        .put('/account/me/password')
        .set('Cookie', interimaire)
        .send({ currentPassword: MDP_INTERIMAIRE, password: 'NouveauMotDePasse#2027' })
        .expect(200);

      await request(server)
        .post('/auth/login')
        .send({ email: worker.email, password: 'NouveauMotDePasse#2027' })
        .expect(200);
      // L'ancien ne doit plus ouvrir : sans cette assertion, un service qui n'écrirait rien
      // passerait le test précédent.
      await request(server)
        .post('/auth/login')
        .send({ email: worker.email, password: MDP_INTERIMAIRE })
        .expect(401);
    });

    it('refuse sans le bon mot de passe actuel', async () => {
      const server = app.getHttpServer();

      await request(server)
        .put('/account/me/password')
        .set('Cookie', entreprise)
        .send({ currentPassword: 'PasLeBon#2026', password: 'NouveauMotDePasse#2027' })
        .expect(400);

      // Rien n'a bougé.
      await request(server)
        .post('/auth/login')
        .send({ email: company.email, password: MDP_ENTREPRISE })
        .expect(200);
    });

    it('applique les mêmes règles de mot de passe qu’à l’inscription', async () => {
      await request(app.getHttpServer())
        .put('/account/me/password')
        .set('Cookie', entreprise)
        .send({ currentPassword: MDP_ENTREPRISE, password: 'court' })
        .expect(400);
    });

    it('refuse sans session', async () => {
      await request(app.getHttpServer())
        .put('/account/me/password')
        .send({ currentPassword: MDP_ENTREPRISE, password: 'NouveauMotDePasse#2027' })
        .expect(401);
    });
  });

  describe('PUT /account/me/email', () => {
    it('change l’adresse, et c’est la nouvelle qui ouvre la session', async () => {
      const server = app.getHttpServer();

      const response = await request(server)
        .put('/account/me/email')
        .set('Cookie', entreprise)
        .send({ email: 'nouvelle@entrepot-nord.fr', currentPassword: MDP_ENTREPRISE })
        .expect(200);

      expect(response.body.email).toBe('nouvelle@entrepot-nord.fr');
      await request(server)
        .post('/auth/login')
        .send({ email: 'nouvelle@entrepot-nord.fr', password: MDP_ENTREPRISE })
        .expect(200);
      await request(server)
        .post('/auth/login')
        .send({ email: company.email, password: MDP_ENTREPRISE })
        .expect(401);
    });

    // La session ne porte que `sub` et `role`, jamais l'email : changer d'adresse ne doit
    // donc pas déconnecter. C'est ce qui justifie de ne pas réémettre le cookie.
    it('laisse la session en cours valide', async () => {
      const server = app.getHttpServer();

      await request(server)
        .put('/account/me/email')
        .set('Cookie', entreprise)
        .send({ email: 'nouvelle@entrepot-nord.fr', currentPassword: MDP_ENTREPRISE })
        .expect(200);

      const apres = await request(server).get('/account/me').set('Cookie', entreprise).expect(200);
      expect(apres.body.email).toBe('nouvelle@entrepot-nord.fr');
    });

    it('refuse une adresse déjà utilisée par un autre compte', async () => {
      await request(app.getHttpServer())
        .put('/account/me/email')
        .set('Cookie', entreprise)
        .send({ email: worker.email, currentPassword: MDP_ENTREPRISE })
        .expect(409);
    });

    // Le point de sécurité : un poste laissé ouvert ne doit pas suffire à s'emparer du
    // compte en détournant l'adresse de réinitialisation.
    it('refuse sans le bon mot de passe actuel', async () => {
      const server = app.getHttpServer();

      await request(server)
        .put('/account/me/email')
        .set('Cookie', entreprise)
        .send({ email: 'nouvelle@entrepot-nord.fr', currentPassword: 'PasLeBon#2026' })
        .expect(400);

      await request(server)
        .post('/auth/login')
        .send({ email: company.email, password: MDP_ENTREPRISE })
        .expect(200);
    });

    it('refuse une adresse mal formée', async () => {
      await request(app.getHttpServer())
        .put('/account/me/email')
        .set('Cookie', entreprise)
        .send({ email: 'pas-une-adresse', currentPassword: MDP_ENTREPRISE })
        .expect(400);
    });
  });
});
