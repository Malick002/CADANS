import { Prisma } from '@prisma/client';
import { randomUUID } from 'node:crypto';

type Profile = Record<string, unknown>;

interface CreateUserArgs {
  data: {
    email: string;
    passwordHash: string;
    role: string;
    company?: { create: Profile & { siret: string } };
    worker?: { create: Profile };
  };
}

interface StoredUser {
  id: string;
  email: string;
  passwordHash: string;
  role: string;
  createdAt: Date;
  updatedAt: Date;
  company: (Profile & { siret: string }) | null;
  worker: Profile | null;
}

// PostgreSQL est remplacé par un stockage en mémoire qui reproduit les contraintes
// d'unicité (email, SIRET). Le parcours testé reste complet : HTTP, validation des
// DTO, hachage argon2 réel, gestion des conflits et sérialisation de la réponse.
// Les tests passent ainsi sans base lancée, en local comme en CI.
export class InMemoryUsers {
  private readonly users: StoredUser[] = [];

  // Un compte agent CADANS ne peut pas être créé par HTTP : l'inscription publique ne
  // propose que WORKER et COMPANY, et le DTO refuse le reste. Les tests fonctionnels le
  // posent donc directement, comme le fait `seed:demo` en base.
  addAdmin(email: string, passwordHash: string): StoredUser {
    const now = new Date();
    const user: StoredUser = {
      id: randomUUID(),
      email,
      passwordHash,
      role: 'ADMIN',
      createdAt: now,
      updatedAt: now,
      company: null,
      worker: null,
    };
    this.users.push(user);
    return user;
  }

  create = ({ data }: CreateUserArgs): Promise<StoredUser> => {
    const company = data.company?.create ?? null;
    if (this.users.some((user) => user.email === data.email)) {
      return Promise.reject(uniqueViolation('email'));
    }
    if (company && this.users.some((user) => user.company?.siret === company.siret)) {
      return Promise.reject(uniqueViolation('siret'));
    }

    const id = randomUUID();
    const now = new Date();
    const user: StoredUser = {
      id,
      email: data.email,
      passwordHash: data.passwordHash,
      role: data.role,
      createdAt: now,
      updatedAt: now,
      // Comme Prisma : une relation absente vaut null, pas undefined.
      company: company && { id: randomUUID(), userId: id, phone: null, ...company },
      worker: data.worker
        ? { id: randomUUID(), userId: id, phone: null, ...data.worker.create }
        : null,
    };
    this.users.push(user);
    return Promise.resolve(user);
  };

  // `select` est honoré quand il est fourni : Prisma n'envoie que les colonnes demandées, et
  // une doublure qui rendrait tout laisserait passer une fuite de `passwordHash` sans que le
  // test s'en aperçoive. Les appelants qui n'en passent pas (auth) reçoivent l'objet entier,
  // comme avant.
  findUnique = ({
    where,
    select,
  }: {
    where: { email?: string; id?: string };
    select?: Record<string, boolean>;
  }): Promise<Partial<StoredUser> | null> => {
    const user = this.users.find((candidate) =>
      where.id !== undefined ? candidate.id === where.id : candidate.email === where.email,
    );
    if (!user) {
      return Promise.resolve(null);
    }
    if (!select) {
      return Promise.resolve(user);
    }
    return Promise.resolve(
      Object.fromEntries(Object.entries(user).filter(([cle]) => select[cle] === true)),
    );
  };

  // Hash du mot de passe (réinitialisation, changement depuis les paramètres) et adresse de
  // connexion (changement depuis les paramètres). Les deux champs sont facultatifs : une
  // mise à jour n'en porte qu'un à la fois.
  update = ({
    where,
    data,
    select,
  }: {
    where: { id: string };
    data: { passwordHash?: string; email?: string };
    select?: Record<string, boolean>;
  }): Promise<Partial<StoredUser>> => {
    const user = this.users.find((candidate) => candidate.id === where.id);
    if (!user) {
      return Promise.reject(new Error(`Utilisateur inconnu : ${where.id}`));
    }
    if (data.passwordHash !== undefined) {
      user.passwordHash = data.passwordHash;
    }
    if (data.email !== undefined) {
      user.email = data.email;
    }
    user.updatedAt = new Date();
    if (!select) {
      return Promise.resolve(user);
    }
    return Promise.resolve(
      Object.fromEntries(Object.entries(user).filter(([cle]) => select[cle] === true)),
    );
  };

  // Coordonnées de l'intérimaire (page Paramètres), pendant de updateCompanyProfile.
  updateWorkerProfile(workerId: string, data: Profile): (Profile & { id: string }) | null {
    const worker = this.users.find((user) => user.worker?.id === workerId)?.worker;
    if (!worker) {
      return null;
    }
    Object.assign(worker, data);
    return worker as Profile & { id: string };
  }

  workerIdOf(userId: string): string | null {
    const worker = this.users.find((user) => user.id === userId)?.worker;
    return typeof worker?.id === 'string' ? worker.id : null;
  }

  companyIdOf(userId: string): string | null {
    const company = this.users.find((user) => user.id === userId)?.company;
    return typeof company?.id === 'string' ? company.id : null;
  }

  workerOf(userId: string): (Profile & { id: string }) | null {
    const worker = this.users.find((user) => user.id === userId)?.worker;
    return typeof worker?.id === 'string' ? (worker as Profile & { id: string }) : null;
  }

  // Sens inverse de companyIdOf : sert au contrôle de propriété d'une mission.
  userIdOfCompany(companyId: string): string | null {
    return this.users.find((user) => user.company?.id === companyId)?.id ?? null;
  }

  // Ajouté avec les candidatures : le service en a besoin pour retrouver l'intérimaire
  // depuis son identifiant de profil.
  workerById(workerId: string): (Profile & { id: string }) | null {
    const worker = this.users.find((user) => user.worker?.id === workerId)?.worker;
    return typeof worker?.id === 'string' ? (worker as Profile & { id: string }) : null;
  }

  // Ajoutés avec les contrats : le générateur identifie l'entreprise utilisatrice par son
  // SIRET, et l'intérimaire retenu par le compte auquel son profil est rattaché.
  companySiretOf(companyId: string): string | null {
    return this.users.find((user) => user.company?.id === companyId)?.company?.siret ?? null;
  }

  userIdOfWorker(workerId: string): string {
    return this.users.find((user) => user.worker?.id === workerId)?.id ?? '';
  }

  companyLegalNameOf(companyId: string): string | null {
    const company = this.users.find((user) => user.company?.id === companyId)?.company;
    return typeof company?.legalName === 'string' ? company.legalName : null;
  }

  // Ajouté avec la page Paramètres entreprise : profil complet et mise à jour, sur le même
  // principe que workerOf/workerById pour l'intérimaire.
  companyOf(userId: string): (Profile & { siret: string }) | null {
    return this.users.find((user) => user.id === userId)?.company ?? null;
  }

  updateCompanyProfile(userId: string, data: Profile): (Profile & { siret: string }) | null {
    const company = this.users.find((user) => user.id === userId)?.company;
    if (!company) {
      return null;
    }
    Object.assign(company, data);
    return company;
  }

  // Les trois suivants servent aux notifications n8n (mission pourvue, nouveau match) :
  // elles ont besoin de l'email du compte, porté par User, pas par le profil Company/Worker.
  emailOf(userId: string): string | null {
    return this.users.find((user) => user.id === userId)?.email ?? null;
  }

  companyEmailOf(companyId: string): string | null {
    return this.users.find((user) => user.company?.id === companyId)?.email ?? null;
  }

  // Recherche par identifiant du profil intérimaire (et non du compte) : c'est ce que reçoit
  // une mission une fois l'intérimaire retenu (Mission.assignedWorkerId).
  workerRecordById(workerId: string): (Profile & { id: string; email: string }) | null {
    const user = this.users.find((candidate) => candidate.worker?.id === workerId);
    if (!user?.worker) {
      return null;
    }
    return { ...user.worker, email: user.email } as Profile & { id: string; email: string };
  }
}

export function uniqueViolation(field: string): Prisma.PrismaClientKnownRequestError {
  return new Prisma.PrismaClientKnownRequestError('Unique constraint failed', {
    code: 'P2002',
    clientVersion: Prisma.prismaVersion.client,
    meta: { target: [field] },
  });
}
