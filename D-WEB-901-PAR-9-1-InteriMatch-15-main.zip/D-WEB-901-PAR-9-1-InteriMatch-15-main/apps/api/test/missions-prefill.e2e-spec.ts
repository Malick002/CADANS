import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import {
  FranceTravailClient,
  OffreFranceTravailError,
  RaisonEchecOffre,
} from '../src/referentiel/france-travail.client';
import { OffreEmploi } from '../src/referentiel/offre-emploi';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryMissions } from './in-memory-missions';
import { InMemoryReferentiel } from './in-memory-referentiel';
import { InMemoryUsers } from './in-memory-users';

// Parcours complet « préremplir une mission depuis une offre France Travail », de la requête
// HTTP à la mission enregistrée.
//
// AUCUN APPEL RÉSEAU : le client France Travail est remplacé par une doublure dont on pilote
// la réponse. Les codes HTTP réels de l'API (204, 400, 429) sont vérifiés, eux aussi sans
// réseau, dans france-travail.client.spec.ts, sur des réponses simulées relevées le
// 23/09/2026 contre le service réel.

const company = {
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

const worker = {
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  acceptConditions: true,
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '69007',
  city: 'Lyon',
};

// Offre réelle relevée le 23/09/2026 (GET /offres/214GWTK), réduite aux champs lus. La
// description porte volontairement un courriel, un téléphone et une URL.
const OFFRE: OffreEmploi = {
  id: '214GWTK',
  intitule: 'Cariste (H/F)',
  description:
    'Votre agence recrute un cariste pour le secteur de Sarrebourg.\n\n' +
    'Vous êtes titulaire des caces 1-3-5 ?\n\n' +
    'Postulez sur https://job.exemple.com/offre/0fe8, par mail à recrute@agence.fr, ' +
    'ou appelez le 03 87 23 45 67.',
  romeCode: 'N1101',
  appellationlibelle: 'Cariste secteur industrie',
  lieuTravail: { libelle: '57 - Sarrebourg', codePostal: '57400' },
  salaire: { libelle: 'Horaire de 13.0 Euros à 13.0 Euros' },
  dureeTravailLibelle: '38H/semaine\nTravail posté (2x8, 3x8, 5x8, etc.)',
};

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

describe('Préremplissage d’une mission depuis une offre France Travail (e2e)', () => {
  let app: INestApplication;
  let entreprise: string;
  let interimaire: string;

  // Pilotage de la doublure : `configured` masque l'entrée à l'écran, `echec` rejoue chacune
  // des trois pannes.
  let configured = true;
  let echec: RaisonEchecOffre | null = null;

  beforeAll(async () => {
    const users = new InMemoryUsers();
    const missions = new InMemoryMissions(users);
    const referentiel = new InMemoryReferentiel();

    const franceTravail = {
      get configured() {
        return configured;
      },
      offreEmploi: (reference: string): Promise<OffreEmploi> => {
        if (echec) {
          return Promise.reject(new OffreFranceTravailError(echec, `simulé : ${echec}`));
        }
        return Promise.resolve({ ...OFFRE, id: reference });
      },
    };

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        company: missions.company,
        // Le préremplissage lit les postes par ReferentielService (poste.findMany), la
        // création les vérifie par MissionsService (poste.findFirst) : les deux doublures
        // partagent les mêmes fixtures.
        poste: { ...missions.poste, ...referentiel.poste },
        romeCompetence: referentiel.romeCompetence,
        competence: missions.competence,
        worker: missions.worker,
        mission: missions.mission,
        contract: missions.contract,
      })
      .overrideProvider(FranceTravailClient)
      .useValue(franceTravail)
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    entreprise = cookieOf(await request(server).post('/auth/register/company').send(company));
    interimaire = cookieOf(await request(server).post('/auth/register/worker').send(worker));
  });

  beforeEach(() => {
    configured = true;
    echec = null;
  });

  afterAll(async () => {
    await app.close();
  });

  describe('GET /missions/prefill/disponibilite', () => {
    it('est publique : l’écran de création la lit sans session', async () => {
      await request(app.getHttpServer())
        .get('/missions/prefill/disponibilite')
        .expect(200, { disponible: true });
    });

    it('annonce l’indisponibilité quand les identifiants France Travail manquent', async () => {
      configured = false;
      await request(app.getHttpServer())
        .get('/missions/prefill/disponibilite')
        .expect(200, { disponible: false });
    });
  });

  describe('POST /missions/prefill', () => {
    it('refuse sans session, et à un compte intérimaire', async () => {
      await request(app.getHttpServer())
        .post('/missions/prefill')
        .send({ source: '214GWTK' })
        .expect(401);
      await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', interimaire)
        .send({ source: '214GWTK' })
        .expect(403);
    });

    it('préremplit depuis l’URL de la fiche publique', async () => {
      const response = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: 'https://candidat.francetravail.fr/offres/recherche/detail/214GWTK' })
        .expect(201);

      expect(response.body).toMatchObject({
        reference: '214GWTK',
        intituleOffre: 'Cariste (H/F)',
        urlOffre: 'https://candidat.francetravail.fr/offres/recherche/detail/214GWTK',
        valeurs: {
          // « Cariste secteur industrie » n'est pas exposée : repli sur l'appellation
          // principale de N1101.
          posteCode: '11679',
          siteLabel: '57 - Sarrebourg',
          postalCode: '57400',
          hourlyRate: '13.00',
        },
      });
    });

    // Le cœur de la consigne : ce qui n'est pas dans l'offre n'est pas inventé. L'écran le
    // dit à l'entreprise, encore faut-il que l'API ne remplisse pas ces champs en douce.
    it('ne préremplit ni les dates, ni le motif de recours, ni le créneau d’un 3x8', async () => {
      const response = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: '214GWTK' })
        .expect(201);

      expect(response.body.valeurs.startDate).toBeUndefined();
      expect(response.body.valeurs.endDate).toBeUndefined();
      expect(response.body.valeurs.motifRecours).toBeUndefined();
      expect(response.body.valeurs.shift).toBeUndefined();
    });

    // Une offre sur huit exprime son salaire au mois ou à l'année (mesuré sur 450 offres).
    // Le champ est rempli par conversion, et la réponse porte de quoi le DIRE à l'écran.
    it('convertit un salaire mensuel et annonce que le taux est estimé', async () => {
      const precedent = OFFRE.salaire;
      Object.assign(OFFRE, { salaire: { libelle: 'Mensuel de 2206.0 Euros à 2500.0 Euros' } });

      const response = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: '214GWTK' })
        .expect(201);

      // L'offre de référence porte « 38H/semaine » : 2206 ÷ (38 × 52 ÷ 12) = 13,40 €.
      // Convertie sur 35 h, elle aurait donné 14,55 € — 8 % de trop, sur un taux qui finit
      // au contrat de mission.
      expect(response.body.valeurs.hourlyRate).toBe('13.40');
      expect(response.body.remuneration).toEqual({
        libelle: 'Mensuel de 2206.0 Euros à 2500.0 Euros',
        estimation: {
          taux: '13.40',
          periode: 'mensuel',
          montant: 2206,
          fourchette: true,
          heuresHebdo: 38,
          dureeLue: true,
        },
      });

      Object.assign(OFFRE, { salaire: precedent });
    });

    it('retombe sur 35 h quand l’offre ne porte pas de durée exploitable', async () => {
      const precedents = { salaire: OFFRE.salaire, duree: OFFRE.dureeTravailLibelle };
      Object.assign(OFFRE, {
        salaire: { libelle: 'Mensuel de 2206.0 Euros' },
        dureeTravailLibelle: 'Travail en journée',
      });

      const response = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: '214GWTK' })
        .expect(201);

      expect(response.body.remuneration.estimation).toMatchObject({
        taux: '14.55',
        heuresHebdo: 35,
        dureeLue: false,
      });

      Object.assign(OFFRE, {
        salaire: precedents.salaire,
        dureeTravailLibelle: precedents.duree,
      });
    });

    it('laisse le champ vide et transmet le libellé brut sur un format inconnu', async () => {
      const precedent = OFFRE.salaire;
      Object.assign(OFFRE, { salaire: { libelle: 'Selon profil' } });

      const response = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: '214GWTK' })
        .expect(201);

      expect(response.body.valeurs.hourlyRate).toBeUndefined();
      expect(response.body.remuneration).toEqual({ libelle: 'Selon profil' });

      Object.assign(OFFRE, { salaire: precedent });
    });

    // Un taux estimé reste un taux que l'API doit accepter : s'il ne passait pas la
    // validation du DTO, l'entreprise verrait son formulaire refusé sur un champ prérempli.
    it('propose un taux que la création de mission accepte', async () => {
      const precedent = OFFRE.salaire;
      Object.assign(OFFRE, { salaire: { libelle: 'Annuel de 22405.0 Euros' } });

      const prefill = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: '214GWTK' })
        .expect(201);

      await request(app.getHttpServer())
        .post('/missions')
        .set('Cookie', entreprise)
        .send({
          ...prefill.body.valeurs,
          startDate: '2026-10-05',
          endDate: '2026-11-05',
          shift: 'MATIN',
          motifRecours: 'ACCROISSEMENT_TEMPORAIRE',
          hourlyRate: Number(prefill.body.valeurs.hourlyRate),
          sourceOffreId: prefill.body.reference,
        })
        .expect(201);

      Object.assign(OFFRE, { salaire: precedent });
    });

    it('rend une description débarrassée du courriel, du téléphone et de l’URL', async () => {
      const response = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: '214GWTK' })
        .expect(201);

      const { description } = response.body.valeurs;
      expect(description).not.toMatch(/@/);
      expect(description).not.toMatch(/https?:\/\//);
      expect(description).not.toMatch(/03[\s.]?87/);
      // Le texte utile survit, y compris sa ponctuation française.
      expect(description).toContain('Vous êtes titulaire des caces 1-3-5 ?');
    });

    it('refuse une saisie qui ne contient pas d’identifiant d’offre', async () => {
      const response = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: 'https://exemple.fr/une-annonce' })
        .expect(400);

      expect(String(response.body.message)).toContain('214GWTK');
    });

    // Les trois pannes. Chacune doit rendre un message que l'écran affiche tel quel, et qui
    // renvoie au formulaire vierge : jamais d'écran cassé, jamais de trace technique.
    it.each([
      ['une offre expirée (204 chez France Travail)', 'introuvable' as const, 404],
      ['le quota atteint (429)', 'quota' as const, 429],
      ['l’API indisponible', 'indisponible' as const, 503],
    ])('gère %s sans bloquer l’entreprise', async (_cas, raison, statut) => {
      echec = raison;

      const response = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: '214GWTK' })
        .expect(statut);

      const message = String(response.body.message);
      expect(message).toMatch(/formulaire|Réessayez/);
      // Rien de technique ne remonte à l'écran.
      expect(message).not.toMatch(/simulé|Error|undefined/);
    });

    it('répond 503 quand les identifiants France Travail ne sont pas configurés', async () => {
      configured = false;

      await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: '214GWTK' })
        .expect(503);
    });
  });

  describe('la mission publiée ensuite', () => {
    const complement = {
      startDate: '2026-10-05',
      endDate: '2026-11-05',
      shift: 'MATIN',
      motifRecours: 'ACCROISSEMENT_TEMPORAIRE',
    };

    it('conserve la référence de l’offre, et rien d’autre de celle-ci', async () => {
      const prefill = await request(app.getHttpServer())
        .post('/missions/prefill')
        .set('Cookie', entreprise)
        .send({ source: '214GWTK' })
        .expect(201);

      const created = await request(app.getHttpServer())
        .post('/missions')
        .set('Cookie', entreprise)
        .send({
          ...prefill.body.valeurs,
          ...complement,
          hourlyRate: Number(prefill.body.valeurs.hourlyRate),
          sourceOffreId: prefill.body.reference,
        })
        .expect(201);

      expect(created.body.sourceOffreId).toBe('214GWTK');
      expect(created.body.siteLabel).toBe('57 - Sarrebourg');
      // Ce qui n'est PAS stocké : aucune coordonnée, ni de l'offre ni de son recruteur. Le
      // texte de l'annonce, lui, est conservé tel que l'entreprise l'a validé — caviarder des
      // données personnelles n'est pas réécrire la prose, et l'écran affiche l'étiquette
      // « texte repris de l'offre France Travail, à relire et adapter ».
      const enregistre = JSON.stringify(created.body);
      expect(enregistre).not.toMatch(/@/);
      expect(enregistre).not.toMatch(/https?:\/\//);
      expect(enregistre).not.toMatch(/\d{2}[\s.-]\d{2}[\s.-]\d{2}[\s.-]\d{2}/);
    });

    it('refuse une référence d’offre qui n’en est pas une', async () => {
      await request(app.getHttpServer())
        .post('/missions')
        .set('Cookie', entreprise)
        .send({
          posteCode: '11679',
          siteLabel: 'LogiNord',
          postalCode: '95700',
          ...complement,
          hourlyRate: 13.5,
          sourceOffreId: 'pas-une-reference',
        })
        .expect(400);
    });

    // Une mission saisie à la main n'a pas de provenance : la colonne doit rester nulle,
    // et surtout pas prendre une valeur par défaut qui ferait croire à une origine.
    it('laisse la référence nulle pour une mission saisie au formulaire vierge', async () => {
      const created = await request(app.getHttpServer())
        .post('/missions')
        .set('Cookie', entreprise)
        .send({
          posteCode: '11679',
          siteLabel: 'LogiNord - Roissy (95)',
          postalCode: '95700',
          ...complement,
          hourlyRate: 13.5,
        })
        .expect(201);

      expect(created.body.sourceOffreId).toBeNull();
    });
  });
});
