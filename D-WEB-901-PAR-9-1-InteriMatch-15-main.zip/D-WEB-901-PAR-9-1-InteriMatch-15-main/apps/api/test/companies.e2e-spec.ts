import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryUsers } from './in-memory-users';

const worker = {
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  acceptConditions: true,
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '69007',
  city: 'Lyon',
};

const company = {
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

describe('Paramètres entreprise (e2e)', () => {
  let app: INestApplication;
  let users: InMemoryUsers;
  let entreprise: string;
  let interimaire: string;

  beforeAll(async () => {
    users = new InMemoryUsers();

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        company: {
          findUnique: ({ where }: { where: { userId: string } }) =>
            Promise.resolve(users.companyOf(where.userId)),
          update: ({ where, data }: { where: { id: string }; data: Record<string, unknown> }) => {
            const userId = users.userIdOfCompany(where.id)!;
            return Promise.resolve(users.updateCompanyProfile(userId, data));
          },
        },
      })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    entreprise = cookieOf(await request(server).post('/auth/register/company').send(company));
    interimaire = cookieOf(await request(server).post('/auth/register/worker').send(worker));
  });

  afterAll(async () => {
    await app.close();
  });

  it('refuse sans session', async () => {
    await request(app.getHttpServer()).get('/companies/me').expect(401);
  });

  it('refuse un compte intérimaire', async () => {
    await request(app.getHttpServer()).get('/companies/me').set('Cookie', interimaire).expect(403);
  });

  it("renvoie le profil de l'entreprise connectée", async () => {
    const response = await request(app.getHttpServer())
      .get('/companies/me')
      .set('Cookie', entreprise)
      .expect(200);

    expect(response.body).toMatchObject({ legalName: 'Entrepôt du Nord', siret: '73282932000074' });
  });

  it('met à jour les coordonnées et les relit', async () => {
    await request(app.getHttpServer())
      .put('/companies/me')
      .set('Cookie', entreprise)
      .send({
        legalName: 'Entrepôt du Nord (renommé)',
        contactFirstName: 'Nadia',
        contactLastName: 'Benali',
        phone: '0612345678',
        addressLine: '14 rue des Docks',
        postalCode: '59000',
        city: 'Lille',
      })
      .expect(200);

    const response = await request(app.getHttpServer())
      .get('/companies/me')
      .set('Cookie', entreprise)
      .expect(200);

    expect(response.body).toMatchObject({
      legalName: 'Entrepôt du Nord (renommé)',
      addressLine: '14 rue des Docks',
      siret: '73282932000074',
      nafCode: '52.10B',
    });
  });

  it('refuse une mise à jour invalide (code postal incorrect)', async () => {
    await request(app.getHttpServer())
      .put('/companies/me')
      .set('Cookie', entreprise)
      .send({
        legalName: 'Entrepôt du Nord',
        contactFirstName: 'Nadia',
        contactLastName: 'Benali',
        addressLine: '12 rue des Docks',
        postalCode: '123',
        city: 'Lille',
      })
      .expect(400);
  });
});
