// Variables nécessaires au démarrage de l'API pendant les tests fonctionnels.
// Si la variable manque, on en pose une factice. Si elle est déjà définie (.env en local,
// .github/workflows/ci.yml en CI), elle est conservée : elle doit alors respecter les
// contraintes de l'API (JWT_SECRET d'au moins 32 caractères).
process.env.JWT_SECRET ??= 'secret-factice-reserve-aux-tests-e2e';
// Clé AES-256 factice (32 octets en base64), réservée aux tests.
process.env.ENCRYPTION_KEY ??= Buffer.alloc(32, 7).toString('base64');
