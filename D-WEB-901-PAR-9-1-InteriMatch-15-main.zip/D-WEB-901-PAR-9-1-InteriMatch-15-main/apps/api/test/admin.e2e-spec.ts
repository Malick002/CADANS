import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PasswordService } from '../src/auth/password.service';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemorySensitiveDocuments } from './in-memory-documents';
import { InMemoryUsers } from './in-memory-users';

const PDF = Buffer.from('%PDF-1.7\nScan de la carte CACES R489 catégorie 3\n%%EOF');

// Compteurs figés pour le tableau de bord : des nombres distincts les uns des autres, pour
// qu'une inversion entre deux champs se voie immédiatement.
const NB_MISSIONS_OUVERTES = 7;
const NB_MISSIONS_POURVUES = 2;
const NB_CONTRATS_A_SIGNER = 4;
const NB_INTERIMAIRES = 12;
const NB_ENTREPRISES = 5;
const MOT_DE_PASSE = 'Preparateur!42x';

const worker = {
  acceptConditions: true,
  email: 'leila@example.fr',
  password: MOT_DE_PASSE,
  firstName: 'Leïla',
  lastName: 'Moreau',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

const company = {
  acceptConditions: true,
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

const binary = (
  response: request.Response,
  callback: (err: Error | null, body: Buffer) => void,
) => {
  const chunks: Buffer[] = [];
  response.on('data', (chunk: Buffer) => chunks.push(chunk));
  response.on('end', () => callback(null, Buffer.concat(chunks)));
};

describe('Espace agent CADANS (e2e)', () => {
  let app: INestApplication;
  let storage: InMemorySensitiveDocuments;
  let interimaire: string;
  let entreprise: string;
  let agent: string;
  let certificationId: string;

  beforeAll(async () => {
    const users = new InMemoryUsers();
    storage = new InMemorySensitiveDocuments(users);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        // Le tableau de bord compte les intérimaires ; la doublure des documents ne fournit
        // qu'un `findUnique`. Les deux cohabitent sans se marcher dessus.
        worker: { ...storage.worker, count: () => Promise.resolve(NB_INTERIMAIRES) },
        identityDocument: storage.identityDocument,
        certification: storage.certification,
        certificationDecision: storage.certificationDecision,
        $transaction: storage.$transaction,
        // Missions et contrats n'ont pas d'écran agent : seuls leurs compteurs sont lus ici,
        // des constantes suffisent. Les deux appels à mission.count sont distingués par leur
        // filtre, comme le service les émet.
        mission: {
          count: ({ where }: { where: { status: string } }) =>
            Promise.resolve(
              where.status === 'OUVERTE' ? NB_MISSIONS_OUVERTES : NB_MISSIONS_POURVUES,
            ),
        },
        contract: { count: () => Promise.resolve(NB_CONTRATS_A_SIGNER) },
        company: { count: () => Promise.resolve(NB_ENTREPRISES) },
      })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    interimaire = cookieOf(await request(server).post('/auth/register/worker').send(worker));
    entreprise = cookieOf(await request(server).post('/auth/register/company').send(company));

    // Le compte agent est posé directement : aucune route publique ne permet de le créer.
    users.addAdmin('admin@cadans.fr', await app.get(PasswordService).hash(MOT_DE_PASSE));
    agent = cookieOf(
      await request(server)
        .post('/auth/login')
        .send({ email: 'admin@cadans.fr', password: MOT_DE_PASSE }),
    );

    // L'intérimaire dépose un justificatif : c'est ce dépôt qui alimente la file d'attente.
    await request(server)
      .put('/workers/me/certifications/CACES_R489_3')
      .set('Cookie', interimaire)
      .field('expiresAt', '2029-03-10')
      .attach('file', PDF, { filename: 'caces.pdf', contentType: 'application/pdf' })
      .expect(200);

    certificationId = storage.certificationRows[0].id;
  });

  afterAll(async () => {
    await app.close();
  });

  // Le cœur de la demande : personne d'autre qu'un agent CADANS n'entre ici.
  describe('permissions', () => {
    const routes = [
      ['get', '/admin/justificatifs'],
      ['get', '/admin/justificatifs/00000000-0000-4000-8000-000000000000/document'],
      ['post', '/admin/justificatifs/00000000-0000-4000-8000-000000000000/valider'],
      ['post', '/admin/justificatifs/00000000-0000-4000-8000-000000000000/refuser'],
    ] as const;

    it.each(routes)('refuse (403) %s %s à un intérimaire', async (methode, route) => {
      await request(app.getHttpServer())[methode](route).set('Cookie', interimaire).expect(403);
    });

    it.each(routes)('refuse (403) %s %s à une entreprise', async (methode, route) => {
      await request(app.getHttpServer())[methode](route).set('Cookie', entreprise).expect(403);
    });

    // 401 et non 403 : sans session, l'utilisateur n'a pas encore de rôle à comparer.
    it.each(routes)('refuse (401) %s %s sans session', async (methode, route) => {
      await request(app.getHttpServer())[methode](route).expect(401);
    });
  });

  describe("file d'attente", () => {
    it('remonte le justificatif déposé, avec le nom de l’intérimaire', async () => {
      const response = await request(app.getHttpServer())
        .get('/admin/justificatifs')
        .set('Cookie', agent)
        .expect(200);

      expect(response.body).toHaveLength(1);
      expect(response.body[0]).toMatchObject({
        type: 'CACES_R489_3',
        verificationStatus: 'EN_ATTENTE',
        interimaire: { prenom: 'Leïla', nom: 'Moreau', ville: 'Roissy-en-France' },
      });
    });

    // L'agent vérifie une pièce professionnelle : il lui faut un nom, pas un moyen de
    // contacter la personne en direct.
    it('ne divulgue ni l’email ni le document chiffré', async () => {
      const response = await request(app.getHttpServer())
        .get('/admin/justificatifs')
        .set('Cookie', agent)
        .expect(200);

      const serialise = JSON.stringify(response.body);
      expect(serialise).not.toContain(worker.email);
      expect(serialise).not.toContain('documentEncrypted');
    });
  });

  describe('consultation du document', () => {
    it('rend le PDF déchiffré à l’agent, sans mise en cache et sans reniflage de type', async () => {
      const response = await request(app.getHttpServer())
        .get(`/admin/justificatifs/${certificationId}/document`)
        .set('Cookie', agent)
        .buffer()
        .parse(binary)
        .expect(200);

      expect(response.headers['content-type']).toContain('application/pdf');
      expect(response.headers['cache-control']).toBe('no-store');
      expect(response.headers['x-content-type-options']).toBe('nosniff');
      expect(response.body.equals(PDF)).toBe(true);
    });

    // Ce qui est écrit en base n'est jamais le document en clair.
    it('stocke le justificatif chiffré', () => {
      const stocke = Buffer.from(storage.certificationRows[0].documentEncrypted as Uint8Array);

      expect(stocke.includes(PDF)).toBe(false);
      expect(stocke.length).toBeGreaterThan(PDF.length);
    });
  });

  describe('décision', () => {
    it('refuse un refus dont le motif est trop court pour être utile', async () => {
      await request(app.getHttpServer())
        .post(`/admin/justificatifs/${certificationId}/refuser`)
        .set('Cookie', agent)
        .send({ motif: 'non' })
        .expect(400);
    });

    it('refuse un refus sans motif du tout', async () => {
      await request(app.getHttpServer())
        .post(`/admin/justificatifs/${certificationId}/refuser`)
        .set('Cookie', agent)
        .send({})
        .expect(400);
    });

    it('enregistre le refus et son motif, que l’intérimaire lit sur son profil', async () => {
      await request(app.getHttpServer())
        .post(`/admin/justificatifs/${certificationId}/refuser`)
        .set('Cookie', agent)
        .send({ motif: 'Le scan est illisible, merci de redéposer une photo nette du recto.' })
        .expect(201);

      const profil = await request(app.getHttpServer())
        .get('/workers/me/certifications')
        .set('Cookie', interimaire)
        .expect(200);

      expect(profil.body[0]).toMatchObject({
        verificationStatus: 'REFUSE',
        refusalMotif: 'Le scan est illisible, merci de redéposer une photo nette du recto.',
      });
    });

    // Redéposer un fichier après un refus doit remettre le compteur à zéro : le document
    // refusé n'est plus celui qui est en base.
    it('repasse en attente quand l’intérimaire redépose un justificatif', async () => {
      await request(app.getHttpServer())
        .put('/workers/me/certifications/CACES_R489_3')
        .set('Cookie', interimaire)
        .field('expiresAt', '2029-03-10')
        .attach('file', PDF, { filename: 'caces-2.pdf', contentType: 'application/pdf' })
        .expect(200);

      const profil = await request(app.getHttpServer())
        .get('/workers/me/certifications')
        .set('Cookie', interimaire)
        .expect(200);

      expect(profil.body[0]).toMatchObject({
        verificationStatus: 'EN_ATTENTE',
        refusalMotif: null,
      });
    });

    it('valide et efface le motif de refus antérieur', async () => {
      const response = await request(app.getHttpServer())
        .post(`/admin/justificatifs/${certificationId}/valider`)
        .set('Cookie', agent)
        .expect(201);

      expect(response.body).toMatchObject({
        verificationStatus: 'VERIFIE',
        refusalMotif: null,
      });
    });

    it('refuse de décider sur une habilitation inconnue', async () => {
      await request(app.getHttpServer())
        .post('/admin/justificatifs/00000000-0000-4000-8000-000000000000/valider')
        .set('Cookie', agent)
        .expect(404);
    });
  });

  describe('GET /admin/tableau-de-bord', () => {
    // Ce bloc s'exécute APRÈS ceux qui valident et refusent : la file est alors vide. Il
    // redépose donc son propre justificatif plutôt que de dépendre de l'ordre des tests —
    // une dépendance d'ordre est ce qui rend une suite fragile.
    beforeAll(async () => {
      await request(app.getHttpServer())
        .put('/workers/me/certifications/CACES_R489_5')
        .set('Cookie', interimaire)
        .field('expiresAt', '2029-06-30')
        .attach('file', PDF, { filename: 'caces-5.pdf', contentType: 'application/pdf' })
        .expect(200);
    });

    it('refuse sans session', async () => {
      await request(app.getHttpServer()).get('/admin/tableau-de-bord').expect(401);
    });

    // 403 et non 404 : l'existence de l'espace d'administration n'est pas un secret, seul
    // son contenu l'est. Même règle que les autres routes de ce contrôleur.
    it.each([
      ['un intérimaire', () => interimaire],
      ['une entreprise', () => entreprise],
    ])('refuse %s avec 403', async (_cas, cookie) => {
      await request(app.getHttpServer())
        .get('/admin/tableau-de-bord')
        .set('Cookie', cookie())
        .expect(403);
    });

    it('rend les six compteurs à un agent CADANS', async () => {
      const response = await request(app.getHttpServer())
        .get('/admin/tableau-de-bord')
        .set('Cookie', agent)
        .expect(200);

      expect(response.body.compteurs).toEqual({
        justificatifsEnAttente: expect.any(Number),
        missionsOuvertes: NB_MISSIONS_OUVERTES,
        missionsPourvues: NB_MISSIONS_POURVUES,
        contratsASigner: NB_CONTRATS_A_SIGNER,
        interimaires: NB_INTERIMAIRES,
        entreprises: NB_ENTREPRISES,
      });
    });

    it('compte le justificatif réellement déposé dans ce test', async () => {
      const response = await request(app.getHttpServer())
        .get('/admin/tableau-de-bord')
        .set('Cookie', agent)
        .expect(200);

      expect(response.body.compteurs.justificatifsEnAttente).toBeGreaterThanOrEqual(1);
      expect(response.body.derniersJustificatifs.length).toBeGreaterThanOrEqual(1);
    });

    // La minimisation se vérifie sur ce qui sort du serveur, pas seulement sur le `select` :
    // le tableau de bord ne doit porter ni ville, ni statut, ni motif de refus.
    it('ne rend d’une ligne que le document, la personne et la date', async () => {
      const response = await request(app.getHttpServer())
        .get('/admin/tableau-de-bord')
        .set('Cookie', agent)
        .expect(200);

      const [ligne] = response.body.derniersJustificatifs;
      expect(Object.keys(ligne).sort()).toEqual([
        'certificationId',
        'deposeLe',
        'interimaire',
        'type',
      ]);
      expect(Object.keys(ligne.interimaire).sort()).toEqual(['nom', 'prenom']);
    });

    it('n’en rend jamais plus de cinq', async () => {
      const response = await request(app.getHttpServer())
        .get('/admin/tableau-de-bord')
        .set('Cookie', agent)
        .expect(200);

      expect(response.body.derniersJustificatifs.length).toBeLessThanOrEqual(5);
    });
  });

  // Le point 2 : revoir une décision à tout moment, et garder la trace de chacune.
  describe('historique et filtres', () => {
    let cible: string;

    beforeAll(async () => {
      const server = app.getHttpServer();
      await request(server)
        .put('/workers/me/certifications/CACES_R485_1')
        .set('Cookie', interimaire)
        .field('expiresAt', '2030-01-31')
        .attach('file', PDF, { filename: 'r485.pdf', contentType: 'application/pdf' })
        .expect(200);

      const file = await request(server)
        .get('/admin/justificatifs?statut=EN_ATTENTE')
        .set('Cookie', agent)
        .expect(200);
      cible = file.body.find((j: { type: string }) => j.type === 'CACES_R485_1').certificationId;
    });

    it('refuse les filtres aux autres rôles', async () => {
      for (const cookie of [interimaire, entreprise]) {
        await request(app.getHttpServer())
          .get('/admin/justificatifs?statut=TOUS')
          .set('Cookie', cookie)
          .expect(403);
      }
    });

    // Un filtre inconnu ne doit pas casser l'écran : on retombe sur la file d'attente.
    it('ignore un filtre inconnu plutôt que de répondre en erreur', async () => {
      await request(app.getHttpServer())
        .get('/admin/justificatifs?statut=NIMPORTEQUOI')
        .set('Cookie', agent)
        .expect(200);
    });

    it('empile une ligne d’historique à chaque décision, motif compris', async () => {
      const server = app.getHttpServer();

      await request(server)
        .post(`/admin/justificatifs/${cible}/refuser`)
        .set('Cookie', agent)
        .send({ motif: 'Scan illisible' })
        .expect(201);
      const apresValidation = await request(server)
        .post(`/admin/justificatifs/${cible}/valider`)
        .set('Cookie', agent)
        .expect(201);

      // Du plus récent au plus ancien : c'est l'ordre dans lequel on lit « ce qui s'est passé ».
      expect(apresValidation.body.decisions).toHaveLength(2);
      expect(apresValidation.body.decisions[0]).toMatchObject({
        decision: 'VERIFIE',
        motif: null,
      });
      expect(apresValidation.body.decisions[1]).toMatchObject({
        decision: 'REFUSE',
        motif: 'Scan illisible',
      });
      // Le motif reste dans SA ligne alors que la certification, elle, n'en porte plus.
      expect(apresValidation.body.refusalMotif).toBeNull();
      expect(apresValidation.body.decisions[0].agent).toContain('@');
    });

    // La décision est modifiable à tout moment : l'API n'a jamais vérifié l'état de départ,
    // et un agent doit pouvoir revenir sur un refus.
    it('accepte une décision sur une habilitation déjà tranchée', async () => {
      const response = await request(app.getHttpServer())
        .post(`/admin/justificatifs/${cible}/refuser`)
        .set('Cookie', agent)
        .send({ motif: 'Finalement non conforme' })
        .expect(201);

      expect(response.body.verificationStatus).toBe('REFUSE');
      expect(response.body.decisions).toHaveLength(3);
    });

    it('retrouve l’habilitation sous son statut, et sous « Tous »', async () => {
      const server = app.getHttpServer();

      const refuses = await request(server)
        .get('/admin/justificatifs?statut=REFUSE')
        .set('Cookie', agent)
        .expect(200);
      expect(refuses.body.map((j: { certificationId: string }) => j.certificationId)).toContain(
        cible,
      );

      const tous = await request(server)
        .get('/admin/justificatifs?statut=TOUS')
        .set('Cookie', agent)
        .expect(200);
      expect(tous.body.length).toBeGreaterThanOrEqual(refuses.body.length);
    });

    /**
     * LE cas qui motivait ce filtre, dans sa forme RÉELLE.
     *
     * Une habilitation déclarée SANS justificatif existe bel et bien : `PUT` sans fichier la
     * crée en NON_VERIFIE, document nul. Elle compte déjà dans le matching, et n'apparaissait
     * sur AUCUN écran agent — la file exige une pièce à examiner.
     *
     * Le cas « vérifiée puis document supprimé » que l'on craignait, lui, ne se produit pas :
     * supprimer une habilitation supprime la ligne entière, pas seulement son document.
     */
    it('montre sous « Tous » une habilitation déclarée sans justificatif', async () => {
      const server = app.getHttpServer();

      await request(server)
        .put('/workers/me/certifications/CACES_R489_7')
        .set('Cookie', interimaire)
        .field('expiresAt', '2031-05-20')
        .expect(200);

      const tous = await request(server)
        .get('/admin/justificatifs?statut=TOUS')
        .set('Cookie', agent)
        .expect(200);
      const sansPiece = (tous.body as { type: string; documentPresent: boolean }[]).find(
        (j) => j.type === 'CACES_R489_7',
      );

      expect(sansPiece).toBeDefined();
      expect(sansPiece!.documentPresent).toBe(false);

      // Elle n'encombre pas pour autant le travail du jour.
      const file = await request(server)
        .get('/admin/justificatifs?statut=EN_ATTENTE')
        .set('Cookie', agent)
        .expect(200);
      expect((file.body as { type: string }[]).some((j) => j.type === 'CACES_R489_7')).toBe(false);
    });

    /**
     * TRAÇABILITÉ. L'habilitation disparaît de l'écran, mais le registre des décisions, lui,
     * SURVIT — `onDelete: SetNull`, pas `Cascade`.
     *
     * Sans cela, la personne contrôlée pouvait effacer la trace des contrôles en supprimant
     * son habilitation : un registre que l'audité peut vider ne vaut rien comme registre.
     */
    it('fait disparaître l’habilitation mais conserve le registre des décisions', async () => {
      const server = app.getHttpServer();

      const avant = storage.decisionRows.filter((ligne) => ligne.certificationId === cible).length;
      expect(avant).toBeGreaterThan(0);

      await request(server)
        .delete('/workers/me/certifications/CACES_R485_1')
        .set('Cookie', interimaire)
        .expect(204);

      const tous = await request(server)
        .get('/admin/justificatifs?statut=TOUS')
        .set('Cookie', agent)
        .expect(200);
      expect((tous.body as { type: string }[]).some((j) => j.type === 'CACES_R485_1')).toBe(false);

      // Les lignes sont toujours là, détachées de l'habilitation…
      const apres = storage.decisionRows.filter((ligne) => ligne.certificationId === null);
      expect(apres).toHaveLength(avant);
      // …et relisibles SEULES : sans ces deux colonnes, elles diraient « quelqu'un a refusé
      // quelque chose ».
      for (const ligne of apres) {
        expect(ligne.certificationType).toBe('CACES_R485_1');
        expect(typeof ligne.workerId).toBe('string');
        expect(ligne.decision).toBeDefined();
        expect(ligne.decidedAt).toBeInstanceOf(Date);
      }
    });
  });
});
