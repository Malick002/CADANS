import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { CertificationType, Shift } from '@prisma/client';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { MongoService } from '../src/mongo/mongo.service';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryUsers } from './in-memory-users';
import { InMemoryWorkerWorld } from './in-memory-worker-world';

const worker = {
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  acceptConditions: true,
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

const company = {
  email: 'contact@loginord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'LogiNord SAS',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

// Poste exposé « Cariste » (N1101) et sa compétence principale, fixés dans
// in-memory-referentiel.ts. Suggère CACES_R489_3.
const POSTE_CODE = '11679';
const COMPETENCE_CODE = '484039';

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

describe('Matching (e2e)', () => {
  let app: INestApplication;
  let world: InMemoryWorkerWorld;
  let interimaire: string;
  let companyId: string;

  beforeAll(async () => {
    const users = new InMemoryUsers();
    world = new InMemoryWorkerWorld(users);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        worker: world.worker,
        workerSkill: world.workerSkill,
        competence: world.competence,
        mission: world.mission,
        $transaction: world.$transaction,
      })
      .overrideProvider(MongoService)
      .useValue(world.mongo)
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    const registeredWorker = await request(server).post('/auth/register/worker').send(worker);
    interimaire = cookieOf(registeredWorker);
    const workerId = users.workerIdOf((registeredWorker.body as { id: string }).id)!;
    const registered = await request(server).post('/auth/register/company').send(company);
    companyId = users.companyIdOf((registered.body as { id: string }).id)!;

    // Profil : disponible sur toute la période, créneau matin, une compétence déclarée.
    await request(server)
      .put('/workers/me/profil-matching')
      .set('Cookie', interimaire)
      .send({
        shifts: ['MATIN'],
        competenceCodes: [COMPETENCE_CODE],
      })
      .expect(200);

    // CACES R489-3 en cours de validité : sans lui, le filtrage bloquant écarterait les
    // missions qui l'exigent et ces tests-ci ne mesureraient plus le scoring.
    world.addCertification(workerId, CertificationType.CACES_R489_3);
  });

  afterAll(async () => {
    await app.close();
  });

  it('refuse sans session', async () => {
    await request(app.getHttpServer()).get('/matches').expect(401);
  });

  it('refuse un compte entreprise', async () => {
    const entreprise = cookieOf(
      await request(app.getHttpServer())
        .post('/auth/register/company')
        .send({ ...company, email: 'autre@loginord.fr', siret: '39838393700131' }),
    );
    await request(app.getHttpServer()).get('/matches').set('Cookie', entreprise).expect(403);
  });

  it('classe une mission couverte devant une mission hors zone/compétences', async () => {
    world.addMission({
      companyId,
      posteCode: POSTE_CODE,
      siteLabel: 'LogiNord - Roissy (95)',
      postalCode: '95700',
      startDate: new Date('2026-09-18'),
      endDate: new Date('2026-09-22'),
      shift: Shift.MATIN,
      hourlyRate: 13.5,
      habilitations: [{ type: CertificationType.CACES_R489_3 }],
      competences: [{ competenceCode: COMPETENCE_CODE }],
    });
    world.addMission({
      companyId,
      posteCode: POSTE_CODE,
      siteLabel: 'LogiNord - Lyon',
      postalCode: '69007',
      startDate: new Date('2026-09-18'),
      endDate: new Date('2026-09-22'),
      shift: Shift.MATIN,
      hourlyRate: 12,
      habilitations: [],
      competences: [],
    });

    const response = await request(app.getHttpServer())
      .get('/matches')
      .set('Cookie', interimaire)
      .expect(200);

    expect(response.body.matches).toHaveLength(2);
    expect(response.body.matches[0]).toMatchObject({
      siteLabel: 'LogiNord - Roissy (95)',
      score: 100,
    });
    expect(response.body.masqueesFauteHabilitation).toEqual({ missions: 0, certifications: [] });
    expect(world.mongoInserts).toHaveLength(1);
    expect(world.mongoInserts[0]).toMatchObject({ missionsEvaluated: 2, matchesFound: 2 });
  });

  // Filtrage bloquant du CLAUDE.md : « un profil sans l'habilitation requise ne remonte
  // jamais ». La mission n'est pas renvoyée, seulement comptée, pour que l'écran puisse dire
  // à l'intérimaire ce que le CACES manquant lui coûte (docs/parcours-interimaire.md).
  it("écarte une mission dont l'habilitation obligatoire manque, et la compte", async () => {
    world.addMission({
      companyId,
      posteCode: POSTE_CODE,
      siteLabel: 'LogiNord - CACES manquant',
      postalCode: '95700',
      startDate: new Date('2026-09-18'),
      endDate: new Date('2026-09-22'),
      shift: Shift.MATIN,
      hourlyRate: 13.5,
      habilitations: [{ type: CertificationType.CACES_R489_5 }],
      competences: [],
    });

    const response = await request(app.getHttpServer())
      .get('/matches')
      .set('Cookie', interimaire)
      .expect(200);

    expect(
      response.body.matches.some(
        (m: { siteLabel: string }) => m.siteLabel === 'LogiNord - CACES manquant',
      ),
    ).toBe(false);
    expect(response.body.masqueesFauteHabilitation).toEqual({
      missions: 1,
      certifications: ['CACES_R489_5'],
    });
  });
});
