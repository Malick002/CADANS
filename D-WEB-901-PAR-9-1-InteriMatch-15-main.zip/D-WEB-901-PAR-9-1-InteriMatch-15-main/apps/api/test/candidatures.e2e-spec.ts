import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { CertificationType, Shift } from '@prisma/client';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { MongoService } from '../src/mongo/mongo.service';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryUsers } from './in-memory-users';
import { InMemoryWorkerWorld } from './in-memory-worker-world';

const worker = {
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  acceptConditions: true,
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

const company = {
  email: 'contact@loginord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'LogiNord SAS',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

const POSTE_CODE = '11679'; // « Cariste » (N1101), in-memory-referentiel.ts

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

describe('Candidatures (e2e)', () => {
  let app: INestApplication;
  let users: InMemoryUsers;
  let world: InMemoryWorkerWorld;
  let interimaire: string;
  let entreprise: string;
  let workerId: string;
  let missionId: string;
  let companyId: string;

  beforeAll(async () => {
    users = new InMemoryUsers();
    world = new InMemoryWorkerWorld(users);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        worker: world.worker,
        workerSkill: world.workerSkill,
        competence: world.competence,
        company: world.company,
        mission: world.mission,
        candidature: world.candidature,
        $transaction: world.$transaction,
      })
      .overrideProvider(MongoService)
      .useValue(world.mongo)
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    const registeredWorker = await request(server).post('/auth/register/worker').send(worker);
    interimaire = cookieOf(registeredWorker);
    workerId = users.workerIdOf((registeredWorker.body as { id: string }).id)!;

    const registeredCompany = await request(server).post('/auth/register/company').send(company);
    entreprise = cookieOf(registeredCompany);
    companyId = users.companyIdOf((registeredCompany.body as { id: string }).id)!;

    await request(server)
      .put('/workers/me/profil-matching')
      .set('Cookie', interimaire)
      .send({ shifts: ['MATIN'], competenceCodes: [] })
      .expect(200);

    missionId = world.addMission({
      companyId,
      posteCode: POSTE_CODE,
      siteLabel: 'LogiNord - Roissy (95)',
      postalCode: '95700',
      startDate: new Date('2026-09-18'),
      endDate: new Date('2026-09-22'),
      shift: Shift.MATIN,
      hourlyRate: 13.5,
      habilitations: [{ type: CertificationType.CACES_R489_3 }],
      competences: [],
    }).id;
  });

  afterAll(async () => {
    await app.close();
  });

  it('refuse une candidature sans session', async () => {
    await request(app.getHttpServer()).post(`/missions/${missionId}/candidatures`).expect(401);
  });

  it('refuse une candidature à un compte entreprise', async () => {
    await request(app.getHttpServer())
      .post(`/missions/${missionId}/candidatures`)
      .set('Cookie', entreprise)
      .expect(403);
  });

  it("refuse la candidature tant que l'habilitation exigée manque", async () => {
    await request(app.getHttpServer())
      .post(`/missions/${missionId}/candidatures`)
      .set('Cookie', interimaire)
      .expect(400);
  });

  it("accepte la candidature une fois l'habilitation ajoutée, et la retrouve dans « mes candidatures »", async () => {
    world.addCertification(workerId, CertificationType.CACES_R489_3);

    const created = await request(app.getHttpServer())
      .post(`/missions/${missionId}/candidatures`)
      .set('Cookie', interimaire)
      .expect(201);

    expect(created.body).toMatchObject({
      missionId,
      status: 'ENVOYEE',
      posteLabel: 'Cariste',
      companyName: 'LogiNord SAS',
    });

    const mine = await request(app.getHttpServer())
      .get('/workers/me/candidatures')
      .set('Cookie', interimaire)
      .expect(200);
    expect(mine.body).toHaveLength(1);
    expect(mine.body[0].missionId).toBe(missionId);
  });

  // Contrepartie du choix de garder la fiche d'une mission pourvue accessible (200) : la
  // protection se joue ici, pas en faisant disparaître la page. Remplace le test 404 de
  // version-khadija.
  it('refuse la candidature sur une mission qui n’est plus ouverte', async () => {
    const pourvueId = world.addMission({
      companyId,
      posteCode: POSTE_CODE,
      siteLabel: 'LogiNord - Lyon',
      postalCode: '69007',
      startDate: new Date('2026-09-18'),
      endDate: new Date('2026-09-22'),
      shift: Shift.MATIN,
      hourlyRate: 12,
      status: 'POURVUE',
      habilitations: [],
      competences: [],
    }).id;

    // La fiche, elle, reste servie.
    await request(app.getHttpServer()).get(`/missions/${pourvueId}`).expect(200);

    const refus = await request(app.getHttpServer())
      .post(`/missions/${pourvueId}/candidatures`)
      .set('Cookie', interimaire)
      .send({})
      .expect(409);

    expect(refus.body.message).toContain('n’est plus ouverte');
  });

  it('refuse une seconde candidature à la même mission', async () => {
    await request(app.getHttpServer())
      .post(`/missions/${missionId}/candidatures`)
      .set('Cookie', interimaire)
      .expect(409);
  });

  it("l'entreprise voit les candidatures reçues pour sa mission, avec le candidat", async () => {
    const response = await request(app.getHttpServer())
      .get(`/missions/${missionId}/candidatures`)
      .set('Cookie', entreprise)
      .expect(200);

    expect(response.body).toHaveLength(1);
    expect(response.body[0].candidat).toMatchObject({
      firstName: 'Samir',
      lastName: 'Diallo',
      city: 'Roissy-en-France',
      postalCode: '95700',
      certifications: [CertificationType.CACES_R489_3],
      // Déclarée mais pas encore examinée par un agent CADANS : l'entreprise voit la
      // différence entre « déclaré » et « vérifié ».
      certificationsVerifiees: [],
    });
  });

  // Sans lui, l'écran listait des candidats sans qu'aucune action soit possible : la route
  // qui retient un intérimaire attend cet identifiant, et rien ne le fournissait.
  it("transmet l'identifiant du profil, pour que l'entreprise puisse retenir le candidat", async () => {
    const response = await request(app.getHttpServer())
      .get(`/missions/${missionId}/candidatures`)
      .set('Cookie', entreprise)
      .expect(200);

    expect(typeof response.body[0].candidat.workerId).toBe('string');
    expect(response.body[0].candidat.workerId).not.toBe('');
  });

  // Le score que l'intérimaire voit déjà sur ses matches. Le cacher à la partie qui DÉCIDE
  // était difficile à tenir — et il arrive avec sa ventilation, sans quoi il ne se discute pas.
  it('transmet le score de correspondance et sa ventilation', async () => {
    const response = await request(app.getHttpServer())
      .get(`/missions/${missionId}/candidatures`)
      .set('Cookie', entreprise)
      .expect(200);

    const { score, detail } = response.body[0].candidat;
    expect(typeof score).toBe('number');
    expect(score).toBe(detail.competences.points + detail.zone.points);
    expect(detail.competences.max).toBe(60);
    expect(detail.zone.max).toBe(40);
  });

  // Elles pèsent 60 % du score, et n'étaient pas transmises : l'entreprise ne jugeait que sur
  // les CACES, qui sont un filtre d'accès valant zéro point.
  it('transmet les compétences déclarées et les créneaux acceptés', async () => {
    const response = await request(app.getHttpServer())
      .get(`/missions/${missionId}/candidatures`)
      .set('Cookie', entreprise)
      .expect(200);

    const { competences, shifts } = response.body[0].candidat;
    expect(Array.isArray(competences)).toBe(true);
    expect(Array.isArray(shifts)).toBe(true);
    for (const competence of competences) {
      expect(Object.keys(competence).sort()).toEqual(['code', 'label']);
    }
  });

  // Minimisation (RGPD) vérifiée au niveau HTTP, pas seulement dans le service : c'est la
  // réponse réellement émise qui compte. L'email du compte intérimaire est connu du test
  // (constante `worker`), donc sa présence se détecte sans ambiguïté.
  it("ne transmet à l'entreprise ni email ni téléphone du candidat", async () => {
    const response = await request(app.getHttpServer())
      .get(`/missions/${missionId}/candidatures`)
      .set('Cookie', entreprise)
      .expect(200);

    expect(JSON.stringify(response.body)).not.toContain(worker.email);
    expect(Object.keys(response.body[0].candidat).sort()).toEqual([
      'certifications',
      'certificationsVerifiees',
      'city',
      'competences',
      'detail',
      'firstName',
      'lastName',
      'postalCode',
      'score',
      'shifts',
      'workerId',
    ]);
  });

  // L'intérimaire consulte les mêmes lignes depuis « mes candidatures » : le bloc candidat
  // n'a rien à y faire, et sa vue ne charge même pas la relation.
  it("n'expose pas le bloc candidat dans « mes candidatures »", async () => {
    const mine = await request(app.getHttpServer())
      .get('/workers/me/candidatures')
      .set('Cookie', interimaire)
      .expect(200);

    expect(mine.body[0].candidat).toBeUndefined();
  });

  it("refuse (404) l'accès aux candidatures d'une mission à une autre entreprise", async () => {
    const autre = cookieOf(
      await request(app.getHttpServer())
        .post('/auth/register/company')
        .send({ ...company, email: 'autre@example.fr', siret: '39838393700131' }),
    );

    const refus = await request(app.getHttpServer())
      .get(`/missions/${missionId}/candidatures`)
      .set('Cookie', autre)
      .expect(404);

    // Le refus ne doit rien laisser filtrer du candidat au passage.
    expect(JSON.stringify(refus.body)).not.toContain('Samir');
  });
});
