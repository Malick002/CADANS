import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { Shift } from '@prisma/client';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryUsers } from './in-memory-users';
import { InMemoryWorkerWorld } from './in-memory-worker-world';

const worker = {
  email: 'leila@example.fr',
  password: 'Cariste!2026ok',
  acceptConditions: true,
  firstName: 'Leïla',
  lastName: 'Moreau',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

const company = {
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  acceptConditions: true,
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '95700',
  city: 'Roissy-en-France',
};

// Clé de contrôle recalculée, pas recopiée : 97 − (1801275116001 mod 97) = 28.
const NIR = '180127511600128';
// IBAN d'exemple de la norme ISO 13616, contrôle mod 97 vérifié.
const IBAN = 'FR1420041010050500013M02606';

const INFORMATIONS = {
  birthDate: '1980-12-04',
  birthPlace: 'Paris',
  birthCountry: 'France',
  nationality: 'Française',
  addressLine: '8 rue des Peupliers',
  addressPostalCode: '95700',
  addressCity: 'Roissy-en-France',
  nir: NIR,
  iban: IBAN,
};

function cookieOf(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  return cookies.find((cookie) => cookie.startsWith('cadans_session='))!.split(';')[0];
}

describe("Informations d'embauche (e2e)", () => {
  let app: INestApplication;
  let world: InMemoryWorkerWorld;
  let users: InMemoryUsers;
  let interimaire: string;
  let entreprise: string;
  let workerId: string;
  let companyId: string;

  beforeAll(async () => {
    users = new InMemoryUsers();
    world = new InMemoryWorkerWorld(users);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({
        user: users,
        worker: world.worker,
        workerSkill: world.workerSkill,
        competence: world.competence,
        company: world.company,
        mission: world.mission,
        hiringInfo: world.hiringInfo,
        $transaction: world.$transaction,
      })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    const server = app.getHttpServer();
    const inscriptionWorker = await request(server).post('/auth/register/worker').send(worker);
    const inscriptionCompany = await request(server).post('/auth/register/company').send(company);
    interimaire = cookieOf(inscriptionWorker);
    entreprise = cookieOf(inscriptionCompany);
    workerId = (inscriptionWorker.body as { worker: { id: string } }).worker.id;
    companyId = (inscriptionCompany.body as { company: { id: string } }).company.id;
  });

  afterAll(async () => {
    await app.close();
  });

  it('refuse sans session', async () => {
    await request(app.getHttpServer()).get('/workers/me/informations-embauche').expect(401);
    await request(app.getHttpServer())
      .put('/workers/me/informations-embauche')
      .send(INFORMATIONS)
      .expect(401);
  });

  // Le cloisonnement demandé : une entreprise n'a rien à faire dans l'état civil, le NIR ou
  // l'IBAN de l'intérimaire qu'elle emploie. 403 et non 404 — la route existe, elle ne lui
  // est simplement pas ouverte.
  it('refuse un compte entreprise, en lecture comme en écriture', async () => {
    await request(app.getHttpServer())
      .get('/workers/me/informations-embauche')
      .set('Cookie', entreprise)
      .expect(403);

    await request(app.getHttpServer())
      .put('/workers/me/informations-embauche')
      .set('Cookie', entreprise)
      .send(INFORMATIONS)
      .expect(403);
  });

  it('renvoie un état incomplet et non requis avant toute saisie', async () => {
    const response = await request(app.getHttpServer())
      .get('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .expect(200);

    expect(response.body).toMatchObject({
      complet: false,
      requis: false,
      missionsRetenues: 0,
      nirMasque: null,
      ibanMasque: null,
    });
  });

  it('refuse un NIR dont la clé est fausse', async () => {
    const response = await request(app.getHttpServer())
      .put('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .send({ ...INFORMATIONS, nir: '180127511600129' })
      .expect(400);

    // Le message dit quoi corriger sans jamais reprendre la valeur saisie : une 400
    // journalisée par un intermédiaire ne doit pas contenir un numéro de sécurité sociale.
    expect(JSON.stringify(response.body)).not.toContain('180127511600129');
  });

  it('refuse un IBAN dont le contrôle mod 97 échoue', async () => {
    const response = await request(app.getHttpServer())
      .put('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .send({ ...INFORMATIONS, iban: 'FR1420041010050500013M02607' })
      .expect(400);

    expect(JSON.stringify(response.body)).not.toContain('FR1420041010050500013M02607');
  });

  it('refuse une date de naissance impossible ou trop récente', async () => {
    await request(app.getHttpServer())
      .put('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .send({ ...INFORMATIONS, birthDate: '1985-02-31' })
      .expect(400);

    await request(app.getHttpServer())
      .put('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .send({ ...INFORMATIONS, birthDate: '2020-05-12' })
      .expect(400);
  });

  it('refuse un champ inconnu (forbidNonWhitelisted)', async () => {
    await request(app.getHttpServer())
      .put('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .send({ ...INFORMATIONS, salaireSouhaite: 20 })
      .expect(400);
  });

  it('accepte un NIR et un IBAN recopiés par blocs, espaces compris', async () => {
    await request(app.getHttpServer())
      .put('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .send({
        ...INFORMATIONS,
        nir: '1 80 12 75 116 001 28',
        iban: 'FR14 2004 1010 0505 0001 3M02 606',
      })
      .expect(200);
  });

  it('enregistre puis relit, en ne renvoyant que les quatre derniers caractères', async () => {
    const ecriture = await request(app.getHttpServer())
      .put('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .send(INFORMATIONS)
      .expect(200);

    const lecture = await request(app.getHttpServer())
      .get('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .expect(200);

    for (const body of [ecriture.body, lecture.body]) {
      expect(body).toMatchObject({
        complet: true,
        birthDate: '1980-12-04',
        birthPlace: 'Paris',
        addressCity: 'Roissy-en-France',
        nirMasque: '•••••••••••0128',
        ibanMasque: `${'•'.repeat(23)}2606`,
      });
    }
  });

  // L'exigence centrale de la tâche, vérifiée sur la réponse HTTP brute et non sur un objet
  // déjà mis en forme : le NIR et l'IBAN ne sortent jamais en clair, ni entiers ni tronqués.
  it("l'API ne renvoie jamais le NIR ni l'IBAN en clair", async () => {
    // En série et non en parallèle : quatre requêtes simultanées sur le serveur de test
    // font tomber la connexion (ECONNRESET), ce qui masquerait l'assertion.
    const reponses = [
      await request(app.getHttpServer())
        .get('/workers/me/informations-embauche')
        .set('Cookie', interimaire),
      await request(app.getHttpServer())
        .put('/workers/me/informations-embauche')
        .set('Cookie', interimaire)
        .send(INFORMATIONS),
      await request(app.getHttpServer()).get('/auth/me').set('Cookie', interimaire),
      await request(app.getHttpServer())
        .get('/workers/me/profil-matching')
        .set('Cookie', interimaire),
    ];

    for (const reponse of reponses) {
      expect(reponse.status).toBe(200);
      expect(reponse.text).not.toContain(NIR);
      expect(reponse.text).not.toContain(IBAN);
      expect(reponse.text).not.toContain(NIR.slice(0, 11));
      expect(reponse.text).not.toContain(IBAN.slice(0, 23));
    }
  });

  // Le chiffrement est le vrai EncryptionService : ce qui est posé dans la doublure de base
  // est donc ce qui serait écrit dans PostgreSQL. On le lit tel quel.
  it('écrit en base des octets chiffrés, pas les valeurs saisies', () => {
    const stocke = world.hiringInfos.get(workerId)!;
    const octets = Buffer.concat([
      Buffer.from(stocke.nirEncrypted as Uint8Array),
      Buffer.from(stocke.ibanEncrypted as Uint8Array),
    ]).toString('latin1');

    expect(octets).not.toContain(NIR);
    expect(octets).not.toContain(IBAN);
  });

  it('bascule « requis » dès que l’intérimaire est retenu sur une mission', async () => {
    world.addMission({
      companyId,
      posteCode: '11679',
      siteLabel: 'Entrepôt du Nord — quai 4',
      postalCode: '95700',
      startDate: new Date(),
      endDate: new Date(),
      shift: Shift.MATIN,
      hourlyRate: 13.5,
      status: 'POURVUE',
      assignedWorkerId: workerId,
      habilitations: [],
      competences: [],
    });

    const response = await request(app.getHttpServer())
      .get('/workers/me/informations-embauche')
      .set('Cookie', interimaire)
      .expect(200);

    expect(response.body).toMatchObject({ requis: true, missionsRetenues: 1 });
  });
});
