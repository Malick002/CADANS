import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';

describe('Health (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  // Le socle doit répondre même sans base lancée : on vérifie le contrat de
  // la route, pas la disponibilité de PostgreSQL et de MongoDB.
  it('GET /health rend le contrat attendu', async () => {
    const response = await request(app.getHttpServer()).get('/health').expect(200);

    expect(response.body).toMatchObject({
      status: expect.stringMatching(/^(up|down)$/),
      postgres: expect.stringMatching(/^(up|down)$/),
      mongo: expect.stringMatching(/^(up|down)$/),
      uptimeSeconds: expect.any(Number),
    });
  });
});
