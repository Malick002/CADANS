import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryUsers } from './in-memory-users';

const company = {
  acceptConditions: true,
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

const worker = {
  acceptConditions: true,
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  firstName: 'Samir',
  lastName: 'Diallo',
  phone: '06 12 34 56 78',
  postalCode: '69007',
  city: 'Lyon',
};

describe('Auth (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({ user: new InMemoryUsers() })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  describe('POST /auth/register/company', () => {
    it('inscrit une entreprise et ne renvoie jamais le hash', async () => {
      const response = await request(app.getHttpServer())
        .post('/auth/register/company')
        .send(company)
        .expect(201);

      expect(response.body).toMatchObject({
        email: 'contact@entrepot-nord.fr',
        role: 'COMPANY',
        company: { siret: '73282932000074', city: 'Lille' },
        worker: null,
      });
      expect(response.body).not.toHaveProperty('passwordHash');
      expect(response.body).not.toHaveProperty('password');
    });

    it('refuse un second compte avec le même SIRET', async () => {
      const response = await request(app.getHttpServer())
        .post('/auth/register/company')
        .send({ ...company, email: 'autre@entrepot-nord.fr' })
        .expect(409);

      expect(response.body.message).toBe('Une entreprise est déjà inscrite avec ce SIRET');
    });

    it('refuse un payload invalide avec le détail des erreurs', async () => {
      const response = await request(app.getHttpServer())
        .post('/auth/register/company')
        .send({ ...company, email: 'x@y.fr', siret: '12345678901234', password: 'faible' })
        .expect(400);

      expect(response.body.message).toEqual(
        expect.arrayContaining([
          'Le SIRET doit comporter 14 chiffres valides',
          'Le mot de passe doit contenir au moins 12 caractères',
        ]),
      );
    });

    it('refuse une inscription sans acceptation de la politique de confidentialité', async () => {
      const response = await request(app.getHttpServer())
        .post('/auth/register/company')
        .send({ ...company, email: 'refus@entrepot-nord.fr', acceptConditions: false })
        .expect(400);

      expect(response.body.message).toContain(
        'Vous devez accepter la politique de confidentialité pour créer un compte',
      );
    });

    it('refuse une inscription où le champ d’acceptation est absent', async () => {
      const { acceptConditions: _omis, ...sansAcceptation } = company;

      await request(app.getHttpServer())
        .post('/auth/register/company')
        .send({ ...sansAcceptation, email: 'absent@entrepot-nord.fr' })
        .expect(400);
    });

    it("refuse qu'un client impose son rôle", async () => {
      await request(app.getHttpServer())
        .post('/auth/register/company')
        .send({ ...company, email: 'role@entrepot-nord.fr', role: 'WORKER' })
        .expect(400);
    });
  });

  describe('POST /auth/register/worker', () => {
    it('inscrit un intérimaire avec un email normalisé', async () => {
      const response = await request(app.getHttpServer())
        .post('/auth/register/worker')
        .send({ ...worker, email: '  Samir@Example.FR ' })
        .expect(201);

      expect(response.body).toMatchObject({
        email: 'samir@example.fr',
        role: 'WORKER',
        company: null,
        worker: { firstName: 'Samir', phone: '0612345678', postalCode: '69007' },
      });
      expect(response.body).not.toHaveProperty('passwordHash');
    });

    it("refuse un email déjà utilisé, même par l'autre type de compte", async () => {
      const response = await request(app.getHttpServer())
        .post('/auth/register/worker')
        .send({ ...worker, email: company.email })
        .expect(409);

      expect(response.body.message).toBe('Un compte existe déjà avec cette adresse email');
    });
  });

  describe('POST /auth/login', () => {
    it('connecte avec les bons identifiants', async () => {
      const response = await request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: 'SAMIR@example.fr', password: worker.password })
        .expect(200);

      expect(response.body).toMatchObject({ email: 'samir@example.fr', role: 'WORKER' });
      expect(response.body).not.toHaveProperty('passwordHash');
    });

    it('renvoie la même erreur pour un mauvais mot de passe et un email inconnu', async () => {
      const wrongPassword = await request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: worker.email, password: 'Mauvais#2026ok' })
        .expect(401);

      const unknownEmail = await request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: 'inconnu@example.fr', password: worker.password })
        .expect(401);

      expect(wrongPassword.body.message).toBe('Email ou mot de passe incorrect');
      expect(unknownEmail.body).toEqual(wrongPassword.body);
    });
  });
});
