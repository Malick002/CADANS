import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryReferentiel } from './in-memory-referentiel';

describe('Référentiel métier (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue(new InMemoryReferentiel())
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  describe('GET /referentiel/postes', () => {
    it('est public et ne renvoie que les postes exposés, actifs, d’un ROME actif', async () => {
      const response = await request(app.getHttpServer()).get('/referentiel/postes').expect(200);

      expect(response.body.map((p: { code: string }) => p.code)).toEqual([
        '11679',
        '11684',
        '17993',
      ]);
    });

    // Le référentiel ne bouge qu'au ré-import : les deux routes sont mises en cache une heure.
    it('autorise une heure de cache public', async () => {
      await request(app.getHttpServer())
        .get('/referentiel/postes')
        .expect('Cache-Control', 'public, max-age=3600');
      await request(app.getHttpServer())
        .get('/referentiel/competences')
        .expect('Cache-Control', 'public, max-age=3600');
    });

    it('donne le code ROME et les habilitations suggérées de chaque poste', async () => {
      const response = await request(app.getHttpServer()).get('/referentiel/postes').expect(200);

      expect(response.body[0]).toEqual({
        code: '11679',
        label: 'Cariste',
        classification: 'PRINCIPALE',
        rome: { code: 'N1101', label: 'Cariste' },
        habilitationsSuggerees: ['CACES_R489_3'],
      });
      expect(response.body[2].habilitationsSuggerees).toEqual([]);
    });
  });

  describe('GET /referentiel/competences', () => {
    it('renvoie les principales actives, sans savoir-être, dédoublonnées et triées', async () => {
      const response = await request(app.getHttpServer())
        .get('/referentiel/competences')
        .expect(200);

      expect(response.body).toEqual([
        {
          code: '484039',
          label: 'Conduire un chariot élévateur en respectant les normes de sécurité',
          type: 'COMPETENCE_DETAILLEE',
          romeCodes: ['N1101'],
        },
        {
          code: '100016',
          label: 'Gestes et postures de manutention',
          type: 'SAVOIR',
          romeCodes: ['N1101', 'N1103'],
        },
      ]);
    });

    it('se restreint à un code ROME', async () => {
      const response = await request(app.getHttpServer())
        .get('/referentiel/competences?rome=N1103')
        .expect(200);

      expect(response.body.map((c: { code: string }) => c.code)).toEqual(['100016']);
    });

    it('refuse un code ROME mal formé', async () => {
      await request(app.getHttpServer()).get('/referentiel/competences?rome=cariste').expect(400);
    });
  });
});
