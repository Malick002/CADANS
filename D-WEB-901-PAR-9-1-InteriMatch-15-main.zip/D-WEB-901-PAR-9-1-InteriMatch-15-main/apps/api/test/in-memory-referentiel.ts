import { CertificationType, CompetenceType } from '@prisma/client';

// Doublure du référentiel pour les tests fonctionnels, sur le modèle de InMemoryUsers :
// un extrait réaliste des trois fiches ROME, et les filtres que le service utilise
// réellement (exposé, actif, code ROME, principale, type). Les jointures `select` sont
// reproduites à la main : le service ne lit que ces champs.

interface Rome {
  code: string;
  label: string;
  active: boolean;
}

interface Poste {
  code: string;
  label: string;
  classification: string;
  romeCode: string;
  exposed: boolean;
  active: boolean;
  habilitations: CertificationType[];
}

interface Competence {
  code: string;
  label: string;
  type: CompetenceType;
  active: boolean;
}

interface Lien {
  romeCode: string;
  competenceCode: string;
  principale: boolean;
}

export const ROMES: Rome[] = [
  { code: 'N1101', label: 'Cariste', active: true },
  { code: 'N1103', label: 'Préparateur / Préparatrice de commandes', active: true },
  { code: 'N1303', label: 'Exploitation logistique (hors périmètre)', active: false },
];

export const POSTES: Poste[] = [
  {
    code: '11679',
    label: 'Cariste',
    classification: 'PRINCIPALE',
    romeCode: 'N1101',
    exposed: true,
    active: true,
    habilitations: [CertificationType.CACES_R489_3],
  },
  {
    code: '11684',
    label: "Cariste d'entrepôt",
    classification: 'SYNONYME',
    romeCode: 'N1101',
    exposed: true,
    active: true,
    habilitations: [CertificationType.CACES_R489_3],
  },
  {
    code: '38979',
    label: 'Conducteur / Conductrice de nacelle',
    classification: 'SYNONYME',
    romeCode: 'N1101',
    exposed: false,
    active: true,
    habilitations: [],
  },
  {
    code: '17993',
    label: 'Préparateur / Préparatrice de commandes',
    classification: 'PRINCIPALE',
    romeCode: 'N1103',
    exposed: true,
    active: true,
    habilitations: [],
  },
  {
    code: '99999',
    label: 'Appellation disparue de la source',
    classification: 'SYNONYME',
    romeCode: 'N1103',
    exposed: true,
    active: false,
    habilitations: [],
  },
  {
    code: '77777',
    label: 'Poste d’un ROME hors périmètre',
    classification: 'PRINCIPALE',
    romeCode: 'N1303',
    exposed: true,
    active: true,
    habilitations: [],
  },
];

export const COMPETENCES: Competence[] = [
  {
    code: '484039',
    label: 'Conduire un chariot élévateur en respectant les normes de sécurité',
    type: CompetenceType.COMPETENCE_DETAILLEE,
    active: true,
  },
  {
    code: '100016',
    label: 'Gestes et postures de manutention',
    type: CompetenceType.SAVOIR,
    active: true,
  },
  {
    code: '300490',
    label: 'Faire preuve de rigueur et de précision',
    type: CompetenceType.MACRO_SAVOIR_ETRE,
    active: true,
  },
  {
    code: '101829',
    label: 'Engins de manutention non motorisés',
    type: CompetenceType.SAVOIR,
    active: true,
  },
  {
    code: '555555',
    label: 'Compétence disparue de la source',
    type: CompetenceType.SAVOIR,
    active: false,
  },
];

export const LIENS: Lien[] = [
  { romeCode: 'N1101', competenceCode: '484039', principale: true },
  { romeCode: 'N1101', competenceCode: '100016', principale: true },
  { romeCode: 'N1101', competenceCode: '300490', principale: true },
  { romeCode: 'N1101', competenceCode: '101829', principale: false },
  { romeCode: 'N1103', competenceCode: '100016', principale: true },
  { romeCode: 'N1103', competenceCode: '555555', principale: true },
];

const romeOf = (code: string): Rome => ROMES.find((r) => r.code === code)!;

export class InMemoryReferentiel {
  poste = {
    findMany: ({
      where,
    }: {
      where: { exposed?: boolean; active?: boolean; rome?: { active?: boolean } };
    }) =>
      Promise.resolve(
        POSTES.filter(
          (p) =>
            (where.exposed === undefined || p.exposed === where.exposed) &&
            (where.active === undefined || p.active === where.active) &&
            (where.rome?.active === undefined || romeOf(p.romeCode).active === where.rome.active),
        )
          .sort(
            (a, b) =>
              a.romeCode.localeCompare(b.romeCode) ||
              a.classification.localeCompare(b.classification) ||
              a.label.localeCompare(b.label),
          )
          .map((p) => ({
            code: p.code,
            label: p.label,
            classification: p.classification,
            rome: { code: p.romeCode, label: romeOf(p.romeCode).label },
            habilitations: p.habilitations.map((type) => ({ type })),
          })),
      ),
  };

  romeCompetence = {
    findMany: ({
      where,
    }: {
      where: {
        principale?: boolean;
        romeCode?: string;
        rome?: { active?: boolean };
        competence?: { active?: boolean; type?: { not?: CompetenceType } };
      };
    }) =>
      Promise.resolve(
        LIENS.filter((l) => {
          const competence = COMPETENCES.find((c) => c.code === l.competenceCode)!;
          return (
            (where.principale === undefined || l.principale === where.principale) &&
            (where.romeCode === undefined || l.romeCode === where.romeCode) &&
            (where.rome?.active === undefined || romeOf(l.romeCode).active === where.rome.active) &&
            (where.competence?.active === undefined ||
              competence.active === where.competence.active) &&
            (where.competence?.type?.not === undefined ||
              competence.type !== where.competence.type.not)
          );
        }).map((l) => {
          const { code, label, type } = COMPETENCES.find((c) => c.code === l.competenceCode)!;
          return { romeCode: l.romeCode, competence: { code, label, type } };
        }),
      ),
  };
}
