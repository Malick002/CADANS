import { Controller, Get, INestApplication, Post } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { Role } from '@prisma/client';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';
import { CurrentUser, Roles } from '../src/auth/decorators';
import { SESSION_TTL_SECONDS, SessionUser } from '../src/auth/token.service';
import { PrismaService } from '../src/prisma/prisma.service';
import { InMemoryUsers } from './in-memory-users';

// Routes de démonstration, présentes uniquement dans ce test : elles vérifient que les
// gardes globales s'appliquent à toute route de l'API, comme le feront les missions.
@Controller('probe')
class ProbeController {
  @Get('connecte')
  connected(@CurrentUser() user: SessionUser): SessionUser {
    return user;
  }

  @Roles(Role.COMPANY)
  @Post('entreprise')
  companyOnly(): { ok: true } {
    return { ok: true };
  }
}

const company = {
  acceptConditions: true,
  email: 'contact@entrepot-nord.fr',
  password: 'Cariste#2026ok',
  legalName: 'Entrepôt du Nord',
  siret: '73282932000074',
  nafCode: '52.10B',
  contactFirstName: 'Nadia',
  contactLastName: 'Benali',
  addressLine: '12 rue des Docks',
  postalCode: '59000',
  city: 'Lille',
};

const worker = {
  acceptConditions: true,
  email: 'samir@example.fr',
  password: 'Preparateur!42x',
  firstName: 'Samir',
  lastName: 'Diallo',
  postalCode: '69007',
  city: 'Lyon',
};

function sessionCookie(response: request.Response): string {
  const cookies = ([] as string[]).concat(response.headers['set-cookie'] ?? []);
  const session = cookies.find((cookie) => cookie.startsWith('cadans_session='));
  if (!session) {
    throw new Error('Aucun cookie de session posé');
  }
  return session;
}

describe('Session et permissions (e2e)', () => {
  let app: INestApplication;
  let companyCookie: string;
  let workerCookie: string;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
      controllers: [ProbeController],
    })
      .overrideProvider(PrismaService)
      .useValue({ user: new InMemoryUsers() })
      .compile();

    app = moduleRef.createNestApplication();
    configureApp(app);
    await app.init();

    companyCookie = sessionCookie(
      await request(app.getHttpServer()).post('/auth/register/company').send(company).expect(201),
    );
    await request(app.getHttpServer()).post('/auth/register/worker').send(worker).expect(201);
  });

  afterAll(async () => {
    await app.close();
  });

  it('pose un cookie de session httpOnly à la connexion', async () => {
    const response = await request(app.getHttpServer())
      .post('/auth/login')
      .send({ email: worker.email, password: worker.password })
      .expect(200);

    workerCookie = sessionCookie(response);
    expect(workerCookie).toMatch(/HttpOnly/i);
    expect(workerCookie).toMatch(/SameSite=Lax/i);
    expect(workerCookie).toMatch(/Path=\//);
    // Exprimé via la constante, jamais en dur : le cookie doit expirer EN MÊME TEMPS que le
    // jeton, et c'est cela que le test vérifie — pas une durée particulière. Écrit « 28800 »,
    // il tombait au premier changement de TTL en disant « 28800 attendu » plutôt que
    // « le cookie survit au jeton ».
    expect(workerCookie).toMatch(new RegExp(`Max-Age=${SESSION_TTL_SECONDS}\\b`));
  });

  it('ne pose aucun cookie si la connexion échoue', async () => {
    const response = await request(app.getHttpServer())
      .post('/auth/login')
      .send({ email: worker.email, password: 'Mauvais#2026ok' })
      .expect(401);

    expect(response.headers['set-cookie']).toBeUndefined();
  });

  describe('GET /auth/me', () => {
    it('renvoie le compte de la session', async () => {
      const response = await request(app.getHttpServer())
        .get('/auth/me')
        .set('Cookie', workerCookie)
        .expect(200);

      expect(response.body).toMatchObject({
        email: worker.email,
        role: 'WORKER',
        worker: { firstName: 'Samir' },
      });
      expect(response.body).not.toHaveProperty('passwordHash');
    });

    it('exige une session', async () => {
      const response = await request(app.getHttpServer()).get('/auth/me').expect(401);

      expect(response.body.message).toBe('Authentification requise');
    });

    it('refuse un token falsifié', async () => {
      const [, token] = workerCookie.split(';')[0].split('=');
      const [header, , signature] = token.split('.');
      const forgedPayload = Buffer.from(
        JSON.stringify({ sub: 'x', role: 'COMPANY', exp: 9999999999 }),
      ).toString('base64url');

      await request(app.getHttpServer())
        .get('/auth/me')
        .set('Cookie', `cadans_session=${header}.${forgedPayload}.${signature}`)
        .expect(401);
    });
  });

  describe('permissions par rôle', () => {
    it('protège par défaut toute nouvelle route', async () => {
      await request(app.getHttpServer()).get('/probe/connecte').expect(401);

      const response = await request(app.getHttpServer())
        .get('/probe/connecte')
        .set('Cookie', workerCookie)
        .expect(200);
      expect(response.body).toMatchObject({ role: 'WORKER' });
    });

    it("ouvre une route @Roles(COMPANY) à l'entreprise", async () => {
      await request(app.getHttpServer())
        .post('/probe/entreprise')
        .set('Cookie', companyCookie)
        .expect(201);
    });

    it("la ferme à l'intérimaire", async () => {
      const response = await request(app.getHttpServer())
        .post('/probe/entreprise')
        .set('Cookie', workerCookie)
        .expect(403);

      expect(response.body.message).toBe(
        "Cette action n'est pas autorisée pour votre type de compte",
      );
    });
  });

  it("refuse une écriture authentifiée venant d'un autre site (CSRF)", async () => {
    await request(app.getHttpServer())
      .post('/probe/entreprise')
      .set('Cookie', companyCookie)
      .set('Origin', 'https://site-pirate.example')
      .expect(403);

    await request(app.getHttpServer())
      .post('/probe/entreprise')
      .set('Cookie', companyCookie)
      .set('Origin', 'http://localhost:3000')
      .expect(201);
  });

  it('ferme la session à la déconnexion', async () => {
    const response = await request(app.getHttpServer())
      .post('/auth/logout')
      .set('Cookie', workerCookie)
      .expect(204);

    const cleared = sessionCookie(response);
    expect(cleared).toMatch(/cadans_session=;/);
    expect(cleared).toMatch(/Expires=Thu, 01 Jan 1970/);
  });

  it('laisse /health public', async () => {
    await request(app.getHttpServer()).get('/health').expect(200);
  });
});
