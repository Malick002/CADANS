import { randomUUID } from 'node:crypto';
import { CertificationType, MotifRecours } from '@prisma/client';
import { COMPETENCES, POSTES } from './in-memory-referentiel';
import { InMemoryUsers } from './in-memory-users';

interface MissionRow {
  id: string;
  companyId: string;
  posteCode: string;
  siteLabel: string;
  postalCode: string;
  startDate: Date;
  endDate: Date;
  shift: string;
  motifRecours: MotifRecours;
  remplaceNom: string | null;
  remplaceQualification: string | null;
  hourlyRate: number;
  description: string | null;
  // Référence de l'offre France Travail d'origine, quand la mission a été préremplie.
  sourceOffreId: string | null;
  status: string;
  createdAt: Date;
  updatedAt: Date;
  habilitations: { type: CertificationType }[];
  competences: { competenceCode: string }[];
}

interface ContractRow {
  id: string;
  missionId: string;
  type: string;
  pdfEncrypted: Uint8Array;
  sha256: string;
  generatedAt: Date;
  finalPdfEncrypted: Uint8Array | null;
  finalSha256: string | null;
  completedAt: Date | null;
}

interface SignatureRow {
  contractId: string;
  party: string;
  userId: string | null;
  typedName: string;
  signedAt: Date;
  ip: string | null;
  userAgent: string | null;
  documentSha256: string;
}

interface CreateMissionArgs {
  data: Omit<
    MissionRow,
    'id' | 'createdAt' | 'updatedAt' | 'status' | 'habilitations' | 'competences'
  > & {
    habilitations: { create: { type: CertificationType }[] };
    competences: { create: { competenceCode: string }[] };
  };
}

// Doublure de la persistance des missions pour les tests fonctionnels, sur le modèle de
// InMemorySensitiveDocuments : réutilise les postes/compétences de in-memory-referentiel.ts,
// les seules fixtures que le service consulte réellement (existence par code).
export class InMemoryMissions {
  readonly rows: MissionRow[] = [];

  constructor(private readonly users: InMemoryUsers) {}

  readonly company = {
    findUnique: ({ where }: { where: { userId: string } }): Promise<{ id: string } | null> => {
      const id = this.users.companyIdOf(where.userId);
      return Promise.resolve(id ? { id } : null);
    },
  };

  // Reproduit le filtre du service : seuls les postes exposés et actifs sont publiables.
  readonly poste = {
    findFirst: ({ where }: { where: { code: string; exposed?: boolean; active?: boolean } }) =>
      Promise.resolve(
        POSTES.some(
          (p) =>
            p.code === where.code &&
            (where.exposed === undefined || p.exposed === where.exposed) &&
            (where.active === undefined || p.active === where.active),
        )
          ? { code: where.code }
          : null,
      ),
  };

  readonly competence = {
    findMany: ({ where }: { where: { code: { in: string[] } } }): Promise<{ code: string }[]> =>
      Promise.resolve(
        COMPETENCES.filter((c) => where.code.in.includes(c.code)).map((c) => ({ code: c.code })),
      ),
  };

  // Intérimaire retenu (Mission.assignedWorkerId), consulté par MissionsService pour
  // valider le choix de l'entreprise et construire la notification n8n « mission pourvue ».
  readonly worker = {
    findUnique: ({ where }: { where: { id: string } }) => {
      const record = this.users.workerRecordById(where.id);
      if (!record) {
        return Promise.resolve(null);
      }
      return Promise.resolve({
        id: record.id,
        firstName: record.firstName,
        lastName: record.lastName,
        user: { email: record.email },
      });
    },
  };

  // Contrats. Le PDF, lui, est bien réel : c'est le vrai ContractPdfService qui tourne dans
  // ces tests, et le vrai EncryptionService qui le chiffre. Seule la persistance est doublée.
  readonly contracts: ContractRow[] = [];
  readonly signatures: SignatureRow[] = [];

  readonly contract = {
    upsert: ({
      where,
      create,
      update,
    }: {
      where: { missionId_type: { missionId: string; type: string } };
      create: Omit<ContractRow, 'id' | 'finalPdfEncrypted' | 'finalSha256' | 'completedAt'> &
        Partial<ContractRow>;
      update: Partial<ContractRow>;
    }) => {
      const { missionId, type } = where.missionId_type;
      const existant = this.contracts.find((c) => c.missionId === missionId && c.type === type);
      if (existant) {
        Object.assign(existant, update);
        return Promise.resolve(existant);
      }
      const row: ContractRow = {
        ...create,
        id: randomUUID(),
        finalPdfEncrypted: create.finalPdfEncrypted ?? null,
        finalSha256: create.finalSha256 ?? null,
        completedAt: create.completedAt ?? null,
      };
      this.contracts.push(row);
      return Promise.resolve(row);
    },

    update: ({ where, data }: { where: { id: string }; data: Partial<ContractRow> }) => {
      const row = this.contracts.find((c) => c.id === where.id)!;
      Object.assign(row, data);
      return Promise.resolve(row);
    },

    findUniqueOrThrow: ({ where }: { where: { id: string } }) => {
      const row = this.contracts.find((c) => c.id === where.id)!;
      return Promise.resolve({
        ...row,
        signatures: this.signatures.filter((s) => s.contractId === row.id),
      });
    },

    findUnique: ({
      where,
    }: {
      where: { id?: string; missionId_type?: { missionId: string; type: string } };
    }) => {
      const row = where.id
        ? this.contracts.find((c) => c.id === where.id)
        : this.contracts.find(
            (c) =>
              c.missionId === where.missionId_type!.missionId &&
              c.type === where.missionId_type!.type,
          );
      if (!row) {
        return Promise.resolve(null);
      }
      return Promise.resolve({
        ...row,
        signatures: this.signatures.filter((s) => s.contractId === row.id),
        mission: this.missionRelations(row.missionId),
      });
    },

    // Le service filtre par type ET par propriétaire ; la doublure honore les deux, sans quoi
    // le test « chacun ne voit que son document » ne vérifierait plus rien.
    findMany: ({
      where,
    }: {
      where: {
        id?: string;
        type?: string;
        mission?: { company?: { userId: string }; assignedWorker?: { userId: string } };
      };
    }) =>
      Promise.resolve(
        this.contracts
          .filter((row) => {
            // `type` et `id` sont facultatifs : le service relit un contrat précis après
            // signature, sans filtrer par type. Les traiter comme obligatoires ne rendait
            // alors aucune ligne — et la réponse de signature arrivait vide.
            if (where.id !== undefined && row.id !== where.id) {
              return false;
            }
            if (where.type !== undefined && row.type !== where.type) {
              return false;
            }
            const parties = this.missionRelations(row.missionId);
            if (where.mission?.company) {
              return parties.company.userId === where.mission.company.userId;
            }
            if (where.mission?.assignedWorker) {
              return parties.assignedWorker?.userId === where.mission.assignedWorker.userId;
            }
            return true;
          })
          .map((row) => ({
            ...row,
            signatures: this.signatures.filter((s) => s.contractId === row.id),
            mission: this.missionRelations(row.missionId),
          })),
      ),
  };

  // Annexes de mission : mêmes conventions que les contrats, persistance doublée et
  // chiffrement réel.
  readonly annexes: Record<string, unknown>[] = [];

  readonly missionAttachment = {
    create: ({ data }: { data: Record<string, unknown> }) => {
      const row = { createdAt: new Date(), ...data };
      this.annexes.push(row);
      return Promise.resolve(row);
    },
    findMany: ({ where }: { where: { missionId: string } }) =>
      Promise.resolve(this.annexes.filter((row) => row.missionId === where.missionId)),
    // Deux formes rendues à la fois : les colonnes plates (lecture) et la mission avec ses
    // contrats (suppression). C'est le `select` du service qui choisit ce qu'il lit.
    findUnique: ({ where }: { where: { id: string } }) => {
      const row = this.annexes.find((candidate) => candidate.id === where.id);
      if (!row) {
        return Promise.resolve(null);
      }
      return Promise.resolve({
        ...row,
        mission: {
          company: { userId: this.missionRelations(row.missionId as string).company.userId },
          contracts: this.contracts
            .filter((contrat) => contrat.missionId === row.missionId)
            .map((contrat) => ({ completedAt: contrat.completedAt })),
        },
      });
    },
    delete: ({ where }: { where: { id: string } }) => {
      const index = this.annexes.findIndex((row) => row.id === where.id);
      const [supprimee] = this.annexes.splice(index, 1);
      return Promise.resolve(supprimee);
    },
  };

  readonly contractSignature = {
    upsert: ({
      where,
      create,
      update,
    }: {
      where: { contractId_party: { contractId: string; party: string } };
      create: Omit<SignatureRow, 'userId' | 'signedAt' | 'ip' | 'userAgent'> &
        Partial<SignatureRow>;
      update: Partial<SignatureRow>;
    }) => {
      const { contractId, party } = where.contractId_party;
      const existante = this.signatures.find(
        (s) => s.contractId === contractId && s.party === party,
      );
      if (existante) {
        Object.assign(existante, update);
        return Promise.resolve(existante);
      }
      const row: SignatureRow = {
        ...create,
        userId: create.userId ?? null,
        ip: create.ip ?? null,
        userAgent: create.userAgent ?? null,
        signedAt: create.signedAt ?? new Date(),
      };
      this.signatures.push(row);
      return Promise.resolve(row);
    },
    create: ({ data }: { data: SignatureRow }) => {
      const row: SignatureRow = { ...data, signedAt: data.signedAt ?? new Date() };
      this.signatures.push(row);
      return Promise.resolve(row);
    },
  };

  private companyIdOfMission(missionId: string): string | null {
    return this.rows.find((row) => row.id === missionId)?.companyId ?? null;
  }

  private posteLabelOf(missionId: string): string {
    const row = this.rows.find((candidate) => candidate.id === missionId)!;
    return POSTES.find((p) => p.code === row.posteCode)!.label;
  }

  // Relations de la mission telles que ContractsService les charge : les parties (pour le
  // contrôle d'accès et la comparaison du nom saisi), le poste et le terme (pour la vue).
  private missionRelations(missionId: string) {
    const row = this.rows.find((candidate) => candidate.id === missionId)!;
    const assignedWorkerId = (row as unknown as { assignedWorkerId?: string }).assignedWorkerId;
    const record = assignedWorkerId ? this.users.workerRecordById(assignedWorkerId) : null;
    return {
      startDate: row.startDate,
      endDate: row.endDate,
      poste: { label: this.posteLabelOf(missionId) },
      contracts: this.contracts
        .filter((c) => c.missionId === missionId)
        .map((c) => ({ type: c.type, completedAt: c.completedAt })),
      company: {
        userId: this.users.userIdOfCompany(row.companyId)!,
        legalName: this.users.companyLegalNameOf(row.companyId),
        contactFirstName: 'Nadia',
        contactLastName: 'Benali',
      },
      assignedWorker: record
        ? {
            userId: this.users.userIdOfWorker(record.id),
            firstName: record.firstName as string,
            lastName: record.lastName as string,
          }
        : null,
    };
  }

  readonly mission = {
    create: ({ data }: CreateMissionArgs) => {
      const { habilitations, competences, ...rest } = data;
      const now = new Date();
      const row: MissionRow = {
        id: randomUUID(),
        createdAt: now,
        updatedAt: now,
        status: 'OUVERTE',
        ...rest,
        habilitations: habilitations.create,
        competences: competences.create,
      };
      this.rows.push(row);
      return Promise.resolve(this.withPoste(row));
    },
    findMany: ({
      where,
    }: {
      where: {
        companyId?: string;
        status?: string;
        assignedWorkerId?: string;
        assignedWorker?: { userId: string };
      };
    }) =>
      Promise.resolve(
        this.rows
          .filter(
            (row) =>
              (!where.companyId || row.companyId === where.companyId) &&
              (!where.status || row.status === where.status) &&
              (!where.assignedWorkerId ||
                (row as unknown as { assignedWorkerId?: string }).assignedWorkerId ===
                  where.assignedWorkerId) &&
              // `listForWorker` filtre par la relation, pas par la colonne.
              (!where.assignedWorker ||
                this.users.userIdOfWorker(
                  (row as unknown as { assignedWorkerId?: string }).assignedWorkerId ?? '',
                ) === where.assignedWorker.userId),
          )
          .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
          .map((row) => ({
            ...this.withPoste(row),
            attachments: this.annexes.filter((annexe) => annexe.missionId === row.id),
          })),
      ),

    // Lecture publique d'une fiche, et vérification de propriété (select réduit) : le service
    // appelle la même méthode dans les deux cas, on renvoie donc les deux formes.
    findUnique: ({ where }: { where: { id: string } }) => {
      const row = this.rows.find((candidate) => candidate.id === where.id);
      if (!row) {
        return Promise.resolve(null);
      }
      const assignedWorkerId = (row as unknown as { assignedWorkerId?: string }).assignedWorkerId;
      const record = assignedWorkerId ? this.users.workerRecordById(assignedWorkerId) : null;
      return Promise.resolve({
        ...this.withPoste(row),
        company: {
          legalName: this.users.companyLegalNameOf(row.companyId),
          siret: this.users.companySiretOf(row.companyId),
          addressLine: '12 rue des Docks',
          postalCode: '95700',
          city: 'Roissy-en-France',
          contactFirstName: 'Nadia',
          contactLastName: 'Benali',
          signatoryRole: null,
          userId: this.users.userIdOfCompany(row.companyId),
          user: { email: this.users.companyEmailOf(row.companyId) },
        },
        // L'intérimaire retenu, tel que ContractsService le charge. `hiringInfo` est nul :
        // ces tests ne renseignent pas les informations d'embauche, donc seul le contrat de
        // mise à disposition est généré — exactement le cas que le service doit tenir.
        assignedWorker: record
          ? {
              id: record.id,
              firstName: record.firstName as string,
              lastName: record.lastName as string,
              city: (record.city as string) ?? 'Roissy-en-France',
              postalCode: (record.postalCode as string) ?? '95700',
              userId: this.users.userIdOfWorker(record.id),
              hiringInfo: null,
            }
          : null,
      });
    },

    update: ({ where, data }: { where: { id: string }; data: Record<string, never> }) => {
      const row = this.rows.find((candidate) => candidate.id === where.id)!;
      const { habilitations, competences, ...rest } = data as Record<string, unknown>;
      Object.assign(row, rest);
      if (habilitations) {
        row.habilitations = (habilitations as { create: { type: CertificationType }[] }).create;
      }
      if (competences) {
        row.competences = (competences as { create: { competenceCode: string }[] }).create;
      }
      row.updatedAt = new Date();
      return Promise.resolve(this.withPoste(row));
    },
  };

  private withPoste(row: MissionRow) {
    const poste = POSTES.find((p) => p.code === row.posteCode)!;
    return {
      ...row,
      poste: { label: poste.label },
      company: { legalName: this.users.companyLegalNameOf(row.companyId) },
    };
  }
}
