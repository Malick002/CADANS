import { CERTIFICATIONS, certificationLabel } from './certifications';

describe('certificationLabel', () => {
  // La recommandation CNAM s'écrit « R489-5 », catégorie comprise. Sans le tiret, le libellé
  // se lit comme deux informations juxtaposées et ne correspond à aucune habilitation réelle.
  it('rend la catégorie collée au tiret, comme le libellé officiel', () => {
    expect(certificationLabel('CACES_R489_5')).toBe('CACES R489-5');
    expect(certificationLabel('CACES_R489_1B')).toBe('CACES R489-1B');
    expect(certificationLabel('CACES_R485_1')).toBe('CACES R485-1');
  });

  it("n'applique pas le format CACES à l'habilitation électrique", () => {
    expect(certificationLabel('HABILITATION_ELECTRIQUE')).toBe('Habilitation électrique');
  });

  // Le référentiel peut gagner un type avant que cette liste ne suive : afficher le code brut
  // reste préférable à une case vide.
  it('retombe sur la valeur brute pour un type inconnu', () => {
    expect(certificationLabel('CACES_R999_9')).toBe('CACES_R999_9');
  });

  it('couvre les 12 types de l’enum, sans doublon', () => {
    expect(CERTIFICATIONS).toHaveLength(12);
    expect(new Set(CERTIFICATIONS.map((c) => c.value)).size).toBe(12);
  });

  // Verrou sur la régression corrigée : plus aucun libellé CACES avec une espace avant la
  // catégorie.
  it('ne laisse aucun libellé CACES sans tiret', () => {
    const sansTiret = CERTIFICATIONS.filter((c) => /^CACES R\d{3} /.test(c.label));
    expect(sansTiret).toEqual([]);
  });
});
