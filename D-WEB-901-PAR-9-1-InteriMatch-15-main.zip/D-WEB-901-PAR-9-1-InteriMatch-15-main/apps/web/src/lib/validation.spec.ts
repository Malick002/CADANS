import {
  compacterIdentifiant,
  isValidIban,
  isValidNir,
  validateBirthDate,
  validateIban,
  validateNir,
} from './validation';

// Ces règles existent en double (apps/api/src/worker-profile/identifiants.ts fait autorité).
// Le jeu d'essai est le même des deux côtés : si les deux implémentations divergent, l'un des
// deux fichiers de test tombe.
describe('NIR', () => {
  it('accepte une clé juste, y compris en Corse et pour un numéro temporaire', () => {
    expect(isValidNir('180127511600128')).toBe(true);
    expect(isValidNir('195052A12345628')).toBe(true);
    expect(isValidNir('790017512345646')).toBe(true);
  });

  it('refuse une clé fausse', () => {
    expect(isValidNir('180127511600129')).toBe(false);
  });

  it('accepte la forme espacée, telle qu’elle se lit sur une carte Vitale', () => {
    expect(validateNir('1 80 12 75 116 001 28')).toBeUndefined();
  });

  it('distingue le champ vide, la mauvaise longueur et la clé fausse', () => {
    expect(validateNir('')).toMatch(/Renseignez/);
    expect(validateNir('180127511600')).toMatch(/15 chiffres/);
    expect(validateNir('180127511600129')).toMatch(/clé/);
  });
});

describe('IBAN', () => {
  it('accepte un IBAN français valide, espacé ou non', () => {
    expect(isValidIban('FR1420041010050500013M02606')).toBe(true);
    expect(validateIban('FR14 2004 1010 0505 0001 3M02 606')).toBeUndefined();
    // Saisi en minuscules : compacterIdentifiant remet en majuscules avant de valider.
    expect(validateIban('fr1420041010050500013m02606')).toBeUndefined();
  });

  it('refuse un caractère modifié et une longueur française fausse', () => {
    expect(validateIban('FR1420041010050500013M02607')).toMatch(/incorrect/);
    expect(validateIban('FR142004101005050001302606')).toMatch(/incorrect/);
  });

  it('refuse un champ vide', () => {
    expect(validateIban('')).toMatch(/Renseignez/);
  });
});

describe('compacterIdentifiant', () => {
  it('retire espaces et tirets et passe en majuscules', () => {
    expect(compacterIdentifiant('fr14 2004-1010 0505 0001 3m02 606')).toBe(
      'FR1420041010050500013M02606',
    );
  });
});

describe('validateBirthDate', () => {
  const aujourdhui = new Date('2026-09-23T00:00:00Z');

  it('accepte une date réelle et un âge de travail', () => {
    expect(validateBirthDate('1980-12-04', aujourdhui)).toBeUndefined();
    // Pile 16 ans le jour même.
    expect(validateBirthDate('2010-09-23', aujourdhui)).toBeUndefined();
  });

  it('refuse une date qui n’existe pas', () => {
    expect(validateBirthDate('1985-02-31', aujourdhui)).toMatch(/n'existe pas/);
  });

  it('refuse un âge en dessous du minimum légal, à un jour près', () => {
    expect(validateBirthDate('2010-09-24', aujourdhui)).toMatch(/16 ans/);
    expect(validateBirthDate('2020-05-12', aujourdhui)).toMatch(/16 ans/);
  });

  it('refuse un siècle tapé de travers', () => {
    expect(validateBirthDate('1080-12-04', aujourdhui)).toMatch(/Vérifiez/);
  });

  it('refuse un champ vide ou un format libre', () => {
    expect(validateBirthDate('', aujourdhui)).toMatch(/Renseignez/);
    expect(validateBirthDate('04/12/1980', aujourdhui)).toMatch(/format/);
  });
});
