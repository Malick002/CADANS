// L'API sérialise les montants en chaîne (Decimal Prisma) : « 13.5 », « 12.8 ». Affiché tel
// quel, ça donne « 13.5 €/h » — point décimal anglais et centimes tronqués, là où un
// bulletin de paie français écrit « 13,50 € ». Un jury le voit, un intérimaire aussi.
export function tauxHoraire(valeur: string | number): string {
  const nombre = typeof valeur === 'number' ? valeur : Number.parseFloat(valeur);
  if (!Number.isFinite(nombre)) {
    return String(valeur);
  }
  return nombre.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Montant en euros sans décimales (« 2 206 »), pour citer un salaire mensuel ou annuel lu
// dans une offre France Travail. Les centimes n'y apportent rien et alourdissent la phrase.
//
// À savoir : en `fr-FR`, Intl sépare les milliers par une espace FINE INSÉCABLE (U+202F).
// C'est voulu — c'est la typographie française — mais une comparaison de chaînes qui écrit
// une espace ordinaire ne correspondra pas.
export function montantEntier(valeur: number): string {
  if (!Number.isFinite(valeur)) {
    return String(valeur);
  }
  return valeur.toLocaleString('fr-FR', { maximumFractionDigits: 0 });
}
