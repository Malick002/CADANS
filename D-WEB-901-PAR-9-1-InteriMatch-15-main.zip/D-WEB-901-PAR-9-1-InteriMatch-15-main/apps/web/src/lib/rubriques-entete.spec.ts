import { RUBRIQUES } from './rubriques-entete';

describe('RUBRIQUES', () => {
  it('ne propose que des pages du site', () => {
    expect(RUBRIQUES.map((rubrique) => rubrique.libelle)).toEqual([
      'Missions',
      'Comment ça marche',
      'Qui sommes-nous',
    ]);
  });

  it('ne renvoie plus vers l’inscription : les boutons de compte s’en chargent', () => {
    expect(RUBRIQUES.some((rubrique) => rubrique.href.startsWith('/inscription'))).toBe(false);
  });
});
