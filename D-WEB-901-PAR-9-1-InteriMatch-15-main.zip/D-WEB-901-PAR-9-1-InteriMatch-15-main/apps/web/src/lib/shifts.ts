// Miroir de l'enum Prisma Shift (apps/api/prisma/schema.prisma). Les horaires entre parenthèses
// sont indicatifs, pour l'affichage seulement : la donnée stockée est le créneau, pas l'horaire.
export const SHIFTS = [
  { value: 'MATIN', label: 'Matin (6h – 14h)' },
  { value: 'APRES_MIDI', label: 'Après-midi (14h – 22h)' },
  { value: 'NUIT', label: 'Nuit (22h – 6h)' },
  { value: 'JOURNEE', label: 'Journée (8h – 17h)' },
] as const;

export function shiftLabel(value: string): string {
  return SHIFTS.find((shift) => shift.value === value)?.label ?? value;
}
