import { bilanPrefill, enumerer, mentionRemuneration, PrefillOffre } from './prefill-offre';

const BASE: PrefillOffre = {
  reference: '214GWTK',
  intituleOffre: 'Cariste (H/F)',
  urlOffre: 'https://candidat.francetravail.fr/offres/recherche/detail/214GWTK',
  valeurs: {},
};

// Formatage identique à celui de l'écran (lib/montants.ts), injecté pour que la mention
// reste testable sans dépendre de la locale du poste qui lance les tests.
//
// PIÈGE : en `fr-FR`, Intl sépare les milliers par une ESPACE FINE INSÉCABLE (U+202F), pas
// par une espace ordinaire. « 2 206 » écrit à la main dans un test ne correspond donc pas au
// « 2 206 » produit ici. Les attentes ci-dessous rappellent le formateur plutôt que de
// recopier le nombre.
const montant = (valeur: number): string =>
  valeur.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 });

describe('bilanPrefill', () => {
  // Cas réel : l'offre 214GWTK, dont le créneau est un 3x8 que l'API ne traduit pas.
  it('sépare ce qui est repris de ce qui reste obligatoire', () => {
    const bilan = bilanPrefill({
      ...BASE,
      valeurs: {
        posteCode: '11679',
        siteLabel: '57 - Sarrebourg',
        postalCode: '57400',
        hourlyRate: '13.00',
        description: 'Préparation de commandes.',
      },
      remuneration: {
        libelle: 'Horaire de 13.0 Euros',
        estimation: {
          taux: '13.00',
          periode: 'horaire',
          montant: 13,
          fourchette: false,
          heuresHebdo: 35,
          dureeLue: true,
        },
      },
    });

    expect(bilan.repris).toEqual([
      'l’intitulé du poste',
      'le site',
      'le code postal',
      'la rémunération',
      'la description',
    ]);
    expect(bilan.aSaisir).toEqual([
      'la date de début',
      'la date de fin',
      'le créneau',
      'le motif du recours',
    ]);
  });

  // Le point de fond : un taux converti d'un salaire mensuel n'est PAS une donnée de
  // l'offre. Le laisser dans « repris de l'offre » ferait dire à l'annonce un taux horaire
  // qu'elle n'énonce nulle part.
  it('sort un taux estimé de « repris de l’offre » et le met à vérifier', () => {
    const bilan = bilanPrefill({
      ...BASE,
      valeurs: { posteCode: '11679', hourlyRate: '14.55' },
      remuneration: {
        libelle: 'Mensuel de 2206.0 Euros',
        estimation: {
          taux: '14.55',
          periode: 'mensuel',
          montant: 2206,
          fourchette: false,
          heuresHebdo: 35,
          dureeLue: true,
        },
      },
    });

    expect(bilan.repris).not.toContain('la rémunération');
    expect(bilan.aVerifier).toContain('la rémunération, estimée et non reprise de l’offre');
    // Le champ est rempli : il ne doit pas non plus apparaître comme restant à saisir.
    expect(bilan.aSaisir).not.toContain('la rémunération');
  });

  it('garde un taux horaire dans « repris de l’offre », lui n’est pas estimé', () => {
    const bilan = bilanPrefill({
      ...BASE,
      valeurs: { hourlyRate: '12.31' },
      remuneration: {
        libelle: 'Horaire de 12.31 Euros à 12.74 Euros',
        estimation: {
          taux: '12.31',
          periode: 'horaire',
          montant: 12.31,
          fourchette: true,
          heuresHebdo: 38,
          dureeLue: true,
        },
      },
    });

    expect(bilan.repris).toContain('la rémunération');
    expect(bilan.aVerifier).toHaveLength(1);
  });

  it('réclame la rémunération quand le format du salaire n’est pas reconnu', () => {
    const bilan = bilanPrefill({
      ...BASE,
      valeurs: { posteCode: '11679' },
      remuneration: { libelle: 'Selon profil' },
    });

    expect(bilan.aSaisir).toContain('la rémunération');
    expect(bilan.aVerifier).toHaveLength(1);
  });

  // La description est facultative : son absence ne doit pas apparaître comme un manque,
  // sinon le bilan réclame un champ qui n'empêche pas de publier.
  it('ne réclame jamais la description', () => {
    expect(bilanPrefill(BASE).aSaisir).not.toContain('la description');
  });

  it('annonce tout comme restant à saisir quand l’offre n’a rien donné', () => {
    expect(bilanPrefill(BASE).repris).toEqual([]);
    expect(bilanPrefill(BASE).aSaisir).toHaveLength(8);
  });

  it('traite une valeur vide ou blanche comme non remplie', () => {
    const bilan = bilanPrefill({ ...BASE, valeurs: { siteLabel: '   ', postalCode: '' } });
    expect(bilan.repris).toEqual([]);
    expect(bilan.aSaisir).toContain('le site');
    expect(bilan.aSaisir).toContain('le code postal');
  });

  it('rend une liste vide quand tous les obligatoires sont remplis', () => {
    const bilan = bilanPrefill({
      ...BASE,
      valeurs: {
        posteCode: '11679',
        siteLabel: 'Site',
        postalCode: '57400',
        startDate: '2026-10-05',
        endDate: '2026-11-05',
        shift: 'JOURNEE',
        motifRecours: 'ACCROISSEMENT_TEMPORAIRE',
        hourlyRate: '13.00',
      } as never,
    });
    expect(bilan.aSaisir).toEqual([]);
  });

  // Les habilitations ne viennent jamais de l'offre, quelle que soit la rémunération.
  it('signale toujours les habilitations comme à vérifier', () => {
    expect(bilanPrefill(BASE).aVerifier[0]).toContain('habilitations');
  });
});

describe('mentionRemuneration', () => {
  it('cite le libellé de l’offre pour un taux horaire simple', () => {
    const mention = mentionRemuneration(
      {
        libelle: 'Horaire de 13.0 Euros',
        estimation: {
          taux: '13.00',
          periode: 'horaire',
          montant: 13,
          fourchette: false,
          heuresHebdo: 35,
          dureeLue: true,
        },
      },
      montant,
    );

    expect(mention).toBe('L’offre indique « Horaire de 13.0 Euros ».');
    expect(mention).not.toMatch(/estim/i);
  });

  it('signale qu’une fourchette a été ramenée à sa borne basse', () => {
    const mention = mentionRemuneration(
      {
        libelle: 'Horaire de 12.31 Euros à 12.74 Euros',
        estimation: {
          taux: '12.31',
          periode: 'horaire',
          montant: 12.31,
          fourchette: true,
          heuresHebdo: 38,
          dureeLue: true,
        },
      },
      montant,
    );

    expect(mention).toContain('borne basse');
  });

  // Exigence centrale : un taux converti ne doit jamais passer pour une donnée de l'offre.
  // La mention dit le montant d'origine, la base de conversion, et « à vérifier ».
  it('explique d’où vient un taux converti d’un salaire mensuel', () => {
    const mention = mentionRemuneration(
      {
        libelle: 'Mensuel de 2206.0 Euros',
        estimation: {
          taux: '13.40',
          periode: 'mensuel',
          montant: 2206,
          fourchette: false,
          heuresHebdo: 38,
          dureeLue: true,
        },
      },
      montant,
    );

    expect(mention).toContain(`estimé à partir d’un salaire mensuel de ${montant(2206)} €`);
    // La base citée est celle de l'offre, pas 35 h : c'est ce qui rend l'estimation
    // vérifiable par l'entreprise.
    expect(mention).toContain('base 38 h/semaine, celle de l’offre');
    expect(mention).toContain('à vérifier');
  });

  it('dit que la base est un repli quand l’offre ne précise pas de durée', () => {
    const mention = mentionRemuneration(
      {
        libelle: 'Mensuel de 2206.0 Euros',
        estimation: {
          taux: '14.55',
          periode: 'mensuel',
          montant: 2206,
          fourchette: false,
          heuresHebdo: 35,
          dureeLue: false,
        },
      },
      montant,
    );

    expect(mention).toContain('base 35 h/semaine, l’offre n’en précisant aucune');
  });

  // « 38H45/semaine » existe dans l'échantillon : 38,75 h, écrit à la française.
  it('écrit une durée à minutes avec une virgule', () => {
    const mention = mentionRemuneration(
      {
        libelle: 'Mensuel de 2206.0 Euros',
        estimation: {
          taux: '13.14',
          periode: 'mensuel',
          montant: 2206,
          fourchette: false,
          heuresHebdo: 38.75,
          dureeLue: true,
        },
      },
      montant,
    );

    expect(mention).toContain('base 38,75 h/semaine');
  });

  it('cumule la fourchette et la conversion pour un annuel', () => {
    const mention = mentionRemuneration(
      {
        libelle: 'Annuel de 22405.0 Euros à 25000.0 Euros',
        estimation: {
          taux: '12.31',
          periode: 'annuel',
          montant: 22405,
          fourchette: true,
          heuresHebdo: 35,
          dureeLue: true,
        },
      },
      montant,
    );

    expect(mention).toContain('borne basse');
    expect(mention).toContain(`salaire annuel de ${montant(22405)} €`);
  });

  it('dit quoi faire quand le format n’est pas reconnu', () => {
    const mention = mentionRemuneration({ libelle: 'Selon profil' }, montant);

    expect(mention).toContain('« Selon profil »');
    expect(mention).toContain('saisissez la rémunération horaire');
  });
});

describe('enumerer', () => {
  it('énumère à la française', () => {
    expect(enumerer(['le site'])).toBe('le site');
    expect(enumerer(['le site', 'le code postal'])).toBe('le site et le code postal');
    expect(enumerer(['a', 'b', 'c'])).toBe('a, b et c');
  });

  it('rend une chaîne vide sans élément', () => {
    expect(enumerer([])).toBe('');
  });
});
