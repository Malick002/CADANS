// Page d'accueil de chaque rôle après connexion.
//
// LE DÉFAUT QU'ELLE CORRIGE : la redirection était une suite de `if` sur `COMPANY` et
// `WORKER`, et le type `Account` du formulaire de connexion ne déclarait que ces deux rôles.
// TypeScript ne pouvait donc pas signaler la branche manquante quand le rôle ADMIN est
// apparu. Résultat : un agent CADANS se connectait, sa session s'ouvrait, le formulaire
// disparaissait — et rien ne le remplaçait. Il restait devant une carte vide.
//
// Un `Record` exhaustif à la place : ajouter un rôle sans lui donner d'accueil ne compile
// plus. C'est le compilateur qui tient la règle, pas la vigilance du relecteur.

export type RoleCompte = 'COMPANY' | 'WORKER' | 'ADMIN';

const ACCUEIL: Record<RoleCompte, string> = {
  COMPANY: '/entreprise/missions',
  WORKER: '/interimaire/matches',
  ADMIN: '/admin',
};

export function accueilDuRole(role: RoleCompte): string {
  return ACCUEIL[role];
}
