// Rubriques de la barre de navigation publique.
//
// La liste vit ici, et non dans le composant : `EnteteSite` est un composant client que le
// harnais de test (environnement Node, fichiers `.spec.ts`) ne sait pas rendre.
//
// Elle ne contient que des **pages** du site. Les deux entrées « Pour les entreprises » et
// « Pour les intérimaires » en ont été retirées : elles menaient toutes deux à l'inscription,
// que les boutons de compte proposent déjà à droite de la barre, et elles n'avaient aucun
// sens pour un visiteur déjà connecté. Les deux parcours restent accessibles depuis les
// appels à l'action de l'accueil et de la page « Qui sommes-nous », qui présélectionnent
// chacun leur profil.

export interface Rubrique {
  href: string;
  libelle: string;
}

export const RUBRIQUES: Rubrique[] = [
  // « Missions » est la porte d'entrée des annonces publiques, la seule page indexable qui
  // ne soit pas la vitrine.
  { href: '/missions', libelle: 'Missions' },
  { href: '/#comment-ca-marche', libelle: 'Comment ça marche' },
  { href: '/qui-sommes-nous', libelle: 'Qui sommes-nous' },
];
