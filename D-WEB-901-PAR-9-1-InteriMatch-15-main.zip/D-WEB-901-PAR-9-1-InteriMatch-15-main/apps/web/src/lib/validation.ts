// Validation des formulaires d'inscription côté navigateur.
//
// Ces règles reproduisent celles de l'API (apps/api/src/auth/dto) pour afficher chaque erreur
// à côté de son champ, ce que l'API ne permet pas : elle renvoie une liste de messages non
// rattachés aux champs. L'API reste l'autorité : une règle modifiée côté API doit l'être ici.

export type FieldErrors<K extends string> = Partial<Record<K, string>>;

export const PASSWORD_MIN_LENGTH = 12;
export const PASSWORD_MAX_LENGTH = 128;

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const POSTAL_CODE_PATTERN = /^\d{5}$/;
const PHONE_PATTERN = /^(?:0|\+33)[1-9]\d{8}$/;
const NAF_CODE_PATTERN = /^\d{2}\.\d{2}[A-Z]$/;

export const required = (value: string, label: string): string | undefined =>
  value.trim() === '' ? `Renseignez ${label}.` : undefined;

export const maxLength = (value: string, max: number): string | undefined =>
  value.trim().length > max ? `${max} caractères maximum.` : undefined;

export function validateEmail(value: string): string | undefined {
  if (value.trim() === '') {
    return 'Renseignez votre adresse email.';
  }
  return EMAIL_PATTERN.test(value.trim())
    ? undefined
    : "L'adresse email n'est pas valide. Exemple : nom@entreprise.fr";
}

// Règle CNIL appliquée par l'API : 12 caractères, minuscule, majuscule, chiffre, spécial.
export function passwordRules(value: string): { label: string; ok: boolean }[] {
  return [
    {
      label: `au moins ${PASSWORD_MIN_LENGTH} caractères`,
      ok: value.length >= PASSWORD_MIN_LENGTH,
    },
    { label: 'une lettre minuscule', ok: /[a-z]/.test(value) },
    { label: 'une lettre majuscule', ok: /[A-Z]/.test(value) },
    { label: 'un chiffre', ok: /\d/.test(value) },
    { label: 'un caractère spécial', ok: /[^A-Za-z0-9]/.test(value) },
  ];
}

export function validatePassword(value: string): string | undefined {
  if (value === '') {
    return 'Choisissez un mot de passe.';
  }
  if (value.length > PASSWORD_MAX_LENGTH) {
    return `${PASSWORD_MAX_LENGTH} caractères maximum.`;
  }
  const missing = passwordRules(value).filter((rule) => !rule.ok);
  return missing.length === 0
    ? undefined
    : `Le mot de passe doit contenir ${missing.map((rule) => rule.label).join(', ')}.`;
}

// Connexion : on vérifie seulement qu'un mot de passe est saisi. Le re-valider sur les règles
// de création dirait à un visiteur quels mots de passe la plateforme accepte, et bloquerait un
// compte créé avant un durcissement de ces règles. C'est l'API qui tranche.
export function validateCurrentPassword(value: string): string | undefined {
  return value === '' ? 'Saisissez votre mot de passe.' : undefined;
}

export function validatePostalCode(value: string): string | undefined {
  if (value.trim() === '') {
    return 'Renseignez le code postal.';
  }
  return POSTAL_CODE_PATTERN.test(value.trim())
    ? undefined
    : 'Le code postal doit comporter 5 chiffres. Exemple : 69007';
}

// Facultatif : validé seulement s'il est renseigné. Espaces acceptés, comme par l'API.
export function validatePhone(value: string): string | undefined {
  const compact = value.replace(/\s+/g, '');
  if (compact === '') {
    return undefined;
  }
  return PHONE_PATTERN.test(compact)
    ? undefined
    : "Le numéro de téléphone n'est pas valide. Exemple : 06 12 34 56 78";
}

export function validateNafCode(value: string): string | undefined {
  if (value.trim() === '') {
    return 'Renseignez le code NAF.';
  }
  return NAF_CODE_PATTERN.test(value.trim())
    ? undefined
    : 'Le code NAF doit être au format 52.10B (deux chiffres, un point, deux chiffres, une lettre).';
}

// Même algorithme que l'API (apps/api/src/auth/dto/validation.ts) : clé de Luhn, avec la
// dérogation de La Poste dont la somme des chiffres doit être un multiple de 5.
const LA_POSTE_SIREN = '356000000';

export function isValidSiret(value: string): boolean {
  if (!/^\d{14}$/.test(value)) {
    return false;
  }
  if (value.startsWith(LA_POSTE_SIREN)) {
    return [...value].reduce((total, digit) => total + Number(digit), 0) % 5 === 0;
  }
  const sum = [...value].reverse().reduce((total, char, index) => {
    let digit = Number(char);
    if (index % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    return total + digit;
  }, 0);
  return sum % 10 === 0;
}

export function validateSiret(value: string): string | undefined {
  const compact = value.replace(/\s+/g, '');
  if (compact === '') {
    return 'Renseignez le numéro SIRET.';
  }
  if (!/^\d{14}$/.test(compact)) {
    return 'Le SIRET doit comporter 14 chiffres. Exemple : 732 829 320 00074';
  }
  return isValidSiret(compact)
    ? undefined
    : "Ce numéro SIRET n'existe pas : vérifiez les chiffres saisis.";
}

// Acceptation des CGU et de la politique de confidentialité, obligatoire à l'inscription.
// L'API la refuse aussi (CredentialsDto) et enregistre la date d'acceptation : la case n'est
// pas la seule barrière.
export function validateConsent(value: string): string | undefined {
  return value === ''
    ? "Vous devez accepter les conditions générales d'utilisation et la politique de confidentialité."
    : undefined;
}

// --- Informations d'embauche ----------------------------------------------------------
//
// Mêmes règles que l'API (apps/api/src/worker-profile/identifiants.ts et
// dto/save-informations-embauche.dto.ts). L'API reste l'autorité : elle revalide tout.
// Ce qu'on gagne ici, c'est de dire à l'intérimaire QUEL champ est en cause — et de ne pas
// envoyer un NIR sur le réseau pour apprendre qu'il manquait un chiffre.

// Espaces et tirets de mise en forme : un RIB se recopie par blocs de quatre, un NIR aussi.
export function compacterIdentifiant(value: string): string {
  return value.replace(/[\s-]/g, '').toUpperCase();
}

const NIR_PATTERN = /^[1278]\d{4}(?:\d{2}|2[AB])\d{6}(\d{2})$/;
const CORSE: Record<string, string> = { '2A': '19', '2B': '18' };

export function isValidNir(value: string): boolean {
  const match = NIR_PATTERN.exec(value);
  if (!match) {
    return false;
  }
  const numero = value.slice(0, 13).replace(/2[AB]/, (corse) => CORSE[corse]);
  return 97n - (BigInt(numero) % 97n) === BigInt(match[1]);
}

export function validateNir(value: string): string | undefined {
  const compact = compacterIdentifiant(value);
  if (compact === '') {
    return 'Renseignez votre numéro de sécurité sociale.';
  }
  if (compact.length !== 15) {
    return 'Le numéro de sécurité sociale comporte 15 chiffres, clé comprise.';
  }
  return isValidNir(compact)
    ? undefined
    : 'Ce numéro de sécurité sociale est incorrect : vérifiez les chiffres et la clé.';
}

const IBAN_PATTERN = /^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/;
const IBAN_LONGUEURS: Record<string, number> = { FR: 27 };

export function isValidIban(value: string): boolean {
  if (!IBAN_PATTERN.test(value)) {
    return false;
  }
  const attendue = IBAN_LONGUEURS[value.slice(0, 2)];
  if (attendue !== undefined && value.length !== attendue) {
    return false;
  }
  const reordonne = value.slice(4) + value.slice(0, 4);
  const numerique = [...reordonne]
    .map((caractere) =>
      /[A-Z]/.test(caractere) ? String(caractere.charCodeAt(0) - 55) : caractere,
    )
    .join('');
  return BigInt(numerique) % 97n === 1n;
}

export function validateIban(value: string): string | undefined {
  const compact = compacterIdentifiant(value);
  if (compact === '') {
    return 'Renseignez votre IBAN.';
  }
  return isValidIban(compact)
    ? undefined
    : 'Cet IBAN est incorrect : vérifiez les caractères saisis. Exemple : FR76 3000 6000 0112 3456 7890 189';
}

// Bornes de l'API : 16 ans (âge minimum légal pour travailler, art. L. 4153-1) et 100 ans.
export const AGE_MINIMUM = 16;
export const AGE_MAXIMUM = 100;

export function validateBirthDate(value: string, aujourdhui = new Date()): string | undefined {
  if (value.trim() === '') {
    return 'Renseignez votre date de naissance.';
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return 'La date de naissance doit être au format JJ/MM/AAAA.';
  }
  const date = new Date(`${value}T00:00:00Z`);
  // `new Date('1985-02-31')` ne lève pas : il glisse au 3 mars. On compare donc la date
  // reconstruite à celle qui a été saisie.
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) {
    return "Cette date n'existe pas.";
  }
  let age = aujourdhui.getUTCFullYear() - date.getUTCFullYear();
  const anniversairePasse =
    aujourdhui.getUTCMonth() > date.getUTCMonth() ||
    (aujourdhui.getUTCMonth() === date.getUTCMonth() &&
      aujourdhui.getUTCDate() >= date.getUTCDate());
  if (!anniversairePasse) {
    age -= 1;
  }
  if (age < AGE_MINIMUM) {
    return `Vous devez avoir au moins ${AGE_MINIMUM} ans pour signer un contrat de mission.`;
  }
  if (age > AGE_MAXIMUM) {
    return 'Vérifiez votre date de naissance.';
  }
  return undefined;
}

// Garde seulement les erreurs effectivement présentes.
export function collectErrors<K extends string>(
  checks: Record<K, string | undefined>,
): FieldErrors<K> {
  const errors: FieldErrors<K> = {};
  for (const key of Object.keys(checks) as K[]) {
    const message = checks[key];
    if (message) {
      errors[key] = message;
    }
  }
  return errors;
}
