// Lecture de la session côté serveur (Server Component) : le serveur Next.js n'a pas les
// cookies du navigateur, il faut transmettre celui de la requête entrante (docs/api.md,
// « Côté front »).

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';

const SESSION_COOKIE = 'cadans_session';

export interface SessionAccount {
  id: string;
  email: string;
  role: 'COMPANY' | 'WORKER' | 'ADMIN';
  // Le contact de l'entreprise signe le contrat de mise à disposition : c'est son nom que
  // l'API attend, il doit donc être lisible côté site.
  company: { legalName: string; contactFirstName: string; contactLastName: string } | null;
  // `/auth/me` rend le profil complet (PublicAccount côté API) : la commune et le code
  // postal déclarés à l'inscription pré-remplissent l'adresse des informations d'embauche.
  worker: { firstName: string; lastName: string; postalCode: string; city: string } | null;
}

async function sessionCookieHeader(): Promise<Record<string, string>> {
  const session = (await cookies()).get(SESSION_COOKIE);
  return session ? { Cookie: `${SESSION_COOKIE}=${session.value}` } : {};
}

function apiUrl(path: string, query?: Record<string, string>): string {
  const base = process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? '';
  const suffix = query ? `?${new URLSearchParams(query).toString()}` : '';
  return `${base}${path}${suffix}`;
}

// Compte de la session, ou null si absente/expirée : à la page appelante de rediriger.
export async function getSessionAccount(): Promise<SessionAccount | null> {
  const response = await fetch(apiUrl('/auth/me'), {
    headers: await sessionCookieHeader(),
    cache: 'no-store',
  });
  return response.ok ? ((await response.json()) as SessionAccount) : null;
}

// GET authentifié depuis un Server Component (cookie transmis à la main, voir plus haut).
export async function serverGet<T>(path: string, query?: Record<string, string>): Promise<T> {
  const response = await fetch(apiUrl(path, query), {
    headers: await sessionCookieHeader(),
    cache: 'no-store',
  });
  if (!response.ok) {
    throw new Error(`Échec de l'appel API ${path} (${response.status})`);
  }
  return response.json() as Promise<T>;
}

// Même geste que le layout qui protège la page (redirect vers /connexion) : le layout et la
// page peuvent démarrer leurs requêtes en parallèle (Server Components), donc un appel de la
// page peut échouer avant que le redirect du layout n'ait pris effet — une session expirée
// entre les deux, par exemple. Cette variante rattrape ce cas plutôt que de laisser planter
// la page.
export async function serverGetOrRedirect<T>(
  path: string,
  query?: Record<string, string>,
): Promise<T> {
  try {
    return await serverGet<T>(path, query);
  } catch {
    redirect('/connexion');
  }
}
