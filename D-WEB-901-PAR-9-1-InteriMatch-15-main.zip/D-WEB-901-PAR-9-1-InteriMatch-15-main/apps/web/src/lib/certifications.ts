// Les 12 habilitations du référentiel (apps/api/prisma/schema.prisma, enum CertificationType).
//
// Le tiret des libellés n'est pas cosmétique : la recommandation CNAM s'écrit « R489-5 »,
// catégorie comprise. « CACES R489 5 » se lit comme deux informations juxtaposées et ne
// correspond à aucun libellé officiel — un cariste ne reconnaît pas son habilitation.
// Duplication volontaire, comme apps/web/src/lib/validation.ts le fait déjà pour les règles de
// l'API : toute évolution de l'enum doit être répercutée ici.
export const CERTIFICATIONS = [
  { value: 'CACES_R489_1A', label: 'CACES R489-1A' },
  { value: 'CACES_R489_1B', label: 'CACES R489-1B' },
  { value: 'CACES_R489_2A', label: 'CACES R489-2A' },
  { value: 'CACES_R489_2B', label: 'CACES R489-2B' },
  { value: 'CACES_R489_3', label: 'CACES R489-3' },
  { value: 'CACES_R489_4', label: 'CACES R489-4' },
  { value: 'CACES_R489_5', label: 'CACES R489-5' },
  { value: 'CACES_R489_6', label: 'CACES R489-6' },
  { value: 'CACES_R489_7', label: 'CACES R489-7' },
  { value: 'CACES_R485_1', label: 'CACES R485-1' },
  { value: 'CACES_R485_2', label: 'CACES R485-2' },
  { value: 'HABILITATION_ELECTRIQUE', label: 'Habilitation électrique' },
] as const;

export function certificationLabel(value: string): string {
  return CERTIFICATIONS.find((cert) => cert.value === value)?.label ?? value;
}
