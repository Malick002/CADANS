// Miroir de l'enum Prisma MotifRecours (apps/api/prisma/schema.prisma) et de
// apps/api/src/missions/motif-recours-label.ts. Même convention que shifts.ts et
// certifications.ts (CLAUDE.md) : le site ne peut pas importer depuis l'API.
//
// Les libellés reprennent la formulation du Code du travail plutôt qu'une paraphrase : c'est
// la mention qui figure au contrat (art. L. 1251-43 1°), elle doit être reconnaissable.
export const MOTIFS_RECOURS = [
  { value: 'ACCROISSEMENT_TEMPORAIRE', label: 'Accroissement temporaire d’activité' },
  { value: 'REMPLACEMENT', label: 'Remplacement d’un salarié absent' },
  { value: 'SAISONNIER', label: 'Emploi à caractère saisonnier' },
  { value: 'USAGE', label: 'Emploi pour lequel il est d’usage de ne pas recourir au CDI' },
] as const;

// Seule valeur qui exige de nommer le salarié remplacé et sa qualification.
export const MOTIF_REMPLACEMENT = 'REMPLACEMENT';

export function motifRecoursLabel(value: string): string {
  return MOTIFS_RECOURS.find((motif) => motif.value === value)?.label ?? value;
}
