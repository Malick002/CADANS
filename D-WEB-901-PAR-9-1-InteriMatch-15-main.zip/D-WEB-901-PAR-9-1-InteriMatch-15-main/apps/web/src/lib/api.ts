// Appels à l'API CADANS depuis le navigateur.
//
// La session est un cookie httpOnly posé par l'API : le JavaScript ne le lit jamais.
// `credentials: 'include'` est obligatoire sur chaque appel pour que le navigateur
// envoie et enregistre ce cookie (voir docs/api.md, « Côté front »).

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly messages: string[],
  ) {
    super(messages.join(' '));
  }
}

// Erreur réseau, API arrêtée ou adresse mal configurée : aucune réponse HTTP.
export const UNREACHABLE_STATUS = 0;

function apiUrl(path: string): string {
  // Variable lue dans le .env racine par dotenv-cli (scripts de package.json), et inlinée
  // au build par Next.js. En production, fournie par l'hébergeur.
  const base = process.env.NEXT_PUBLIC_API_URL;
  if (!base) {
    throw new ApiError(UNREACHABLE_STATUS, [
      "L'adresse de l'API n'est pas configurée (NEXT_PUBLIC_API_URL).",
    ]);
  }
  return `${base.replace(/\/$/, '')}${path}`;
}

export async function postJson<T>(path: string, body: unknown): Promise<T> {
  return handle<T>(
    fetch(apiUrl(path), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(body),
    }),
  );
}

export async function putJson<T>(path: string, body: unknown): Promise<T> {
  return handle<T>(
    fetch(apiUrl(path), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(body),
    }),
  );
}

// PATCH : modification partielle, là où PUT remplace la ressource entière. Le changement de
// statut d'une mission n'en touche qu'un champ — et le seul appelant, « retenir un candidat »,
// n'envoie que l'intérimaire choisi.
export async function patchJson<T>(path: string, body: unknown): Promise<T> {
  return handle<T>(
    fetch(apiUrl(path), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(body),
    }),
  );
}

// Query params : uniquement des valeurs simples (l'API n'attend que ça sur les filtres).
export async function getJson<T>(
  path: string,
  query?: Record<string, string | undefined>,
): Promise<T> {
  const params = query
    ? Object.entries(query).filter((entry): entry is [string, string] => entry[1] !== undefined)
    : [];
  const suffix = params.length > 0 ? `?${new URLSearchParams(params).toString()}` : '';

  return handle<T>(fetch(apiUrl(`${path}${suffix}`), { credentials: 'include' }));
}

async function handle<T>(fetching: Promise<Response>): Promise<T> {
  let response: Response;
  try {
    response = await fetching;
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    throw new ApiError(UNREACHABLE_STATUS, [
      'Le serveur ne répond pas. Vérifiez votre connexion et réessayez.',
    ]);
  }

  const payload: unknown = await response.json().catch(() => null);

  if (!response.ok) {
    throw new ApiError(response.status, errorMessages(payload));
  }

  return payload as T;
}

// L'API renvoie `message` sous forme de chaîne, ou de tableau pour une erreur 400.
function errorMessages(payload: unknown): string[] {
  if (typeof payload === 'object' && payload !== null && 'message' in payload) {
    const { message } = payload;
    if (Array.isArray(message)) {
      return message.map(String);
    }
    if (typeof message === 'string') {
      return [message];
    }
  }
  return ['Une erreur inattendue est survenue. Réessayez dans quelques instants.'];
}
