// Préremplissage d'une mission depuis une offre France Travail : ce que l'API renvoie, et le
// bilan « repris / reste à saisir / à vérifier » affiché à l'entreprise.
//
// Le bilan n'est pas cosmétique. Une offre n'alimente que quatre à six champs sur onze : un
// formulaire qui a l'air rempli se relit mal, et l'entreprise publierait une mission sans
// dates ni motif de recours — les deux mentions que l'article L. 1251-43 impose au contrat.
// Dire noir sur blanc ce qui manque est ce qui empêche cette erreur.

// Champs de la mission qu'une offre peut alimenter (voir apps/api/src/missions/offre-prefill.ts).
export type ChampPrerempli =
  'posteCode' | 'siteLabel' | 'postalCode' | 'hourlyRate' | 'shift' | 'description';

export type PeriodeSalaire = 'horaire' | 'mensuel' | 'annuel';

export interface EstimationTaux {
  taux: string;
  periode: PeriodeSalaire;
  montant: number;
  fourchette: boolean;
  // Durée hebdomadaire ayant servi de base à la conversion, et si elle vient de l'offre ou
  // du repli à 35 h. Affichée : une estimation dont on ignore la base ne se vérifie pas.
  heuresHebdo: number;
  dureeLue: boolean;
}

export interface RemunerationOffre {
  // Libellé brut de l'offre, toujours présent. Affiché tel quel : c'est ce qui montre à
  // l'entreprise ce que la conversion laisse de côté (primes, paniers, IFM).
  libelle: string;
  // Absente quand le format n'est pas reconnu : le champ reste vide.
  estimation?: EstimationTaux;
}

export interface PrefillOffre {
  reference: string;
  intituleOffre: string;
  urlOffre: string;
  valeurs: Partial<Record<ChampPrerempli, string>>;
  remuneration?: RemunerationOffre;
}

// Libellés au format « le site », « les dates » : ils s'enchaînent dans une phrase.
const LIBELLES: Record<string, string> = {
  posteCode: 'l’intitulé du poste',
  siteLabel: 'le site',
  postalCode: 'le code postal',
  startDate: 'la date de début',
  endDate: 'la date de fin',
  shift: 'le créneau',
  motifRecours: 'le motif du recours',
  hourlyRate: 'la rémunération',
  description: 'la description',
};

// Obligatoires à la publication, dans l'ordre du formulaire. `description` en est absente :
// elle est facultative, et son absence n'empêche personne de publier.
const OBLIGATOIRES = [
  'posteCode',
  'siteLabel',
  'postalCode',
  'startDate',
  'endDate',
  'shift',
  'motifRecours',
  'hourlyRate',
] as const;

// Les habilitations ne viennent jamais de l'offre : aucune n'y figure dans un champ
// exploitable (mesuré dans docs/referentiel-matching.md). Ce qui est coché vient du poste retenu.
const HABILITATIONS_A_VERIFIER =
  'les habilitations, proposées d’après le poste et non d’après l’offre — celle-ci ne les ' +
  'porte dans aucun champ exploitable';

export interface BilanPrefill {
  repris: string[];
  aSaisir: string[];
  aVerifier: string[];
}

/**
 * Ce que l'offre a rempli, ce qu'il reste à saisir, et ce qui demande une relecture.
 *
 * Une clé absente des `valeurs` vaut « non rempli » : l'API omet les champs qu'elle n'a pas
 * pu déduire plutôt que de les renvoyer vides, précisément pour que ce calcul soit exact.
 *
 * La rémunération est le cas particulier : un taux CONVERTI d'un salaire mensuel ou annuel
 * n'est pas une donnée de l'offre, c'est une estimation de notre part. Il bascule donc de
 * « repris de l'offre » vers « à vérifier ». Le laisser dans la première liste reviendrait à
 * faire dire à l'offre un taux horaire qu'elle n'énonce nulle part.
 */
export function bilanPrefill(prefill: PrefillOffre): BilanPrefill {
  const { valeurs, remuneration } = prefill;
  const rempli = (champ: string): boolean =>
    Boolean(valeurs[champ as ChampPrerempli]?.toString().trim());

  const estime =
    remuneration?.estimation !== undefined && remuneration.estimation.periode !== 'horaire';

  return {
    repris: Object.keys(LIBELLES)
      .filter((champ) => rempli(champ) && !(champ === 'hourlyRate' && estime))
      .map((champ) => LIBELLES[champ]),
    aSaisir: OBLIGATOIRES.filter((champ) => !rempli(champ)).map((champ) => LIBELLES[champ]),
    aVerifier: [
      HABILITATIONS_A_VERIFIER,
      ...(estime ? ['la rémunération, estimée et non reprise de l’offre'] : []),
    ],
  };
}

// Mention affichée sous le champ de rémunération. Elle dit toujours ce que l'offre énonce,
// et — quand il y a eu conversion — de quel montant vient le taux proposé. Jamais de taux
// converti présenté comme une donnée de l'offre : c'est la règle de cette fonctionnalité.
export function mentionRemuneration(
  remuneration: RemunerationOffre,
  formaterMontant: (valeur: number) => string,
): string {
  const offreIndique = `L’offre indique « ${remuneration.libelle} ».`;
  const { estimation } = remuneration;

  if (!estimation) {
    return `${offreIndique} Ce format n’est pas reconnu : saisissez la rémunération horaire.`;
  }

  const borne = estimation.fourchette
    ? ' C’est la borne basse de la fourchette qui est reprise.'
    : '';

  if (estimation.periode === 'horaire') {
    return `${offreIndique}${borne}`;
  }

  const periode = estimation.periode === 'mensuel' ? 'mensuel' : 'annuel';
  // La base est citée telle qu'elle a servi, et l'on dit d'où elle vient. Un repli silencieux
  // sur 35 h donnerait une estimation invérifiable : l'entreprise ne saurait pas si la durée
  // de son offre a été prise en compte.
  const base = estimation.dureeLue
    ? `base ${formaterDuree(estimation.heuresHebdo)} h/semaine, celle de l’offre`
    : `base ${formaterDuree(estimation.heuresHebdo)} h/semaine, l’offre n’en précisant aucune`;

  return (
    `${offreIndique}${borne} Le taux proposé est estimé à partir d’un salaire ${periode} de ` +
    `${formaterMontant(estimation.montant)} €, ${base} — à vérifier.`
  );
}

// « 38,75 » plutôt que « 38.75 » : une durée hebdomadaire s'écrit avec une virgule, et les
// heures rondes (le cas de 449 offres sur 450) n'ont pas de décimale du tout.
function formaterDuree(heures: number): string {
  return heures.toLocaleString('fr-FR', { maximumFractionDigits: 2 });
}

// « le site, le code postal et la rémunération » : une énumération française, pas une liste
// à puces de trois éléments.
export function enumerer(elements: string[]): string {
  if (elements.length <= 1) {
    return elements[0] ?? '';
  }
  return `${elements.slice(0, -1).join(', ')} et ${elements.at(-1)}`;
}
