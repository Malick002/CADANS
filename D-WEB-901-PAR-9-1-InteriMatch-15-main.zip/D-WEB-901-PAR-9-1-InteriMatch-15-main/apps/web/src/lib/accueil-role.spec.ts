import { accueilDuRole, RoleCompte } from './accueil-role';

describe('accueilDuRole', () => {
  it.each([
    ['COMPANY', '/entreprise/missions'],
    ['WORKER', '/interimaire/matches'],
    ['ADMIN', '/admin'],
  ] as [RoleCompte, string][])('envoie %s vers %s', (role, attendu) => {
    expect(accueilDuRole(role)).toBe(attendu);
  });

  // Le défaut d'origine : ADMIN n'avait aucune destination, le formulaire de connexion
  // disparaissait sans rien afficher à la place. Un accueil défini pour CHAQUE rôle est la
  // seule garantie qu'aucune connexion ne finisse sur un écran vide.
  it('donne une destination à tous les rôles, sans exception', () => {
    const roles: RoleCompte[] = ['COMPANY', 'WORKER', 'ADMIN'];

    for (const role of roles) {
      expect(accueilDuRole(role)).toMatch(/^\/\w/);
    }
    expect(new Set(roles.map(accueilDuRole)).size).toBe(roles.length);
  });
});
