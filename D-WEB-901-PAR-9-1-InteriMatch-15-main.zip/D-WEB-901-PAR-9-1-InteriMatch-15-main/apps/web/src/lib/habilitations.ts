// Validité d'une habilitation, côté écran.
//
// RÈGLE MIROIR de `certificationValide` (apps/api/src/matching/matching.service.ts) : une
// habilitation sans date reste valide, sinon elle l'est JUSQU'À LA FIN de son jour
// d'expiration, HEURE DE PARIS. Duplication assumée — il n'y a pas de paquet partagé dans ce
// monorepo (`workspaces: apps/*`), et `lib/validation.ts` reproduit déjà les règles des DTO
// de la même façon. Ce qui empêche la dérive, ce n'est pas du code commun, c'est le TEST DE
// BORD écrit à l'identique des deux côtés : le jour même compte encore, et la bascule tombe
// à minuit heure de Paris.
//
// Si les deux divergeaient, l'écran afficherait « valide » sur une habilitation que le
// matching écarte, et l'intérimaire ne comprendrait plus pourquoi il n'a plus de missions.
// C'est exactement le défaut que cet affichage corrige : il ne faut pas en créer le
// symétrique.

// CADANS est une plateforme française : la date métier est celle de Paris, pas celle d'UTC.
// L'écart n'est pas théorique — nos missions du matin commencent à 6 h. `Intl` gère le
// passage heure d'été / heure d'hiver : la bascule tombe à 22:00 UTC en septembre et à
// 23:00 UTC en janvier, soit minuit à Paris dans les deux cas.
const JOUR_PARIS = new Intl.DateTimeFormat('fr-FR', {
  timeZone: 'Europe/Paris',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});

// « 2026-09-23 » : zéros compris, donc comparable directement par `<`.
function jourParis(instant: Date): string {
  const parts = Object.fromEntries(
    JOUR_PARIS.formatToParts(instant).map((part) => [part.type, part.value]),
  );
  return `${parts.year}-${parts.month}-${parts.day}`;
}

const DATE_ISO = /^\d{4}-\d{2}-\d{2}$/;

/**
 * `expiresAt` arrive déjà au format « AAAA-MM-JJ » : c'est la date inscrite sur la carte, et
 * on la compare telle quelle. La construire en `Date` pour la recomparer ensuite
 * n'ajouterait qu'une occasion de se tromper de fuseau.
 */
export function estExpiree(expiresAt: string | null, aujourdhui: Date = new Date()): boolean {
  if (!expiresAt || !DATE_ISO.test(expiresAt)) {
    // Date absente ou illisible : on ne déclare pas une habilitation expirée sur une donnée
    // qu'on ne sait pas lire. L'API, elle, tranchera.
    return false;
  }
  return expiresAt < jourParis(aujourdhui);
}
