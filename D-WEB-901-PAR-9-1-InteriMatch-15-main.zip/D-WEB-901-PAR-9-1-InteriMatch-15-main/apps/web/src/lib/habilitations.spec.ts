import { estExpiree } from './habilitations';

const LE_23_SEPTEMBRE = new Date('2026-09-23T09:00:00Z');

describe('estExpiree', () => {
  it('ne déclare rien expiré sans date', () => {
    expect(estExpiree(null, LE_23_SEPTEMBRE)).toBe(false);
  });

  it('reconnaît une date passée', () => {
    expect(estExpiree('2024-03-10', LE_23_SEPTEMBRE)).toBe(true);
    expect(estExpiree('2026-09-22', LE_23_SEPTEMBRE)).toBe(true);
  });

  it('laisse valide une date à venir', () => {
    expect(estExpiree('2026-09-24', LE_23_SEPTEMBRE)).toBe(false);
    expect(estExpiree('2029-06-30', LE_23_SEPTEMBRE)).toBe(false);
  });

  // LE CAS LIMITE, et le même est écrit côté API (matching.service.spec.ts). Une carte CACES
  // qui porte « 23/09 » couvre le 23/09 en entier : comparer des instants écartait son
  // titulaire dès le matin, lui faisant perdre un jour de validité.
  //
  // Ces deux tests sont ce qui empêche les deux règles de diverger. Les modifier d'un seul
  // côté doit casser l'autre.
  it('compte encore le jour même de l’expiration', () => {
    expect(estExpiree('2026-09-23', LE_23_SEPTEMBRE)).toBe(false);
  });

  // LA BASCULE, à MINUIT HEURE DE PARIS et non minuit UTC. Le jumeau de ce test est dans
  // apps/api/src/matching/matching.service.spec.ts, AUX MÊMES INSTANTS : c'est lui qui tient
  // les deux règles ensemble, faute de module partagé.
  //
  // En septembre (heure d'été), minuit à Paris vaut 22:00 UTC.
  it('bascule à minuit heure de Paris, pas à minuit UTC', () => {
    // 23:59 à Paris, le 23 : la carte court encore.
    expect(estExpiree('2026-09-23', new Date('2026-09-23T21:59:00Z'))).toBe(false);
    // 00:00 à Paris, le 24 : elle ne court plus.
    expect(estExpiree('2026-09-23', new Date('2026-09-23T22:00:00Z'))).toBe(true);
  });

  // En hiver, minuit à Paris vaut 23:00 UTC. Une règle écrite en UTC serait juste six mois
  // par an, et fausse les six autres.
  it('suit le passage à l’heure d’hiver', () => {
    expect(estExpiree('2026-01-15', new Date('2026-01-15T22:59:00Z'))).toBe(false);
    expect(estExpiree('2026-01-15', new Date('2026-01-15T23:00:00Z'))).toBe(true);
  });

  it('ne déclare pas expirée une date illisible', () => {
    expect(estExpiree('pas-une-date', LE_23_SEPTEMBRE)).toBe(false);
    expect(estExpiree('', LE_23_SEPTEMBRE)).toBe(false);
  });
});
