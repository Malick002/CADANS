'use client';

import { useRouter } from 'next/navigation';
import { useId, useState } from 'react';
import { ApiError, postJson } from '../../lib/api';

interface DecisionJustificatifProps {
  certificationId: string;
  /** Sert à nommer les contrôles : « Refuser le CACES R489-3 de Leïla Moreau ». */
  libelle: string;
}

/**
 * Valider ou refuser un justificatif. Le refus ouvre un champ de motif **obligatoire** :
 * l'intérimaire le lit sur son profil, et un refus muet ne lui apprend pas quoi corriger.
 *
 * L'API impose déjà un motif d'au moins dix caractères ; la même règle est rappelée ici pour
 * que l'agent la voie avant d'envoyer, pas après.
 */
export function DecisionJustificatif({ certificationId, libelle }: DecisionJustificatifProps) {
  const router = useRouter();
  const idMotif = useId();
  const [mode, setMode] = useState<'repos' | 'refus'>('repos');
  const [motif, setMotif] = useState('');
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);

  const envoyer = async (chemin: string, corps: unknown): Promise<void> => {
    setEnCours(true);
    setErreur(null);
    try {
      await postJson(`/admin/justificatifs/${certificationId}/${chemin}`, corps);
      // Les données viennent d'un Server Component : c'est lui qu'il faut relancer.
      router.refresh();
      setMode('repos');
      setMotif('');
    } catch (err) {
      setErreur(
        err instanceof ApiError
          ? err.messages.join(' ')
          : 'Une erreur inattendue est survenue. Réessayez dans quelques instants.',
      );
    } finally {
      setEnCours(false);
    }
  };

  if (mode === 'refus') {
    return (
      <form
        className="decision-justificatif"
        onSubmit={(evenement) => {
          evenement.preventDefault();
          void envoyer('refuser', { motif });
        }}
      >
        <div className="champ">
          <label htmlFor={idMotif} className="champ__libelle">
            Motif du refus
          </label>
          <p id={`${idMotif}-aide`} className="champ__indication">
            Dix caractères au minimum. {libelle} — ce texte est lu par l’intérimaire.
          </p>
          <textarea
            id={idMotif}
            className="champ__saisie"
            aria-describedby={`${idMotif}-aide`}
            rows={3}
            required
            minLength={10}
            maxLength={500}
            value={motif}
            onChange={(evenement) => setMotif(evenement.target.value)}
          />
        </div>

        {erreur && (
          <p className="champ__erreur" role="alert">
            {erreur}
          </p>
        )}

        <div className="decision-justificatif__actions">
          <button type="submit" className="bouton bouton--principal" disabled={enCours}>
            {enCours ? 'Envoi…' : 'Confirmer le refus'}
          </button>
          <button
            type="button"
            className="bouton bouton--secondaire"
            onClick={() => {
              setMode('repos');
              setErreur(null);
            }}
            disabled={enCours}
          >
            Annuler
          </button>
        </div>
      </form>
    );
  }

  return (
    <div className="decision-justificatif">
      {erreur && (
        <p className="champ__erreur" role="alert">
          {erreur}
        </p>
      )}
      <div className="decision-justificatif__actions">
        <button
          type="button"
          className="bouton bouton--principal"
          onClick={() => void envoyer('valider', {})}
          disabled={enCours}
        >
          Valider
          <span className="visuellement-masque"> {libelle}</span>
        </button>
        <button
          type="button"
          className="bouton bouton--secondaire"
          onClick={() => setMode('refus')}
          disabled={enCours}
        >
          Refuser
          <span className="visuellement-masque"> {libelle}</span>
        </button>
      </div>
    </div>
  );
}
