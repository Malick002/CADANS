// La règle d'activation de la navigation des espaces connectés, isolée pour être testée.
// `NavTableauBord` l'importe : il n'y a qu'une implémentation, pas une copie de test.
import { estActive } from './nav-actif';

describe('estActive', () => {
  it('active l’entrée dont le chemin correspond exactement', () => {
    expect(estActive('/interimaire/matches', '/interimaire/matches')).toBe(true);
  });

  // Le défaut d'origine : l'onglet actif était écrit en dur sur la première entrée, donc
  // « Matches » restait surligné partout ailleurs dans l'espace.
  it('n’active pas les autres entrées du même espace', () => {
    expect(estActive('/interimaire/profil', '/interimaire/matches')).toBe(false);
    expect(estActive('/interimaire/contrats', '/interimaire/matches')).toBe(false);
  });

  it('reste actif sur une sous-route', () => {
    expect(estActive('/interimaire/contrats/abc-123/signer', '/interimaire/contrats')).toBe(true);
    expect(estActive('/entreprise/missions/abc-123/annexes', '/entreprise/missions')).toBe(true);
    expect(estActive('/entreprise/missions/nouvelle', '/entreprise/missions')).toBe(true);
  });

  /**
   * Le `/` du préfixe n'est pas décoratif. Sans lui, `startsWith` ferait de
   * `/entreprise/contrats` l'onglet actif sur `/entreprise/contrats-archives`, qui est une
   * autre page — et deux onglets pourraient être actifs en même temps.
   */
  it('n’active pas une page dont le chemin commence par le même texte', () => {
    expect(estActive('/entreprise/contrats-archives', '/entreprise/contrats')).toBe(false);
    expect(estActive('/interimaire/matchesXYZ', '/interimaire/matches')).toBe(false);
  });

  it('n’active rien quand le chemin est inconnu', () => {
    expect(estActive(null, '/interimaire/matches')).toBe(false);
  });

  // Un seul onglet actif à la fois, sur chacune des entrées réelles des trois espaces : c'est
  // l'invariant qui compte, et il se vérifie sur l'ensemble plutôt qu'entrée par entrée.
  it('n’active jamais plus d’une entrée', () => {
    const espaces = [
      [
        '/interimaire/matches',
        '/interimaire/mes-missions',
        '/interimaire/contrats',
        '/interimaire/profil',
        '/interimaire/informations-embauche',
      ],
      ['/entreprise/missions', '/entreprise/candidatures', '/entreprise/contrats'],
      ['/admin/justificatifs'],
    ];

    for (const entrees of espaces) {
      for (const chemin of [...entrees, `${entrees[0]}/sous-route/xyz`]) {
        const actives = entrees.filter((href) => estActive(chemin, href));
        expect(actives).toHaveLength(1);
      }
    }
  });
});

// Entrée racine d'un espace : sans `exact`, « Tableau de bord » (/admin) resterait actif sur
// /admin/justificatifs, en même temps que « Justificatifs ». Deux onglets actifs valent moins
// que pas d'onglet du tout : le menu affirme alors une position fausse.
describe('estActive avec correspondance exacte', () => {
  it('reste actif sur sa propre page', () => {
    expect(estActive('/admin', '/admin', true)).toBe(true);
  });

  it('ne déborde pas sur les sous-routes', () => {
    expect(estActive('/admin/justificatifs', '/admin', true)).toBe(false);
  });

  // Le défaut ci-dessus, démontré : sans le drapeau, les deux entrées s'allument.
  it('sans le drapeau, la racine déborderait sur ses sous-routes', () => {
    expect(estActive('/admin/justificatifs', '/admin')).toBe(true);
    expect(estActive('/admin/justificatifs', '/admin/justificatifs')).toBe(true);
  });

  it('laisse les entrées existantes inchangées', () => {
    expect(estActive('/interimaire/contrats/abc/signer', '/interimaire/contrats')).toBe(true);
  });
});
