/**
 * Règle d'activation d'une entrée de navigation : correspondance exacte, ou préfixe pour les
 * sous-routes — `/interimaire/contrats` reste l'onglet actif quand on signe un contrat, sur
 * `/interimaire/contrats/<id>/signer`.
 *
 * Le `/` du préfixe n'est pas décoratif : sans lui, `/entreprise/contrats` serait actif sur
 * une hypothétique `/entreprise/contrats-archives`, qui est une autre page — et deux onglets
 * pourraient l'être en même temps.
 *
 * Fonction pure, dans son propre fichier : `NavTableauBord` est un composant client, que le
 * harnais de test du site (Jest, `.spec.ts` seulement) ne sait pas rendre. La règle, elle,
 * n'a besoin d'aucun rendu pour être vérifiée.
 *
 * `exact` désactive la règle du préfixe. C'est indispensable pour une entrée qui est la
 * RACINE d'un espace : `/admin` est un préfixe de `/admin/justificatifs`, donc « Tableau de
 * bord » et « Justificatifs » seraient actifs en même temps sur la page des justificatifs —
 * exactement le défaut décrit ci-dessus. Aucune entrée existante ne passe ce drapeau : leur
 * comportement est inchangé.
 */
export function estActive(chemin: string | null, href: string, exact = false): boolean {
  if (!chemin) {
    return false;
  }
  if (exact) {
    return chemin === href;
  }
  return chemin === href || chemin.startsWith(`${href}/`);
}
