'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { estActive } from './nav-actif';

/**
 * Union discriminée plutôt qu'un `href` facultatif : une entrée « à venir » n'a pas d'adresse,
 * et une entrée réelle en a forcément une. Le compilateur refuse les deux erreurs inverses,
 * là où un champ optionnel aurait laissé passer un lien sans destination.
 */
export type EntreeNav =
  | { href: string; label: string; bientot?: false; exact?: boolean }
  | { label: string; bientot: true };

/**
 * Navigation des trois espaces connectés.
 *
 * **Le défaut qu'elle corrige** : l'onglet actif était écrit en dur sur la première entrée de
 * chaque layout. « Matches » restait donc surligné qu'on soit sur son profil, ses contrats ou
 * ses informations d'embauche — le menu affirmait une position fausse, ce qui est pire que de
 * n'en afficher aucune.
 *
 * L'état actif vient maintenant de l'URL, seule source qui ne peut pas mentir. Composant
 * client, parce que `usePathname` en est un : c'est le seul morceau de la barre qui le soit,
 * le reste du layout (session, redirection) demeure rendu côté serveur.
 */
export function NavTableauBord({
  label,
  entrees,
  onNavigate,
}: {
  label: string;
  entrees: EntreeNav[];
  // Appelé au clic sur une entrée : la barre latérale s'en sert pour refermer son panneau
  // sur petit écran. Absent, la navigation se comporte comme avant.
  onNavigate?: () => void;
}) {
  const chemin = usePathname();

  return (
    <nav aria-label={label} className="tableau-bord__nav">
      {entrees.map((entree) => {
        if (entree.bientot) {
          return (
            <span key={entree.label} className="tableau-bord__lien tableau-bord__lien--desactive">
              {entree.label} <span className="tableau-bord__bientot">à venir</span>
            </span>
          );
        }

        const active = estActive(chemin, entree.href, entree.exact);
        return (
          <Link
            key={entree.href}
            href={entree.href}
            className={`tableau-bord__lien${active ? ' tableau-bord__lien--actif' : ''}`}
            onClick={onNavigate}
            // RGAA 4.1, critère 12.11 : l'entrée correspondant à la page consultée doit être
            // signalée aux technologies d'assistance, pas seulement à l'œil.
            aria-current={active ? 'page' : undefined}
          >
            {entree.label}
          </Link>
        );
      })}
    </nav>
  );
}
