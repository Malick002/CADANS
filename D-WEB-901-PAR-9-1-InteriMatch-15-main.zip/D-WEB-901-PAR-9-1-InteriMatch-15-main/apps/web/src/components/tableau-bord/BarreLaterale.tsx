'use client';

import Link from 'next/link';
import { ReactNode, useId } from 'react';
import { BoutonBurger, useBasculeMenu } from '../BasculeMenu';
import { Logo } from '../Logo';
import { EntreeNav, NavTableauBord } from './NavTableauBord';

interface BarreLateraleProps {
  label: string;
  entrees: EntreeNav[];
  // Bloc « qui est connecté, et par où sortir ». Passé en `children` et non construit ici :
  // il dépend de la session, que les layouts lisent CÔTÉ SERVEUR. Ce composant est client
  // pour la seule bascule du menu — faire remonter la session jusqu'ici l'exposerait au
  // navigateur sans raison.
  children: ReactNode;
}

/**
 * Barre latérale des trois espaces connectés.
 *
 * **Le défaut qu'elle corrige.** Sous 800 px, la barre devenait un bandeau horizontal
 * défilant. À quatre entrées ça passait « tout juste » — c'est ce que disait le commentaire
 * du CSS. L'espace intérimaire en compte six aujourd'hui, et « Paramètres » n'était
 * atteignable qu'en balayant une rangée sans le moindre indice qu'elle continue.
 *
 * Le menu s'ouvre donc au clic, sur le motif exact de l'en-tête public : même bouton, même
 * mécanique (`components/BasculeMenu.tsx`), même animation des trois barres. Un seul
 * comportement à apprendre pour un visiteur qui passe du site à son espace.
 */
export function BarreLaterale({ label, entrees, children }: BarreLateraleProps) {
  const idPanneau = useId();
  const { ouvert, setOuvert, basculer, boutonRef } = useBasculeMenu();

  return (
    <aside className="tableau-bord__barre-laterale">
      {/* Logo et bouton sur une ligne. Au-dessus de 800 px le bouton disparaît et cette
          ligne ne contient plus que le logo, comme avant. */}
      <div className="tableau-bord__entete">
        <Link href="/" className="tableau-bord__logo" aria-label="CADANS, retour à l’accueil">
          <Logo taille={1} />
        </Link>
        <BoutonBurger
          ouvert={ouvert}
          onBascule={basculer}
          idPanneau={idPanneau}
          boutonRef={boutonRef}
          className="tableau-bord__bascule"
        />
      </div>

      <div className="tableau-bord__panneau" id={idPanneau} data-ouvert={ouvert}>
        {/* Le menu se ferme quand on navigue : sur téléphone, l'écran d'arrivée serait sinon
            masqué par le panneau resté ouvert. */}
        <NavTableauBord label={label} entrees={entrees} onNavigate={() => setOuvert(false)} />
        {children}
      </div>
    </aside>
  );
}
