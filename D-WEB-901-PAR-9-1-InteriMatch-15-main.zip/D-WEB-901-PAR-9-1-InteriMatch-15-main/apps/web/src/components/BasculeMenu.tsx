'use client';

import { RefObject, useEffect, useRef, useState } from 'react';

/**
 * Mécanique d'un menu qui s'ouvre et se ferme sur petit écran.
 *
 * Extraite de `EnteteSite` pour être partagée avec la barre latérale des trois espaces
 * connectés. Ce qu'elle porte n'est pas la mise en forme — chaque contexte a la sienne —
 * mais les trois comportements qu'on oublie quand on réécrit un menu :
 *
 * 1. `aria-expanded` suit l'état RÉEL. Une classe posée en JavaScript sans cet attribut fait
 *    annoncer « réduit » sur un menu ouvert.
 * 2. Échap ferme.
 * 3. Échap **rend le focus au bouton**. Sans ce retour, le focus reste sur un élément qui
 *    vient de disparaître et la navigation clavier repart du haut du document.
 */
export function useBasculeMenu(): {
  ouvert: boolean;
  setOuvert: (etat: boolean) => void;
  basculer: () => void;
  boutonRef: RefObject<HTMLButtonElement | null>;
} {
  const [ouvert, setOuvert] = useState(false);
  const boutonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!ouvert) {
      return;
    }
    const surTouche = (evenement: KeyboardEvent): void => {
      if (evenement.key === 'Escape') {
        setOuvert(false);
        boutonRef.current?.focus();
      }
    };
    document.addEventListener('keydown', surTouche);
    return () => document.removeEventListener('keydown', surTouche);
  }, [ouvert]);

  return { ouvert, setOuvert, basculer: () => setOuvert(!ouvert), boutonRef };
}

interface BoutonBurgerProps {
  ouvert: boolean;
  onBascule: () => void;
  idPanneau: string;
  boutonRef: RefObject<HTMLButtonElement | null>;
  // Le gabarit diffère selon le contexte (en-tête clair, barre latérale sombre) ; les trois
  // barres, elles, sont peintes en `currentColor` et suivent la couleur du texte ambiant.
  className: string;
}

export function BoutonBurger({
  ouvert,
  onBascule,
  idPanneau,
  boutonRef,
  className,
}: BoutonBurgerProps) {
  return (
    <button
      ref={boutonRef}
      type="button"
      className={className}
      aria-expanded={ouvert}
      aria-controls={idPanneau}
      onClick={onBascule}
    >
      {/* Le libellé change avec l'état : « Ouvrir » sur un menu déjà ouvert serait faux.
          Les trois barres sont décoratives, le texte porte l'information. */}
      <span className="visuellement-masque">{ouvert ? 'Fermer le menu' : 'Ouvrir le menu'}</span>
      <span className="entete__burger" aria-hidden="true" data-ouvert={ouvert} />
    </button>
  );
}
