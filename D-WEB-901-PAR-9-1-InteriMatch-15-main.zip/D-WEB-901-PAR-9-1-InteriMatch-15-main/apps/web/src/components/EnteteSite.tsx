'use client';

import Link from 'next/link';
import { RUBRIQUES } from '../lib/rubriques-entete';
import { BoutonBurger, useBasculeMenu } from './BasculeMenu';
import { BoutonsCompte } from './BoutonsCompte';
import { Logo } from './Logo';

const ID_PANNEAU = 'entete-panneau';

/**
 * Barre de navigation des pages publiques.
 *
 * Au-dessus de 800 px, tout est visible et le bouton d'ouverture disparaît : le panneau est
 * la barre elle-même. En dessous, seul le logo reste, et le reste s'ouvre au clic.
 *
 * L'état n'existe que pour le petit écran, mais il est porté par React et non par une classe
 * posée en JavaScript : `aria-expanded` doit suivre l'état réel, sinon un lecteur d'écran
 * annonce « réduit » sur un menu ouvert.
 */
export function EnteteSite() {
  // Mécanique partagée avec la barre latérale des espaces connectés : état, Échap, et retour
  // du focus au bouton (components/BasculeMenu.tsx).
  const { ouvert, setOuvert, basculer, boutonRef } = useBasculeMenu();

  return (
    <div className="entete-zone">
      <header className="entete">
        {/* Le nom accessible est porté par le lien : le logotype rend déjà le mot
            « CADANS » à l'écran, l'annoncer une seconde fois serait redondant. */}
        <Link href="/" className="entete__logo" aria-label="CADANS, retour à l’accueil">
          <Logo taille={1.25} />
        </Link>

        <BoutonBurger
          ouvert={ouvert}
          onBascule={basculer}
          idPanneau={ID_PANNEAU}
          boutonRef={boutonRef}
          className="entete__bascule"
        />

        <div className="entete__panneau" id={ID_PANNEAU} data-ouvert={ouvert}>
          <nav className="entete__navigation" aria-label="Rubriques">
            {RUBRIQUES.map((rubrique) => (
              <Link key={rubrique.libelle} href={rubrique.href} onClick={() => setOuvert(false)}>
                {rubrique.libelle}
              </Link>
            ))}
          </nav>
          {/* Les deux boutons dépendent de la session, lue dans le navigateur : c'est le
              seul moyen de garder les pages publiques pré-rendues (voir BoutonsCompte). */}
          <nav className="entete__compte" aria-label="Compte">
            <BoutonsCompte onNavigate={() => setOuvert(false)} />
          </nav>
        </div>
      </header>
    </div>
  );
}
