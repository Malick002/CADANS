'use client';

import { FormEvent, useState } from 'react';
import { ApiError, putJson } from '../../lib/api';
import {
  collectErrors,
  maxLength,
  required,
  validatePhone,
  validatePostalCode,
} from '../../lib/validation';
import { ErrorSummary } from '../form/ErrorSummary';
import { TextField } from '../form/TextField';

type Field =
  | 'legalName'
  | 'contactFirstName'
  | 'contactLastName'
  | 'phone'
  | 'addressLine'
  | 'postalCode'
  | 'city';

const FIELD_ORDER: Field[] = [
  'legalName',
  'contactFirstName',
  'contactLastName',
  'phone',
  'addressLine',
  'postalCode',
  'city',
];

interface CompanyProfile {
  legalName: string;
  siret: string;
  nafCode: string;
  contactFirstName: string;
  contactLastName: string;
  phone: string | null;
  addressLine: string;
  postalCode: string;
  city: string;
}

function validate(values: Record<Field, string>) {
  return collectErrors<Field>({
    legalName: required(values.legalName, 'la raison sociale') ?? maxLength(values.legalName, 255),
    contactFirstName:
      required(values.contactFirstName, 'le prénom du contact') ??
      maxLength(values.contactFirstName, 100),
    contactLastName:
      required(values.contactLastName, 'le nom du contact') ??
      maxLength(values.contactLastName, 100),
    phone: validatePhone(values.phone),
    addressLine: required(values.addressLine, "l'adresse") ?? maxLength(values.addressLine, 255),
    postalCode: validatePostalCode(values.postalCode),
    city: required(values.city, 'la ville') ?? maxLength(values.city, 100),
  });
}

export function CompanyParamsForm({ profile }: { profile: CompanyProfile }) {
  const [values, setValues] = useState<Record<Field, string>>({
    legalName: profile.legalName,
    contactFirstName: profile.contactFirstName,
    contactLastName: profile.contactLastName,
    phone: profile.phone ?? '',
    addressLine: profile.addressLine,
    postalCode: profile.postalCode,
    city: profile.city,
  });
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({});
  const [globalErrors, setGlobalErrors] = useState<string[]>([]);
  const [attempt, setAttempt] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [saved, setSaved] = useState(false);

  const setValue =
    (key: Field) =>
    (value: string): void => {
      const next = { ...values, [key]: value };
      setValues(next);
      if (errors[key]) {
        setErrors(validate(next));
      }
    };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    if (submitting) {
      return;
    }
    const fieldErrors = validate(values);
    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      setAttempt((current) => current + 1);
      return;
    }

    setSubmitting(true);
    setSaved(false);
    try {
      await putJson('/companies/me', {
        ...values,
        phone: values.phone.trim() ? values.phone : undefined,
      });
      setErrors({});
      setGlobalErrors([]);
      setSaved(true);
    } catch (error) {
      setGlobalErrors(
        error instanceof ApiError
          ? error.messages
          : ['Une erreur inattendue est survenue. Réessayez dans quelques instants.'],
      );
      setAttempt((current) => current + 1);
    } finally {
      setSubmitting(false);
    }
  };

  const summary = [
    ...FIELD_ORDER.filter((key) => errors[key]).map((key) => ({
      message: errors[key]!,
      fieldId: `parametres-${key}`,
    })),
    ...globalErrors.map((message) => ({ message })),
  ];

  const field = (key: Field) => ({
    id: `parametres-${key}`,
    value: values[key],
    onChange: setValue(key),
    error: errors[key],
  });

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="formulaire carte-formulaire parametres-bloc"
    >
      <h2 className="parametres-bloc__titre">Coordonnées de l’entreprise</h2>
      <ErrorSummary errors={summary} attempt={attempt} />
      {saved && <p className="avis-succes">Paramètres enregistrés.</p>}

      <fieldset>
        <legend>Identité de l’entreprise</legend>
        <p className="champ__indication">
          SIRET et code NAF sont fixés à l’inscription et ne se modifient pas ici.
        </p>
        <div className="champs-duo">
          <div className="champ">
            <span className="champ__etiquette">Numéro SIRET</span>
            <p className="champ__valeur-figee">{profile.siret}</p>
          </div>
          <div className="champ">
            <span className="champ__etiquette">Code NAF (APE)</span>
            <p className="champ__valeur-figee">{profile.nafCode}</p>
          </div>
        </div>
        <TextField {...field('legalName')} label="Raison sociale" maxLength={255} />
      </fieldset>

      <fieldset>
        <legend>Personne à contacter</legend>
        <div className="champs-duo">
          <TextField
            {...field('contactFirstName')}
            label="Prénom"
            autoComplete="given-name"
            maxLength={100}
          />
          <TextField
            {...field('contactLastName')}
            label="Nom"
            autoComplete="family-name"
            maxLength={100}
          />
        </div>
        <TextField
          {...field('phone')}
          label="Téléphone"
          type="tel"
          inputMode="tel"
          autoComplete="tel-national"
          placeholder="04 72 12 34 56"
          optional
        />
      </fieldset>

      <fieldset>
        <legend>Adresse</legend>
        <TextField
          {...field('addressLine')}
          label="Adresse"
          autoComplete="address-line1"
          maxLength={255}
        />
        <div className="champs-duo">
          <TextField
            {...field('postalCode')}
            label="Code postal"
            inputMode="numeric"
            autoComplete="postal-code"
            maxLength={5}
          />
          <TextField
            {...field('city')}
            label="Ville"
            autoComplete="address-level2"
            maxLength={100}
          />
        </div>
      </fieldset>

      <button type="submit" className="bouton bouton--principal" disabled={submitting}>
        {submitting ? 'Enregistrement…' : 'Enregistrer'}
      </button>
    </form>
  );
}
