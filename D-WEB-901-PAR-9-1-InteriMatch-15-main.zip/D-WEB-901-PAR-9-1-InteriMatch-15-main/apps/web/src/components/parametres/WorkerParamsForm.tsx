'use client';

import { FormEvent, useState } from 'react';
import { ApiError, putJson } from '../../lib/api';
import {
  collectErrors,
  maxLength,
  required,
  validatePhone,
  validatePostalCode,
} from '../../lib/validation';
import { ErrorSummary } from '../form/ErrorSummary';
import { TextField } from '../form/TextField';

type Field = 'firstName' | 'lastName' | 'phone' | 'postalCode' | 'city';

const FIELD_ORDER: Field[] = ['firstName', 'lastName', 'phone', 'postalCode', 'city'];

export interface WorkerIdentity {
  firstName: string;
  lastName: string;
  phone: string | null;
  postalCode: string;
  city: string;
}

function validate(values: Record<Field, string>) {
  return collectErrors<Field>({
    firstName: required(values.firstName, 'le prénom') ?? maxLength(values.firstName, 100),
    lastName: required(values.lastName, 'le nom') ?? maxLength(values.lastName, 100),
    phone: validatePhone(values.phone),
    postalCode: validatePostalCode(values.postalCode),
    city: required(values.city, 'la ville') ?? maxLength(values.city, 100),
  });
}

// Pendant de CompanyParamsForm côté entreprise : mêmes composants, même validation partagée,
// mêmes messages. Seuls les champs changent.
export function WorkerParamsForm({ identity }: { identity: WorkerIdentity }) {
  const [values, setValues] = useState<Record<Field, string>>({
    firstName: identity.firstName,
    lastName: identity.lastName,
    phone: identity.phone ?? '',
    postalCode: identity.postalCode,
    city: identity.city,
  });
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({});
  const [globalErrors, setGlobalErrors] = useState<string[]>([]);
  const [attempt, setAttempt] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [saved, setSaved] = useState(false);

  const setValue =
    (key: Field) =>
    (value: string): void => {
      const next = { ...values, [key]: value };
      setValues(next);
      if (errors[key]) {
        setErrors(validate(next));
      }
    };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    if (submitting) {
      return;
    }
    const fieldErrors = validate(values);
    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      setAttempt((current) => current + 1);
      return;
    }

    setSubmitting(true);
    setSaved(false);
    try {
      await putJson('/workers/me/identite', {
        ...values,
        // Champ vidé : on n'envoie rien, et l'API met la colonne à null. L'envoyer comme
        // chaîne vide ferait échouer la validation du format de téléphone.
        phone: values.phone.trim() ? values.phone : undefined,
      });
      setErrors({});
      setGlobalErrors([]);
      setSaved(true);
    } catch (error) {
      setGlobalErrors(
        error instanceof ApiError
          ? error.messages
          : ['Une erreur inattendue est survenue. Réessayez dans quelques instants.'],
      );
      setAttempt((current) => current + 1);
    } finally {
      setSubmitting(false);
    }
  };

  const summary = [
    ...FIELD_ORDER.filter((key) => errors[key]).map((key) => ({
      message: errors[key]!,
      fieldId: `parametres-${key}`,
    })),
    ...globalErrors.map((message) => ({ message })),
  ];

  const field = (key: Field) => ({
    id: `parametres-${key}`,
    value: values[key],
    onChange: setValue(key),
    error: errors[key],
  });

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="formulaire carte-formulaire parametres-bloc"
    >
      <h2 className="parametres-bloc__titre">Vos coordonnées</h2>
      <ErrorSummary errors={summary} attempt={attempt} />
      {saved && <p className="avis-succes">Coordonnées enregistrées.</p>}

      <fieldset>
        <legend>Votre identité</legend>
        <div className="champs-duo">
          <TextField
            {...field('firstName')}
            label="Prénom"
            autoComplete="given-name"
            maxLength={100}
          />
          <TextField
            {...field('lastName')}
            label="Nom"
            autoComplete="family-name"
            maxLength={100}
          />
        </div>
        <TextField
          {...field('phone')}
          label="Téléphone"
          type="tel"
          inputMode="tel"
          autoComplete="tel-national"
          placeholder="06 12 34 56 78"
          optional
        />
      </fieldset>

      <fieldset>
        <legend>Où vous cherchez</legend>
        {/* Ce n'est pas une coordonnée décorative : le code postal porte le critère « zone »
            du matching. Un déménagement non répercuté écarte des missions proches sans que
            l'intérimaire comprenne pourquoi — autant le lui dire ici. */}
        <p className="champ__indication">
          Votre commune sert à vous proposer les missions proches de chez vous. Tenez-la à jour si
          vous déménagez.
        </p>
        <div className="champs-duo">
          <TextField
            {...field('postalCode')}
            label="Code postal"
            inputMode="numeric"
            autoComplete="postal-code"
            maxLength={5}
          />
          <TextField
            {...field('city')}
            label="Ville"
            autoComplete="address-level2"
            maxLength={100}
          />
        </div>
      </fieldset>

      <button type="submit" className="bouton bouton--principal" disabled={submitting}>
        {submitting ? 'Enregistrement…' : 'Enregistrer'}
      </button>
    </form>
  );
}
