'use client';

import { FormEvent, useState } from 'react';
import { ApiError, putJson } from '../../lib/api';
import { validateCurrentPassword, validateEmail, validatePassword } from '../../lib/validation';
import { ErrorSummary } from '../form/ErrorSummary';
import { PasswordField } from '../form/PasswordField';
import { TextField } from '../form/TextField';

interface CompteFormProps {
  email: string;
}

// Deux formulaires FRÈRES, pas un seul : ce sont deux appels d'API distincts, chacun avec sa
// propre confirmation par mot de passe actuel. Les imbriquer est de toute façon interdit en
// HTML, et les fusionner obligerait à ressaisir son mot de passe pour corriger une faute de
// frappe dans son adresse.
export function CompteForm({ email: emailInitial }: CompteFormProps) {
  return (
    <>
      <FormulaireEmail emailInitial={emailInitial} />
      <FormulaireMotDePasse />
    </>
  );
}

// --- Adresse de connexion --------------------------------------------------------------

function FormulaireEmail({ emailInitial }: { emailInitial: string }) {
  const [email, setEmail] = useState(emailInitial);
  const [motDePasse, setMotDePasse] = useState('');
  const [enregistre, setEnregistre] = useState<string | null>(null);
  const soumission = useSoumission();

  const envoyer = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    const erreurs = {
      'compte-email': validateEmail(email),
      'compte-email-motdepasse': validateCurrentPassword(motDePasse),
    };
    if (soumission.refuserSiErreurs(erreurs)) {
      return;
    }

    await soumission.envoyer(async () => {
      const compte = await putJson<{ email: string }>('/account/me/email', {
        email,
        currentPassword: motDePasse,
      });
      setEmail(compte.email);
      setEnregistre(compte.email);
      // Le mot de passe n'a pas à rester en mémoire une fois l'opération faite.
      setMotDePasse('');
    });
  };

  return (
    <form onSubmit={envoyer} noValidate className="formulaire carte-formulaire parametres-bloc">
      {/* Un h2 plutôt qu'un fieldset : ce formulaire n'a qu'un seul groupe de champs, et le
          titre de section aide la navigation par en-têtes (RGAA 9.1) là où une légende ne
          serait qu'un intitulé de plus. */}
      <h2 className="parametres-bloc__titre">Adresse de connexion</h2>
      <ErrorSummary errors={soumission.resume} attempt={soumission.attempt} />
      {enregistre && (
        <p className="avis-succes">
          Adresse de connexion modifiée. Vous vous connecterez désormais avec {enregistre}.
        </p>
      )}

      <div className="parametres-bloc__champs">
        <p className="champ__indication">
          C’est l’adresse qui ouvre votre session et qui reçoit les liens de réinitialisation.
        </p>
        <TextField
          id="compte-email"
          label="Adresse email"
          type="email"
          autoComplete="email"
          value={email}
          onChange={setEmail}
          error={soumission.erreurs['compte-email']}
          maxLength={255}
        />
        {/* Exigé par l'API : sans lui, un poste laissé ouvert suffirait à détourner le
            compte en changeant l'adresse, puis en demandant un nouveau mot de passe. */}
        <TextField
          id="compte-email-motdepasse"
          label="Votre mot de passe actuel"
          type="password"
          autoComplete="current-password"
          value={motDePasse}
          onChange={setMotDePasse}
          error={soumission.erreurs['compte-email-motdepasse']}
          maxLength={128}
        />
      </div>

      <button type="submit" className="bouton bouton--principal" disabled={soumission.enCours}>
        {soumission.enCours ? 'Enregistrement…' : 'Changer d’adresse'}
      </button>
    </form>
  );
}

// --- Mot de passe ----------------------------------------------------------------------

function FormulaireMotDePasse() {
  const [actuel, setActuel] = useState('');
  const [nouveau, setNouveau] = useState('');
  const [enregistre, setEnregistre] = useState(false);
  const soumission = useSoumission();

  const envoyer = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    const erreurs = {
      'compte-motdepasse-actuel': validateCurrentPassword(actuel),
      'compte-motdepasse-nouveau': validatePassword(nouveau),
    };
    if (soumission.refuserSiErreurs(erreurs)) {
      return;
    }

    await soumission.envoyer(async () => {
      await putJson('/account/me/password', { currentPassword: actuel, password: nouveau });
      setEnregistre(true);
      setActuel('');
      setNouveau('');
    });
  };

  return (
    <form onSubmit={envoyer} noValidate className="formulaire carte-formulaire parametres-bloc">
      <h2 className="parametres-bloc__titre">Mot de passe</h2>
      <ErrorSummary errors={soumission.resume} attempt={soumission.attempt} />
      {enregistre && (
        <p className="avis-succes">
          Mot de passe modifié. Votre session reste ouverte ici ; utilisez le nouveau mot de passe à
          la prochaine connexion.
        </p>
      )}

      <div className="parametres-bloc__champs">
        <TextField
          id="compte-motdepasse-actuel"
          label="Mot de passe actuel"
          type="password"
          autoComplete="current-password"
          value={actuel}
          onChange={setActuel}
          error={soumission.erreurs['compte-motdepasse-actuel']}
          maxLength={128}
        />
        {/* Mêmes règles qu'à l'inscription, affichées et cochées au fil de la frappe. */}
        <PasswordField
          id="compte-motdepasse-nouveau"
          label="Nouveau mot de passe"
          value={nouveau}
          onChange={setNouveau}
          error={soumission.erreurs['compte-motdepasse-nouveau']}
        />
      </div>

      <button type="submit" className="bouton bouton--principal" disabled={soumission.enCours}>
        {soumission.enCours ? 'Enregistrement…' : 'Changer de mot de passe'}
      </button>
    </form>
  );
}

// --- Plomberie commune aux deux formulaires ---------------------------------------------

// Validation, envoi, erreurs et récapitulatif accessible : la même mécanique deux fois, avec
// des champs différents. Les clés des erreurs SONT les identifiants des champs, pour que le
// récapitulatif puisse y renvoyer le focus (RGAA 11.10).
function useSoumission() {
  const [erreurs, setErreurs] = useState<Record<string, string | undefined>>({});
  const [globales, setGlobales] = useState<string[]>([]);
  const [attempt, setAttempt] = useState(0);
  const [enCours, setEnCours] = useState(false);

  const refuserSiErreurs = (candidats: Record<string, string | undefined>): boolean => {
    const retenues = Object.fromEntries(
      Object.entries(candidats).filter(([, message]) => message !== undefined),
    );
    setErreurs(retenues);
    if (Object.keys(retenues).length === 0) {
      return false;
    }
    setGlobales([]);
    setAttempt((n) => n + 1);
    return true;
  };

  const envoyer = async (action: () => Promise<void>): Promise<void> => {
    setEnCours(true);
    try {
      await action();
      setErreurs({});
      setGlobales([]);
    } catch (error) {
      setGlobales(
        error instanceof ApiError
          ? error.messages
          : ['Une erreur inattendue est survenue. Réessayez dans quelques instants.'],
      );
      setAttempt((n) => n + 1);
    } finally {
      setEnCours(false);
    }
  };

  const resume = [
    ...Object.entries(erreurs)
      .filter(([, message]) => message !== undefined)
      .map(([fieldId, message]) => ({ message: message!, fieldId })),
    ...globales.map((message) => ({ message })),
  ];

  return { erreurs, resume, attempt, enCours, refuserSiErreurs, envoyer };
}
