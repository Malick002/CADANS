'use client';

import { useState } from 'react';
import { PASSWORD_MAX_LENGTH, passwordRules } from '../../lib/validation';

interface PasswordFieldProps {
  id: string;
  value: string;
  onChange: (value: string) => void;
  error?: string | undefined;
  // « Nouveau mot de passe » sur l'écran de paramètres, où l'ancien est saisi juste au-dessus
  // et où deux champs nommés pareil seraient indiscernables au lecteur d'écran.
  label?: string;
}

// Mot de passe de création de compte : règles affichées avant la saisie (RGAA 11.10), cochées
// visuellement au fil de la frappe, et bouton pour afficher le mot de passe en clair.
export function PasswordField({
  id,
  value,
  onChange,
  error,
  label = 'Mot de passe',
}: PasswordFieldProps) {
  const [visible, setVisible] = useState(false);
  const rulesId = `${id}-regles`;
  const errorId = error ? `${id}-erreur` : undefined;

  return (
    <div className={`champ${error ? ' champ--erreur' : ''}`}>
      <label htmlFor={id} className="champ__etiquette">
        {label}
        <span className="champ__requis" aria-hidden="true">
          {' '}
          *
        </span>
      </label>
      <div id={rulesId} className="champ__indication">
        <p className="regles__intro">Le mot de passe doit contenir :</p>
        <ul className="regles">
          {passwordRules(value).map((rule) => (
            <li key={rule.label} className={rule.ok ? 'regle regle--ok' : 'regle'}>
              <span aria-hidden="true">{rule.ok ? '✓' : '•'}</span> {rule.label}
            </li>
          ))}
        </ul>
      </div>
      {error && (
        <p id={errorId} className="champ__message-erreur">
          <span className="visuellement-masque">Erreur : </span>
          {error}
        </p>
      )}
      <div className="champ__mot-de-passe">
        <input
          id={id}
          name={id}
          type={visible ? 'text' : 'password'}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          required
          aria-invalid={error ? true : undefined}
          aria-describedby={[rulesId, errorId].filter(Boolean).join(' ')}
          autoComplete="new-password"
          maxLength={PASSWORD_MAX_LENGTH}
          className="champ__saisie"
        />
        <button
          type="button"
          className="bouton bouton--secondaire"
          aria-pressed={visible}
          aria-controls={id}
          onClick={() => setVisible((current) => !current)}
        >
          {visible ? 'Masquer' : 'Afficher'}
          <span className="visuellement-masque"> le mot de passe</span>
        </button>
      </div>
    </div>
  );
}
