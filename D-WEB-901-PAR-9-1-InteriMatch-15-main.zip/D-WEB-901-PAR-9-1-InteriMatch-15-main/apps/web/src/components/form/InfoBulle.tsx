interface InfoBulleProps {
  id: string;
  label: string;
  children: string;
}

// Infobulle accessible (RGAA 4.1) : le contenu reste dans le DOM et décrit le champ via
// aria-describedby quelle que soit sa visibilité, donc les lecteurs d'écran l'ont toujours.
// L'affichage visuel se déclenche au survol ET au focus clavier (pas au survol seul), pour
// rester utilisable sans souris.
export function InfoBulle({ id, label, children }: InfoBulleProps) {
  return (
    <span className="info-bulle">
      <button type="button" className="info-bulle__declencheur" aria-describedby={id}>
        <span aria-hidden="true">?</span>
        <span className="visuellement-masque">{label}</span>
      </button>
      <span role="tooltip" id={id} className="info-bulle__contenu">
        {children}
      </span>
    </span>
  );
}
