import type { ReactNode } from 'react';

interface CheckboxFieldProps {
  id: string;
  // ReactNode et pas string : le libellé d'acceptation contient un lien vers la politique
  // de confidentialité, que le RGPD demande d'afficher au moment de la collecte.
  label: ReactNode;
  // Réutilise le même stockage en chaîne que les autres champs du formulaire (pas de généricité
  // booléenne dans useAuthForm) : '' pour décoché, 'oui' pour coché.
  value: string;
  onChange: (value: string) => void;
  error?: string | undefined;
}

export function CheckboxField({ id, label, value, onChange, error }: CheckboxFieldProps) {
  const errorId = error ? `${id}-erreur` : undefined;

  return (
    <div className={`champ champ--case${error ? ' champ--erreur' : ''}`}>
      <label htmlFor={id} className="champ__case">
        <input
          id={id}
          name={id}
          type="checkbox"
          checked={value !== ''}
          onChange={(event) => onChange(event.target.checked ? 'oui' : '')}
          required
          aria-invalid={error ? true : undefined}
          aria-describedby={errorId}
          className="champ__case-saisie"
        />
        <span>{label}</span>
      </label>
      {error && (
        <p id={errorId} className="champ__message-erreur">
          <span className="visuellement-masque">Erreur : </span>
          {error}
        </p>
      )}
    </div>
  );
}
