'use client';

import { useEffect, useRef } from 'react';

export interface SummaryError {
  message: string;
  // Identifiant du champ concerné : le message devient un lien qui y place le focus.
  fieldId?: string;
}

interface ErrorSummaryProps {
  errors: SummaryError[];
  // Change à chaque soumission en erreur, pour redonner le focus au récapitulatif.
  attempt: number;
}

// Récapitulatif des erreurs affiché en haut du formulaire après une soumission refusée.
// Il reçoit le focus : un lecteur d'écran l'annonce, et chaque erreur mène à son champ.
export function ErrorSummary({ errors, attempt }: ErrorSummaryProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (errors.length > 0) {
      ref.current?.focus();
    }
  }, [attempt, errors.length]);

  if (errors.length === 0) {
    return null;
  }

  // Une erreur sans `fieldId` ne vient pas de la saisie (identifiants refusés, service
  // indisponible) : annoncer « le formulaire contient une erreur » envoie relire des champs
  // corrects. Le titre ne parle du formulaire que si au moins un champ est en cause.
  const champsEnCause = errors.filter((error) => error.fieldId).length;
  const title =
    champsEnCause === 0
      ? 'Impossible de continuer'
      : champsEnCause === 1
        ? 'Le formulaire contient une erreur'
        : `Le formulaire contient ${champsEnCause} erreurs`;

  return (
    <div
      ref={ref}
      className="recapitulatif-erreurs"
      tabIndex={-1}
      role="alert"
      aria-labelledby="recapitulatif-erreurs-titre"
    >
      <h2 id="recapitulatif-erreurs-titre" className="recapitulatif-erreurs__titre">
        {title}
      </h2>
      <ul>
        {errors.map((error) => (
          <li key={`${error.fieldId ?? 'global'}-${error.message}`}>
            {error.fieldId ? (
              <a
                href={`#${error.fieldId}`}
                onClick={(event) => {
                  event.preventDefault();
                  document.getElementById(error.fieldId!)?.focus();
                }}
              >
                {error.message}
              </a>
            ) : (
              error.message
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
