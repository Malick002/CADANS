import Link from 'next/link';

// Mention affichée sous chaque formulaire de collecte : le RGPD demande d'informer la
// personne au moment où elle saisit ses données, pas seulement dans une page qu'elle devra
// aller chercher.
export function MentionDonnees() {
  return (
    <p className="mention-donnees">
      Vos données servent uniquement à la mise en relation avec des missions ou des intérimaires.
      Elles ne sont ni vendues ni cédées.{' '}
      <Link href="/politique-de-confidentialite">Politique de confidentialité</Link>
    </p>
  );
}
