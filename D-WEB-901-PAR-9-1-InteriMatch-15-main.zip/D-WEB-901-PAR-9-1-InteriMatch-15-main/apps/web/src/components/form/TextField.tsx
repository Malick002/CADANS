import type { HTMLInputAutoCompleteAttribute, HTMLInputTypeAttribute } from 'react';
import { InfoBulle } from './InfoBulle';

interface TextFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  error?: string | undefined;
  hint?: string;
  placeholder?: string;
  optional?: boolean;
  type?: HTMLInputTypeAttribute;
  autoComplete?: HTMLInputAutoCompleteAttribute;
  inputMode?: 'text' | 'numeric' | 'decimal' | 'tel' | 'email';
  maxLength?: number;
  // type="number" ou type="date" uniquement.
  min?: string | number;
  max?: string | number;
  step?: string | number;
}

// Champ accessible (RGAA 4.1, thématique 11) : étiquette visible reliée au champ, indication
// et message d'erreur rattachés par aria-describedby, état invalide exposé par aria-invalid.
export function TextField({
  id,
  label,
  value,
  onChange,
  error,
  hint,
  placeholder,
  optional = false,
  type = 'text',
  autoComplete,
  inputMode,
  maxLength,
  min,
  max,
  step,
}: TextFieldProps) {
  const hintId = hint ? `${id}-indication` : undefined;
  const errorId = error ? `${id}-erreur` : undefined;
  const describedBy = [hintId, errorId].filter(Boolean).join(' ') || undefined;

  return (
    <div className={`champ${error ? ' champ--erreur' : ''}`}>
      <div className="champ__etiquette-ligne">
        <label htmlFor={id} className="champ__etiquette">
          {label}
          {optional ? (
            <span className="champ__facultatif"> (facultatif)</span>
          ) : (
            <span className="champ__requis" aria-hidden="true">
              {' '}
              *
            </span>
          )}
        </label>
        {hint && hintId && (
          <InfoBulle id={hintId} label={`Aide : ${label}`}>
            {hint}
          </InfoBulle>
        )}
      </div>
      {error && (
        <p id={errorId} className="champ__message-erreur">
          <span className="visuellement-masque">Erreur : </span>
          {error}
        </p>
      )}
      <input
        id={id}
        name={id}
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        required={!optional}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        autoComplete={autoComplete}
        inputMode={inputMode}
        maxLength={maxLength}
        min={min}
        max={max}
        step={step}
        className="champ__saisie"
      />
    </div>
  );
}
