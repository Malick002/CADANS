'use client';

import { useRouter } from 'next/navigation';
import { FormEvent, useEffect, useState } from 'react';
import { ApiError, getJson, postJson } from '../../lib/api';
import { CERTIFICATIONS } from '../../lib/certifications';
import { MOTIF_REMPLACEMENT, MOTIFS_RECOURS } from '../../lib/motifs-recours';
import { montantEntier } from '../../lib/montants';
import { bilanPrefill, enumerer, mentionRemuneration, PrefillOffre } from '../../lib/prefill-offre';
import { SHIFTS } from '../../lib/shifts';
import { collectErrors, maxLength, required, validatePostalCode } from '../../lib/validation';
import { ErrorSummary } from '../form/ErrorSummary';
import { TextField } from '../form/TextField';

export interface PosteOption {
  code: string;
  label: string;
  rome: { code: string; label: string };
  habilitationsSuggerees: string[];
}

interface CompetenceOption {
  code: string;
  label: string;
}

interface MissionFormProps {
  postes: PosteOption[];
  // Valeurs reprises d'une offre France Travail, quand l'entreprise a choisi cette entrée.
  // Absentes, le formulaire est exactement celui d'avant cette fonctionnalité.
  prefill?: PrefillOffre | null;
}

type Field =
  | 'posteCode'
  | 'siteLabel'
  | 'postalCode'
  | 'startDate'
  | 'endDate'
  | 'shift'
  | 'motifRecours'
  | 'remplaceNom'
  | 'remplaceQualification'
  | 'hourlyRate'
  | 'description';

const FIELD_ORDER: Field[] = [
  'posteCode',
  'siteLabel',
  'postalCode',
  'startDate',
  'endDate',
  'shift',
  'motifRecours',
  'remplaceNom',
  'remplaceQualification',
  'hourlyRate',
  'description',
];

const INITIAL_VALUES: Record<Field, string> = {
  posteCode: '',
  siteLabel: '',
  postalCode: '',
  startDate: '',
  endDate: '',
  shift: '',
  motifRecours: '',
  remplaceNom: '',
  remplaceQualification: '',
  hourlyRate: '',
  description: '',
};

function validate(values: Record<Field, string>) {
  const remplacement = values.motifRecours === MOTIF_REMPLACEMENT;
  const errors = collectErrors<Field>({
    posteCode: required(values.posteCode, 'un intitulé de poste'),
    siteLabel: required(values.siteLabel, 'le site') ?? maxLength(values.siteLabel, 255),
    postalCode: validatePostalCode(values.postalCode),
    startDate: required(values.startDate, 'la date de début'),
    endDate: required(values.endDate, 'la date de fin'),
    shift: required(values.shift, 'un créneau'),
    motifRecours: required(values.motifRecours, 'le motif du recours'),
    // Exigés par l'article L. 1251-43 1° pour un remplacement, et par lui seul : les demander
    // dans les autres cas ferait saisir une donnée qui n'a pas à figurer au contrat.
    remplaceNom: remplacement
      ? (required(values.remplaceNom, 'le nom du salarié remplacé') ??
        maxLength(values.remplaceNom, 200))
      : undefined,
    remplaceQualification: remplacement
      ? (required(values.remplaceQualification, 'la qualification du salarié remplacé') ??
        maxLength(values.remplaceQualification, 200))
      : undefined,
    hourlyRate: required(values.hourlyRate, 'la rémunération horaire'),
    description: undefined,
  });
  if (!errors.startDate && !errors.endDate && values.endDate && values.endDate < values.startDate) {
    errors.endDate = 'La date de fin ne peut pas précéder la date de début.';
  }
  return errors;
}

export function MissionForm({ postes, prefill }: MissionFormProps) {
  const router = useRouter();
  // Valeurs initiales seulement : le composant est remonté (`key`) quand le préremplissage
  // change, donc pas besoin de les resynchroniser. Tous les champs restent modifiables.
  const [values, setValues] = useState(() => ({ ...INITIAL_VALUES, ...(prefill?.valeurs ?? {}) }));
  const [errors, setErrors] = useState<ReturnType<typeof validate>>({});
  const [globalErrors, setGlobalErrors] = useState<string[]>([]);
  const [attempt, setAttempt] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [certifications, setCertifications] = useState<Set<string>>(new Set());
  const [competences, setCompetences] = useState<CompetenceOption[]>([]);
  const [selectedCompetences, setSelectedCompetences] = useState<Set<string>>(new Set());

  const selectedPoste = postes.find((poste) => poste.code === values.posteCode);

  // Compétences proposées et habilitations suggérées dépendent du poste choisi : l'entreprise
  // ajuste ensuite librement (docs/referentiel-matching.md).
  useEffect(() => {
    if (!selectedPoste) {
      setCompetences([]);
      setSelectedCompetences(new Set());
      return;
    }
    setCertifications(new Set(selectedPoste.habilitationsSuggerees));
    setSelectedCompetences(new Set());
    let cancelled = false;
    getJson<CompetenceOption[]>('/referentiel/competences', { rome: selectedPoste.rome.code })
      .then((result) => {
        if (!cancelled) {
          setCompetences(result);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setCompetences([]);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [selectedPoste?.code]);

  const setValue =
    (key: Field) =>
    (value: string): void => {
      const next = { ...values, [key]: value };
      setValues(next);
      if (errors[key]) {
        setErrors(validate(next));
      }
    };

  const toggle = (set: Set<string>, setSet: (next: Set<string>) => void, value: string) => {
    const next = new Set(set);
    if (next.has(value)) {
      next.delete(value);
    } else {
      next.add(value);
    }
    setSet(next);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    if (submitting) {
      return;
    }

    const fieldErrors = validate(values);
    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      setAttempt((current) => current + 1);
      return;
    }

    setSubmitting(true);
    try {
      await postJson('/missions', {
        posteCode: values.posteCode,
        siteLabel: values.siteLabel,
        postalCode: values.postalCode,
        startDate: values.startDate,
        endDate: values.endDate,
        shift: values.shift,
        motifRecours: values.motifRecours,
        // Envoyés seulement pour un remplacement : `forbidNonWhitelisted` n'est pas en cause
        // (les champs existent au DTO), mais l'API les remettrait à null de toute façon —
        // autant ne pas les envoyer, le corps dit alors exactement ce que le contrat portera.
        ...(values.motifRecours === MOTIF_REMPLACEMENT
          ? {
              remplaceNom: values.remplaceNom,
              remplaceQualification: values.remplaceQualification,
            }
          : {}),
        hourlyRate: Number(values.hourlyRate),
        description: values.description.trim() ? values.description : undefined,
        requiredCertifications: [...certifications],
        competenceCodes: [...selectedCompetences],
        // Seule donnée de l'offre conservée en plus des champs du formulaire : elle sert à
        // dire d'où vient la mission, sans rien stocker de l'annonce d'origine.
        sourceOffreId: prefill?.reference,
      });
      router.push('/entreprise/missions');
    } catch (error) {
      const messages =
        error instanceof ApiError
          ? error.messages
          : ['Une erreur inattendue est survenue. Réessayez dans quelques instants.'];
      setErrors({});
      setGlobalErrors(messages);
      setAttempt((current) => current + 1);
    } finally {
      setSubmitting(false);
    }
  };

  const summary = [
    ...FIELD_ORDER.filter((key) => errors[key]).map((key) => ({
      message: errors[key]!,
      fieldId: `mission-${key}`,
    })),
    ...globalErrors.map((message) => ({ message })),
  ];

  const field = (key: Field) => ({
    id: `mission-${key}`,
    value: values[key],
    onChange: setValue(key),
    error: errors[key],
  });

  const bilan = prefill ? bilanPrefill(prefill) : null;

  return (
    <form onSubmit={handleSubmit} noValidate className="formulaire carte-formulaire">
      <ErrorSummary errors={summary} attempt={attempt} />

      {/* Provenance. Elle dit d'où viennent les champs déjà remplis SANS laisser croire que
          l'entreprise est l'auteur de l'annonce : CADANS reprend des informations publiques,
          l'offre reste celle de quelqu'un d'autre, et le lien permet de la vérifier. */}
      {prefill && bilan && (
        <section className="provenance-offre" aria-labelledby="provenance-offre-titre">
          <h2 id="provenance-offre-titre" className="provenance-offre__titre">
            Prérempli depuis l’offre France Travail n° {prefill.reference}
          </h2>
          <p className="provenance-offre__texte">
            « {prefill.intituleOffre} » — offre publiée sur France Travail par un tiers. CADANS n’en
            est pas l’auteur : les champs ci-dessous sont repris à titre d’aide à la saisie, et
            c’est la mission que vous publiez qui fait foi.{' '}
            <a href={prefill.urlOffre} target="_blank" rel="noopener noreferrer">
              Consulter l’offre d’origine (nouvel onglet)
            </a>
          </p>
          <dl className="provenance-offre__bilan">
            <div>
              <dt>Repris de l’offre</dt>
              <dd>{bilan.repris.length > 0 ? enumerer(bilan.repris) : 'aucun champ'}</dd>
            </div>
            {bilan.aSaisir.length > 0 && (
              <div>
                <dt>Reste à saisir</dt>
                <dd>{enumerer(bilan.aSaisir)}</dd>
              </div>
            )}
            <div>
              <dt>À vérifier</dt>
              {/* Une liste, pas une énumération : ces entrées sont des phrases entières, avec
                  leurs propres virgules. Recollées par « et », elles deviennent illisibles —
                  or c'est la ligne qui porte l'avertissement. `repris` et `aSaisir`, eux,
                  sont des groupes nominaux courts qui s'énumèrent très bien. */}
              <dd>
                <ul className="provenance-offre__liste">
                  {bilan.aVerifier.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </dd>
            </div>
          </dl>
        </section>
      )}

      <fieldset>
        <legend>Le poste</legend>
        <div className="champ">
          <label htmlFor="mission-posteCode" className="champ__etiquette">
            Intitulé du poste
          </label>
          <p id="mission-posteCode-indication" className="champ__indication">
            Choisi dans le référentiel des métiers de l’entrepôt (France Travail).
          </p>
          {errors.posteCode && (
            <p className="champ__message-erreur">
              <span className="visuellement-masque">Erreur : </span>
              {errors.posteCode}
            </p>
          )}
          <select
            id="mission-posteCode"
            className="champ__saisie"
            value={values.posteCode}
            onChange={(event) => setValue('posteCode')(event.target.value)}
            aria-describedby="mission-posteCode-indication"
            required
          >
            <option value="">— Choisir —</option>
            {postes.map((poste) => (
              <option key={poste.code} value={poste.code}>
                {poste.label}
              </option>
            ))}
          </select>
        </div>
      </fieldset>

      <fieldset>
        <legend>Le site</legend>
        <TextField {...field('siteLabel')} label="Site" maxLength={255} />
        <TextField
          {...field('postalCode')}
          label="Code postal du site"
          inputMode="numeric"
          maxLength={5}
        />
      </fieldset>

      <fieldset>
        <legend>La mission</legend>
        <TextField {...field('startDate')} label="Date de début" type="date" />
        <TextField {...field('endDate')} label="Date de fin" type="date" />
        <div className="champ">
          <label htmlFor="mission-shift" className="champ__etiquette">
            Créneau
          </label>
          {errors.shift && (
            <p className="champ__message-erreur">
              <span className="visuellement-masque">Erreur : </span>
              {errors.shift}
            </p>
          )}
          <select
            id="mission-shift"
            className="champ__saisie"
            value={values.shift}
            onChange={(event) => setValue('shift')(event.target.value)}
            required
          >
            <option value="">— Choisir —</option>
            {SHIFTS.map((shift) => (
              <option key={shift.value} value={shift.value}>
                {shift.label}
              </option>
            ))}
          </select>
        </div>

        {/* Première mention obligatoire du contrat de mise à disposition (art. L. 1251-43 1°).
            Liste fermée : le Code du travail énumère les cas de recours, un texte libre
            laisserait écrire n'importe quoi là où la loi attend une qualification juridique. */}
        <div className="champ">
          <label htmlFor="mission-motifRecours" className="champ__etiquette">
            Motif du recours
          </label>
          <p id="mission-motifRecours-indication" className="champ__indication">
            Il figure au contrat de mise à disposition et au contrat de mission, comme l’exige
            l’article L. 1251-43 du Code du travail.
          </p>
          {errors.motifRecours && (
            <p className="champ__message-erreur">
              <span className="visuellement-masque">Erreur : </span>
              {errors.motifRecours}
            </p>
          )}
          <select
            id="mission-motifRecours"
            className="champ__saisie"
            value={values.motifRecours}
            onChange={(event) => setValue('motifRecours')(event.target.value)}
            aria-describedby="mission-motifRecours-indication"
            required
          >
            <option value="">— Choisir —</option>
            {MOTIFS_RECOURS.map((motif) => (
              <option key={motif.value} value={motif.value}>
                {motif.label}
              </option>
            ))}
          </select>
        </div>

        {/* Affichés seulement pour un remplacement : ce sont les deux seules mentions que
            l'article rattache à ce motif, et les demander autrement ferait saisir une donnée
            qui n'a pas à figurer au contrat. */}
        {values.motifRecours === MOTIF_REMPLACEMENT && (
          <>
            <TextField
              {...field('remplaceNom')}
              label="Salarié remplacé"
              placeholder="Julien Lefevre"
              maxLength={200}
            />
            <TextField
              {...field('remplaceQualification')}
              label="Qualification du salarié remplacé"
              placeholder="Cariste"
              maxLength={200}
            />
          </>
        )}
        <TextField
          {...field('hourlyRate')}
          label="Rémunération (€/h)"
          type="number"
          inputMode="decimal"
          min={0}
          step="0.01"
        />
        {/* Visible sans interaction, contrairement à l'infobulle de TextField : un taux
            converti d'un salaire mensuel ne doit jamais pouvoir être pris pour une donnée de
            l'offre, même par quelqu'un qui ne survole rien. */}
        {prefill?.remuneration && (
          <p className="mention-remuneration">
            {mentionRemuneration(prefill.remuneration, montantEntier)}
          </p>
        )}
      </fieldset>

      <fieldset>
        <legend>Habilitation CACES requise</legend>
        <p className="champ__indication">
          Pré-remplie d’après le poste choisi, ajustable. Aucune sélection : pas d’habilitation
          exigée.
        </p>
        <div className="puces">
          {CERTIFICATIONS.map((cert) => (
            <button
              key={cert.value}
              type="button"
              className={`puce${certifications.has(cert.value) ? ' puce--selectionnee' : ''}`}
              aria-pressed={certifications.has(cert.value)}
              onClick={() => toggle(certifications, setCertifications, cert.value)}
            >
              {cert.label}
            </button>
          ))}
        </div>
        {certifications.size > 0 && (
          <p className="avis-caces">
            Le matching écartera toute candidature sans{' '}
            {[...certifications]
              .map((c) => CERTIFICATIONS.find((x) => x.value === c)?.label ?? c)
              .join(', ')}{' '}
            valide.
          </p>
        )}
      </fieldset>

      <fieldset>
        <legend>Compétences souhaitées</legend>
        {!selectedPoste ? (
          <p className="champ__indication">Choisissez d’abord un intitulé de poste.</p>
        ) : competences.length === 0 ? (
          <p className="champ__indication">Aucune compétence proposée pour ce métier.</p>
        ) : (
          <div className="puces">
            {competences.map((competence) => (
              <button
                key={competence.code}
                type="button"
                className={`puce${selectedCompetences.has(competence.code) ? ' puce--selectionnee' : ''}`}
                aria-pressed={selectedCompetences.has(competence.code)}
                onClick={() => toggle(selectedCompetences, setSelectedCompetences, competence.code)}
              >
                {competence.label}
              </button>
            ))}
          </div>
        )}
      </fieldset>

      <fieldset>
        <legend>Description</legend>
        <div className="champ">
          <label htmlFor="mission-description" className="champ__etiquette">
            Description libre
            <span className="champ__facultatif"> (facultatif)</span>
          </label>
          {prefill?.valeurs.description && (
            <p id="mission-description-provenance" className="champ__indication">
              Texte repris de l’offre France Travail, à relire et adapter. Les adresses
              électroniques, numéros de téléphone et liens de l’annonce d’origine en ont été
              retirés.
            </p>
          )}
          <textarea
            id="mission-description"
            className="champ__saisie"
            rows={4}
            maxLength={2000}
            value={values.description}
            onChange={(event) => setValue('description')(event.target.value)}
            aria-describedby={
              prefill?.valeurs.description ? 'mission-description-provenance' : undefined
            }
          />
        </div>
      </fieldset>

      <div className="mission-form__actions">
        <button
          type="button"
          className="bouton bouton--secondaire"
          onClick={() => router.push('/entreprise/missions')}
          disabled={submitting}
        >
          Annuler
        </button>
        <button type="submit" className="bouton bouton--principal" disabled={submitting}>
          {submitting ? 'Publication…' : 'Publier la mission'}
        </button>
      </div>
    </form>
  );
}
