'use client';

import { FormEvent, useId, useState } from 'react';
import { ApiError, postJson } from '../../lib/api';
import { PrefillOffre } from '../../lib/prefill-offre';
import { MissionForm, PosteOption } from './MissionForm';

interface SourceMissionProps {
  postes: PosteOption[];
  // Faux quand le serveur n'a pas les identifiants France Travail : l'entrée est alors
  // absente, pas désactivée. Une entrée qui échoue à tous les coups vaut moins qu'une
  // entrée qu'on ne propose pas.
  offresDisponibles: boolean;
}

type Source = 'vierge' | 'offre';

export function SourceMission({ postes, offresDisponibles }: SourceMissionProps) {
  const groupe = useId();
  const [source, setSource] = useState<Source>('vierge');
  const [saisie, setSaisie] = useState('');
  const [chargement, setChargement] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);
  const [prefill, setPrefill] = useState<PrefillOffre | null>(null);

  // Le formulaire vierge reste le comportement par défaut et n'est pas modifié : sans cette
  // entrée, l'écran est exactement celui d'avant.
  if (!offresDisponibles) {
    return <MissionForm postes={postes} />;
  }

  const choisir = (valeur: Source): void => {
    setSource(valeur);
    setErreur(null);
    // Revenir au formulaire vierge abandonne le préremplissage : les champs repris de
    // l'offre disparaissent avec lui, sans quoi l'écran mentirait sur leur provenance.
    if (valeur === 'vierge') {
      setPrefill(null);
    }
  };

  const preremplir = async (event: FormEvent): Promise<void> => {
    event.preventDefault();
    if (chargement) {
      return;
    }
    setChargement(true);
    setErreur(null);
    try {
      setPrefill(await postJson<PrefillOffre>('/missions/prefill', { source: saisie }));
    } catch (error) {
      // Tout échec ramène au formulaire vierge, qui est déjà affiché en dessous : l'entreprise
      // n'est jamais bloquée, elle lit ce qui s'est passé et continue sa saisie. La valeur
      // collée est conservée dans l'état : re-choisir l'entrée « Partir d'une offre » la
      // retrouve telle quelle, sans avoir à la retaper pour corriger une faute de frappe.
      setPrefill(null);
      setSource('vierge');
      setErreur(
        error instanceof ApiError
          ? error.messages.join(' ')
          : 'Le préremplissage a échoué. Saisissez la mission dans le formulaire.',
      );
    } finally {
      setChargement(false);
    }
  };

  return (
    <>
      <fieldset className="choix-parcours-fieldset">
        <legend>Comment voulez-vous commencer ?</legend>
        <ul className="choix-parcours">
          {(
            [
              {
                valeur: 'vierge' as const,
                titre: 'Formulaire vierge',
                texte: 'Vous saisissez la mission de bout en bout.',
              },
              {
                valeur: 'offre' as const,
                titre: 'Partir d’une offre France Travail',
                texte:
                  'Quelques champs sont repris d’une offre existante. Vous complétez et ' +
                  'corrigez tout ce qui doit l’être.',
              },
            ] satisfies { valeur: Source; titre: string; texte: string }[]
          ).map((choix) => (
            <li key={choix.valeur}>
              <label
                className={
                  source === choix.valeur ? 'carte-choix carte-choix--selectionnee' : 'carte-choix'
                }
              >
                <input
                  type="radio"
                  name={groupe}
                  value={choix.valeur}
                  checked={source === choix.valeur}
                  onChange={() => choisir(choix.valeur)}
                  className="carte-choix__radio"
                />
                <span className="carte-choix__titre">{choix.titre}</span>
                <span className="carte-choix__texte">{choix.texte}</span>
              </label>
            </li>
          ))}
        </ul>
      </fieldset>

      {/* `role="status"` : l'échec est annoncé sans voler le focus, que l'on replace nous-mêmes
          sur le champ de saisie pour que l'entreprise puisse corriger son lien. */}
      {erreur && (
        <div className="toast toast--danger source-offre__erreur" role="status">
          <p className="toast__texte">{erreur}</p>
        </div>
      )}

      {source === 'offre' && (
        // Formulaire imbriqué interdit en HTML : celui-ci est déclaré AVANT le formulaire de
        // mission, jamais dedans. C'est aussi pourquoi il porte son propre bouton de
        // soumission, qui n'a rien à voir avec « Publier la mission ».
        <form onSubmit={preremplir} noValidate className="source-offre">
          <div className="champ">
            <label htmlFor="offre-source" className="champ__etiquette">
              Adresse ou identifiant de l’offre
            </label>
            <p id="offre-source-indication" className="champ__indication">
              Par exemple <code>candidat.francetravail.fr/offres/recherche/detail/214GWTK</code>, ou
              simplement <code>214GWTK</code>.
            </p>
            <div className="source-offre__ligne">
              <input
                id="offre-source"
                type="text"
                className="champ__saisie"
                value={saisie}
                onChange={(event) => setSaisie(event.target.value)}
                aria-describedby="offre-source-indication"
                maxLength={500}
                autoComplete="off"
              />
              <button
                type="submit"
                className="bouton bouton--secondaire"
                disabled={chargement || saisie.trim() === ''}
              >
                {chargement ? 'Lecture…' : 'Préremplir'}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* `key` remonte le formulaire quand le préremplissage change : les valeurs initiales
          sont reprises, et les champs d'une tentative précédente ne survivent pas. */}
      <MissionForm key={prefill?.reference ?? 'vierge'} postes={postes} prefill={prefill} />
    </>
  );
}
