'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getJson } from '../../lib/api';

interface Compte {
  role: 'COMPANY' | 'WORKER' | 'ADMIN';
}

/**
 * Rappel affiché en tête de `/missions` **pour un intérimaire connecté** : cette liste n'est
 * pas celle de ses matches.
 *
 * **Le défaut qu'il corrige.** Les deux listes n'ont ni la même source ni le même tri —
 * `/missions` montre toutes les missions ouvertes, `/interimaire/matches` celles qui passent
 * le filtre créneau puis le filtrage bloquant sur les CACES. Rien ne l'expliquait. Un
 * intérimaire voyait six offres ici, trois dans ses matches, et les trois manquantes étaient
 * précisément celles qu'il ne peut pas obtenir : il pouvait les ouvrir, les lire, et se faire
 * refuser en 409 à la candidature. La seule trace de la règle — le compteur de missions
 * masquées — vit dans les matches, c'est-à-dire là où il n'est pas.
 *
 * **Pourquoi la session est lue dans le navigateur.** Pas pour préserver un pré-rendu :
 * `/missions` est déjà rendue à la demande, son `fetch` des offres est en `no-store`
 * (vérifié au rapport de build, elle y est marquée `ƒ`). La raison est que **le HTML servi
 * doit rester identique avec et sans cookie de session** : c'est la page qu'un moteur
 * indexe, et ce qu'il voit doit être ce que voit un visiteur. Lire le cookie côté serveur
 * ferait varier le document selon le demandeur, et ajouterait un appel `/auth/me` au rendu
 * de chaque visiteur anonyme — c'est-à-dire de la quasi-totalité d'entre eux.
 *
 * Même arbitrage et même conséquence assumée que `BoutonsCompte` : le rendu initial est celui
 * du visiteur anonyme, remplacé après hydratation. Un navigateur sans JavaScript ne voit pas
 * ce rappel — il ne perd rien qui ne soit déjà dit par le chapeau de la page.
 *
 * Les entreprises et les agents ne le voient pas : ils n'ont pas de matches.
 */
export function RappelMatches() {
  const [estInterimaire, setEstInterimaire] = useState(false);

  useEffect(() => {
    let annule = false;
    getJson<Compte>('/auth/me')
      .then((compte) => {
        if (!annule && compte.role === 'WORKER') {
          setEstInterimaire(true);
        }
      })
      .catch(() => {
        // 401 attendu pour un visiteur : c'est le cas courant, pas une erreur.
      });
    return () => {
      annule = true;
    };
  }, []);

  if (!estInterimaire) {
    return null;
  }

  return (
    <div className="rappel-matches" role="status">
      <p className="rappel-matches__texte">
        Vous voyez ici <strong>toutes les offres ouvertes</strong>, y compris celles qui exigent une
        habilitation que vous n’avez pas ou un créneau que vous n’acceptez pas. Les missions
        auxquelles vous pouvez réellement postuler sont dans vos matches, les mieux notées d’abord.
      </p>
      <Link href="/interimaire/matches" className="bouton bouton--secondaire">
        Voir mes matches
      </Link>
    </div>
  );
}
