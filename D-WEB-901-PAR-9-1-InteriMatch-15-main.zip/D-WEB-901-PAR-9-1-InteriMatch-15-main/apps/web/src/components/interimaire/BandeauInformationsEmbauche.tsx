import Link from 'next/link';
import { serverGet } from '../../lib/session';

interface Etat {
  complet: boolean;
  requis: boolean;
  missionsRetenues: number;
}

/**
 * Bandeau « informations nécessaires à votre contrat », rendu en tête de l'espace
 * intérimaire.
 *
 * **Il vit dans le layout, pas dans une page**, parce que l'intérimaire retenu sur une
 * mission doit le voir où qu'il soit — sur ses matches comme sur son profil. Une seule
 * requête supplémentaire par navigation : l'espace connecté est déjà rendu dynamiquement
 * (il lit la session), aucun pré-rendu n'est perdu.
 *
 * **Il ne s'affiche que quand il a quelque chose à dire** : l'intérimaire est retenu sur au
 * moins une mission ET son formulaire n'est pas complet. Tant qu'il n'a aucune mission, lui
 * réclamer un NIR et un IBAN serait collecter au-delà du nécessaire.
 *
 * Une erreur d'appel ne rend rien : un bandeau informatif ne doit jamais faire tomber
 * l'espace entier.
 */
export async function BandeauInformationsEmbauche() {
  let etat: Etat;
  try {
    etat = await serverGet<Etat>('/workers/me/informations-embauche');
  } catch {
    return null;
  }

  if (!etat.requis || etat.complet) {
    return null;
  }

  return (
    // La zone extérieure reproduit la colonne du `main` du tableau de bord : le bandeau
    // vit hors de `main` (il est rendu par le layout), il n'hériterait donc d'aucune marge
    // et partirait d'un bord à l'autre de l'écran.
    <div className="bandeau-embauche-zone">
      <div className="bandeau-embauche" role="status">
        <p className="bandeau-embauche__titre">Informations nécessaires à votre contrat</p>
        <p className="bandeau-embauche__texte">
          Vous avez été retenu sur{' '}
          {etat.missionsRetenues > 1 ? `${etat.missionsRetenues} missions` : 'une mission'}. CADANS
          est votre employeur : votre contrat de mission ne peut être établi qu’une fois votre état
          civil, votre adresse, votre numéro de sécurité sociale et votre IBAN renseignés.
        </p>
        <Link href="/interimaire/informations-embauche" className="bouton bouton--principal">
          Compléter mes informations
        </Link>
      </div>
    </div>
  );
}
