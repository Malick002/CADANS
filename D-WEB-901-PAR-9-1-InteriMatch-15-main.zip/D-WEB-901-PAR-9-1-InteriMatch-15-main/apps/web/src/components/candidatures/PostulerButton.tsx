'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { ApiError, postJson } from '../../lib/api';

interface PostulerButtonProps {
  missionId: string;
  initiallyApplied: boolean;
}

// Postule sans quitter la page, puis rafraîchit les données serveur (score, liste) pour
// refléter le nouvel état — plus simple qu'un état local dupliqué de ce que l'API renvoie.
export function PostulerButton({ missionId, initiallyApplied }: PostulerButtonProps) {
  const router = useRouter();
  const [applied, setApplied] = useState(initiallyApplied);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (applied) {
    return <p className="candidature-envoyee">Candidature envoyée</p>;
  }

  const handleClick = async (): Promise<void> => {
    if (submitting) {
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await postJson(`/missions/${missionId}/candidatures`, {});
      setApplied(true);
      router.refresh();
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.messages.join(' ')
          : 'Une erreur inattendue est survenue. Réessayez dans quelques instants.',
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <button
        type="button"
        className="bouton bouton--principal"
        onClick={handleClick}
        disabled={submitting}
      >
        {submitting ? 'Envoi…' : 'Postuler'}
      </button>
      {error && (
        <p className="champ__message-erreur" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
