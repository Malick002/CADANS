'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { ApiError, patchJson } from '../../lib/api';

interface RetenirCandidatProps {
  missionId: string;
  workerId: string;
  // Prénom et nom, pour que la confirmation nomme la personne plutôt que « ce candidat ».
  candidat: string;
}

/**
 * Retenir un intérimaire sur une mission.
 *
 * **Le trou que ce bouton comble** : l'écran des candidatures listait des candidats sans
 * qu'aucune action soit possible. `PATCH /missions/:id/status` existait, était testé — et
 * n'était appelé par AUCUNE page. Toute la suite (génération des deux contrats, notification
 * n8n « mission pourvue ») n'avait donc pas de point d'entrée dans l'interface.
 *
 * **Confirmation obligatoire, et c'est délibéré.** L'action n'est pas réversible depuis
 * l'écran : elle passe la mission à POURVUE, fait générer les contrats et déclenche l'envoi
 * d'un email à l'intérimaire. Un clic isolé sur une liste de candidats ne doit pas faire tout
 * cela sans qu'on ait dit à quoi on s'engage.
 */
export function RetenirCandidat({ missionId, workerId, candidat }: RetenirCandidatProps) {
  const router = useRouter();
  const [confirmation, setConfirmation] = useState(false);
  const [envoi, setEnvoi] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);

  const retenir = async (): Promise<void> => {
    if (envoi) {
      return;
    }
    setEnvoi(true);
    setErreur(null);
    try {
      await patchJson(`/missions/${missionId}/status`, { status: 'POURVUE', workerId });
      // `refresh` et non `push` : la page est rendue côté serveur, elle se recharge avec la
      // mission passée à POURVUE et disparaît donc de la liste des missions à pourvoir.
      router.refresh();
    } catch (error) {
      setErreur(
        error instanceof ApiError
          ? error.messages.join(' ')
          : 'Une erreur inattendue est survenue. Réessayez dans quelques instants.',
      );
      setConfirmation(false);
    } finally {
      setEnvoi(false);
    }
  };

  if (!confirmation) {
    return (
      <div className="candidature-recue__action">
        {erreur && (
          <p className="candidature-recue__erreur" role="alert">
            {erreur}
          </p>
        )}
        <button
          type="button"
          className="bouton bouton--principal"
          onClick={() => setConfirmation(true)}
        >
          Retenir {candidat}
        </button>
      </div>
    );
  }

  return (
    // `role="group"` et non `alertdialog` : ce n'est pas une fenêtre modale, elle ne capture
    // ni le focus ni la page. Le texte dit ce qui va se produire, les deux boutons se suivent
    // dans l'ordre de lecture.
    <div className="candidature-recue__confirmation" role="group" aria-label="Confirmation">
      <p>
        <strong>Retenir {candidat} pour cette mission ?</strong> La mission passera à « Pourvue »,
        les deux contrats seront générés, et {candidat.split(' ')[0]} recevra un email l’invitant à
        les signer. Les autres candidatures resteront visibles, mais la mission ne sera plus
        proposée.
      </p>
      <div className="candidature-recue__confirmation-actions">
        <button
          type="button"
          className="bouton bouton--principal"
          onClick={retenir}
          disabled={envoi}
        >
          {envoi ? 'Enregistrement…' : 'Confirmer'}
        </button>
        <button
          type="button"
          className="bouton bouton--secondaire"
          onClick={() => setConfirmation(false)}
          disabled={envoi}
        >
          Annuler
        </button>
      </div>
    </div>
  );
}
