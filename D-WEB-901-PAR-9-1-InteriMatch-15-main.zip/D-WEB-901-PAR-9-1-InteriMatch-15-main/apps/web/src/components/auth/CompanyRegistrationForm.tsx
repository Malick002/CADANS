'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { postJson } from '../../lib/api';
import {
  collectErrors,
  maxLength,
  required,
  validateConsent,
  validateEmail,
  validateNafCode,
  validatePassword,
  validatePhone,
  validatePostalCode,
  validateSiret,
} from '../../lib/validation';
import { CheckboxField } from '../form/CheckboxField';
import { ErrorSummary } from '../form/ErrorSummary';
import { PasswordField } from '../form/PasswordField';
import { TextField } from '../form/TextField';
import { useAuthForm } from './useAuthForm';

type CompanyField =
  | 'legalName'
  | 'siret'
  | 'nafCode'
  | 'addressLine'
  | 'postalCode'
  | 'city'
  | 'contactFirstName'
  | 'contactLastName'
  | 'phone'
  | 'email'
  | 'password'
  | 'consentement';

interface CompanyAccount {
  email: string;
  company: { legalName: string } | null;
}

const FIELD_ORDER: CompanyField[] = [
  'legalName',
  'siret',
  'nafCode',
  'addressLine',
  'postalCode',
  'city',
  'contactFirstName',
  'contactLastName',
  'phone',
  'email',
  'password',
  'consentement',
];

const INITIAL_VALUES = Object.fromEntries(FIELD_ORDER.map((key) => [key, ''])) as Record<
  CompanyField,
  string
>;

function validate(values: Record<CompanyField, string>) {
  return collectErrors<CompanyField>({
    legalName: required(values.legalName, 'la raison sociale') ?? maxLength(values.legalName, 255),
    siret: validateSiret(values.siret),
    nafCode: validateNafCode(values.nafCode),
    addressLine: required(values.addressLine, "l'adresse") ?? maxLength(values.addressLine, 255),
    postalCode: validatePostalCode(values.postalCode),
    city: required(values.city, 'la ville') ?? maxLength(values.city, 100),
    contactFirstName:
      required(values.contactFirstName, 'le prénom du contact') ??
      maxLength(values.contactFirstName, 100),
    contactLastName:
      required(values.contactLastName, 'le nom du contact') ??
      maxLength(values.contactLastName, 100),
    phone: validatePhone(values.phone),
    email: validateEmail(values.email),
    password: validatePassword(values.password),
    consentement: validateConsent(values.consentement),
  });
}

// POST /auth/register/company : crée le compte et ouvre la session (cookie posé par l'API).
function send(values: Record<CompanyField, string>): Promise<CompanyAccount> {
  // La case est validée ici et par l'API, qui refuse l'inscription sans acceptation et en
  // enregistre la date (CredentialsDto, AuthService).
  const { phone, nafCode, consentement, ...rest } = values;
  return postJson<CompanyAccount>('/auth/register/company', {
    ...rest,
    acceptConditions: true,
    // L'API attend la lettre du code NAF en majuscule (52.10B).
    nafCode: nafCode.trim().toUpperCase(),
    // Champ facultatif : absent plutôt que vide, sinon l'API le valide et le refuse.
    ...(phone.trim() ? { phone } : {}),
  });
}

export function CompanyRegistrationForm() {
  const router = useRouter();
  const form = useAuthForm<CompanyField, CompanyAccount>({
    idPrefix: 'entreprise',
    initialValues: INITIAL_VALUES,
    fieldOrder: FIELD_ORDER,
    // La lettre du code NAF est acceptée en minuscule à la saisie, comme à l'envoi.
    validate: (values) => validate({ ...values, nafCode: values.nafCode.trim().toUpperCase() }),
    send,
    conflictField: (message) =>
      message.includes('SIRET') ? 'siret' : message.includes('email') ? 'email' : undefined,
  });

  const result = form.result;
  useEffect(() => {
    if (result) {
      router.push('/entreprise/missions');
    }
  }, [result, router]);

  // L'API ouvre déjà la session à l'inscription : renvoyer vers /connexion demanderait de
  // se reconnecter alors qu'on l'est. On entre directement dans l'espace, comme après une
  // connexion (LoginForm). L'écran de confirmation était un cul-de-sac : sa seule sortie,
  // « Retour à l'accueil », ramenait sur la page publique.
  if (form.result) {
    return null;
  }

  const field = (key: CompanyField) => ({
    id: form.fieldId(key),
    value: form.values[key],
    onChange: form.setValue(key),
    error: form.errors[key],
  });

  return (
    <form onSubmit={form.handleSubmit} noValidate className="formulaire">
      <ErrorSummary errors={form.summary} attempt={form.attempt} />

      <p className="formulaire__mention">
        Tous les champs sont obligatoires, sauf mention « facultatif ».
      </p>

      <fieldset>
        <legend>Identification de l’entreprise</legend>
        <div className="champs-duo">
          <TextField
            {...field('siret')}
            label="Numéro SIRET"
            inputMode="numeric"
            hint="14 chiffres, espaces acceptés."
            placeholder="732 829 320 00074"
            maxLength={20}
          />
          <TextField
            {...field('nafCode')}
            label="Code NAF (APE)"
            hint="Figure sur votre extrait Kbis."
            placeholder="52.10B"
            maxLength={6}
          />
        </div>
        <TextField
          {...field('legalName')}
          label="Raison sociale"
          autoComplete="organization"
          placeholder="Entrepôts du Rhône SARL"
          maxLength={255}
        />
      </fieldset>

      <fieldset>
        <legend>Personne à contacter</legend>
        <div className="champs-duo">
          <TextField
            {...field('contactFirstName')}
            label="Prénom"
            autoComplete="given-name"
            placeholder="Camille"
            maxLength={100}
          />
          <TextField
            {...field('contactLastName')}
            label="Nom"
            autoComplete="family-name"
            placeholder="Martin"
            maxLength={100}
          />
        </div>
        <TextField
          {...field('email')}
          label="Adresse email professionnelle"
          type="email"
          inputMode="email"
          autoComplete="email"
          placeholder="recrutement@entreprise.fr"
          maxLength={255}
        />
        <TextField
          {...field('phone')}
          label="Téléphone"
          type="tel"
          inputMode="tel"
          autoComplete="tel-national"
          placeholder="04 72 12 34 56"
          optional
        />
      </fieldset>

      <fieldset>
        <legend>Adresse de l’entreprise</legend>
        <TextField
          {...field('addressLine')}
          label="Adresse"
          autoComplete="address-line1"
          hint="Numéro et nom de la voie."
          placeholder="12 rue des Entrepôts"
          maxLength={255}
        />
        <div className="champs-duo">
          <TextField
            {...field('postalCode')}
            label="Code postal"
            inputMode="numeric"
            autoComplete="postal-code"
            placeholder="69007"
            maxLength={5}
          />
          <TextField
            {...field('city')}
            label="Ville"
            autoComplete="address-level2"
            placeholder="Lyon"
            maxLength={100}
          />
        </div>
      </fieldset>

      <fieldset>
        <legend>Mot de passe</legend>
        <PasswordField {...field('password')} />
      </fieldset>

      <CheckboxField
        {...field('consentement')}
        label={
          <>
            J’accepte les conditions générales d’utilisation et la{' '}
            <Link href="/politique-de-confidentialite">politique de confidentialité</Link>.
          </>
        }
      />

      <button type="submit" className="bouton bouton--principal" disabled={form.submitting}>
        {form.submitting ? 'Création du compte…' : 'Créer mon compte entreprise'}
      </button>

      <p className="page-auth__pied page-auth__pied--sans-ligne">
        Vous avez déjà un compte ? <Link href="/connexion">Se connecter →</Link>
      </p>
    </form>
  );
}
