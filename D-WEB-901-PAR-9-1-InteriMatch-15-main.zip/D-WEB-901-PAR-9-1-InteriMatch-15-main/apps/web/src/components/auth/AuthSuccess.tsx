'use client';

import Link from 'next/link';
import { type ReactNode, useEffect, useRef } from 'react';

interface AuthSuccessProps {
  title: string;
  children: ReactNode;
}

// Confirmation affichée à la place du formulaire, après une inscription ou une connexion
// réussie : le titre reçoit le focus pour être annoncé par les lecteurs d'écran, le
// formulaire ayant disparu de la page.
export function AuthSuccess({ title, children }: AuthSuccessProps) {
  const titleRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    titleRef.current?.focus();
  }, []);

  return (
    <section className="confirmation" aria-labelledby="confirmation-titre">
      <h2 id="confirmation-titre" ref={titleRef} tabIndex={-1}>
        {title}
      </h2>
      {children}
      <p>
        <Link href="/">Retour à l’accueil</Link>
      </p>
    </section>
  );
}
