'use client';

import { useSearchParams } from 'next/navigation';
import { useEffect, useId, useState } from 'react';
import { CompanyRegistrationForm } from './CompanyRegistrationForm';
import { WorkerRegistrationForm } from './WorkerRegistrationForm';
import { Logo } from '../Logo';

type TypeCompte = 'interimaire' | 'entreprise';

interface Choix {
  valeur: TypeCompte;
  badge: string;
  titre: string;
  texte: string;
}

const CHOIX: Choix[] = [
  {
    valeur: 'interimaire',
    badge: 'Intérimaire',
    titre: 'Un ou une intérimaire',
    texte:
      'Vous recevez des missions en entrepôt proches de chez vous, selon vos CACES et vos créneaux.',
  },
  {
    valeur: 'entreprise',
    badge: 'Entreprise',
    titre: 'Une entreprise',
    texte: 'Vous publiez des missions et recevez des profils qualifiés, habilitations vérifiées.',
  },
];

/**
 * Inscription en une seule page : le profil choisi met à jour le formulaire affiché en
 * dessous, sans navigation. Le choix passe par un vrai groupe de radios — le clavier et les
 * lecteurs d'écran y voient un choix unique standard, et l'état sélectionné est annoncé sans
 * dépendre de la mise en forme des cartes.
 *
 * Le composant est client pour l'interactivité, mais rendu côté serveur au premier
 * chargement : la page reste indexable.
 */
// `?profil=entreprise` ou `?profil=interimaire` : les rubriques « Pour les entreprises » et
// « Pour les intérimaires » de l'en-tête mènent ici avec le bon profil déjà choisi. Toute
// autre valeur est ignorée, on retombe sur le premier profil.
function profilDemande(valeur: string | null): TypeCompte | null {
  return CHOIX.some((candidat) => candidat.valeur === valeur) ? (valeur as TypeCompte) : null;
}

export function InscriptionFormulaire() {
  const profil = profilDemande(useSearchParams().get('profil'));
  const [type, setType] = useState<TypeCompte>(profil ?? CHOIX[0]!.valeur);
  const nomGroupe = useId();
  const choix = CHOIX.find((candidat) => candidat.valeur === type)!;

  // Le composant reste monté quand on passe d'une rubrique à l'autre depuis l'en-tête :
  // seule l'adresse change, il faut donc suivre le paramètre après le premier rendu.
  // Le profil choisi à la main n'est pas écrasé, puisque seul un changement d'adresse
  // relance cet effet.
  useEffect(() => {
    if (profil) {
      setType(profil);
    }
  }, [profil]);

  return (
    <>
      <div className="page-auth__entete">
        <p className="page-auth__logo">
          <Logo taille={1.125} />
        </p>
        {/* Le badge suit le profil sélectionné : le visiteur voit à tout moment ce qu'il crée.
            `key` refait apparaître le badge à chaque changement, pour l'animation d'entrée. */}
        <span className="badge-role" key={type}>
          {choix.badge}
        </span>
      </div>

      <h1>Créer un compte CADANS</h1>

      <fieldset className="choix-parcours-fieldset">
        <legend>Vous êtes :</legend>
        <ul className="choix-parcours">
          {CHOIX.map((candidat) => (
            <li key={candidat.valeur}>
              <label
                className={
                  type === candidat.valeur ? 'carte-choix carte-choix--selectionnee' : 'carte-choix'
                }
              >
                <input
                  type="radio"
                  name={nomGroupe}
                  value={candidat.valeur}
                  checked={type === candidat.valeur}
                  onChange={() => setType(candidat.valeur)}
                  className="carte-choix__radio"
                />
                <span className="carte-choix__titre">{candidat.titre}</span>
                <span className="carte-choix__texte">{candidat.texte}</span>
              </label>
            </li>
          ))}
        </ul>
      </fieldset>

      {/* `key` remonte le formulaire à chaque changement de profil : les champs saisis pour
          l'un ne restent pas affichés sous l'autre, et l'animation d'entrée rejoue. */}
      <div key={type} className="formulaire-transition">
        {type === 'entreprise' ? <CompanyRegistrationForm /> : <WorkerRegistrationForm />}
      </div>
    </>
  );
}
