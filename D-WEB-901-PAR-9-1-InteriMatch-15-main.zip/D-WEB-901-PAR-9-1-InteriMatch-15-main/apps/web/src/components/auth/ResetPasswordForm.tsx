'use client';

import Link from 'next/link';
import { postJson } from '../../lib/api';
import { collectErrors, PASSWORD_MAX_LENGTH, validatePassword } from '../../lib/validation';
import { ErrorSummary } from '../form/ErrorSummary';
import { PasswordField } from '../form/PasswordField';
import { TextField } from '../form/TextField';
import { AuthSuccess } from './AuthSuccess';
import { useAuthForm } from './useAuthForm';

type ResetField = 'password' | 'confirmation';

const FIELD_ORDER: ResetField[] = ['password', 'confirmation'];

function validate(values: Record<ResetField, string>) {
  return collectErrors<ResetField>({
    password: validatePassword(values.password),
    // Une faute de frappe non détectée enfermerait dehors : le lien est à usage unique.
    confirmation:
      values.confirmation === ''
        ? 'Saisissez à nouveau le mot de passe.'
        : values.confirmation === values.password
          ? undefined
          : 'Les deux mots de passe ne sont pas identiques.',
  });
}

export function ResetPasswordForm({ token }: { token: string }) {
  const form = useAuthForm<ResetField, 'modifié'>({
    idPrefix: 'reinitialisation',
    initialValues: { password: '', confirmation: '' },
    fieldOrder: FIELD_ORDER,
    validate,
    // POST /auth/password-reset/confirm : 204 sans corps, 400 si le lien ne vaut plus.
    send: async (values) => {
      await postJson<void>('/auth/password-reset/confirm', {
        token,
        password: values.password,
      });
      return 'modifié';
    },
  });

  // La session n'est pas ouverte automatiquement : on renvoie vers la connexion, qui est
  // aussi la preuve que le nouveau mot de passe fonctionne.
  if (form.result) {
    return (
      <AuthSuccess title="Votre mot de passe est modifié">
        <p>
          Vous pouvez maintenant <Link href="/connexion">vous connecter</Link> avec votre nouveau
          mot de passe.
        </p>
      </AuthSuccess>
    );
  }

  return (
    <form onSubmit={form.handleSubmit} noValidate className="formulaire">
      {/* Lien expiré, déjà utilisé ou inconnu : l'API renvoie un seul et même message,
          affiché ici en erreur globale. */}
      <ErrorSummary errors={form.summary} attempt={form.attempt} />

      <PasswordField
        id={form.fieldId('password')}
        value={form.values.password}
        onChange={form.setValue('password')}
        error={form.errors.password}
      />
      <TextField
        id={form.fieldId('confirmation')}
        label="Confirmer le mot de passe"
        value={form.values.confirmation}
        onChange={form.setValue('confirmation')}
        error={form.errors.confirmation}
        type="password"
        autoComplete="new-password"
        maxLength={PASSWORD_MAX_LENGTH}
      />

      <button type="submit" className="bouton bouton--principal" disabled={form.submitting}>
        {form.submitting ? 'Enregistrement…' : 'Choisir ce mot de passe'}
      </button>
    </form>
  );
}
