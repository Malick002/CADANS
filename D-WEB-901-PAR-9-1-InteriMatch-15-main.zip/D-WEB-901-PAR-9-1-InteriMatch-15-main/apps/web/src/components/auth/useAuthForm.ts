'use client';

import { FormEvent, useRef, useState } from 'react';
import { ApiError } from '../../lib/api';
import type { FieldErrors } from '../../lib/validation';
import type { SummaryError } from '../form/ErrorSummary';

interface Options<K extends string, Result> {
  // Préfixe des identifiants HTML, pour qu'ils restent uniques dans la page.
  idPrefix: string;
  initialValues: Record<K, string>;
  // Ordre des champs dans le formulaire : le récapitulatif d'erreurs le respecte.
  fieldOrder: K[];
  validate: (values: Record<K, string>) => FieldErrors<K>;
  send: (values: Record<K, string>) => Promise<Result>;
  // Rattache un message 409 de l'API (email ou SIRET déjà utilisé) au champ concerné.
  // Inutile à la connexion, qui n'a pas de conflit possible : l'erreur y reste globale.
  conflictField?: (message: string) => K | undefined;
}

// Formulaire d'authentification : inscription entreprise, inscription intérimaire, connexion.
// Les trois partagent la même mécanique — validation avant envoi, récapitulatif d'erreurs,
// protection contre la double soumission — et ne diffèrent que par leurs champs.
export function useAuthForm<K extends string, Result>({
  idPrefix,
  initialValues,
  fieldOrder,
  validate,
  send,
  conflictField,
}: Options<K, Result>) {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState<FieldErrors<K>>({});
  const [globalErrors, setGlobalErrors] = useState<string[]>([]);
  const [attempt, setAttempt] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  // Miroir synchrone de `values` : un appel de `setValue` déclenché après coup par un effet
  // asynchrone (le remplissage de la ville depuis le code postal, par exemple) doit repartir
  // des dernières valeurs, pas de celles figées dans la fermeture au moment où l'effet a
  // démarré — sinon il écrase la frappe la plus récente sur un autre champ.
  const valuesRef = useRef(values);
  valuesRef.current = values;

  const fieldId = (key: K): string => `${idPrefix}-${key}`;

  // Après une soumission refusée, l'erreur d'un champ disparaît dès qu'il devient valide.
  const setValue =
    (key: K) =>
    (value: string): void => {
      const next = { ...valuesRef.current, [key]: value };
      valuesRef.current = next;
      setValues(next);
      if (errors[key]) {
        setErrors((current) => ({ ...current, [key]: validate(next)[key] }));
      }
    };

  const fail = (fieldErrors: FieldErrors<K>, messages: string[] = []): void => {
    setErrors(fieldErrors);
    setGlobalErrors(messages);
    setAttempt((current) => current + 1);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    if (submitting) {
      return;
    }

    const fieldErrors = validate(values);
    if (Object.keys(fieldErrors).length > 0) {
      fail(fieldErrors);
      return;
    }

    setSubmitting(true);
    try {
      setResult(await send(values));
      setErrors({});
      setGlobalErrors([]);
    } catch (error) {
      if (!(error instanceof ApiError)) {
        fail({}, ['Une erreur inattendue est survenue. Réessayez dans quelques instants.']);
        return;
      }
      const conflictKey =
        error.status === 409 ? conflictField?.(error.messages[0] ?? '') : undefined;
      if (conflictKey) {
        fail({ [conflictKey]: error.messages[0] } as FieldErrors<K>);
      } else if (error.status >= 500) {
        // « Internal server error » sous le titre « Le formulaire contient une erreur »
        // envoyait l'utilisateur relire une saisie irréprochable. La panne est côté
        // serveur : on le dit, et on ne recopie pas le message technique de l'API.
        fail({}, ['Le service est momentanément indisponible. Réessayez dans quelques instants.']);
      } else {
        fail({}, error.messages);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const summary: SummaryError[] = [
    ...fieldOrder
      .filter((key) => errors[key])
      .map((key) => ({ message: errors[key]!, fieldId: fieldId(key) })),
    ...globalErrors.map((message) => ({ message })),
  ];

  return { values, setValue, errors, summary, attempt, submitting, result, fieldId, handleSubmit };
}
