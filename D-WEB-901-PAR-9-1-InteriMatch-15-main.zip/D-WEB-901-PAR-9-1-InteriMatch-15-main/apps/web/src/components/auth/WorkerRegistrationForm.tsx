'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useRef } from 'react';
import { postJson } from '../../lib/api';
import {
  collectErrors,
  maxLength,
  required,
  validateConsent,
  validateEmail,
  validatePassword,
  validatePhone,
  validatePostalCode,
} from '../../lib/validation';
import { CheckboxField } from '../form/CheckboxField';
import { ErrorSummary } from '../form/ErrorSummary';
import { PasswordField } from '../form/PasswordField';
import { TextField } from '../form/TextField';
import { useAuthForm } from './useAuthForm';

type WorkerField =
  | 'firstName'
  | 'lastName'
  | 'email'
  | 'password'
  | 'phone'
  | 'postalCode'
  | 'city'
  | 'consentement';

interface WorkerAccount {
  email: string;
  worker: { firstName: string } | null;
}

interface GeoCommune {
  nom: string;
}

const FIELD_ORDER: WorkerField[] = [
  'firstName',
  'lastName',
  'email',
  'password',
  'phone',
  'postalCode',
  'city',
  'consentement',
];

const INITIAL_VALUES: Record<WorkerField, string> = {
  firstName: '',
  lastName: '',
  email: '',
  password: '',
  phone: '',
  postalCode: '',
  city: '',
  consentement: '',
};

function validate(values: Record<WorkerField, string>) {
  return collectErrors<WorkerField>({
    firstName: required(values.firstName, 'votre prénom') ?? maxLength(values.firstName, 100),
    lastName: required(values.lastName, 'votre nom') ?? maxLength(values.lastName, 100),
    email: validateEmail(values.email),
    password: validatePassword(values.password),
    phone: validatePhone(values.phone),
    postalCode: validatePostalCode(values.postalCode),
    city: required(values.city, 'votre ville') ?? maxLength(values.city, 100),
    consentement: validateConsent(values.consentement),
  });
}

// POST /auth/register/worker : crée le compte et ouvre la session (cookie posé par l'API).
function send(values: Record<WorkerField, string>): Promise<WorkerAccount> {
  // La case est validée ici et par l'API, qui refuse l'inscription sans acceptation et en
  // enregistre la date (CredentialsDto, AuthService).
  const { phone, consentement, ...rest } = values;
  return postJson<WorkerAccount>('/auth/register/worker', {
    ...rest,
    acceptConditions: true,
    // Champ facultatif : absent plutôt que vide, sinon l'API le valide et le refuse.
    ...(phone.trim() ? { phone } : {}),
  });
}

export function WorkerRegistrationForm() {
  const router = useRouter();
  const cityLookupRequest = useRef(0);
  const form = useAuthForm<WorkerField, WorkerAccount>({
    idPrefix: 'interimaire',
    initialValues: INITIAL_VALUES,
    fieldOrder: FIELD_ORDER,
    validate,
    send,
    conflictField: (message) => (message.includes('email') ? 'email' : undefined),
  });

  const result = form.result;
  useEffect(() => {
    if (result) {
      router.push('/interimaire/profil');
    }
  }, [result, router]);

  // L'API ouvre déjà la session à l'inscription : renvoyer vers /connexion demanderait de
  // se reconnecter alors qu'on l'est. On entre directement dans l'espace, comme après une
  // connexion (LoginForm). L'écran de confirmation était un cul-de-sac : sa seule sortie,
  // « Retour à l'accueil », ramenait sur la page publique.
  if (form.result) {
    return null;
  }

  const field = (key: WorkerField) => ({
    id: form.fieldId(key),
    value: form.values[key],
    onChange: form.setValue(key),
    error: form.errors[key],
  });

  const handlePostalCodeChange = (postalCode: string): void => {
    form.setValue('postalCode')(postalCode);

    if (!/^\d{5}$/.test(postalCode)) {
      return;
    }

    const requestId = cityLookupRequest.current + 1;
    cityLookupRequest.current = requestId;

    void fetch(`https://geo.api.gouv.fr/communes?codePostal=${postalCode}&fields=nom&format=json`)
      .then((response) => (response.ok ? (response.json() as Promise<GeoCommune[]>) : []))
      .then((communes) => {
        if (requestId === cityLookupRequest.current && communes.length > 0) {
          form.setValue('city')(communes[0].nom);
        }
      })
      .catch(() => {
        // La ville reste saisissable manuellement si le service est indisponible.
      });
  };

  return (
    <form onSubmit={form.handleSubmit} noValidate className="formulaire">
      <ErrorSummary errors={form.summary} attempt={form.attempt} />

      <p className="formulaire__mention">
        Tous les champs sont obligatoires, sauf mention « facultatif ».
      </p>

      <fieldset>
        <legend>Votre identité</legend>
        <div className="champs-duo">
          <TextField
            {...field('firstName')}
            label="Prénom"
            autoComplete="given-name"
            placeholder="Camille"
            maxLength={100}
          />
          <TextField
            {...field('lastName')}
            label="Nom"
            autoComplete="family-name"
            placeholder="Martin"
            maxLength={100}
          />
        </div>
        <TextField
          {...field('email')}
          label="Adresse email"
          type="email"
          inputMode="email"
          autoComplete="email"
          placeholder="prenom.nom@exemple.fr"
          maxLength={255}
        />
      </fieldset>

      <fieldset>
        <legend>Vos coordonnées</legend>
        <TextField
          {...field('phone')}
          label="Téléphone"
          type="tel"
          inputMode="tel"
          autoComplete="tel-national"
          placeholder="06 12 34 56 78"
          optional
        />
        <div className="champs-duo">
          <TextField
            {...field('postalCode')}
            onChange={handlePostalCodeChange}
            label="Code postal"
            inputMode="numeric"
            autoComplete="postal-code"
            hint="Sert au matching de zone."
            placeholder="69007"
            maxLength={5}
          />
          <TextField
            {...field('city')}
            label="Ville"
            autoComplete="address-level2"
            placeholder="Lyon"
            maxLength={100}
          />
        </div>
      </fieldset>

      <fieldset>
        <legend>Mot de passe</legend>
        <PasswordField {...field('password')} />
      </fieldset>

      <CheckboxField
        {...field('consentement')}
        label={
          <>
            J’accepte les conditions générales d’utilisation et la{' '}
            <Link href="/politique-de-confidentialite">politique de confidentialité</Link>.
          </>
        }
      />

      <button type="submit" className="bouton bouton--principal" disabled={form.submitting}>
        {form.submitting ? 'Création du compte…' : 'Créer mon compte intérimaire'}
      </button>

      <p className="page-auth__pied page-auth__pied--sans-ligne">
        Déjà inscrit ? <Link href="/connexion">Se connecter →</Link>
      </p>
    </form>
  );
}
