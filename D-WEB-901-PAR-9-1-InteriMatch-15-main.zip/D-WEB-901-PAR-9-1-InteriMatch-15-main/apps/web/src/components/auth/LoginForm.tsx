'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { accueilDuRole, RoleCompte } from '../../lib/accueil-role';
import { postJson } from '../../lib/api';
import {
  collectErrors,
  PASSWORD_MAX_LENGTH,
  validateCurrentPassword,
  validateEmail,
} from '../../lib/validation';
import { ErrorSummary } from '../form/ErrorSummary';
import { TextField } from '../form/TextField';
import { useAuthForm } from './useAuthForm';

type LoginField = 'email' | 'password';

interface Account {
  email: string;
  // ADMIN en fait partie : l'API le renvoie depuis que l'espace agent existe, et l'omettre
  // ici empêchait TypeScript de signaler qu'aucune redirection ne le traitait.
  role: RoleCompte;
  company: { legalName: string } | null;
  worker: { firstName: string } | null;
}

const FIELD_ORDER: LoginField[] = ['email', 'password'];

const INITIAL_VALUES: Record<LoginField, string> = { email: '', password: '' };

function validate(values: Record<LoginField, string>) {
  return collectErrors<LoginField>({
    email: validateEmail(values.email),
    password: validateCurrentPassword(values.password),
  });
}

// POST /auth/login : vérifie les identifiants et ouvre la session (cookie posé par l'API).
function send(values: Record<LoginField, string>): Promise<Account> {
  return postJson<Account>('/auth/login', values);
}

export function LoginForm() {
  const router = useRouter();
  const form = useAuthForm<LoginField, Account>({
    idPrefix: 'connexion',
    initialValues: INITIAL_VALUES,
    fieldOrder: FIELD_ORDER,
    validate,
    send,
  });

  // Chaque rôle a son tableau de bord, et TOUS en ont un : la table d'accueil est exhaustive
  // (lib/accueil-role.ts), si bien qu'un rôle ajouté sans destination ne compile plus.
  useEffect(() => {
    if (form.result) {
      router.push(accueilDuRole(form.result.role));
    }
  }, [form.result, router]);

  if (form.result) {
    return null;
  }

  const field = (key: LoginField) => ({
    id: form.fieldId(key),
    value: form.values[key],
    onChange: form.setValue(key),
    error: form.errors[key],
  });

  return (
    <form onSubmit={form.handleSubmit} noValidate className="formulaire">
      {/* Une erreur 401 de l'API arrive ici en message global : « Email ou mot de passe
          incorrect », sans jamais dire lequel des deux est en cause. */}
      <ErrorSummary errors={form.summary} attempt={form.attempt} />

      <TextField
        {...field('email')}
        label="Adresse email"
        type="email"
        inputMode="email"
        autoComplete="email"
        maxLength={255}
      />
      <TextField
        {...field('password')}
        label="Mot de passe"
        type="password"
        autoComplete="current-password"
        maxLength={PASSWORD_MAX_LENGTH}
      />

      <p className="formulaire__mention formulaire__mention--droite">
        <Link href="/mot-de-passe-oublie">Mot de passe oublié ?</Link>
      </p>

      <button type="submit" className="bouton bouton--principal" disabled={form.submitting}>
        {form.submitting ? 'Connexion en cours…' : 'Se connecter'}
      </button>

      <p className="page-auth__pied">
        Pas encore de compte ? <Link href="/inscription">Créer un compte →</Link>
      </p>
    </form>
  );
}
