'use client';

import { postJson } from '../../lib/api';
import { collectErrors, validateEmail } from '../../lib/validation';
import { ErrorSummary } from '../form/ErrorSummary';
import { TextField } from '../form/TextField';
import { AuthSuccess } from './AuthSuccess';
import { useAuthForm } from './useAuthForm';
import { MentionDonnees } from '../form/MentionDonnees';

type ForgotField = 'email';

const FIELD_ORDER: ForgotField[] = ['email'];

function validate(values: Record<ForgotField, string>) {
  return collectErrors<ForgotField>({ email: validateEmail(values.email) });
}

// POST /auth/password-reset/request : répond 204 sans corps, que le compte existe ou non.
function send(values: Record<ForgotField, string>): Promise<void> {
  return postJson<void>('/auth/password-reset/request', values);
}

export function ForgotPasswordForm() {
  const form = useAuthForm<ForgotField, 'envoyé'>({
    idPrefix: 'oubli',
    initialValues: { email: '' },
    fieldOrder: FIELD_ORDER,
    validate,
    send: async (values) => {
      await send(values);
      return 'envoyé';
    },
  });

  // Le message de confirmation ne dit pas si un compte existe : il serait sinon un moyen
  // de tester quelles adresses sont inscrites sur la plateforme.
  if (form.result) {
    return (
      <AuthSuccess title="Consultez votre boîte mail">
        <p>
          Si un compte est associé à cette adresse, un lien pour choisir un nouveau mot de passe
          vient d’être envoyé. <strong>Il est valable 30 minutes</strong> et ne peut servir qu’une
          fois.
        </p>
        <p>Pensez à regarder dans les courriers indésirables.</p>
      </AuthSuccess>
    );
  }

  return (
    <form onSubmit={form.handleSubmit} noValidate className="formulaire">
      <ErrorSummary errors={form.summary} attempt={form.attempt} />

      <TextField
        id={form.fieldId('email')}
        label="Adresse email"
        value={form.values.email}
        onChange={form.setValue('email')}
        error={form.errors.email}
        type="email"
        inputMode="email"
        autoComplete="email"
        hint="Celle utilisée à la création de votre compte."
        maxLength={255}
      />

      <MentionDonnees />

      <button type="submit" className="bouton bouton--principal" disabled={form.submitting}>
        {form.submitting ? 'Envoi en cours…' : 'Recevoir un lien'}
      </button>
    </form>
  );
}
