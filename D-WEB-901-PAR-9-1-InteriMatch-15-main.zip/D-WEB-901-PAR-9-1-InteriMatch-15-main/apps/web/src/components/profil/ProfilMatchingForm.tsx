'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { ApiError, getJson, putJson } from '../../lib/api';
import { SHIFTS } from '../../lib/shifts';
import { ErrorSummary } from '../form/ErrorSummary';

export interface RomeOption {
  code: string;
  label: string;
}

interface CompetenceOption {
  code: string;
  label: string;
}

interface ProfilMatchingProps {
  profil: {
    shifts: string[];
    competences: { code: string; label: string }[];
  };
  romes: RomeOption[];
}

// Recherche insensible à la casse et aux accents : « elevateur » doit trouver « élévateur ».
function normaliser(valeur: string): string {
  return valeur.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

export function ProfilMatchingForm({ profil, romes }: ProfilMatchingProps) {
  const [shifts, setShifts] = useState<Set<string>>(new Set(profil.shifts));
  const [selection, setSelection] = useState<Set<string>>(
    new Set(profil.competences.map((c) => c.code)),
  );
  // Les libellés des compétences déjà choisies sont conservés à part : elles disparaissent de
  // la liste dès qu'on change de métier ou qu'on filtre, mais le récapitulatif doit continuer
  // à les nommer.
  const [libelles, setLibelles] = useState<Map<string, string>>(
    new Map(profil.competences.map((c) => [c.code, c.label])),
  );
  const [rome, setRome] = useState(romes[0]?.code ?? '');
  const [recherche, setRecherche] = useState('');
  const [competences, setCompetences] = useState<CompetenceOption[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [saved, setSaved] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!rome) {
      return;
    }
    let cancelled = false;
    getJson<CompetenceOption[]>('/referentiel/competences', { rome })
      .then((result) => {
        if (!cancelled) {
          setCompetences(result);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setCompetences([]);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [rome]);

  const visibles = useMemo(() => {
    const terme = normaliser(recherche.trim());
    if (!terme) {
      return competences;
    }
    return competences.filter((competence) => normaliser(competence.label).includes(terme));
  }, [competences, recherche]);

  const toggleShift = (value: string): void => {
    const next = new Set(shifts);
    if (next.has(value)) {
      next.delete(value);
    } else {
      next.add(value);
    }
    setShifts(next);
  };

  const toggleCompetence = (competence: CompetenceOption): void => {
    const next = new Set(selection);
    if (next.has(competence.code)) {
      next.delete(competence.code);
    } else {
      next.add(competence.code);
      setLibelles((current) => new Map(current).set(competence.code, competence.label));
    }
    setSelection(next);
  };

  const retirer = (code: string): void => {
    const next = new Set(selection);
    next.delete(code);
    setSelection(next);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    if (submitting) {
      return;
    }
    setSubmitting(true);
    setSaved(false);
    try {
      await putJson('/workers/me/profil-matching', {
        shifts: [...shifts],
        competenceCodes: [...selection],
      });
      setErrors([]);
      setSaved(true);
    } catch (error) {
      setErrors(
        error instanceof ApiError
          ? error.messages
          : ['Une erreur inattendue est survenue. Réessayez dans quelques instants.'],
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="formulaire carte-formulaire">
      <ErrorSummary errors={errors.map((message) => ({ message }))} attempt={errors.length} />
      {saved && <p className="avis-succes">Profil enregistré.</p>}

      <fieldset>
        <legend>Créneaux de travail</legend>
        {/* Pas de fenêtre de disponibilité : consulter la plateforme vaut disponibilité
            (décision produit du 21/09). Le créneau, lui, élimine réellement. */}
        <p className="champ__indication">
          Cochez les horaires que vous acceptez. Vous ne serez proposé que sur des missions qui
          tombent dans ces créneaux. Aucun coché : tous les créneaux vous sont proposés.
        </p>
        <div className="puces">
          {SHIFTS.map((shift) => (
            <button
              key={shift.value}
              type="button"
              className={`puce${shifts.has(shift.value) ? ' puce--selectionnee' : ''}`}
              aria-pressed={shifts.has(shift.value)}
              onClick={() => toggleShift(shift.value)}
            >
              {shift.label}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend>Compétences</legend>
        <p className="champ__indication">
          Elles améliorent votre score sur une mission, elles ne vous excluent jamais. Seules les
          habilitations (CACES) conditionnent l’accès à une mission.
        </p>

        <div className="selection">
          <p className="selection__titre">
            {selection.size === 0
              ? 'Aucune compétence sélectionnée'
              : `${selection.size} compétence${selection.size > 1 ? 's' : ''} sélectionnée${selection.size > 1 ? 's' : ''}`}
          </p>
          {selection.size > 0 && (
            <ul className="jetons">
              {[...selection].map((code) => (
                <li key={code} className="jeton">
                  <span>{libelles.get(code) ?? code}</span>
                  <button
                    type="button"
                    className="jeton__retirer"
                    onClick={() => retirer(code)}
                    aria-label={`Retirer « ${libelles.get(code) ?? code} »`}
                  >
                    <span aria-hidden="true">×</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Référentiel injoignable ou pas encore importé : on le dit, plutôt que d'afficher
            un sélecteur vide que l'utilisateur prendrait pour un bug de sa part. */}
        {romes.length === 0 ? (
          <p className="champ__indication">
            La liste des métiers n’a pas pu être chargée. Vos créneaux restent enregistrables ;
            réessayez plus tard pour les compétences.
          </p>
        ) : (
          <>
            {/* Des boutons radio et non un menu déroulant : trois métiers seulement, tous
                visibles d'un coup, et les flèches du clavier fonctionnent nativement. */}
            <div className="champ">
              <span className="champ__etiquette" id="profil-metier">
                Métier
              </span>
              <div className="segmente" role="group" aria-labelledby="profil-metier">
                {romes.map((option) => (
                  <label
                    key={option.code}
                    className={`segmente__choix${rome === option.code ? ' segmente__choix--actif' : ''}`}
                  >
                    <input
                      type="radio"
                      name="profil-metier-choix"
                      className="visuellement-masque"
                      value={option.code}
                      checked={rome === option.code}
                      onChange={() => setRome(option.code)}
                    />
                    <span>{option.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="champ">
              <label htmlFor="profil-recherche" className="champ__etiquette">
                Rechercher une compétence
              </label>
              <input
                id="profil-recherche"
                type="search"
                className="champ__saisie"
                value={recherche}
                onChange={(event) => setRecherche(event.target.value)}
                placeholder="chariot, sécurité, stockage…"
              />
            </div>

            <p className="champ__indication" aria-live="polite">
              {visibles.length === 0
                ? 'Aucune compétence ne correspond à cette recherche.'
                : `${visibles.length} compétence${visibles.length > 1 ? 's' : ''} proposée${visibles.length > 1 ? 's' : ''}`}
            </p>

            {/* Une liste à cocher et non des pastilles : les libellés du référentiel ROME font
                jusqu'à 120 caractères, une pastille de cette largeur n'est plus lisible et ne
                ressemble plus à un choix. */}
            <ul className="liste-competences">
              {visibles.map((competence) => (
                <li key={competence.code}>
                  <label className="choix">
                    <input
                      type="checkbox"
                      checked={selection.has(competence.code)}
                      onChange={() => toggleCompetence(competence)}
                    />
                    <span>{competence.label}</span>
                  </label>
                </li>
              ))}
            </ul>
          </>
        )}
      </fieldset>

      <button type="submit" className="bouton bouton--principal" disabled={submitting}>
        {submitting ? 'Enregistrement…' : 'Enregistrer mon profil'}
      </button>
    </form>
  );
}
