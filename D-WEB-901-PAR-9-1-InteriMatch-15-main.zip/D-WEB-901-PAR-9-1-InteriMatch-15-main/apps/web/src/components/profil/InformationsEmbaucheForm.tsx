'use client';

import { FormEvent, useState } from 'react';
import { ApiError, putJson } from '../../lib/api';
import {
  collectErrors,
  FieldErrors,
  maxLength,
  required,
  validateBirthDate,
  validateIban,
  validateNir,
  validatePostalCode,
} from '../../lib/validation';
import { ErrorSummary } from '../form/ErrorSummary';
import { TextField } from '../form/TextField';

export interface InformationsEmbauche {
  complet: boolean;
  requis: boolean;
  missionsRetenues: number;
  birthDate: string | null;
  birthPlace: string | null;
  birthCountry: string | null;
  nationality: string | null;
  addressLine: string | null;
  addressPostalCode: string | null;
  addressCity: string | null;
  nirMasque: string | null;
  ibanMasque: string | null;
}

type Champ =
  | 'birthDate'
  | 'birthPlace'
  | 'birthCountry'
  | 'nationality'
  | 'addressLine'
  | 'addressPostalCode'
  | 'addressCity'
  | 'nir'
  | 'iban';

// L'ordre du récapitulatif d'erreurs suit l'ordre visuel des champs : un lecteur d'écran
// annonce les erreurs dans l'ordre où elles apparaissent à l'écran.
const ORDRE: Champ[] = [
  'birthDate',
  'birthPlace',
  'birthCountry',
  'nationality',
  'addressLine',
  'addressPostalCode',
  'addressCity',
  'nir',
  'iban',
];

const LIBELLES: Record<Champ, string> = {
  birthDate: 'Date de naissance',
  birthPlace: 'Commune de naissance',
  birthCountry: 'Pays de naissance',
  nationality: 'Nationalité',
  addressLine: 'Adresse',
  addressPostalCode: 'Code postal',
  addressCity: 'Commune',
  nir: 'Numéro de sécurité sociale',
  iban: 'IBAN',
};

function valider(valeurs: Record<Champ, string>): FieldErrors<Champ> {
  return collectErrors<Champ>({
    birthDate: validateBirthDate(valeurs.birthDate),
    birthPlace:
      required(valeurs.birthPlace, 'votre commune de naissance') ??
      maxLength(valeurs.birthPlace, 100),
    birthCountry:
      required(valeurs.birthCountry, 'votre pays de naissance') ??
      maxLength(valeurs.birthCountry, 100),
    nationality:
      required(valeurs.nationality, 'votre nationalité') ?? maxLength(valeurs.nationality, 100),
    addressLine:
      required(valeurs.addressLine, 'votre adresse') ?? maxLength(valeurs.addressLine, 255),
    addressPostalCode: validatePostalCode(valeurs.addressPostalCode),
    addressCity:
      required(valeurs.addressCity, 'votre commune') ?? maxLength(valeurs.addressCity, 100),
    nir: validateNir(valeurs.nir),
    iban: validateIban(valeurs.iban),
  });
}

interface Props {
  informations: InformationsEmbauche;
  // Commune et code postal déclarés à l'inscription : ils pré-remplissent l'adresse, qui
  // coïncide le plus souvent. L'intérimaire reste libre de les corriger — ce ne sont pas
  // la même donnée (l'une sert au matching, l'autre au contrat).
  domicile: { postalCode: string; city: string };
}

export function InformationsEmbaucheForm({ informations, domicile }: Props) {
  const [valeurs, setValeurs] = useState<Record<Champ, string>>({
    birthDate: informations.birthDate ?? '',
    birthPlace: informations.birthPlace ?? '',
    birthCountry: informations.birthCountry ?? 'France',
    nationality: informations.nationality ?? 'Française',
    addressLine: informations.addressLine ?? '',
    addressPostalCode: informations.addressPostalCode ?? domicile.postalCode,
    addressCity: informations.addressCity ?? domicile.city,
    // Jamais pré-remplis : l'API ne les renvoie pas en clair, et c'est voulu. L'intérimaire
    // voit ce qui est déjà enregistré sous forme masquée, au-dessus du champ.
    nir: '',
    iban: '',
  });
  const [erreurs, setErreurs] = useState<FieldErrors<Champ>>({});
  const [erreursApi, setErreursApi] = useState<string[]>([]);
  const [tentative, setTentative] = useState(0);
  const [enregistre, setEnregistre] = useState(false);
  const [envoi, setEnvoi] = useState(false);

  const modifier = (champ: Champ, valeur: string): void => {
    setValeurs((courant) => ({ ...courant, [champ]: valeur }));
    setEnregistre(false);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    if (envoi) {
      return;
    }

    const trouvees = valider(valeurs);
    setErreurs(trouvees);
    setErreursApi([]);
    setTentative((n) => n + 1);
    if (Object.keys(trouvees).length > 0) {
      return;
    }

    setEnvoi(true);
    try {
      await putJson('/workers/me/informations-embauche', valeurs);
      setEnregistre(true);
      // Les deux identifiants sont vidés après l'envoi : les laisser à l'écran les
      // exposerait sur un poste partagé bien après la saisie, sans aucun usage.
      setValeurs((courant) => ({ ...courant, nir: '', iban: '' }));
    } catch (error) {
      setErreursApi(
        error instanceof ApiError
          ? error.messages
          : ['Une erreur inattendue est survenue. Réessayez dans quelques instants.'],
      );
    } finally {
      setEnvoi(false);
    }
  };

  const recapitulatif = [
    ...ORDRE.filter((champ) => erreurs[champ]).map((champ) => ({
      message: `${LIBELLES[champ]} : ${erreurs[champ]!}`,
      fieldId: `embauche-${champ}`,
    })),
    ...erreursApi.map((message) => ({ message })),
  ];

  return (
    <form onSubmit={handleSubmit} noValidate className="formulaire carte-formulaire">
      <ErrorSummary errors={recapitulatif} attempt={tentative} />
      {enregistre && (
        <p className="avis-succes">
          Informations enregistrées. Votre contrat de mission peut être établi.
        </p>
      )}

      <fieldset>
        <legend>État civil</legend>
        <TextField
          id="embauche-birthDate"
          label={LIBELLES.birthDate}
          type="date"
          value={valeurs.birthDate}
          onChange={(valeur) => modifier('birthDate', valeur)}
          error={erreurs.birthDate}
          autoComplete="bday"
        />
        <TextField
          id="embauche-birthPlace"
          label={LIBELLES.birthPlace}
          value={valeurs.birthPlace}
          onChange={(valeur) => modifier('birthPlace', valeur)}
          error={erreurs.birthPlace}
          placeholder="Paris"
          maxLength={100}
        />
        <TextField
          id="embauche-birthCountry"
          label={LIBELLES.birthCountry}
          value={valeurs.birthCountry}
          onChange={(valeur) => modifier('birthCountry', valeur)}
          error={erreurs.birthCountry}
          maxLength={100}
        />
        <TextField
          id="embauche-nationality"
          label={LIBELLES.nationality}
          value={valeurs.nationality}
          onChange={(valeur) => modifier('nationality', valeur)}
          error={erreurs.nationality}
          maxLength={100}
        />
      </fieldset>

      <fieldset>
        <legend>Adresse postale</legend>
        <p className="champ__indication">
          Votre domicile, tel qu’il figurera au contrat. Il peut différer de la commune que vous
          avez indiquée pour vos recherches.
        </p>
        <TextField
          id="embauche-addressLine"
          label={LIBELLES.addressLine}
          value={valeurs.addressLine}
          onChange={(valeur) => modifier('addressLine', valeur)}
          error={erreurs.addressLine}
          placeholder="8 rue des Peupliers"
          autoComplete="street-address"
          maxLength={255}
        />
        <TextField
          id="embauche-addressPostalCode"
          label={LIBELLES.addressPostalCode}
          value={valeurs.addressPostalCode}
          onChange={(valeur) => modifier('addressPostalCode', valeur)}
          error={erreurs.addressPostalCode}
          inputMode="numeric"
          maxLength={5}
          autoComplete="postal-code"
        />
        <TextField
          id="embauche-addressCity"
          label={LIBELLES.addressCity}
          value={valeurs.addressCity}
          onChange={(valeur) => modifier('addressCity', valeur)}
          error={erreurs.addressCity}
          autoComplete="address-level2"
          maxLength={100}
        />
      </fieldset>

      <fieldset>
        <legend>Identifiants de paie</legend>
        <p className="champ__indication">
          Ces deux informations sont <strong>chiffrées</strong> avant d’être enregistrées. Elles ne
          sont jamais affichées en entier, jamais transmises à l’entreprise qui vous accueille, et
          servent uniquement à votre contrat et au versement de votre salaire.
        </p>
        {/* Conséquence assumée du « tout ou rien » : le formulaire enregistre les neuf champs
            ensemble, donc les deux identifiants sont à ressaisir même pour corriger une
            adresse. Le dire ici vaut mieux qu'une erreur au moment d'enregistrer. */}
        {informations.complet && (
          <p className="champ__indication">
            Ils sont déjà enregistrés. Toute modification, même sur un autre champ, demande de les
            ressaisir : l’enregistrement porte sur l’ensemble du formulaire.
          </p>
        )}

        {informations.nirMasque && (
          <p className="valeur-masquee">
            <span className="mono">Enregistré</span>{' '}
            <span className="valeur-masquee__valeur">{informations.nirMasque}</span>
          </p>
        )}
        <TextField
          id="embauche-nir"
          label={LIBELLES.nir}
          value={valeurs.nir}
          onChange={(valeur) => modifier('nir', valeur)}
          error={erreurs.nir}
          hint="15 chiffres, clé comprise, tels qu'ils figurent sur votre carte Vitale. Les espaces sont acceptés."
          placeholder="1 80 12 75 116 001 28"
          inputMode="numeric"
          maxLength={21}
        />

        {informations.ibanMasque && (
          <p className="valeur-masquee">
            <span className="mono">Enregistré</span>{' '}
            <span className="valeur-masquee__valeur">{informations.ibanMasque}</span>
          </p>
        )}
        <TextField
          id="embauche-iban"
          label={LIBELLES.iban}
          value={valeurs.iban}
          onChange={(valeur) => modifier('iban', valeur)}
          error={erreurs.iban}
          hint="Il figure sur votre RIB, au-dessus du BIC. Les espaces sont acceptés."
          placeholder="FR76 3000 6000 0112 3456 7890 189"
          maxLength={42}
        />
      </fieldset>

      <button type="submit" className="bouton bouton--principal" disabled={envoi}>
        {envoi ? 'Enregistrement…' : 'Enregistrer mes informations'}
      </button>
    </form>
  );
}
