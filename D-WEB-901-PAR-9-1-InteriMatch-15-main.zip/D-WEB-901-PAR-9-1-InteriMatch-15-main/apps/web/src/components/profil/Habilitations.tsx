'use client';

import { useId, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { CERTIFICATIONS, certificationLabel } from '../../lib/certifications';
import { estExpiree } from '../../lib/habilitations';

export type StatutVerification = 'NON_VERIFIE' | 'EN_ATTENTE' | 'VERIFIE' | 'REFUSE';

export interface HabilitationRow {
  type: string;
  expiresAt: string | null;
  hasDocument: boolean;
  verificationStatus: StatutVerification;
  refusalMotif: string | null;
}

// Le libellé est toujours écrit en toutes lettres : l'information n'est jamais portée par la
// seule couleur (RGAA 4.1). La classe ne fait que renforcer ce que le texte dit déjà.
const STATUTS: Record<StatutVerification, { libelle: string; classe: string }> = {
  NON_VERIFIE: { libelle: 'Non vérifié', classe: 'badge' },
  EN_ATTENTE: { libelle: 'En attente de vérification', classe: 'badge' },
  VERIFIE: { libelle: 'CACES vérifié', classe: 'badge badge--verifie' },
  REFUSE: { libelle: 'Refusé', classe: 'badge badge--refuse' },
};

// Miroir de MAX_DOCUMENT_SIZE_BYTES (apps/api/src/sensitive-documents/file-type.ts). Le
// contrôle côté navigateur évite un aller-retour de 5 Mo pour rien ; c'est l'API qui fait
// foi, et elle vérifie en plus le type réel par les octets du fichier.
const TAILLE_MAX = 5 * 1024 * 1024;
const TYPES_ACCEPTES = 'application/pdf,image/jpeg,image/png';

interface HabilitationsProps {
  habilitations: HabilitationRow[];
}

/**
 * Habilitations déclarées et justificatifs.
 *
 * Le dépôt passe par `PUT /workers/me/certifications/:type` en `multipart/form-data` — et
 * non par la couche `postJson`, qui sérialise en JSON et ne sait pas porter de fichier.
 */
export function Habilitations({ habilitations }: HabilitationsProps) {
  const router = useRouter();
  const idType = useId();
  const idDate = useId();
  const idFichier = useId();
  const champFichier = useRef<HTMLInputElement>(null);

  const [type, setType] = useState<string>(CERTIFICATIONS[0].value);
  const [expiresAt, setExpiresAt] = useState('');
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);
  const [succes, setSucces] = useState<string | null>(null);

  const envoyer = async (evenement: React.FormEvent): Promise<void> => {
    evenement.preventDefault();
    const fichier = champFichier.current?.files?.[0];

    if (!fichier) {
      setErreur('Choisissez le justificatif à déposer.');
      return;
    }
    if (fichier.size > TAILLE_MAX) {
      setErreur('Le fichier dépasse 5 Mo. Réduisez sa taille avant de le déposer.');
      return;
    }

    setEnCours(true);
    setErreur(null);
    setSucces(null);

    const corps = new FormData();
    if (expiresAt) {
      corps.append('expiresAt', expiresAt);
    }
    corps.append('file', fichier);

    try {
      const base = process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? '';
      const reponse = await fetch(`${base}/workers/me/certifications/${type}`, {
        method: 'PUT',
        credentials: 'include',
        body: corps,
      });

      if (!reponse.ok) {
        const charge: unknown = await reponse.json().catch(() => null);
        const message =
          typeof charge === 'object' && charge !== null && 'message' in charge
            ? [charge.message].flat().join(' ')
            : 'Le dépôt a échoué. Réessayez dans quelques instants.';
        setErreur(String(message));
        return;
      }

      setSucces(
        `${certificationLabel(type)} déposé. Un agent CADANS le vérifie, vous verrez le résultat ici.`,
      );
      if (champFichier.current) {
        champFichier.current.value = '';
      }
      setExpiresAt('');
      router.refresh();
    } catch {
      setErreur('Le serveur ne répond pas. Vérifiez votre connexion et réessayez.');
    } finally {
      setEnCours(false);
    }
  };

  return (
    <section className="habilitations">
      <h2>Mes habilitations</h2>
      <p className="champ__indication">
        Déposez le justificatif de chaque CACES déclaré : PDF, JPEG ou PNG, 5 Mo maximum. Un agent
        CADANS le vérifie. Le document est chiffré et n’est jamais transmis aux entreprises.
      </p>

      {habilitations.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>Aucune habilitation déclarée.</strong>
          </p>
          <p className="etat-vide__texte">
            Sans CACES, vous ne verrez que les missions qui n’en exigent pas.
          </p>
        </div>
      ) : (
        <ul className="liste-habilitations">
          {habilitations.map((habilitation) => {
            const statut = STATUTS[habilitation.verificationStatus];
            const expiree = estExpiree(habilitation.expiresAt);
            return (
              <li key={habilitation.type} className="carte habilitation">
                <div className="habilitation__entete">
                  <p className="habilitation__titre">{certificationLabel(habilitation.type)}</p>
                  {/* Deux badges quand l'habilitation est expirée, et c'est voulu : « CACES
                      vérifié » reste vrai — un agent a bien contrôlé la pièce — mais la date
                      est passée. Remplacer l'un par l'autre effacerait une information
                      exacte ; les juxtaposer dit la situation entière. */}
                  {/* Les badges dans un conteneur : `space-between` sur l'en-tête les
                      éparpillerait aux deux bouts de la ligne, le statut au milieu et
                      « Expirée » collé au bord droit. Ils se lisent ensemble. */}
                  <span className="habilitation__badges">
                    <span className={statut.classe}>{statut.libelle}</span>
                    {expiree && <span className="badge badge--expiree">Expirée</span>}
                  </span>
                </div>
                <p className="habilitation__date">
                  {habilitation.expiresAt
                    ? `${expiree ? 'A expiré le' : 'Expire le'} ${new Date(`${habilitation.expiresAt}T00:00:00Z`).toLocaleDateString('fr-FR')}`
                    : 'Date d’expiration non renseignée'}
                  {habilitation.hasDocument ? ' · justificatif déposé' : ' · aucun justificatif'}
                </p>

                {/* Le défaut que ce bloc corrige : une habilitation expirée s'affichait
                    exactement comme une habilitation valide. L'intérimaire ne voyait plus
                    aucune mission exigeant ce CACES et n'avait AUCUN moyen de comprendre
                    pourquoi — son profil lui disait « vérifié ». */}
                {expiree && (
                  <p className="habilitation__alerte" role="status">
                    <strong>Les missions exigeant ce CACES ne vous sont plus proposées.</strong> Une
                    habilitation expirée n’est plus prise en compte. Redéposez votre justificatif à
                    jour avec sa nouvelle date d’expiration, ci-dessous : il remplacera l’ancien et
                    vos missions réapparaîtront.
                  </p>
                )}
                {/* Le motif d'un refus dit quoi corriger : sans lui, l'intérimaire ne peut
                    que redéposer le même document au hasard. */}
                {habilitation.verificationStatus === 'REFUSE' && habilitation.refusalMotif && (
                  <p className="habilitation__motif" role="status">
                    <strong>Motif du refus :</strong> {habilitation.refusalMotif} Redéposez un
                    justificatif ci-dessous pour relancer la vérification.
                  </p>
                )}
              </li>
            );
          })}
        </ul>
      )}

      <form className="habilitations__depot" onSubmit={(evenement) => void envoyer(evenement)}>
        <h3>Déposer un justificatif</h3>

        <div className="champ">
          <label htmlFor={idType} className="champ__libelle">
            Habilitation
          </label>
          <select
            id={idType}
            className="champ__saisie"
            value={type}
            onChange={(evenement) => setType(evenement.target.value)}
          >
            {CERTIFICATIONS.map((certification) => (
              <option key={certification.value} value={certification.value}>
                {certification.label}
              </option>
            ))}
          </select>
        </div>

        <div className="champ">
          <label htmlFor={idDate} className="champ__libelle">
            Date d’expiration
          </label>
          <p id={`${idDate}-aide`} className="champ__indication">
            Facultative, mais une habilitation expirée ne compte plus dans le matching.
          </p>
          <input
            id={idDate}
            type="date"
            className="champ__saisie"
            aria-describedby={`${idDate}-aide`}
            value={expiresAt}
            onChange={(evenement) => setExpiresAt(evenement.target.value)}
          />
        </div>

        <div className="champ">
          <label htmlFor={idFichier} className="champ__libelle">
            Justificatif
          </label>
          <p id={`${idFichier}-aide`} className="champ__indication">
            PDF, JPEG ou PNG, 5 Mo maximum.
          </p>
          <input
            id={idFichier}
            ref={champFichier}
            type="file"
            className="champ__saisie"
            aria-describedby={`${idFichier}-aide`}
            accept={TYPES_ACCEPTES}
            required
          />
        </div>

        {erreur && (
          <p className="champ__erreur" role="alert">
            {erreur}
          </p>
        )}
        {succes && (
          <p className="habilitations__succes" role="status">
            {succes}
          </p>
        )}

        <button type="submit" className="bouton bouton--principal" disabled={enCours}>
          {enCours ? 'Envoi…' : 'Déposer le justificatif'}
        </button>
      </form>
    </section>
  );
}
