interface LogoProps {
  /** Taille de police du mot « CADANS », en rem. Le symbole et l'espacement en découlent. */
  taille?: number;
  /** Symbole seul, sans le mot : barres latérales, favicon, écrans étroits. */
  symboleSeul?: boolean;
  className?: string;
}

// Proportions du logotype, fixées par la charte : la hauteur du symbole vaut 0,93 fois la
// taille de police du mot, et l'espacement entre les deux 0,3 fois cette même taille. Les
// exprimer en `em` plutôt qu'en pixels garde le rapport intact à n'importe quelle taille.
const RATIO_SYMBOLE = 0.93;
const RATIO_ESPACEMENT = 0.3;

/**
 * Logotype CADANS : symbole + « CADANS » en DM Sans Medium.
 *
 * Le symbole est un SVG inline avec `fill="currentColor"` : une seule source sert sur fond
 * clair (encre) comme sur fond foncé (blanc), la couleur venant du CSS environnant. C'est
 * aussi ce qui évite une requête réseau pour une image de 1 Ko.
 *
 * Le `viewBox` est resserré sur le tracé : celui du fichier d'origine (`0 0 64 64`) laissait
 * 45 % de vide autour, si bien que le symbole rendu ne faisait que 0,52 em au lieu de 0,93.
 *
 * Accessibilité : le SVG est décoratif (`aria-hidden`) dès lors que le mot « CADANS » est
 * rendu à côté — sinon un lecteur d'écran annoncerait le nom deux fois. En variante
 * `symboleSeul`, c'est au lien parent de porter le nom accessible (`aria-label="CADANS"`).
 */
export function Logo({ taille = 1.25, symboleSeul = false, className }: LogoProps) {
  return (
    <span
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: `${RATIO_ESPACEMENT}em`,
        fontSize: `${taille}rem`,
        color: 'inherit',
      }}
    >
      <svg
        viewBox="5.77 14.3 52.49 35.44"
        aria-hidden="true"
        focusable="false"
        style={{
          // La hauteur pilote, la largeur suit : le symbole est plus large que haut, et
          // c'est sa hauteur que la charte rapporte a la taille de police.
          height: `${RATIO_SYMBOLE}em`,
          width: 'auto',
          flex: 'none',
          display: 'block',
        }}
      >
        <g
          transform="translate(-10.5269,72.7575) scale(0.004021,-0.004021)"
          fill="currentColor"
          fillRule="evenodd"
        >
          <path
            d="M8811 14533 l-234 -3 125 -73 c265 -155 480 -319 678 -517 286 -285
509 -609 653 -950 147 -346 270 -862 303 -1268 l6 -82 -1073 2 -1072 3 -24
130 c-82 450 -214 724 -478 990 -182 184 -398 314 -661 400 -226 74 -688 112
-964 81 -421 -48 -633 -109 -855 -246 -341 -209 -566 -473 -790 -923 -136
-272 -204 -468 -264 -759 -60 -289 -86 -531 -103 -951 -49 -1212 223 -2135
798 -2711 311 -311 649 -485 1094 -563 148 -26 603 -26 767 0 584 92 1016 388
1291 884 62 112 125 268 175 433 37 123 87 334 87 369 l0 21 1085 0 1085 0 0
-25 c0 -97 -66 -446 -134 -708 -86 -333 -180 -595 -294 -822 -318 -636 -808
-1134 -1450 -1473 l-89 -47 2216 3 c2314 2 2515 6 2886 48 825 93 1624 402
2165 835 193 154 421 398 580 619 307 428 557 1028 674 1625 130 658 148 1578
45 2290 -136 944 -551 1802 -1143 2362 -270 256 -585 456 -1006 641 -398 175
-874 304 -1297 352 -326 37 -552 40 -2573 38 -1086 -2 -2080 -4 -2209 -5z
m3934 -1713 c269 -18 588 -73 751 -131 382 -135 680 -374 916 -734 217 -331
347 -688 408 -1115 53 -376 59 -935 15 -1316 -97 -837 -402 -1398 -942 -1737
-157 -99 -417 -204 -638 -258 -314 -77 -507 -89 -1407 -89 l-738 0 0 2695 0
2695 738 0 c405 0 809 -5 897 -10z"
          />
        </g>
      </svg>
      {!symboleSeul && (
        <span
          style={{
            fontFamily: 'var(--police), system-ui, sans-serif',
            fontWeight: 500,
            letterSpacing: '0.01em',
            lineHeight: 1,
          }}
        >
          CADANS
        </span>
      )}
    </span>
  );
}
