import { AnnexeRow, ListeAnnexes } from './ListeAnnexes';
import { serverGet } from '../../lib/session';

interface MissionAnnexes {
  missionId: string;
  missionTitre: string;
  siteLabel: string;
  annexes: AnnexeRow[];
}

/**
 * Documents joints par l'entreprise, côté intérimaire retenu.
 *
 * **Indépendant des contrats, et c'est le point.** Un intérimaire retenu dont le contrat de
 * mission attend encore ses informations d'embauche doit quand même recevoir le plan d'accès
 * et les consignes de sécurité du site. Les accrocher à la liste des contrats laissait ce cas
 * sans rien — constaté à l'écran, pas déduit.
 *
 * Ne rend rien quand il n'y a pas d'annexe, ni quand l'appel échoue : un bloc informatif ne
 * doit jamais faire tomber la page qui le contient.
 */
export async function AnnexesMission() {
  let missions: MissionAnnexes[];
  try {
    missions = await serverGet<MissionAnnexes[]>('/workers/me/annexes');
  } catch {
    return null;
  }

  if (missions.length === 0) {
    return null;
  }

  return (
    <section className="carte carte-annexes">
      <h2 className="carte-contrat__titre">Documents joints par l’entreprise</h2>
      <p className="champ__indication">
        Plan d’accès, consignes de sécurité, fiche de poste : à lire avant votre premier jour.
      </p>
      {missions.map((mission) => (
        <div key={mission.missionId} className="carte-annexes__mission">
          <p className="mono carte-annexes__titre-mission">
            {mission.missionTitre} — {mission.siteLabel}
          </p>
          <ListeAnnexes annexes={mission.annexes} />
        </div>
      ))}
    </section>
  );
}
