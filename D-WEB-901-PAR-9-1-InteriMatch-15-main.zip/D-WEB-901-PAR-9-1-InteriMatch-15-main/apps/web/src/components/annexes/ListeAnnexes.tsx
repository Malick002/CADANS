import { BoutonSupprimerAnnexe } from './BoutonSupprimerAnnexe';

export interface AnnexeRow {
  id: string;
  missionId: string;
  filename: string;
  sizeBytes: number;
  createdAt: string;
}

// Poids lisible : « 1,2 Mo » plutôt que « 1258291 octets ». Base 1000 et non 1024 — c'est ce
// qu'affichent les systèmes d'exploitation grand public, et l'utilisateur compare à ça.
export function poids(octets: number): string {
  if (octets < 1000) {
    return `${octets} o`;
  }
  if (octets < 1_000_000) {
    return `${(octets / 1000).toFixed(0)} Ko`;
  }
  return `${(octets / 1_000_000).toLocaleString('fr-FR', { maximumFractionDigits: 1 })} Mo`;
}

/**
 * Liste des documents joints à une mission, partagée par les deux espaces : l'entreprise qui
 * les dépose et l'intérimaire retenu qui les lit. L'API ne sert la liste qu'à ces deux-là, il
 * n'y a rien à filtrer ici.
 */
export function ListeAnnexes({
  annexes,
  supprimable = false,
}: {
  annexes: AnnexeRow[];
  // Vrai seulement côté entreprise, et seulement tant qu'aucun contrat n'est signé. L'API
  // revérifie les deux : c'est elle qui décide, l'écran ne fait que ne pas proposer ce qui
  // sera refusé.
  supprimable?: boolean;
}) {
  if (annexes.length === 0) {
    return null;
  }

  return (
    <ul className="liste-annexes">
      {annexes.map((annexe) => (
        <li key={annexe.id}>
          <a
            href={`${process.env.NEXT_PUBLIC_API_URL}/annexes/${annexe.id}/document`}
            target="_blank"
            rel="noopener noreferrer"
          >
            {annexe.filename}
          </a>{' '}
          <span className="liste-annexes__poids mono">{poids(annexe.sizeBytes)}</span>
          {supprimable && (
            <>
              {' '}
              <BoutonSupprimerAnnexe annexeId={annexe.id} filename={annexe.filename} />
            </>
          )}
        </li>
      ))}
    </ul>
  );
}
