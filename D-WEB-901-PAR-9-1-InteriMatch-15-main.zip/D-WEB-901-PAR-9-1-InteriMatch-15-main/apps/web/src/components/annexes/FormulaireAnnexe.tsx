'use client';

import { useRouter } from 'next/navigation';
import { ChangeEvent, FormEvent, useState } from 'react';
import { ErrorSummary } from '../form/ErrorSummary';
import { TextField } from '../form/TextField';

// Même limite que l'API et que les justificatifs d'habilitation : 5 Mo.
const TAILLE_MAX = 5 * 1024 * 1024;

/**
 * Dépôt d'une annexe. `fetch` direct et non le helper `postJson` : celui-ci sérialise en JSON,
 * et un fichier voyage en `multipart/form-data`. Le navigateur pose lui-même l'en-tête
 * `Content-Type` avec sa frontière — le fixer à la main casserait l'envoi.
 */
export function FormulaireAnnexe({ missionId }: { missionId: string }) {
  const router = useRouter();
  const [nom, setNom] = useState('');
  const [fichier, setFichier] = useState<File | null>(null);
  // Remis à zéro après un envoi réussi : `setFichier(null)` ne vide pas le champ de fichier,
  // qui n'est pas contrôlé par React. Sans ça, le formulaire garde à l'écran le nom d'un
  // document déjà envoyé, et on croit qu'il n'est pas parti.
  const [cleChamp, setCleChamp] = useState(0);
  const [erreurs, setErreurs] = useState<{ message: string; fieldId?: string }[]>([]);
  const [tentative, setTentative] = useState(0);
  const [envoi, setEnvoi] = useState(false);

  const choisir = (event: ChangeEvent<HTMLInputElement>): void => {
    const choisi = event.target.files?.[0] ?? null;
    setFichier(choisi);
    // Le nom du document se pré-remplit avec celui du fichier, sans son extension :
    // l'entreprise le corrige si elle veut, mais n'a rien à saisir dans le cas courant.
    if (choisi && nom.trim() === '') {
      setNom(choisi.name.replace(/\.pdf$/i, ''));
    }
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    if (envoi) {
      return;
    }
    setTentative((n) => n + 1);

    const trouvees: { message: string; fieldId?: string }[] = [];
    if (!fichier) {
      trouvees.push({ message: 'Choisissez un fichier PDF.', fieldId: 'annexe-fichier' });
    } else if (fichier.size > TAILLE_MAX) {
      trouvees.push({
        message: 'Le document ne doit pas dépasser 5 Mo.',
        fieldId: 'annexe-fichier',
      });
    }
    if (nom.trim() === '') {
      trouvees.push({ message: 'Donnez un nom au document.', fieldId: 'annexe-nom' });
    }
    setErreurs(trouvees);
    if (trouvees.length > 0) {
      return;
    }

    setEnvoi(true);
    const corps = new FormData();
    corps.append('filename', nom);
    corps.append('file', fichier!);

    try {
      const reponse = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/missions/${missionId}/annexes`,
        { method: 'POST', credentials: 'include', body: corps },
      );
      if (!reponse.ok) {
        const charge: unknown = await reponse.json().catch(() => null);
        const message =
          typeof charge === 'object' && charge !== null && 'message' in charge
            ? String((charge as { message: unknown }).message)
            : 'Le document n’a pas pu être envoyé.';
        setErreurs([{ message }]);
        return;
      }
      setNom('');
      setFichier(null);
      setCleChamp((n) => n + 1);
      router.refresh();
    } catch {
      setErreurs([{ message: 'Le serveur ne répond pas. Réessayez dans quelques instants.' }]);
    } finally {
      setEnvoi(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="formulaire carte-formulaire">
      <ErrorSummary errors={erreurs} attempt={tentative} />

      <div className="champ">
        <label htmlFor="annexe-fichier" className="champ__etiquette">
          Fichier PDF
          <span className="champ__requis" aria-hidden="true">
            {' '}
            *
          </span>
        </label>
        <p id="annexe-fichier-indication" className="champ__indication">
          5 Mo maximum. Le document est chiffré avant d’être enregistré, et n’est lisible que par
          vous et par l’intérimaire retenu sur cette mission.
        </p>
        {erreurs.find((e) => e.fieldId === 'annexe-fichier') && (
          <p className="champ__message-erreur">
            <span className="visuellement-masque">Erreur : </span>
            {erreurs.find((e) => e.fieldId === 'annexe-fichier')!.message}
          </p>
        )}
        <input
          key={cleChamp}
          id="annexe-fichier"
          name="file"
          type="file"
          accept="application/pdf"
          onChange={choisir}
          aria-describedby="annexe-fichier-indication"
          className="champ__saisie"
        />
      </div>

      <TextField
        id="annexe-nom"
        label="Nom du document"
        value={nom}
        onChange={setNom}
        error={erreurs.find((e) => e.fieldId === 'annexe-nom')?.message}
        hint="C'est ce nom que l'intérimaire verra. « Consignes de sécurité du site » est plus utile que « scan_0043 »."
        placeholder="Consignes de sécurité du site"
        maxLength={255}
      />

      <button type="submit" className="bouton bouton--principal" disabled={envoi}>
        {envoi ? 'Envoi…' : 'Joindre le document'}
      </button>
    </form>
  );
}
