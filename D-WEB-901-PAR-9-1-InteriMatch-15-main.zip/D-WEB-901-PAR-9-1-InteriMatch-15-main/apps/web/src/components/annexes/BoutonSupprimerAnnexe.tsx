'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

/**
 * Suppression d'une annexe, en deux temps.
 *
 * **Pas de `window.confirm`** : la boîte native n'est pas stylable, ne dit pas ce qu'elle
 * supprime, et sort du flux du clavier. La confirmation est donc rendue dans la page — le
 * bouton devient une question, avec le nom du document et deux réponses explicites.
 *
 * Le focus reste dans le composant d'un état à l'autre : les deux boutons remplacent le
 * premier au même endroit, et « Annuler » ramène à l'état initial.
 */
export function BoutonSupprimerAnnexe({
  annexeId,
  filename,
}: {
  annexeId: string;
  filename: string;
}) {
  const router = useRouter();
  const [confirme, setConfirme] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);
  const [envoi, setEnvoi] = useState(false);

  const supprimer = async (): Promise<void> => {
    setEnvoi(true);
    setErreur(null);
    try {
      const reponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/annexes/${annexeId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!reponse.ok) {
        const charge: unknown = await reponse.json().catch(() => null);
        setErreur(
          typeof charge === 'object' && charge !== null && 'message' in charge
            ? String((charge as { message: unknown }).message)
            : 'Le document n’a pas pu être retiré.',
        );
        setConfirme(false);
        return;
      }
      router.refresh();
    } catch {
      setErreur('Le serveur ne répond pas. Réessayez dans quelques instants.');
      setConfirme(false);
    } finally {
      setEnvoi(false);
    }
  };

  if (!confirme) {
    return (
      <>
        <button
          type="button"
          className="lien-action"
          onClick={() => setConfirme(true)}
          // Le nom du document dans le libellé accessible : « Retirer » seul, répété sur
          // chaque ligne, ne dit pas quoi à un lecteur d'écran qui parcourt les boutons.
          aria-label={`Retirer « ${filename} »`}
        >
          Retirer
        </button>
        {erreur && (
          <span role="alert" className="champ__message-erreur">
            <span className="visuellement-masque">Erreur : </span>
            {erreur}
          </span>
        )}
      </>
    );
  }

  return (
    <span className="confirmation-annexe" role="group" aria-label={`Retirer « ${filename} » ?`}>
      <span className="confirmation-annexe__question">Retirer ce document ?</span>
      <button
        type="button"
        className="lien-action lien-action--danger"
        onClick={() => void supprimer()}
        disabled={envoi}
      >
        {envoi ? 'Suppression…' : 'Oui, retirer'}
      </button>
      <button type="button" className="lien-action" onClick={() => setConfirme(false)}>
        Annuler
      </button>
    </span>
  );
}
