import Link from 'next/link';
import { notFound } from 'next/navigation';
import { serverGetOrRedirect } from '../../lib/session';
import { ContratRow } from './ListeContrats';
import { FormulaireSignature } from './FormulaireSignature';

const TITRE: Record<ContratRow['type'], string> = {
  MISSION: 'Contrat de mission',
  MISE_A_DISPOSITION: 'Contrat de mise à disposition',
};

/**
 * Écran de signature, partagé par les deux espaces.
 *
 * Le contrat est retrouvé dans la liste que l'API sert au demandeur, et non demandé par son
 * identifiant : un contrat qui ne le concerne pas n'y figure pas, et la page rend 404 sans
 * qu'aucune règle d'accès n'ait à être réécrite côté site. L'API refuserait de toute façon,
 * c'est la deuxième barrière, pas la première.
 */
export async function PageSignature({
  contratId,
  nomAttendu,
  retour,
}: {
  contratId: string;
  nomAttendu: string;
  retour: string;
}) {
  const contrats = await serverGetOrRedirect<ContratRow[]>('/contrats');
  const contrat = contrats.find((candidat) => candidat.id === contratId);

  if (!contrat) {
    notFound();
  }

  // Déjà signé : on ne propose pas un formulaire qui serait refusé en 409. On le dit, et on
  // renvoie vers la liste où le document final est lisible.
  if (!contrat.aSigner) {
    return (
      <main>
        <h1>Contrat déjà signé</h1>
        <p className="accroche">
          Vous avez déjà signé ce {TITRE[contrat.type].toLowerCase()}. Un document signé ne peut
          plus être modifié.
        </p>
        <Link href={retour} className="bouton bouton--principal">
          Revenir à mes contrats
        </Link>
      </main>
    );
  }

  return (
    <main>
      <h1>Signer le {TITRE[contrat.type].toLowerCase()}</h1>
      <p className="accroche">
        Mission <strong>{contrat.missionTitre}</strong> chez {contrat.companyName}. CADANS a déjà
        signé ; votre signature rend le contrat définitif.
      </p>

      <FormulaireSignature
        contratId={contrat.id}
        nomAttendu={nomAttendu}
        documentUrl={`${process.env.NEXT_PUBLIC_API_URL}/contrats/${contrat.id}/document`}
        retour={retour}
      />
    </main>
  );
}
