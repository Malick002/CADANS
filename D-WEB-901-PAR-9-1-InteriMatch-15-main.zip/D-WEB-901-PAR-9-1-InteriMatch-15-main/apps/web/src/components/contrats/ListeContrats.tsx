import Link from 'next/link';

export interface SignatureRow {
  party: 'CADANS' | 'INTERIMAIRE' | 'ENTREPRISE';
  typedName: string;
  signedAt: string;
}

export interface ContratRow {
  id: string;
  type: 'MISSION' | 'MISE_A_DISPOSITION';
  missionId: string;
  missionTitre: string;
  companyName: string;
  generatedAt: string;
  // Empreinte SHA-256 du document servi. Elle n'est pas décorative : c'est elle qui identifie
  // le document exact sur lequel porte la signature.
  sha256: string;
  signatures: SignatureRow[];
  signe: boolean;
  missionPrete: boolean;
  aSigner: boolean;
  missionStartDate: string;
  missionEndDate: string;
}

const PARTIE_LIBELLE: Record<SignatureRow['party'], string> = {
  CADANS: 'CADANS',
  INTERIMAIRE: 'L’intérimaire',
  ENTREPRISE: 'L’entreprise',
};

const TYPE_LIBELLE: Record<ContratRow['type'], string> = {
  MISSION: 'Contrat de mission',
  MISE_A_DISPOSITION: 'Contrat de mise à disposition',
};

const TYPE_ARTICLE: Record<ContratRow['type'], string> = {
  MISSION: 'art. L. 1251-16',
  MISE_A_DISPOSITION: 'art. L. 1251-43',
};

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

function formatJour(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
  });
}

/**
 * Liste des contrats, partagée par les deux espaces : le document diffère, la présentation
 * non. L'API ne sert à chacun que ses propres contrats, il n'y a donc rien à filtrer ici.
 *
 * Le lien ouvre le PDF dans un nouvel onglet (`target="_blank"`) plutôt que de forcer un
 * téléchargement : un contrat doit pouvoir être relu avant d'être signé.
 */
export function ListeContrats({
  contrats,
  basePath,
}: {
  contrats: ContratRow[];
  // `/interimaire/contrats` ou `/entreprise/contrats` : le composant est partagé, l'URL de
  // signature ne l'est pas — chaque espace a la sienne, et le layout qui va avec.
  basePath: string;
}) {
  return (
    <ul className="cartes-contrat">
      {contrats.map((contrat) => (
        <li key={contrat.id} className="carte carte-contrat">
          <div className="carte__entete">
            <h2 className="carte-contrat__titre">{TYPE_LIBELLE[contrat.type]}</h2>
            <span className="badge">{TYPE_ARTICLE[contrat.type]}</span>
          </div>
          <dl className="carte-contrat__details">
            <div>
              <dt className="mono">Mission</dt>
              <dd>
                {contrat.missionTitre} · {contrat.companyName}
              </dd>
            </div>
            <div>
              <dt className="mono">Établi le</dt>
              <dd>{formatDate(contrat.generatedAt)}</dd>
            </div>
            <div>
              <dt className="mono">Empreinte</dt>
              {/* Tronquée à l'affichage : 64 caractères hexadécimaux sur une carte ne se
                  lisent pas, et les 16 premiers suffisent à comparer deux documents à l'œil.
                  La valeur entière reste dans le titre, donc copiable et lisible au survol. */}
              <dd className="mono carte-contrat__empreinte" title={contrat.sha256}>
                {contrat.sha256.slice(0, 16)}…
              </dd>
            </div>
          </dl>
          {/* Qui a signé, et quand. Écrit en toutes lettres et non porté par une couleur :
              un statut n'est jamais signalé par la seule couleur (RGAA 4.1, critère 1.3). */}
          <ul className="carte-contrat__signatures">
            {contrat.signatures.map((signature) => (
              <li key={signature.party}>
                <span className="carte-contrat__coche" aria-hidden="true">
                  ✓
                </span>
                {PARTIE_LIBELLE[signature.party]} — signé le {formatDate(signature.signedAt)} par{' '}
                {signature.typedName}
              </li>
            ))}
          </ul>

          {/* Deux états distincts, et les confondre serait mentir : ce document est signé
              (il est figé), et la mission est prête (plus aucun contrat n'attend personne).
              L'entreprise peut avoir signé le sien pendant que l'intérimaire n'a pas signé le
              sien — la mission n'est alors pas prête.
              Les dates finissent la phrase : « 15 oct. » porte déjà un point, en ajouter un
              second donnerait « 15 oct.. ». */}
          {contrat.signe && (
            <p className="carte-contrat__pret">
              {contrat.missionPrete ? (
                <>
                  <strong>Mission prête à démarrer.</strong> Tous les contrats sont signés, pour la
                  période du {formatJour(contrat.missionStartDate)} au{' '}
                  {formatJour(contrat.missionEndDate)}
                </>
              ) : (
                <>
                  <strong>Document signé.</strong> Il ne peut plus être modifié. La mission
                  démarrera quand l’autre contrat aura été signé.
                </>
              )}
            </p>
          )}

          <p className="carte-contrat__actions">
            <a
              href={`${process.env.NEXT_PUBLIC_API_URL}/contrats/${contrat.id}/document`}
              className="bouton bouton--secondaire"
              target="_blank"
              rel="noopener noreferrer"
            >
              Lire le document (nouvelle fenêtre)
            </a>
            {contrat.aSigner && (
              <Link href={`${basePath}/${contrat.id}/signer`} className="bouton bouton--principal">
                Signer
              </Link>
            )}
            <Link href={`/missions/${contrat.missionId}`}>Voir la mission</Link>
          </p>
        </li>
      ))}
    </ul>
  );
}
