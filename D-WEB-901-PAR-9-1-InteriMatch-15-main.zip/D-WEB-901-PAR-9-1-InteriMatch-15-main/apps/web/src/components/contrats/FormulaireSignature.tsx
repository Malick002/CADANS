'use client';

import { useRouter } from 'next/navigation';
import { FormEvent, useState } from 'react';
import { ApiError, postJson } from '../../lib/api';
import { CheckboxField } from '../form/CheckboxField';
import { ErrorSummary } from '../form/ErrorSummary';
import { TextField } from '../form/TextField';

interface Props {
  contratId: string;
  // Nom attendu, celui du compte. Il est affiché : signer n'est pas un jeu de devinettes, et
  // l'API refuse de toute façon un nom qui ne correspond pas.
  nomAttendu: string;
  documentUrl: string;
  retour: string;
}

/**
 * Signature en trois gestes délibérés : lire, taper son nom, cocher.
 *
 * Le bouton reste actif même quand le formulaire est incomplet, et c'est volontaire : un
 * bouton grisé n'explique rien. La soumission dit ce qui manque, et le récapitulatif d'erreurs
 * prend le focus — un lecteur d'écran l'annonce.
 */
export function FormulaireSignature({ contratId, nomAttendu, documentUrl, retour }: Props) {
  const router = useRouter();
  const [nom, setNom] = useState('');
  // Même stockage en chaîne que les autres formulaires ('' décoché, 'oui' coché) : c'est la
  // convention de CheckboxField, la changer ici aurait demandé de le rendre générique.
  const [accepte, setAccepte] = useState('');
  const [erreurs, setErreurs] = useState<{ message: string; fieldId?: string }[]>([]);
  const [tentative, setTentative] = useState(0);
  const [envoi, setEnvoi] = useState(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>): Promise<void> => {
    event.preventDefault();
    if (envoi) {
      return;
    }
    setTentative((n) => n + 1);

    const trouvees: { message: string; fieldId?: string }[] = [];
    if (nom.trim() === '') {
      trouvees.push({ message: 'Saisissez votre nom complet.', fieldId: 'signature-nom' });
    }
    if (accepte === '') {
      trouvees.push({
        message: 'Cochez la case d’acceptation pour signer.',
        fieldId: 'signature-accepte',
      });
    }
    setErreurs(trouvees);
    if (trouvees.length > 0) {
      return;
    }

    setEnvoi(true);
    try {
      await postJson(`/contrats/${contratId}/signer`, { nomComplet: nom, accepte: true });
      // `refresh()` avant `push()` : la liste est rendue côté serveur, sans lui elle
      // réafficherait l'état d'avant signature depuis le cache du routeur.
      router.refresh();
      router.push(retour);
    } catch (error) {
      setErreurs(
        error instanceof ApiError
          ? error.messages.map((message) => ({ message }))
          : [{ message: 'Une erreur inattendue est survenue. Réessayez dans quelques instants.' }],
      );
      setEnvoi(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="formulaire carte-formulaire">
      <ErrorSummary errors={erreurs} attempt={tentative} />

      <fieldset>
        <legend>Le document</legend>
        <p className="champ__indication">
          Lisez-le avant de signer. Après signature, il ne peut plus être modifié.
        </p>
        {/* Aperçu intégré, et lien de secours juste dessous : tous les navigateurs n'affichent
            pas un PDF dans un cadre, et certains le téléchargent. Sans le lien, un utilisateur
            dans ce cas signerait sans avoir rien vu. */}
        <iframe src={documentUrl} title="Aperçu du contrat" className="apercu-contrat" />
        <p className="champ__indication">
          <a href={documentUrl} target="_blank" rel="noopener noreferrer">
            Ouvrir le document dans un nouvel onglet
          </a>
        </p>
      </fieldset>

      <fieldset>
        <legend>Votre signature</legend>
        <TextField
          id="signature-nom"
          label="Votre nom complet"
          value={nom}
          onChange={setNom}
          error={erreurs.find((e) => e.fieldId === 'signature-nom')?.message}
          hint={`Saisissez « ${nomAttendu} », tel qu'il figure sur votre compte. C'est ce nom qui apparaîtra sur le document signé.`}
          placeholder={nomAttendu}
          maxLength={200}
          autoComplete="name"
        />
        <CheckboxField
          id="signature-accepte"
          value={accepte}
          onChange={setAccepte}
          error={erreurs.find((e) => e.fieldId === 'signature-accepte')?.message}
          label={
            <>
              J’ai lu le contrat ci-dessus et je l’accepte. Je sais que ma signature est enregistrée
              avec la date, mon adresse IP et l’empreinte du document.
            </>
          }
        />
      </fieldset>

      <button type="submit" className="bouton bouton--principal" disabled={envoi}>
        {envoi ? 'Signature en cours…' : 'Signer le contrat'}
      </button>
    </form>
  );
}
