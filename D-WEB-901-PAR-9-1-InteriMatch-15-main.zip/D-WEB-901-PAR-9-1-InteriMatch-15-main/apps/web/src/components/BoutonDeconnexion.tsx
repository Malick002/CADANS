'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { postJson } from '../lib/api';

// POST /auth/logout : l'API efface le cookie de session (il est httpOnly, le navigateur ne
// peut pas le supprimer lui-même). `router.refresh()` force les Server Components à relire
// la session, sinon l'écran resterait affiché avec les données de l'ancien compte.
export function BoutonDeconnexion() {
  const router = useRouter();
  const [enCours, setEnCours] = useState(false);

  const deconnecter = async (): Promise<void> => {
    setEnCours(true);
    try {
      await postJson('/auth/logout', {});
    } catch {
      // Même si l'appel échoue, on quitte l'espace connecté : laisser l'utilisateur sur un
      // écran qu'il croit déconnecté serait pire que de le renvoyer à l'accueil.
    }
    router.push('/');
    router.refresh();
  };

  return (
    <button
      type="button"
      onClick={deconnecter}
      disabled={enCours}
      className="tableau-bord__deconnexion"
    >
      {enCours ? 'Déconnexion…' : 'Se déconnecter'}
    </button>
  );
}
