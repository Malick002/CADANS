'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { getJson, postJson } from '../lib/api';

interface Compte {
  role: 'COMPANY' | 'WORKER' | 'ADMIN';
}

// Un espace par rôle. `Record<Compte['role'], string>` plutôt qu'un objet libre : ajouter un
// rôle sans lui donner d'espace ne compile plus. Sans ça, le rôle ADMIN a rendu `href`
// indéfini pendant une demi-journée, sans erreur de compilation.
const ESPACE_PAR_ROLE: Record<Compte['role'], string> = {
  COMPANY: '/entreprise/missions',
  WORKER: '/interimaire/matches',
  ADMIN: '/admin/justificatifs',
};

interface BoutonsCompteProps {
  // Ferme le menu mobile quand on suit un lien : l'état vit dans EnteteSite.
  onNavigate?: () => void;
}

/**
 * Boutons de compte de l'en-tête public : « Se connecter / Créer un compte » pour un
 * visiteur, « Mon espace / Se déconnecter » pour une session ouverte.
 *
 * **Pourquoi la session est lue dans le navigateur et non sur le serveur.** Lire le cookie
 * côté serveur (`cookies()`) marque toute la page comme dynamique : l'accueil, l'inscription
 * et la politique de confidentialité cesseraient d'être pré-rendues, ce qui coûterait à la
 * fois le SEO et la sobriété (RGESN). Seul ce fragment s'hydrate ; le reste de l'en-tête et
 * la page entière restent statiques.
 *
 * **Conséquence assumée** : le rendu initial est celui du visiteur anonyme, remplacé après
 * hydratation si une session existe. C'est aussi ce que voit un navigateur sans JavaScript —
 * et les deux liens proposés y restent corrects, ils mènent à la connexion.
 */
export function BoutonsCompte({ onNavigate }: BoutonsCompteProps) {
  const router = useRouter();
  const [compte, setCompte] = useState<Compte | null>(null);
  const [deconnexion, setDeconnexion] = useState(false);

  useEffect(() => {
    // `annule` évite un setState après démontage (navigation rapide pendant l'appel).
    let annule = false;
    getJson<Compte>('/auth/me')
      .then((reponse) => {
        if (!annule) {
          setCompte(reponse);
        }
      })
      .catch(() => {
        // 401 attendu pour un visiteur : ce n'est pas une erreur, c'est le cas courant.
      });
    return () => {
      annule = true;
    };
  }, []);

  const seDeconnecter = async (): Promise<void> => {
    setDeconnexion(true);
    try {
      await postJson('/auth/logout', {});
    } catch {
      // Même geste que BoutonDeconnexion : on quitte l'état connecté quoi qu'il arrive.
    }
    setCompte(null);
    setDeconnexion(false);
    onNavigate?.();
    // Les pages connectées lisent la session côté serveur : sans ce rafraîchissement, elles
    // continueraient d'afficher les données de l'ancien compte.
    router.refresh();
  };

  if (!compte) {
    return (
      <>
        <Link href="/connexion" className="bouton bouton--secondaire" onClick={onNavigate}>
          Se connecter
        </Link>
        <Link href="/inscription" className="bouton bouton--principal" onClick={onNavigate}>
          Créer un compte
        </Link>
      </>
    );
  }

  return (
    <>
      <Link
        href={ESPACE_PAR_ROLE[compte.role]}
        className="bouton bouton--secondaire"
        onClick={onNavigate}
      >
        Mon espace
      </Link>
      <button
        type="button"
        className="bouton bouton--principal"
        onClick={seDeconnecter}
        disabled={deconnexion}
      >
        {deconnexion ? 'Déconnexion…' : 'Se déconnecter'}
      </button>
    </>
  );
}
