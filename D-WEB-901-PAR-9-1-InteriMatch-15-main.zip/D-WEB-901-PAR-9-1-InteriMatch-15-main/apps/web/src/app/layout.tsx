import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import './globals.css';
import { police, policeMono, policeTitre } from '../fonts/police';

export const metadata: Metadata = {
  title: {
    default: 'CADANS — intérim logistique d’entrepôt',
    template: '%s | CADANS',
  },
  description:
    'CADANS met en relation les entreprises de logistique d’entrepôt et les intérimaires ' +
    'qualifiés : missions proches, habilitations vérifiées, mise en relation automatisée.',
};

// Coquille commune à tout le site. L'en-tête n'est volontairement pas ici : les pages
// publiques portent la barre marketing (app/(site)/layout.tsx), les espaces connectés leur
// barre latérale et leur bandeau de compte. Les afficher toutes les deux donnait deux
// navigations superposées, et des boutons « Se connecter » sur un écran déjà connecté.
export default function RootLayout({ children }: { children: ReactNode }) {
  // lang="fr" est requis par le RGAA : il conditionne la restitution vocale.
  return (
    <html lang="fr" className={`${police.variable} ${policeTitre.variable} ${policeMono.variable}`}>
      <body>
        {/* Lien d'évitement (RGAA 12.7) : premier élément atteint au clavier. */}
        <a href="#contenu" className="lien-evitement">
          Aller au contenu
        </a>
        <div id="contenu">{children}</div>
      </body>
    </html>
  );
}
