import { redirect } from 'next/navigation';
import type { ReactNode } from 'react';
import { BoutonDeconnexion } from '../../components/BoutonDeconnexion';
import { BarreLaterale } from '../../components/tableau-bord/BarreLaterale';
import { getSessionAccount } from '../../lib/session';

// Espace des agents CADANS. Protégé ici une seule fois, comme les deux autres espaces.
// Un intérimaire ou une entreprise qui arrive sur /admin est renvoyé vers la connexion ;
// l'API, elle, répond 403 sur ses propres routes — la protection est des deux côtés.
export default async function AdminLayout({ children }: { children: ReactNode }) {
  const account = await getSessionAccount();
  if (!account || account.role !== 'ADMIN') {
    redirect('/connexion');
  }

  return (
    <div className="tableau-bord">
      <BarreLaterale
        label="Espace agent CADANS"
        entrees={[
          { href: '/admin', label: 'Tableau de bord', exact: true },
          { href: '/admin/justificatifs', label: 'Justificatifs' },
          { href: '/admin/missions', label: 'Missions' },
          { href: '/admin/contrats', label: 'Contrats' },
          { href: '/admin/interimaires', label: 'Intérimaires' },
          { href: '/admin/entreprises', label: 'Entreprises' },
        ]}
      >
        <div className="tableau-bord__compte">
          <p className="tableau-bord__compte-nom">Agent CADANS</p>
          <BoutonDeconnexion />
        </div>
      </BarreLaterale>

      <div className="tableau-bord__contenu">{children}</div>
    </div>
  );
}
