import type { Metadata } from 'next';
import Link from 'next/link';
import { certificationLabel } from '../../lib/certifications';
import { serverGetOrRedirect } from '../../lib/session';

export const metadata: Metadata = {
  title: 'Tableau de bord',
  robots: { index: false, follow: false },
};

interface TableauDeBord {
  compteurs: {
    justificatifsEnAttente: number;
    missionsOuvertes: number;
    missionsPourvues: number;
    contratsASigner: number;
    interimaires: number;
    entreprises: number;
  };
  derniersJustificatifs: {
    certificationId: string;
    type: string;
    deposeLe: string;
    interimaire: { prenom: string; nom: string };
  }[];
}

// Les six compteurs, dans l'ordre d'urgence décroissante : ce sur quoi l'agent doit agir
// d'abord, puis l'activité de la plateforme, puis les volumes.
//
// `href` mène à l'écran qui permet de VOIR ce que le nombre recouvre — filtré sur le même
// statut quand la vue le permet (missions, contrats), sinon la liste entière (intérimaires,
// entreprises). Un compteur sans écran derrière serait un lien mort, pire qu'un texte ; les
// quatre écrans existent désormais tous.
const COMPTEURS: {
  cle: keyof TableauDeBord['compteurs'];
  label: string;
  href?: string;
  precision?: string;
}[] = [
  {
    cle: 'justificatifsEnAttente',
    label: 'Justificatifs en attente',
    href: '/admin/justificatifs',
    precision: 'à examiner',
  },
  {
    cle: 'missionsOuvertes',
    label: 'Missions ouvertes',
    href: '/admin/missions?statut=OUVERTE',
    precision: 'en recherche',
  },
  {
    cle: 'missionsPourvues',
    label: 'Missions pourvues',
    href: '/admin/missions?statut=POURVUE',
    precision: 'intérimaire retenu',
  },
  {
    cle: 'contratsASigner',
    label: 'Contrats à signer',
    href: '/admin/contrats?statut=A_SIGNER',
    precision: 'signature incomplète',
  },
  { cle: 'interimaires', label: 'Intérimaires inscrits', href: '/admin/interimaires' },
  { cle: 'entreprises', label: 'Entreprises inscrites', href: '/admin/entreprises' },
];

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export default async function AdminTableauDeBordPage() {
  const { compteurs, derniersJustificatifs } =
    await serverGetOrRedirect<TableauDeBord>('/admin/tableau-de-bord');

  return (
    <main>
      <h1>Tableau de bord</h1>
      <p className="accroche">
        L’état de la plateforme, et ce qui attend une décision de votre part.
      </p>

      <section aria-labelledby="compteurs-titre">
        <h2 id="compteurs-titre" className="visuellement-masque">
          Chiffres de la plateforme
        </h2>
        <ul className="compteurs">
          {COMPTEURS.map(({ cle, label, href, precision }) => {
            const valeur = compteurs[cle];
            const contenu = (
              <>
                <span className="compteur__valeur">{valeur}</span>
                <span className="compteur__label">{label}</span>
                {precision && <span className="compteur__precision">{precision}</span>}
              </>
            );

            return (
              <li key={cle}>
                {href ? (
                  <Link href={href} className="compteur compteur--lien">
                    {contenu}
                  </Link>
                ) : (
                  <div className="compteur">{contenu}</div>
                )}
              </li>
            );
          })}
        </ul>
      </section>

      <section aria-labelledby="derniers-titre" className="section-admin">
        <h2 id="derniers-titre">Derniers justificatifs déposés</h2>

        {derniersJustificatifs.length === 0 ? (
          <div className="etat-vide">
            <p className="etat-vide__titre">
              <strong>Rien à examiner.</strong>
            </p>
            <p className="etat-vide__texte">
              Les justificatifs déposés par les intérimaires apparaissent ici dès leur envoi.
            </p>
          </div>
        ) : (
          <>
            <ul className="liste-simple">
              {derniersJustificatifs.map((justificatif) => (
                <li key={justificatif.certificationId} className="ligne-justificatif">
                  <span className="ligne-justificatif__intitule">
                    {certificationLabel(justificatif.type)} — {justificatif.interimaire.prenom}{' '}
                    {justificatif.interimaire.nom}
                  </span>
                  <span className="ligne-justificatif__date">
                    déposé le {formatDate(justificatif.deposeLe)}
                  </span>
                </li>
              ))}
            </ul>
            {/* Le lien porte l'action, pas la liste : chaque ligne mènerait à la même page,
                et cinq liens identiques sont une nuisance au lecteur d'écran (RGAA 6.1). */}
            <Link href="/admin/justificatifs" className="bouton bouton--principal">
              Examiner la file d’attente
            </Link>
          </>
        )}
      </section>

      <section aria-labelledby="acces-titre" className="section-admin">
        <h2 id="acces-titre">Accès rapides</h2>
        <ul className="liste-simple">
          <li>
            <Link href="/admin/justificatifs">Justificatifs à vérifier</Link> — valider ou refuser
            les habilitations déposées par les intérimaires.
          </li>
          <li>
            <Link href="/missions">Missions publiées</Link> — la liste publique, telle qu’un
            intérimaire la voit.
          </li>
        </ul>
      </section>
    </main>
  );
}
