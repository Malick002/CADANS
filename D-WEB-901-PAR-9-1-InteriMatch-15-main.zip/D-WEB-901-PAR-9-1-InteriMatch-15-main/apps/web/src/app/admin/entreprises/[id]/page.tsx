import type { Metadata } from 'next';
import Link from 'next/link';
import { serverGetOrRedirect } from '../../../../lib/session';

interface MissionResume {
  id: string;
  posteLabel: string;
  status: 'OUVERTE' | 'POURVUE' | 'TERMINEE';
  startDate: string;
  endDate: string;
}

interface EntrepriseDetail {
  id: string;
  raisonSociale: string;
  siret: string;
  codeNaf: string;
  contactPrenom: string;
  contactNom: string;
  email: string;
  telephone: string | null;
  adresse: string;
  codePostal: string;
  ville: string;
  inscritLe: string;
  missions: MissionResume[];
}

// Même correspondance que /entreprise/missions : le libellé du statut est toujours écrit en
// toutes lettres, jamais la seule couleur (RGAA 4.1).
const STATUT_LIBELLE: Record<MissionResume['status'], string> = {
  OUVERTE: 'Ouverte',
  POURVUE: 'Pourvue',
  TERMINEE: 'Terminée',
};

function formatDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const entreprise = await serverGetOrRedirect<EntrepriseDetail>(`/admin/entreprises/${id}`);
  return { title: entreprise.raisonSociale, robots: { index: false, follow: false } };
}

export default async function EntreprisePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const entreprise = await serverGetOrRedirect<EntrepriseDetail>(`/admin/entreprises/${id}`);

  return (
    <main>
      <p className="fil-retour">
        <Link href="/admin/entreprises">Entreprises</Link> › {entreprise.raisonSociale}
      </p>

      <h1>{entreprise.raisonSociale}</h1>
      <p className="accroche">
        {entreprise.ville} ({entreprise.codePostal}) — inscrite le{' '}
        <time dateTime={entreprise.inscritLe}>{formatDate(entreprise.inscritLe.slice(0, 10))}</time>
      </p>

      <div className="carte">
        <dl className="carte-mission__details">
          <div>
            <dt>SIRET</dt>
            <dd className="mono">{entreprise.siret}</dd>
          </div>
          <div>
            <dt>Code NAF</dt>
            <dd className="mono">{entreprise.codeNaf}</dd>
          </div>
          <div>
            <dt>Contact</dt>
            <dd>
              {entreprise.contactPrenom} {entreprise.contactNom}
            </dd>
          </div>
          <div>
            <dt>Email</dt>
            <dd>{entreprise.email}</dd>
          </div>
          <div>
            <dt>Téléphone</dt>
            <dd>{entreprise.telephone ?? 'Non renseigné'}</dd>
          </div>
          <div>
            <dt>Adresse</dt>
            <dd>
              {entreprise.adresse}, {entreprise.codePostal} {entreprise.ville}
            </dd>
          </div>
        </dl>
      </div>

      <section className="section-admin">
        <h2>Missions publiées</h2>
        {entreprise.missions.length === 0 ? (
          <p className="champ__indication">Aucune mission publiée.</p>
        ) : (
          <ul className="liste-simple">
            {entreprise.missions.map((mission) => (
              <li key={mission.id}>
                <span className={`statut statut--${mission.status.toLowerCase()}`}>
                  <span className="statut__pastille" aria-hidden="true" />
                  {STATUT_LIBELLE[mission.status]}
                </span>{' '}
                {mission.posteLabel} — {formatDate(mission.startDate)} →{' '}
                {formatDate(mission.endDate)}
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
