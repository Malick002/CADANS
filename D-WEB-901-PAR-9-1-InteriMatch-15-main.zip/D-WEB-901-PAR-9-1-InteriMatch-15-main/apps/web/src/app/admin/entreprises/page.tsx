import type { Metadata } from 'next';
import Link from 'next/link';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Entreprises',
  robots: { index: false, follow: false },
};

interface EntrepriseRow {
  id: string;
  raisonSociale: string;
  siret: string;
  ville: string;
  inscritLe: string;
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export default async function EntreprisesPage() {
  const entreprises = await serverGetOrRedirect<EntrepriseRow[]>('/admin/entreprises');

  return (
    <main>
      <h1>Entreprises</h1>
      <p className="accroche">
        {entreprises.length} entreprise{entreprises.length > 1 ? 's' : ''} inscrite
        {entreprises.length > 1 ? 's' : ''}.
      </p>

      {entreprises.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>Aucune entreprise inscrite.</strong>
          </p>
        </div>
      ) : (
        /* Une zone qui défile doit rester atteignable au clavier (WCAG 2.1.1) : même motif
           que le comparatif de la page d'accueil. */
        // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
        <div className="tableau" tabIndex={0} role="region" aria-label="Liste des entreprises">
          <table>
            <caption className="visuellement-masque">Liste des entreprises inscrites</caption>
            <thead>
              <tr>
                <th scope="col">Raison sociale</th>
                <th scope="col">SIRET</th>
                <th scope="col">Ville</th>
                <th scope="col">Inscrite le</th>
              </tr>
            </thead>
            <tbody>
              {entreprises.map((entreprise) => (
                <tr key={entreprise.id}>
                  <th scope="row">
                    <Link href={`/admin/entreprises/${entreprise.id}`}>
                      {entreprise.raisonSociale}
                    </Link>
                  </th>
                  <td className="mono">{entreprise.siret}</td>
                  <td>{entreprise.ville}</td>
                  <td>
                    <time dateTime={entreprise.inscritLe}>{formatDate(entreprise.inscritLe)}</time>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
