import type { Metadata } from 'next';
import Link from 'next/link';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Missions',
  robots: { index: false, follow: false },
};

type Statut = 'OUVERTE' | 'POURVUE' | 'TERMINEE';

interface MissionRow {
  id: string;
  posteLabel: string;
  companyName: string;
  siteLabel: string;
  status: Statut;
  startDate: string;
  endDate: string;
}

const FILTRES = [
  { valeur: 'TOUTES', libelle: 'Toutes' },
  { valeur: 'OUVERTE', libelle: 'Ouvertes' },
  { valeur: 'POURVUE', libelle: 'Pourvues' },
  { valeur: 'TERMINEE', libelle: 'Terminées' },
] as const;

type Filtre = (typeof FILTRES)[number]['valeur'];

const STATUT_LIBELLE: Record<Statut, string> = {
  OUVERTE: 'Ouverte',
  POURVUE: 'Pourvue',
  TERMINEE: 'Terminée',
};

function formatDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export default async function AdminMissionsPage({
  searchParams,
}: {
  searchParams: Promise<{ statut?: string }>;
}) {
  const { statut } = await searchParams;
  const filtre: Filtre = FILTRES.some((f) => f.valeur === statut) ? (statut as Filtre) : 'TOUTES';
  const missions = await serverGetOrRedirect<MissionRow[]>(`/admin/missions?statut=${filtre}`);

  return (
    <main>
      <h1>Missions</h1>
      <p className="accroche">
        {missions.length} mission{missions.length > 1 ? 's' : ''}, toutes entreprises confondues.
      </p>

      <nav className="filtres" aria-label="Filtrer les missions">
        {FILTRES.map((option) => (
          <Link
            key={option.valeur}
            href={`/admin/missions?statut=${option.valeur}`}
            className={`filtre${option.valeur === filtre ? ' filtre--actif' : ''}`}
            aria-current={option.valeur === filtre ? 'page' : undefined}
          >
            {option.libelle}
          </Link>
        ))}
      </nav>

      {missions.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>Aucune mission dans cette vue.</strong>
          </p>
        </div>
      ) : (
        /* Une zone qui défile doit rester atteignable au clavier (WCAG 2.1.1) : même motif
           que le comparatif de la page d'accueil. */
        // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
        <div className="tableau" tabIndex={0} role="region" aria-label="Liste des missions">
          <table>
            <caption className="visuellement-masque">Liste des missions</caption>
            <thead>
              <tr>
                <th scope="col">Poste</th>
                <th scope="col">Entreprise</th>
                <th scope="col">Statut</th>
                <th scope="col">Dates</th>
              </tr>
            </thead>
            <tbody>
              {missions.map((mission) => (
                <tr key={mission.id}>
                  <th scope="row">
                    <Link href={`/admin/missions/${mission.id}`}>
                      {mission.posteLabel} — {mission.siteLabel}
                    </Link>
                  </th>
                  <td>{mission.companyName}</td>
                  <td>
                    <span className={`statut statut--${mission.status.toLowerCase()}`}>
                      <span className="statut__pastille" aria-hidden="true" />
                      {STATUT_LIBELLE[mission.status]}
                    </span>
                  </td>
                  <td>
                    {formatDate(mission.startDate)} → {formatDate(mission.endDate)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
