import type { Metadata } from 'next';
import Link from 'next/link';
import { serverGetOrRedirect } from '../../../../lib/session';
import { shiftLabel } from '../../../../lib/shifts';
import { tauxHoraire } from '../../../../lib/montants';

type Statut = 'OUVERTE' | 'POURVUE' | 'TERMINEE';

interface MissionDetail {
  id: string;
  posteLabel: string;
  companyName: string;
  siteLabel: string;
  postalCode: string;
  status: Statut;
  startDate: string;
  endDate: string;
  shift: string;
  hourlyRate: string;
  assignedWorker: { prenom: string; nom: string } | null;
  candidaturesCount: number;
  contrats: { type: 'MISSION' | 'MISE_A_DISPOSITION'; completedAt: string | null }[];
}

const STATUT_LIBELLE: Record<Statut, string> = {
  OUVERTE: 'Ouverte',
  POURVUE: 'Pourvue',
  TERMINEE: 'Terminée',
};

const CONTRAT_LIBELLE: Record<MissionDetail['contrats'][number]['type'], string> = {
  MISSION: 'Contrat de mission (intérimaire)',
  MISE_A_DISPOSITION: 'Contrat de mise à disposition (entreprise)',
};

function formatDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const mission = await serverGetOrRedirect<MissionDetail>(`/admin/missions/${id}`);
  return {
    title: `${mission.posteLabel} — ${mission.companyName}`,
    robots: { index: false, follow: false },
  };
}

export default async function AdminMissionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const mission = await serverGetOrRedirect<MissionDetail>(`/admin/missions/${id}`);

  return (
    <main>
      <p className="fil-retour">
        <Link href="/admin/missions">Missions</Link> › {mission.posteLabel}
      </p>

      <h1>{mission.posteLabel}</h1>
      <p className="accroche">
        {mission.companyName} · {mission.siteLabel} · {mission.postalCode}
      </p>

      <div className="carte">
        <dl className="carte-mission__details">
          <div>
            <dt>Statut</dt>
            <dd>
              <span className={`statut statut--${mission.status.toLowerCase()}`}>
                <span className="statut__pastille" aria-hidden="true" />
                {STATUT_LIBELLE[mission.status]}
              </span>
            </dd>
          </div>
          <div>
            <dt>Dates</dt>
            <dd>
              {formatDate(mission.startDate)} → {formatDate(mission.endDate)}
            </dd>
          </div>
          <div>
            <dt>Créneau</dt>
            <dd>{shiftLabel(mission.shift)}</dd>
          </div>
          <div>
            <dt>Rémunération</dt>
            <dd>{tauxHoraire(mission.hourlyRate)} €/h</dd>
          </div>
          <div>
            <dt>Intérimaire retenu</dt>
            <dd>
              {mission.assignedWorker
                ? `${mission.assignedWorker.prenom} ${mission.assignedWorker.nom}`
                : 'Aucun pour le moment'}
            </dd>
          </div>
          <div>
            <dt>Candidatures reçues</dt>
            <dd>{mission.candidaturesCount}</dd>
          </div>
        </dl>
      </div>

      <section className="section-admin">
        <h2>Contrats</h2>
        {mission.contrats.length === 0 ? (
          <p className="champ__indication">Aucun contrat généré pour cette mission.</p>
        ) : (
          <ul className="liste-simple">
            {mission.contrats.map((contrat) => (
              <li key={contrat.type}>
                {CONTRAT_LIBELLE[contrat.type]} —{' '}
                {contrat.completedAt ? (
                  <span className="badge badge--verifie">Signé</span>
                ) : (
                  <span className="badge">En attente de signature</span>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
