import type { Metadata } from 'next';
import Link from 'next/link';
import { certificationLabel } from '../../../../lib/certifications';
import { estExpiree } from '../../../../lib/habilitations';
import { serverGetOrRedirect } from '../../../../lib/session';
import { shiftLabel } from '../../../../lib/shifts';

type StatutVerification = 'NON_VERIFIE' | 'EN_ATTENTE' | 'VERIFIE' | 'REFUSE';

interface InterimaireDetail {
  id: string;
  prenom: string;
  nom: string;
  email: string;
  telephone: string | null;
  ville: string;
  codePostal: string;
  inscritLe: string;
  disponibleDu: string | null;
  disponibleAu: string | null;
  creneaux: string[];
  competences: { code: string; label: string }[];
  habilitations: {
    type: string;
    expiresAt: string | null;
    verificationStatus: StatutVerification;
  }[];
}

// Même correspondance que /admin/justificatifs : un statut se lit toujours pareil, quel que
// soit l'écran qui l'affiche.
const STATUTS: Record<StatutVerification, { libelle: string; classe: string }> = {
  NON_VERIFIE: { libelle: 'Non vérifié', classe: 'badge' },
  EN_ATTENTE: { libelle: 'En attente', classe: 'badge' },
  VERIFIE: { libelle: 'Vérifié', classe: 'badge badge--verifie' },
  REFUSE: { libelle: 'Refusé', classe: 'badge badge--refuse' },
};

function formatDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const interimaire = await serverGetOrRedirect<InterimaireDetail>(`/admin/interimaires/${id}`);
  return {
    title: `${interimaire.prenom} ${interimaire.nom}`,
    robots: { index: false, follow: false },
  };
}

export default async function InterimairePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const interimaire = await serverGetOrRedirect<InterimaireDetail>(`/admin/interimaires/${id}`);

  return (
    <main>
      <p className="fil-retour">
        <Link href="/admin/interimaires">Intérimaires</Link> › {interimaire.prenom}{' '}
        {interimaire.nom}
      </p>

      <h1>
        {interimaire.prenom} {interimaire.nom}
      </h1>
      <p className="accroche">
        {interimaire.ville} ({interimaire.codePostal}) — inscrit le{' '}
        <time dateTime={interimaire.inscritLe}>
          {formatDate(interimaire.inscritLe.slice(0, 10))}
        </time>
      </p>

      <div className="carte">
        <dl className="carte-mission__details">
          <div>
            <dt>Email</dt>
            <dd>{interimaire.email}</dd>
          </div>
          <div>
            <dt>Téléphone</dt>
            <dd>{interimaire.telephone ?? 'Non renseigné'}</dd>
          </div>
          <div>
            <dt>Disponibilité</dt>
            <dd>
              {interimaire.disponibleDu && interimaire.disponibleAu
                ? `${formatDate(interimaire.disponibleDu)} → ${formatDate(interimaire.disponibleAu)}`
                : 'Non renseignée'}
            </dd>
          </div>
          <div>
            <dt>Créneaux acceptés</dt>
            <dd>
              {interimaire.creneaux.length > 0
                ? interimaire.creneaux.map((creneau) => shiftLabel(creneau)).join(', ')
                : 'Tous (aucune préférence déclarée)'}
            </dd>
          </div>
        </dl>
      </div>

      <section className="section-admin">
        <h2>Compétences déclarées</h2>
        {interimaire.competences.length === 0 ? (
          <p className="champ__indication">Aucune compétence déclarée.</p>
        ) : (
          <ul className="carte-mission__tags" aria-label="Compétences déclarées">
            {interimaire.competences.map((competence) => (
              <li key={competence.code}>{competence.label}</li>
            ))}
          </ul>
        )}
      </section>

      <section className="section-admin">
        <h2>Habilitations</h2>
        {interimaire.habilitations.length === 0 ? (
          <p className="champ__indication">Aucune habilitation déclarée.</p>
        ) : (
          <ul className="liste-simple">
            {interimaire.habilitations.map((habilitation) => (
              <li key={habilitation.type}>
                <span className="badge">{certificationLabel(habilitation.type)}</span>{' '}
                <span className={STATUTS[habilitation.verificationStatus].classe}>
                  {STATUTS[habilitation.verificationStatus].libelle}
                </span>
                {habilitation.expiresAt && (
                  <>
                    {' — expire le '}
                    {formatDate(habilitation.expiresAt)}
                    {estExpiree(habilitation.expiresAt) && (
                      <>
                        {' '}
                        <span className="badge badge--expiree">Expirée</span>
                      </>
                    )}
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
