import type { Metadata } from 'next';
import Link from 'next/link';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Intérimaires',
  robots: { index: false, follow: false },
};

interface InterimaireRow {
  id: string;
  prenom: string;
  nom: string;
  ville: string;
  codePostal: string;
  inscritLe: string;
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export default async function InterimairesPage() {
  const interimaires = await serverGetOrRedirect<InterimaireRow[]>('/admin/interimaires');

  return (
    <main>
      <h1>Intérimaires</h1>
      <p className="accroche">
        {interimaires.length} intérimaire{interimaires.length > 1 ? 's' : ''} inscrit
        {interimaires.length > 1 ? 's' : ''}.
      </p>

      {interimaires.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>Aucun intérimaire inscrit.</strong>
          </p>
        </div>
      ) : (
        /* Une zone qui défile doit rester atteignable au clavier (WCAG 2.1.1) : même motif
           que le comparatif de la page d'accueil. */
        // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
        <div className="tableau" tabIndex={0} role="region" aria-label="Liste des intérimaires">
          <table>
            <caption className="visuellement-masque">Liste des intérimaires inscrits</caption>
            <thead>
              <tr>
                <th scope="col">Nom</th>
                <th scope="col">Ville</th>
                <th scope="col">Code postal</th>
                <th scope="col">Inscrit le</th>
              </tr>
            </thead>
            <tbody>
              {interimaires.map((interimaire) => (
                <tr key={interimaire.id}>
                  <th scope="row">
                    <Link href={`/admin/interimaires/${interimaire.id}`}>
                      {interimaire.prenom} {interimaire.nom}
                    </Link>
                  </th>
                  <td>{interimaire.ville}</td>
                  <td className="mono">{interimaire.codePostal}</td>
                  <td>
                    <time dateTime={interimaire.inscritLe}>
                      {formatDate(interimaire.inscritLe)}
                    </time>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
