import type { Metadata } from 'next';
import Link from 'next/link';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Contrats',
  robots: { index: false, follow: false },
};

type ContratType = 'MISSION' | 'MISE_A_DISPOSITION';

interface ContratRow {
  id: string;
  type: ContratType;
  posteLabel: string;
  companyName: string;
  workerName: string | null;
  generatedAt: string;
  completedAt: string | null;
}

const FILTRES = [
  { valeur: 'A_SIGNER', libelle: 'À signer' },
  { valeur: 'TOUS', libelle: 'Tous' },
] as const;

type Filtre = (typeof FILTRES)[number]['valeur'];

const TYPE_LIBELLE: Record<ContratType, string> = {
  MISSION: 'Contrat de mission',
  MISE_A_DISPOSITION: 'Mise à disposition',
};

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export default async function AdminContratsPage({
  searchParams,
}: {
  searchParams: Promise<{ statut?: string }>;
}) {
  const { statut } = await searchParams;
  const filtre: Filtre = FILTRES.some((f) => f.valeur === statut) ? (statut as Filtre) : 'A_SIGNER';
  const contrats = await serverGetOrRedirect<ContratRow[]>(`/admin/contrats?statut=${filtre}`);

  return (
    <main>
      <h1>Contrats</h1>
      <p className="accroche">
        {filtre === 'A_SIGNER'
          ? `${contrats.length} contrat${contrats.length > 1 ? 's' : ''} en attente de signature, du plus ancien au plus récent.`
          : `${contrats.length} contrat${contrats.length > 1 ? 's' : ''}, tous statuts confondus.`}
      </p>

      <nav className="filtres" aria-label="Filtrer les contrats">
        {FILTRES.map((option) => (
          <Link
            key={option.valeur}
            href={`/admin/contrats?statut=${option.valeur}`}
            className={`filtre${option.valeur === filtre ? ' filtre--actif' : ''}`}
            aria-current={option.valeur === filtre ? 'page' : undefined}
          >
            {option.libelle}
          </Link>
        ))}
      </nav>

      {contrats.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>
              {filtre === 'A_SIGNER' ? 'Rien à signer.' : 'Aucun contrat pour l’instant.'}
            </strong>
          </p>
        </div>
      ) : (
        /* Une zone qui défile doit rester atteignable au clavier (WCAG 2.1.1) : même motif
           que le comparatif de la page d'accueil. */
        // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
        <div className="tableau" tabIndex={0} role="region" aria-label="Liste des contrats">
          <table>
            <caption className="visuellement-masque">Liste des contrats</caption>
            <thead>
              <tr>
                <th scope="col">Contrat</th>
                <th scope="col">Entreprise</th>
                <th scope="col">Intérimaire</th>
                <th scope="col">Généré le</th>
                <th scope="col">Statut</th>
              </tr>
            </thead>
            <tbody>
              {contrats.map((contrat) => (
                <tr key={contrat.id}>
                  <th scope="row">
                    <Link href={`/admin/contrats/${contrat.id}`}>
                      {TYPE_LIBELLE[contrat.type]} — {contrat.posteLabel}
                    </Link>
                  </th>
                  <td>{contrat.companyName}</td>
                  <td>{contrat.workerName ?? 'Non retenu'}</td>
                  <td>
                    <time dateTime={contrat.generatedAt}>{formatDate(contrat.generatedAt)}</time>
                  </td>
                  <td>
                    {contrat.completedAt ? (
                      <span className="badge badge--verifie">Signé</span>
                    ) : (
                      <span className="badge">En attente</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
