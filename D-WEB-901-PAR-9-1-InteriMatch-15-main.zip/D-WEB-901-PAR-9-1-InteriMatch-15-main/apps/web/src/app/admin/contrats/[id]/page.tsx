import type { Metadata } from 'next';
import Link from 'next/link';
import { serverGetOrRedirect } from '../../../../lib/session';

type ContratType = 'MISSION' | 'MISE_A_DISPOSITION';
type Party = 'CADANS' | 'INTERIMAIRE' | 'ENTREPRISE';

interface ContratDetail {
  id: string;
  type: ContratType;
  posteLabel: string;
  companyName: string;
  workerName: string | null;
  generatedAt: string;
  completedAt: string | null;
  signatures: { party: Party; typedName: string; signedAt: string }[];
}

const TYPE_LIBELLE: Record<ContratType, string> = {
  MISSION: 'Contrat de mission',
  MISE_A_DISPOSITION: 'Mise à disposition',
};

const PARTY_LIBELLE: Record<Party, string> = {
  CADANS: 'CADANS',
  INTERIMAIRE: 'Intérimaire',
  ENTREPRISE: 'Entreprise',
};

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const contrat = await serverGetOrRedirect<ContratDetail>(`/admin/contrats/${id}`);
  return {
    title: `${TYPE_LIBELLE[contrat.type]} — ${contrat.posteLabel}`,
    robots: { index: false, follow: false },
  };
}

export default async function AdminContratPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const contrat = await serverGetOrRedirect<ContratDetail>(`/admin/contrats/${id}`);

  // Chaque contrat porte EXACTEMENT deux signatures (contracts.service.ts) : CADANS, qui
  // signe automatiquement à la génération, et une seule autre partie selon le type — jamais
  // les deux. Afficher l'entreprise sur un contrat de mission (ou l'inverse) créerait une
  // ligne « en attente » qui ne se remplira jamais, personne n'étant censé la signer.
  const autrePartie: Party = contrat.type === 'MISSION' ? 'INTERIMAIRE' : 'ENTREPRISE';
  const parties: Party[] = ['CADANS', autrePartie];

  return (
    <main>
      <p className="fil-retour">
        <Link href="/admin/contrats">Contrats</Link> › {TYPE_LIBELLE[contrat.type]}
      </p>

      <h1>
        {TYPE_LIBELLE[contrat.type]} — {contrat.posteLabel}
      </h1>
      <p className="accroche">
        {contrat.companyName}
        {contrat.workerName && <> · {contrat.workerName}</>}
      </p>

      <div className="carte">
        <dl className="carte-mission__details">
          <div>
            <dt>Généré le</dt>
            <dd>
              <time dateTime={contrat.generatedAt}>{formatDate(contrat.generatedAt)}</time>
            </dd>
          </div>
          <div>
            <dt>Statut</dt>
            <dd>
              {contrat.completedAt ? (
                <span className="badge badge--verifie">Signé par les deux parties</span>
              ) : (
                <span className="badge">Signature incomplète</span>
              )}
            </dd>
          </div>
        </dl>
      </div>

      <section className="section-admin">
        <h2>Signatures</h2>
        <ul className="liste-simple">
          {parties.map((party) => {
            const signature = contrat.signatures.find((s) => s.party === party);
            return (
              <li key={party}>
                <strong>{PARTY_LIBELLE[party]}</strong>
                {' — '}
                {signature ? (
                  <>
                    <span className="badge badge--verifie">Signé</span> par {signature.typedName}
                    {' le '}
                    <time dateTime={signature.signedAt}>{formatDate(signature.signedAt)}</time>
                  </>
                ) : (
                  <span className="badge">En attente</span>
                )}
              </li>
            );
          })}
        </ul>
      </section>
    </main>
  );
}
