import type { Metadata } from 'next';
import { DecisionJustificatif } from '../../../components/admin/DecisionJustificatif';
import Link from 'next/link';
import { certificationLabel } from '../../../lib/certifications';
import { estExpiree } from '../../../lib/habilitations';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Justificatifs à vérifier',
  robots: { index: false, follow: false },
};

type StatutVerification = 'NON_VERIFIE' | 'EN_ATTENTE' | 'VERIFIE' | 'REFUSE';

interface DecisionRow {
  decision: StatutVerification;
  motif: string | null;
  decidedAt: string;
  agent: string | null;
}

interface JustificatifRow {
  certificationId: string;
  type: string;
  expiresAt: string | null;
  verificationStatus: StatutVerification;
  refusalMotif: string | null;
  deposeLe: string;
  interimaire: { prenom: string; nom: string; ville: string };
  documentPresent: boolean;
  decisions: DecisionRow[];
}

// Les cinq filtres, dans l'ordre de travail : ce qui attend d'abord, l'issue ensuite, la
// péremption, puis tout. `EXPIREES` et `TOUS` ne sont pas des statuts — une habilitation
// expirée peut être vérifiée, en attente ou refusée.
const FILTRES = [
  { valeur: 'EN_ATTENTE', libelle: 'En attente' },
  { valeur: 'VERIFIE', libelle: 'Vérifiés' },
  { valeur: 'REFUSE', libelle: 'Refusés' },
  { valeur: 'EXPIREES', libelle: 'Expirées' },
  { valeur: 'TOUS', libelle: 'Tous' },
] as const;

type Filtre = (typeof FILTRES)[number]['valeur'];

const STATUTS: Record<StatutVerification, { libelle: string; classe: string }> = {
  NON_VERIFIE: { libelle: 'Non vérifié', classe: 'badge' },
  EN_ATTENTE: { libelle: 'En attente', classe: 'badge' },
  VERIFIE: { libelle: 'Vérifié', classe: 'badge badge--verifie' },
  REFUSE: { libelle: 'Refusé', classe: 'badge badge--refuse' },
};

// Ce que dit l'en-tête selon le filtre : « en attente d'examen » est faux sur « Refusés ».
const ACCROCHES: Record<Filtre, (n: number) => string> = {
  EN_ATTENTE: (n) =>
    `${n} justificatif${n > 1 ? 's' : ''} en attente d’examen, du plus ancien au plus récent.`,
  VERIFIE: (n) => `${n} habilitation${n > 1 ? 's' : ''} vérifiée${n > 1 ? 's' : ''}.`,
  REFUSE: (n) => `${n} habilitation${n > 1 ? 's' : ''} refusée${n > 1 ? 's' : ''}.`,
  EXPIREES: (n) =>
    `${n} habilitation${n > 1 ? 's' : ''} dont la date est passée, tous statuts confondus.`,
  // Pas « avec justificatif » : cette vue inclut justement celles qui n'en ont pas, c'est la
  // seule où elles apparaissent.
  TOUS: (n) =>
    `${n} habilitation${n > 1 ? 's' : ''}, tous statuts confondus, avec ou sans justificatif.`,
};

const VIDE: Record<Filtre, string> = {
  EN_ATTENTE: 'Les justificatifs déposés par les intérimaires apparaissent ici dès leur envoi.',
  VERIFIE: 'Aucune habilitation n’a encore été validée.',
  REFUSE: 'Aucune habilitation n’a été refusée.',
  EXPIREES: 'Aucune habilitation n’a dépassé sa date d’expiration.',
  TOUS: 'Aucune habilitation n’a encore été déposée.',
};

// URL de l'API, lue côté serveur : le lien vers le document part directement vers l'API,
// qui vérifie le rôle et déchiffre à la volée. Rien n'est recopié sur le site.
function apiUrl(chemin: string): string {
  return `${process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? ''}${chemin}`;
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

/**
 * Le filtre vit dans l'URL (`?statut=`) et non dans un état React : la page reste rendue
 * côté serveur, chaque filtre a son adresse partageable, et le retour arrière du navigateur
 * fonctionne. Des onglets en JavaScript auraient forcé un rendu client sur un écran qui lit
 * des données sensibles.
 */
export default async function JustificatifsPage({
  searchParams,
}: {
  searchParams: Promise<{ statut?: string }>;
}) {
  const { statut } = await searchParams;
  const filtre: Filtre = FILTRES.some((f) => f.valeur === statut)
    ? (statut as Filtre)
    : 'EN_ATTENTE';
  const justificatifs = await serverGetOrRedirect<JustificatifRow[]>(
    `/admin/justificatifs?statut=${filtre}`,
  );

  return (
    <main>
      <h1>Justificatifs à vérifier</h1>
      <p className="accroche">
        {justificatifs.length > 0
          ? ACCROCHES[filtre](justificatifs.length)
          : 'Aucune habilitation dans cette vue.'}
      </p>

      {/* Un groupe de liens, pas des boutons : chaque filtre est une page. `aria-current`
          signale celui qui est affiché aux technologies d'assistance (RGAA 12.11). */}
      <nav className="filtres" aria-label="Filtrer les habilitations">
        {FILTRES.map((option) => (
          <Link
            key={option.valeur}
            href={`/admin/justificatifs?statut=${option.valeur}`}
            className={`filtre${option.valeur === filtre ? ' filtre--actif' : ''}`}
            aria-current={option.valeur === filtre ? 'page' : undefined}
          >
            {option.libelle}
          </Link>
        ))}
      </nav>

      {justificatifs.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>Rien à afficher.</strong>
          </p>
          <p className="etat-vide__texte">{VIDE[filtre]}</p>
        </div>
      ) : (
        <ul className="liste-justificatifs">
          {justificatifs.map((justificatif) => {
            const libelle = `${certificationLabel(justificatif.type)} de ${justificatif.interimaire.prenom} ${justificatif.interimaire.nom}`;

            return (
              <li key={justificatif.certificationId} className="carte justificatif">
                <div className="justificatif__entete">
                  <h2 className="justificatif__titre">
                    {justificatif.interimaire.prenom} {justificatif.interimaire.nom}
                  </h2>
                  {/* Le statut courant se voit sur chaque fiche, et plus seulement par le
                      filtre choisi : sur « Tous » ou « Expirées », la liste mélange les
                      quatre états. */}
                  <span className="habilitation__badges">
                    <span className="badge">{certificationLabel(justificatif.type)}</span>
                    <span className={STATUTS[justificatif.verificationStatus].classe}>
                      {STATUTS[justificatif.verificationStatus].libelle}
                    </span>
                  </span>
                </div>

                <dl className="justificatif__details">
                  <dt>Commune</dt>
                  <dd>{justificatif.interimaire.ville}</dd>

                  <dt>Expire le</dt>
                  {/* Un justificatif peut arriver dans la file DÉJÀ expiré : l'intérimaire a
                      saisi une date passée, ou le document a attendu. Sans cette mention,
                      l'agent validerait une pièce qui ne couvre plus rien. */}
                  <dd>
                    {justificatif.expiresAt ? (
                      <>
                        {formatDate(`${justificatif.expiresAt}T00:00:00Z`)}
                        {estExpiree(justificatif.expiresAt) && (
                          <>
                            {' '}
                            <span className="badge badge--expiree">Expirée</span>
                          </>
                        )}
                      </>
                    ) : (
                      'Non renseignée'
                    )}
                  </dd>

                  <dt>Déposé le</dt>
                  <dd>
                    <time dateTime={justificatif.deposeLe}>
                      {formatDate(justificatif.deposeLe)}
                    </time>
                  </dd>
                </dl>

                {/* Le document n'a pas d'URL publique : ce lien vise l'API, qui exige le rôle
                    agent, déchiffre à la volée et interdit toute mise en cache. Nouvel onglet
                    pour ne pas perdre la file d'attente en cours d'examen. */}
                {justificatif.documentPresent ? (
                  <p className="justificatif__lien">
                    <a
                      href={apiUrl(`/admin/justificatifs/${justificatif.certificationId}/document`)}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Ouvrir le justificatif (nouvelle fenêtre)
                      <span className="visuellement-masque"> — {libelle}</span>
                    </a>
                  </p>
                ) : (
                  /* Sans pièce en base. Le cas COURANT est une habilitation déclarée sans
                     justificatif : elle n'apparaissait sur aucun écran agent, alors qu'elle
                     compte déjà dans le matching. Le second cas — une pièce disparue après
                     une décision — ne se produit pas aujourd'hui (supprimer une habilitation
                     supprime la ligne entière), mais le message reste juste s'il survenait. */
                  <p className="justificatif__absent">
                    {justificatif.verificationStatus === 'NON_VERIFIE' ? (
                      <>
                        <strong>Déclarée sans justificatif.</strong> L’intérimaire l’a saisie sans
                        déposer de pièce : elle compte déjà dans le matching, mais il n’y a rien à
                        examiner.
                      </>
                    ) : (
                      <>
                        <strong>Justificatif absent.</strong> La décision ci-dessous reste celle qui
                        s’applique ; il n’y a plus de pièce à rouvrir.
                      </>
                    )}
                  </p>
                )}

                {justificatif.decisions.length > 0 && (
                  <details className="historique">
                    <summary>Historique des décisions ({justificatif.decisions.length})</summary>
                    <ol className="historique__liste">
                      {justificatif.decisions.map((decision) => (
                        <li key={decision.decidedAt} className="historique__ligne">
                          <span className={STATUTS[decision.decision].classe}>
                            {STATUTS[decision.decision].libelle}
                          </span>
                          <span className="historique__date">
                            <time dateTime={decision.decidedAt}>
                              {formatDate(decision.decidedAt)}
                            </time>
                            {' · '}
                            {/* Compte d'agent supprimé : on perd l'auteur, jamais la
                                décision. Le dire vaut mieux qu'une ligne sans nom. */}
                            {decision.agent ?? 'agent supprimé'}
                          </span>
                          {decision.motif && (
                            <span className="historique__motif">« {decision.motif} »</span>
                          )}
                        </li>
                      ))}
                    </ol>
                  </details>
                )}

                {/* La décision reste modifiable à tout moment, quel que soit le statut
                    courant : l'API n'a jamais vérifié l'état de départ, et un agent doit
                    pouvoir revenir sur un refus. Chaque clic ajoute une ligne d'historique. */}
                {justificatif.documentPresent && (
                  <DecisionJustificatif
                    certificationId={justificatif.certificationId}
                    libelle={libelle}
                  />
                )}
              </li>
            );
          })}
        </ul>
      )}
    </main>
  );
}
