import type { Metadata } from 'next';
import Link from 'next/link';
import { Logo } from '../../components/Logo';

export const metadata: Metadata = {
  title: 'Le bon profil, à l’heure, demain matin',
  description:
    'Agence d’intérim en ligne spécialisée en logistique d’entrepôt : préparation de ' +
    'commandes, conduite de chariots, manutention, gestion de stock. CACES vérifiés, ' +
    'contrats établis par CADANS.',
};

// Chiffres figés et sourcés, pas d'appel d'API : ce sont des repères de marché, ils bougent
// une fois par trimestre. Les brancher sur France Travail ferait dépendre la page d'accueil
// d'un service externe pour une information qui ne change pas d'un jour à l'autre.
const CHIFFRES = [
  {
    valeur: '694 800',
    libelle: 'intérimaires en France, fin juin 2026',
    source: 'DARES, 2026',
  },
  {
    valeur: '24 %',
    libelle:
      'de recours à l’intérim dans l’entreposage et la manutention, contre 3 % pour l’ensemble de l’économie',
    source: 'SDES, 2015',
  },
];

const BENEFICES = [
  {
    titre: 'Matching automatique',
    texte:
      'Vous publiez la mission, la plateforme classe les profils. Pas de tri manuel, pas de CV à éplucher.',
  },
  {
    titre: 'CACES vérifiés',
    texte:
      'Chaque habilitation est déposée avec sa date d’expiration. Un CACES périmé ne compte plus : le profil ne remonte pas sur les missions qui l’exigent.',
  },
  {
    titre: 'Des missions près de chez soi',
    texte:
      'L’intérimaire renseigne sa ville dès l’inscription. Le département compte dans le score : on ne propose pas Roissy à quelqu’un de Lyon.',
  },
  {
    titre: 'Contrats établis par CADANS',
    texte:
      'Employeur de l’intérimaire, CADANS établit le contrat de mission et le contrat de mise à disposition dès que la mission est pourvue.',
  },
];

const COMPARATIF = [
  {
    critere: 'Mise en relation',
    cadans: 'Les profils qualifiés remontent dès la publication de la mission.',
    agence: 'Un chargé de recrutement rappelle, puis cherche dans son vivier.',
  },
  {
    critere: 'Habilitations',
    cadans: 'CACES déposé, daté, contrôlé à chaque calcul de matching.',
    agence: 'Vérification à la prise de poste, souvent déclarative.',
  },
  {
    critere: 'Périmètre',
    cadans: 'Logistique d’entrepôt uniquement : cariste, préparation de commandes, quai.',
    agence: 'Tous secteurs : la logistique est une ligne parmi d’autres.',
  },
  {
    critere: 'Visibilité côté intérimaire',
    cadans:
      'Il voit les missions auxquelles il peut prétendre, et ce qui lui manque pour les autres.',
    agence: 'Il attend un appel.',
  },
];

const ETAPES = [
  {
    numero: '01',
    titre: 'Inscription',
    texte:
      'Entreprise ou intérimaire, même formulaire d’entrée. L’intérimaire ajoute ses CACES, ses créneaux et ses compétences — chaque étape peut attendre.',
  },
  {
    numero: '02',
    titre: 'Matching',
    texte:
      'Filtrage bloquant sur les habilitations exigées, puis score sur les compétences et le département. Un profil sans le CACES requis ne remonte jamais.',
  },
  {
    numero: '03',
    titre: 'Mission',
    texte:
      'L’entreprise retient un profil, le contrat est généré et envoyé. La mission passe de « Ouverte » à « Pourvue ».',
  },
];

// Page rendue côté serveur par défaut (App Router, pas de directive "use client").
export default function AccueilPage() {
  return (
    <>
      <main className="accueil">
        {/* --- Hero -------------------------------------------------------
            Pleine largeur et colonne unique : a 160 px, le titre a besoin de toute la
            colonne. Dans une grille a deux colonnes il tombait sur quatre lignes et
            repoussait les boutons sous la ligne de flottaison. */}
        <section className="hero conteneur">
          <p className="sur-titre">Logistique d’entrepôt · France</p>
          <h1 className="display hero__titre">Le bon profil, à l’heure, demain matin.</h1>
          <p className="accroche hero__accroche">
            CADANS est une agence d’intérim en ligne : nous employons l’intérimaire et le mettons à
            disposition des entrepôts en tension de personnel. Matching automatisé, CACES vérifiés,
            contrats établis par nos soins.
          </p>
          <p className="hero__cta">
            <Link href="/inscription" className="bouton bouton--principal">
              Je recrute
            </Link>
            <Link href="/inscription" className="bouton bouton--secondaire">
              Je cherche une mission
            </Link>
          </p>
        </section>

        {/* --- Chiffres de marché ----------------------------------------- */}
        <section className="section conteneur" aria-labelledby="marche">
          <h2 id="marche" className="visuellement-masque">
            Le marché de l’intérim logistique
          </h2>
          <dl className="chiffres">
            {CHIFFRES.map((chiffre) => (
              <div key={chiffre.libelle} className="chiffre">
                <dt className="visuellement-masque">{chiffre.libelle}</dt>
                <dd className="chiffre__valeur">{chiffre.valeur}</dd>
                <dd className="chiffre__libelle" aria-hidden="true">
                  {chiffre.libelle}
                </dd>
                <dd className="chiffre__source mono">Source : {chiffre.source}</dd>
              </div>
            ))}
          </dl>
        </section>

        {/* --- Bénéfices --------------------------------------------------- */}
        <section className="section conteneur" aria-labelledby="benefices">
          <p className="sur-titre">Ce que la plateforme fait</p>
          <h2 id="benefices">Quatre choses, faites correctement.</h2>
          <ul className="grille-benefices">
            {BENEFICES.map((benefice) => (
              <li key={benefice.titre} className="carte">
                <h3>{benefice.titre}</h3>
                <p className="carte__texte">{benefice.texte}</p>
              </li>
            ))}
          </ul>
        </section>

        {/* --- Comparatif --------------------------------------------------
            Un vrai tableau : les données se comparent ligne à ligne, et un lecteur d'écran
            annonce l'en-tête de colonne avec chaque cellule. Sur téléphone, il défile
            horizontalement plutôt que de casser la page. */}
        <section className="section conteneur" aria-labelledby="comparatif">
          <p className="sur-titre">Ce qui change</p>
          <h2 id="comparatif">CADANS et une agence généraliste</h2>
          {/* Sous 800 px le tableau defile horizontalement dans son conteneur plutot que de
              casser la page. Une zone qui defile doit pouvoir etre atteinte au clavier :
              d'ou tabIndex et le role de region nomme (WCAG 2.1.1).

              jsx-a11y/no-noninteractive-tabindex est ici un faux positif connu : la regle
              interdit tabIndex sur un element non interactif, alors que WCAG 2.1.1 et la
              regle axe « scrollable-region-focusable » l'exigent justement pour une zone qui
              defile. Les deux ne peuvent pas etre satisfaites en meme temps ; on suit WCAG. */}
          {/* eslint-disable jsx-a11y/no-noninteractive-tabindex */}
          <div
            className="tableau"
            tabIndex={0}
            role="region"
            aria-label="Comparatif CADANS et agence d’intérim généraliste"
          >
            {/* eslint-enable jsx-a11y/no-noninteractive-tabindex */}
            <table>
              <caption>
                Comparaison sur les quatre points qui pèsent le plus sur le délai de mise en
                relation.
              </caption>
              <thead>
                <tr>
                  <th scope="col">Critère</th>
                  <th scope="col">CADANS</th>
                  <th scope="col">Agence d’intérim généraliste</th>
                </tr>
              </thead>
              <tbody>
                {COMPARATIF.map((ligne) => (
                  <tr key={ligne.critere}>
                    <th scope="row">{ligne.critere}</th>
                    <td>{ligne.cadans}</td>
                    <td>{ligne.agence}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* --- Comment ça marche -------------------------------------------- */}
        <section className="section conteneur" aria-labelledby="comment-ca-marche">
          <p className="sur-titre">En trois temps</p>
          <h2 id="comment-ca-marche">Comment ça marche</h2>
          <ol className="etapes__liste">
            {ETAPES.map((etape) => (
              <li key={etape.numero} className="carte etape">
                <span className="etape__numero mono" aria-hidden="true">
                  {etape.numero}
                </span>
                <h3>{etape.titre}</h3>
                <p className="carte__texte">{etape.texte}</p>
              </li>
            ))}
          </ol>
        </section>

        {/* --- Tendances du marché ------------------------------------------
            Emplacement réservé, volontairement vide. Les tendances viendraient des offres
            France Travail ; la page est sortie du périmètre au gel du 22/09 (décision
            d'équipe, pas une question de mise en page). Mieux vaut un encart qui dit ce qu'il
            attend qu'un faux graphique. */}
        <section className="section conteneur" aria-labelledby="tendances">
          <div className="etat-vide">
            <p className="sur-titre">Bientôt</p>
            <h2 id="tendances" className="etat-vide__titre">
              Tendances du marché
            </h2>
            <p className="etat-vide__texte">
              Les métiers qui recrutent, les CACES les plus demandés et les rémunérations
              constatées, à partir des offres publiées sur France Travail. En cours de construction.
            </p>
            <Link href="/inscription" className="bouton bouton--secondaire">
              Créer un compte en attendant
            </Link>
          </div>
        </section>

        {/* --- Appel à l'action final ---------------------------------------- */}
        <section className="section conteneur">
          <div className="cta-final">
            <h2>Votre prochaine équipe de quai est déjà inscrite.</h2>
            <p className="accroche">
              Publier une mission prend deux minutes. Créer un profil, autant.
            </p>
            <p className="hero__cta">
              <Link href="/inscription" className="bouton bouton--principal">
                Je recrute
              </Link>
              <Link href="/inscription" className="bouton bouton--secondaire">
                Je cherche une mission
              </Link>
            </p>
          </div>
        </section>
      </main>

      <footer className="pied-de-page">
        <div className="conteneur pied-de-page__grille">
          <p className="pied-de-page__mention">
            <Logo taille={1.125} />
            <span>POC 11 jours · Epitech D-WEB-901</span>
          </p>
          <nav className="pied-de-page__liens" aria-label="Liens de pied de page">
            <Link href="/qui-sommes-nous">Qui sommes-nous</Link>
            <Link href="/politique-de-confidentialite">Politique de confidentialité</Link>
            <Link href="/mentions-legales">Mentions légales</Link>
            {/* Page non écrite : du texte, pas un lien mort. */}
            <span className="pied-de-page__a-venir">Plan du site (à venir)</span>
          </nav>
        </div>
      </footer>
    </>
  );
}
