import type { Metadata } from 'next';
import Link from 'next/link';

// Boîte de l'équipe, à créer puis à reporter ici : c'est le seul endroit où l'adresse est
// écrite. Une politique de confidentialité sans moyen de contact ne permet pas d'exercer
// ses droits, donc ne vaut rien.
const CONTACT = 'confidentialite.cadans@gmail.com';

// Date de la dernière révision : le RGPD impose de pouvoir dater la version en vigueur.
const DERNIERE_MISE_A_JOUR = '23 septembre 2026';

export const metadata: Metadata = {
  title: 'Politique de confidentialité',
  description:
    'Quelles données CADANS collecte, pourquoi, combien de temps elles sont conservées, ' +
    'comment elles sont protégées et comment exercer vos droits RGPD.',
};

export default function PolitiqueConfidentialitePage() {
  return (
    <main className="page-legale">
      <div className="conteneur page-legale__contenu">
        <h1>Politique de confidentialité</h1>
        <p className="page-legale__date">Dernière mise à jour : {DERNIERE_MISE_A_JOUR}</p>

        <p>
          CADANS est une <strong>agence d’intérim</strong> spécialisée en logistique d’entrepôt.
          Cette page explique quelles données nous collectons, pourquoi, combien de temps nous les
          conservons et comment exercer vos droits.
        </p>

        <h2>1. Responsable du traitement</h2>
        <p>
          <strong>CADANS est responsable du traitement</strong> de l’ensemble des données collectées
          sur ce site. En tant qu’<strong>entreprise de travail temporaire</strong>, CADANS est l’
          <strong>employeur de l’intérimaire</strong> : elle traite ses données à ce titre, et non
          comme un simple intermédiaire.
        </p>
        <p>
          Les entreprises clientes ne sont ni responsables conjointes, ni sous-traitantes : ce sont
          des <strong>destinataires</strong>, qui ne reçoivent que ce qui leur est nécessaire pour
          décider d’une mise à disposition (voir le point 5).
        </p>
        <p>
          Pour toute question ou demande : <a href={`mailto:${CONTACT}`}>{CONTACT}</a>. CADANS est
          un projet pédagogique réalisé dans le cadre du cursus Epitech (D-WEB-901) ; ses
          identifiants d’entreprise figurent dans les{' '}
          <Link href="/mentions-legales">mentions légales</Link>.
        </p>

        <h2>2. Données collectées</h2>
        <p>Nous collectons uniquement les données nécessaires à la mise en relation :</p>
        <ul>
          <li>
            <strong>Compte</strong> : adresse email, mot de passe, type de compte (entreprise ou
            intérimaire).
          </li>
          <li>
            <strong>Entreprise</strong> : raison sociale, SIRET, code NAF, nom et prénom du contact,
            téléphone, adresse.
          </li>
          <li>
            <strong>Intérimaire</strong> : nom, prénom, téléphone, ville et code postal.
          </li>
          <li>
            <strong>Habilitations</strong> : type de CACES ou d’habilitation, date d’expiration,
            numéro et scan du certificat.
          </li>
          <li>
            <strong>Pièce d’identité</strong> : carte d’identité, passeport ou titre de séjour.
          </li>
          <li>
            <strong>Informations d’embauche</strong> : date et lieu de naissance, nationalité,
            adresse postale, numéro de sécurité sociale (NIR) et IBAN. Elles ne sont demandées qu’
            <strong>une fois l’intérimaire retenu sur une mission</strong>, jamais à l’inscription.
          </li>
          <li>
            <strong>Connexion</strong> : cookie de session, jetons de réinitialisation de mot de
            passe.
          </li>
        </ul>

        <h2>3. Finalités et bases légales</h2>
        <p>
          Les données de compte, de profil et d’habilitation sont traitées pour{' '}
          <strong>exécuter le contrat</strong> qui nous lie à vous : contrat de mission pour
          l’intérimaire, contrat de mise à disposition pour l’entreprise cliente.
        </p>
        <p>
          La vérification des habilitations, la conservation de la pièce d’identité et
          l’établissement des contrats relèvent en outre d’une <strong>obligation légale</strong>{' '}
          pesant sur l’entreprise de travail temporaire : Code du travail sur le travail temporaire,
          et obligations de sécurité attachées à la conduite d’engins.
        </p>
        <p>
          Les <strong>informations d’embauche</strong> relèvent des deux bases à la fois. L’état
          civil, l’adresse et l’IBAN sont nécessaires à l’
          <strong>exécution de votre contrat de travail</strong> : sans eux, ni contrat de mission,
          ni bulletin de paie, ni versement de salaire. Le{' '}
          <strong>numéro de sécurité sociale</strong> répond à une{' '}
          <strong>obligation légale</strong> distincte : il identifie le salarié auprès des
          organismes sociaux (déclaration préalable à l’embauche, déclaration sociale nominative).
          Son usage est strictement limité à cette finalité ; il ne sert ni au matching, ni à aucun
          rapprochement de fichiers.
        </p>
        <p>Vos données ne sont ni vendues, ni louées, ni utilisées à des fins publicitaires.</p>

        <h2>4. Durées de conservation</h2>
        <ul>
          <li>
            <strong>Compte et profil</strong> : supprimés un an après votre dernière connexion.
          </li>
          <li>
            <strong>Pièce d’identité</strong> : supprimée à la fin de la mission concernée, et au
            plus tard un an après son dépôt.
          </li>
          <li>
            <strong>Justificatifs d’habilitation</strong> (scan du CACES déposé pour vérification) :
            conservés <strong>jusqu’à l’expiration de l’habilitation</strong>, et au plus tard un an
            après la fin de la dernière mission qui l’exigeait. Passé ce délai, seuls le type
            d’habilitation, sa date d’expiration et le résultat de la vérification sont conservés —
            le document lui-même est supprimé.
          </li>
          <li>
            <strong>Habilitations, missions et candidatures</strong> : conservées tant que votre
            compte existe. Vous pouvez supprimer une habilitation à tout moment.
          </li>
          <li>
            <strong>Registre des décisions de vérification</strong> (qui a validé ou refusé une
            habilitation, quand, et pour quel motif) : conservé <strong>cinq ans</strong> à compter
            de la décision, comme les contrats qu’il permet de justifier.{' '}
            <strong>Il subsiste même si vous supprimez l’habilitation concernée</strong> : c’est la
            trace des contrôles que nous avons effectués, et elle nous engage. Elle ne contient ni
            votre document, ni votre numéro de certificat, ni votre identité en clair — seulement un
            identifiant de compte, le type d’habilitation, la décision, son motif et sa date.
          </li>
          <li>
            <strong>Contrats de mission et de mise à disposition</strong> : conservés{' '}
            <strong>cinq ans</strong> à compter de la fin de la mission, durée de droit commun de la
            prescription en matière contractuelle. Ils ne peuvent pas être supprimés à la demande :
            ce sont des pièces qui nous engagent, et qui vous protègent.
          </li>
          <li>
            <strong>Informations d’embauche</strong> : conservées{' '}
            <strong>cinq ans après la fin de votre dernière mission</strong>, comme les contrats
            qu’elles servent à établir et les pièces de paie qui en découlent. Elles suivent le sort
            du contrat parce qu’elles en font partie : un bulletin de paie sans le numéro de
            sécurité sociale du salarié n’est pas un bulletin de paie. Au-delà, elles sont
            supprimées.
          </li>
          <li>
            <strong>Cookie de session</strong> : huit heures, ou jusqu’à votre déconnexion.
          </li>
          <li>
            <strong>Jeton de réinitialisation de mot de passe</strong> : trente minutes, et un seul
            usage.
          </li>
        </ul>

        <h2>5. Destinataires</h2>
        <p>
          Vos données sont accessibles aux <strong>agents CADANS</strong> habilités : pour vérifier
          un justificatif d’habilitation, et pour consulter votre fiche depuis l’annuaire de
          l’agence — identité, coordonnées (email, téléphone, adresse), habilitations et leur
          statut, compétences déclarées, missions et contrats. CADANS est votre employeur : ses
          agents doivent pouvoir vous joindre. Cet annuaire ne donne accès ni à votre pièce
          d’identité, ni à vos informations d’embauche (numéro de sécurité sociale, IBAN), ni au
          contenu des contrats.
        </p>
        <p>
          Elles sont aussi accessibles à nos prestataires techniques : Render (hébergement de
          l’application), Neon (base de données), MongoDB Atlas (journaux techniques), Resend et
          Gmail (envoi des emails). Ils agissent sur nos instructions et n’utilisent pas vos données
          pour leur compte.
        </p>
        <p>
          L’<strong>entreprise cliente</strong> ne reçoit, avant décision, que ce qui lui est
          nécessaire : nom et prénom du candidat, habilitations valides et commune. Ni son adresse
          email, ni son téléphone, ni sa pièce d’identité, ni le scan de ses habilitations ne lui
          sont transmis. Vos <strong>informations d’embauche</strong> — état civil, adresse, numéro
          de sécurité sociale, IBAN — ne lui sont <strong>jamais</strong> transmises : elles
          concernent votre contrat de travail avec CADANS, pas la mise à disposition.
        </p>
        <p>
          Les données publiques de France Travail alimentent la liste des métiers et des compétences
          proposés. Aucune donnée vous concernant ne leur est transmise.
        </p>

        <h2>6. Sécurité</h2>
        <ul>
          <li>Les mots de passe sont hachés avec argon2id et ne sont jamais lisibles.</li>
          <li>
            Les pièces d’identité, les habilitations, le numéro de sécurité sociale et l’IBAN sont
            chiffrés (AES-256-GCM) avant d’être enregistrés.
          </li>
          <li>
            Le numéro de sécurité sociale et l’IBAN ne sont{' '}
            <strong>jamais réaffichés en entier</strong>, pas même à vous : seuls leurs quatre
            derniers caractères apparaissent à l’écran, le temps que vous reconnaissiez ce que vous
            avez saisi.
          </li>
          <li>Les échanges avec la plateforme sont chiffrés en HTTPS.</li>
          <li>
            Chaque utilisateur n’accède qu’à ses propres documents : une entreprise ne voit jamais
            la pièce d’identité d’un intérimaire.
          </li>
        </ul>

        <h2>7. Traitement automatisé</h2>
        <p>
          Notre algorithme de matching présente aux entreprises les profils correspondant à une
          mission et écarte automatiquement ceux qui ne disposent pas de l’habilitation obligatoire
          exigée. Ce tri ne constitue pas une décision d’embauche : celle-ci est prise par une
          personne, chez l’entreprise. Vous pouvez nous écrire pour contester un résultat.
        </p>

        <h2>8. Cookies</h2>
        <p>
          CADANS dépose un seul cookie, celui qui maintient votre session ouverte après la
          connexion. Strictement nécessaire au fonctionnement du site, il expire au bout de huit
          heures et n’est pas lisible par les scripts de la page. Aucun traceur publicitaire ni
          outil de mesure d’audience n’est utilisé : aucun consentement ne vous est donc demandé.
        </p>

        <h2>9. Vos droits</h2>
        <p>
          Conformément au RGPD, vous disposez d’un droit d’accès, de rectification, d’effacement, de
          limitation, d’opposition et de portabilité de vos données. Pour les exercer, écrivez à{' '}
          <a href={`mailto:${CONTACT}`}>{CONTACT}</a>. Nous répondons dans un délai d’un mois.
        </p>
        <p>
          Si notre réponse ne vous satisfait pas, vous pouvez introduire une réclamation auprès de
          la CNIL,{' '}
          <a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer">
            cnil.fr (nouvelle fenêtre)
          </a>
          .
        </p>
      </div>
    </main>
  );
}
