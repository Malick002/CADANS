import type { Metadata } from 'next';
import { Suspense } from 'react';
import { InscriptionFormulaire } from '../../../components/auth/InscriptionFormulaire';

export const metadata: Metadata = {
  title: 'Créer un compte',
  description:
    'Inscrivez-vous sur CADANS : entreprise de logistique d’entrepôt qui recrute, ou intérimaire ' +
    'cariste, préparateur de commandes ou manutentionnaire qui cherche des missions proches.',
};

// Page rendue côté serveur ; seul le sélecteur de profil et les formulaires sont interactifs.
// Le titre h1 vit dans InscriptionFormulaire, avec le badge de rôle qu'il met à jour.
export default function InscriptionPage() {
  return (
    <main className="page-auth">
      <div className="page-auth__fond">
        <div className="page-auth__carte page-auth__carte--large">
          {/* InscriptionFormulaire lit `?profil=` : la frontière Suspense permet de garder
              la page pré-rendue au lieu de la basculer en rendu à la demande. */}
          <Suspense fallback={null}>
            <InscriptionFormulaire />
          </Suspense>
        </div>
      </div>
    </main>
  );
}
