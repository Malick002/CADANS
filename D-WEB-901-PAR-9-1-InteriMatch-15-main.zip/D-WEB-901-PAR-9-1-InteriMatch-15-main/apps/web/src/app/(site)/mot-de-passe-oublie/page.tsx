import type { Metadata } from 'next';
import Link from 'next/link';
import { ForgotPasswordForm } from '../../../components/auth/ForgotPasswordForm';
import { Logo } from '../../../components/Logo';

export const metadata: Metadata = {
  title: 'Mot de passe oublié',
  description:
    'Recevez un lien pour choisir un nouveau mot de passe et retrouver l’accès à votre compte ' +
    'CADANS, entreprise ou intérimaire.',
};

// Page rendue côté serveur ; seul le formulaire est interactif (composant client).
// Même traitement en carte que la connexion et l'inscription : les quatre écrans
// d'authentification se ressemblent, et le contenu reste dans une colonne lisible.
export default function MotDePasseOubliePage() {
  return (
    <main className="page-auth">
      <div className="page-auth__fond">
        <div className="page-auth__carte">
          <p className="page-auth__logo">
            <Logo taille={1.125} />
          </p>

          <p className="fil-retour">
            <Link href="/connexion">Retour à la connexion</Link>
          </p>

          <h1>Mot de passe oublié</h1>
          <p className="accroche">
            Indiquez l’adresse email de votre compte : nous vous envoyons un lien pour en choisir un
            nouveau.
          </p>

          <ForgotPasswordForm />
        </div>
      </div>
    </main>
  );
}
