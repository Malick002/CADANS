import type { Metadata } from 'next';
import Link from 'next/link';
import { RappelMatches } from '../../../components/missions/RappelMatches';
import { certificationLabel } from '../../../lib/certifications';
import { shiftLabel } from '../../../lib/shifts';
import { tauxHoraire } from '../../../lib/montants';

export const metadata: Metadata = {
  title: 'Missions ouvertes',
  description:
    'Missions en logistique d’entrepôt actuellement ouvertes sur CADANS : cariste, ' +
    'préparateur de commandes, manutentionnaire.',
};

interface PublicMission {
  id: string;
  posteLabel: string;
  companyName: string;
  siteLabel: string;
  postalCode: string;
  startDate: string;
  endDate: string;
  shift: string;
  hourlyRate: string;
  requiredCertifications: string[];
}

function formatDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
  });
}

async function getOpenMissions(): Promise<PublicMission[]> {
  const base = process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? '';
  const response = await fetch(`${base}/missions/ouvertes`, { cache: 'no-store' });
  return response.ok ? response.json() : [];
}

// Page publique rendue côté serveur (SEO) : un seul h1, URL lisible, pas de JavaScript
// nécessaire pour la lire. Les titres des cartes sont des h2 — la hiérarchie de la page est
// lisible au lecteur d'écran comme au robot d'indexation.
export default async function MissionsPubliquesPage() {
  const missions = await getOpenMissions();

  return (
    <main className="page-missions">
      <header className="page-missions__entete">
        {/* « Toutes les offres » et non « Offres en cours » : le sur-titre est le premier
            endroit où dire que cette liste n'est filtrée par rien. Le h1 ne bouge pas — c'est
            lui que les moteurs indexent. */}
        <span className="sur-titre">Toutes les offres</span>
        <h1>Missions en logistique d’entrepôt</h1>
        <p className="accroche">
          {missions.length > 0
            ? `${missions.length} mission${missions.length > 1 ? 's' : ''} ouverte${missions.length > 1 ? 's' : ''} en ce moment, publiées par des entreprises qui recrutent en intérim. Cette liste n’est filtrée par rien : elle montre tout ce qui est ouvert.`
            : 'Aucune mission ouverte pour le moment.'}
        </p>
      </header>

      {/* Pour un intérimaire connecté seulement : cette liste n'est pas celle de ses matches.
          Composant client, pour que le HTML servi reste identique avec et sans cookie — c'est
          la page qu'un moteur indexe. Le raisonnement complet est dans RappelMatches. */}
      <RappelMatches />

      {missions.length === 0 ? (
        // État vide qui dit quoi faire, plutôt qu'une liste blanche : une page publique
        // sans offre est le premier écran que voit un visiteur arrivé hors saison.
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>Aucune mission n’est ouverte aujourd’hui.</strong>
          </p>
          <p className="etat-vide__texte">
            Créez votre compte intérimaire : dès qu’une mission correspond à vos habilitations et à
            votre zone, elle apparaît dans vos matches.
          </p>
          <Link href="/inscription" className="bouton bouton--principal">
            Créer un compte intérimaire
          </Link>
        </div>
      ) : (
        <ul className="cartes-mission-publiques">
          {missions.map((mission) => (
            <li key={mission.id} className="carte-mission">
              <div className="carte-mission__entete">
                <h2 className="carte-mission__titre">{mission.posteLabel}</h2>
                <span className="statut statut--ouverte">
                  <span className="statut__pastille" aria-hidden="true" />
                  Ouverte
                </span>
              </div>
              <p className="carte-mission__lieu">
                {mission.companyName} · {mission.siteLabel} · {mission.postalCode}
              </p>

              <dl className="carte-mission__details">
                <div>
                  <dt>Dates</dt>
                  <dd>
                    {formatDate(mission.startDate)} → {formatDate(mission.endDate)}
                  </dd>
                </div>
                <div>
                  <dt>Créneau</dt>
                  <dd>{shiftLabel(mission.shift)}</dd>
                </div>
                <div>
                  <dt>Rémunération</dt>
                  <dd>{tauxHoraire(mission.hourlyRate)} €/h</dd>
                </div>
              </dl>

              {/* Les habilitations exigées dès la liste : c'est le filtre bloquant du
                  matching, autant que le visiteur le sache avant d'ouvrir la fiche. */}
              {mission.requiredCertifications.length > 0 && (
                <ul className="carte-mission__tags" aria-label="Habilitations exigées">
                  {mission.requiredCertifications.map((certification) => (
                    <li key={certification}>{certificationLabel(certification)}</li>
                  ))}
                </ul>
              )}

              <Link
                href={`/missions/${mission.id}`}
                className="bouton bouton--principal carte-mission__cta"
              >
                Voir la mission
                <span className="visuellement-masque"> : {mission.posteLabel}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
