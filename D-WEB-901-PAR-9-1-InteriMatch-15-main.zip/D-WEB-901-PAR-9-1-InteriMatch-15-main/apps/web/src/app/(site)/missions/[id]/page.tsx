import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { PostulerButton } from '../../../../components/candidatures/PostulerButton';
import { certificationLabel } from '../../../../lib/certifications';
import { motifRecoursLabel } from '../../../../lib/motifs-recours';
import { getSessionAccount, serverGet } from '../../../../lib/session';
import { shiftLabel } from '../../../../lib/shifts';
import { tauxHoraire } from '../../../../lib/montants';

interface PublicMission {
  id: string;
  posteLabel: string;
  companyName: string;
  siteLabel: string;
  postalCode: string;
  startDate: string;
  endDate: string;
  shift: string;
  hourlyRate: string;
  description: string | null;
  requiredCertifications: string[];
  motifRecours: string;
  remplaceNom: string | null;
  status: 'OUVERTE' | 'POURVUE' | 'TERMINEE';
}

interface MatchRow {
  missionId: string;
  applied: boolean;
}

// `blocked` et `missingCertifications` ont disparu du contrat : une mission dont
// l'habilitation manque n'est plus renvoyée par /matches (filtrage bloquant). Sur cette page
// publique on ne peut donc pas savoir localement ce qui manque — c'est l'API qui refuse la
// candidature avec son message, affiché par PostulerButton.
interface MatchesResponse {
  matches: MatchRow[];
}

const STATUT_LIBELLE = {
  OUVERTE: 'Ouverte',
  POURVUE: 'Pourvue',
  TERMINEE: 'Terminée',
} as const;

const STATUT_CLASSE = {
  OUVERTE: 'statut--ouverte',
  POURVUE: 'statut--pourvue',
  TERMINEE: 'statut--terminee',
} as const;

function formatDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
  });
}

async function getMission(id: string): Promise<PublicMission | null> {
  const base = process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? '';
  const response = await fetch(`${base}/missions/${id}`, { cache: 'no-store' });
  return response.ok ? response.json() : null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}): Promise<Metadata> {
  const { id } = await params;
  const mission = await getMission(id);
  if (!mission) {
    return { title: 'Mission introuvable' };
  }
  return {
    title: `${mission.posteLabel} — ${mission.siteLabel}`,
    description: `Mission ${mission.posteLabel} chez ${mission.companyName}, ${mission.siteLabel}. ${formatDate(mission.startDate)} au ${formatDate(mission.endDate)}, ${tauxHoraire(mission.hourlyRate)} €/h.`,
    // La fiche reste accessible quand la mission n'est plus ouverte — une URL indexée ou
    // partagée ne doit pas devenir 404 — mais elle sort de l'index : proposer une offre
    // pourvue dans les résultats de recherche ferait perdre son temps au candidat.
    // `follow` reste vrai : les liens de la page (entreprise, autres missions) gardent leur
    // valeur.
    ...(mission.status !== 'OUVERTE' ? { robots: { index: false, follow: true } } : {}),
  };
}

export default async function MissionPubliquePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const mission = await getMission(id);
  if (!mission) {
    notFound();
  }

  const account = await getSessionAccount();

  // Le score exact n'a de sens que sur le dashboard des matches ; ici, on ne lit que ce qui
  // manque pour cette mission précise, en réutilisant la même liste plutôt qu'un nouvel appel.
  // Page publique : une session expirée entre-temps ne doit jamais empêcher d'afficher la
  // mission, seulement masquer la personnalisation (bandeau CACES, bouton Postuler).
  let match: MatchRow | undefined;
  if (account?.role === 'WORKER') {
    try {
      const { matches } = await serverGet<MatchesResponse>('/matches');
      match = matches.find((m) => m.missionId === mission.id);
    } catch {
      match = undefined;
    }
  }

  const ouverte = mission.status === 'OUVERTE';

  return (
    <main className="fiche-mission">
      <p className="fil-retour">
        <Link href="/missions">Missions</Link> › {mission.posteLabel}
      </p>

      {/* Un seul h1 sur la page, et c'est l'intitulé du poste : c'est lui que porte le
          `title` de la fiche, c'est lui que cherche le candidat. */}
      <header className="fiche-mission__entete">
        <span className={`statut ${STATUT_CLASSE[mission.status]}`}>
          <span className="statut__pastille" aria-hidden="true" />
          {STATUT_LIBELLE[mission.status]}
        </span>
        <h1>{mission.posteLabel}</h1>
        <p className="fiche-mission__lieu">
          {mission.companyName} · {mission.siteLabel} · {mission.postalCode}
        </p>
      </header>

      {/* Mission plus ouverte : l'information est portée par le TEXTE du bandeau et par le
          libellé du statut, jamais par la seule couleur (RGAA 4.1). Placé avant le détail :
          c'est la première chose à savoir, pas une note de bas de page. */}
      {!ouverte && (
        <div className="toast toast--danger avis-mission-close" role="status">
          <p className="toast__texte">
            <strong>Mission {STATUT_LIBELLE[mission.status].toLowerCase()}.</strong> Elle n’accepte
            plus de candidature. La page reste consultable, mais l’offre n’est plus à pourvoir.{' '}
            <Link href="/missions">Voir les missions ouvertes</Link>
          </p>
        </div>
      )}

      <div className="carte fiche-mission__carte">
        <dl className="carte-mission__details fiche-mission__details">
          <div>
            <dt>Dates</dt>
            <dd>
              {formatDate(mission.startDate)} → {formatDate(mission.endDate)}
            </dd>
          </div>
          <div>
            <dt>Créneau</dt>
            <dd>{shiftLabel(mission.shift)}</dd>
          </div>
          <div>
            <dt>Rémunération</dt>
            <dd>{tauxHoraire(mission.hourlyRate)} €/h</dd>
          </div>
          {/* Le motif du recours figure au contrat (art. L. 1251-43 1°) : l'afficher ici
              évite qu'un candidat le découvre en signant. Le NOM du salarié remplacé, lui,
              reste hors de la page publique — c'est la donnée d'un tiers, et personne n'a
              besoin de la lire pour décider de postuler. */}
          <div>
            <dt>Motif du recours</dt>
            <dd>{motifRecoursLabel(mission.motifRecours)}</dd>
          </div>
        </dl>
      </div>

      {mission.requiredCertifications.length > 0 && (
        <section className="fiche-mission__section">
          <h2>
            Habilitation{mission.requiredCertifications.length > 1 ? 's' : ''} exigée
            {mission.requiredCertifications.length > 1 ? 's' : ''}
          </h2>
          <ul className="carte-mission__tags" aria-label="Habilitations exigées">
            {mission.requiredCertifications.map((certification) => (
              <li key={certification}>{certificationLabel(certification)}</li>
            ))}
          </ul>
          <p className="champ__indication">
            Sans l’une de ces habilitations en cours de validité, la candidature est refusée.
          </p>
        </section>
      )}

      {mission.description && (
        <section className="fiche-mission__section">
          <h2>La mission</h2>
          <p className="fiche-mission__description">{mission.description}</p>
        </section>
      )}

      <div className="fiche-mission__actions">
        {!account && ouverte && (
          <Link href="/connexion" className="bouton bouton--principal">
            Se connecter pour postuler
          </Link>
        )}

        {/* Le bouton s'affiche pour tout intérimaire connecté. S'il lui manque une
            habilitation, l'API refuse et PostulerButton affiche le message : la page
            publique ne connaît pas le profil, et un second appel pour le deviner serait
            du bruit. */}
        {account?.role === 'WORKER' && ouverte && (
          <PostulerButton missionId={mission.id} initiallyApplied={match?.applied ?? false} />
        )}

        {/* Le bouton reste visible mais inactif, avec sa raison : le faire disparaître
            laisserait croire à un bug. */}
        {account?.role === 'WORKER' && !ouverte && (
          <button type="button" className="bouton bouton--principal" disabled>
            Postuler
            <span className="visuellement-masque">
              {' '}
              — indisponible, la mission n’est plus ouverte
            </span>
          </button>
        )}
      </div>
    </main>
  );
}
