import type { ReactNode } from 'react';
import { EnteteSite } from '../../components/EnteteSite';

// Pages publiques : accueil, authentification, page légale. Elles partagent la barre
// marketing. Groupe de routes « (site) » : les parenthèses n'apparaissent pas dans les URL,
// elles servent uniquement à donner un layout à ce sous-ensemble de pages.
//
// Aucune lecture de session ici : ces pages restent pré-rendues statiquement au build
// (`○ Static`), ce qui sert autant le SEO que la sobriété (RGESN). EnteteSite est un
// composant client, mais un composant client dans une page pré-rendue reste pré-rendu :
// seul son état d'ouverture est repris côté navigateur.
export default function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <EnteteSite />
      {children}
    </>
  );
}
