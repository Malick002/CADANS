import type { Metadata } from 'next';
import Link from 'next/link';

// Même boîte que la politique de confidentialité : une seule adresse à maintenir.
const CONTACT = 'confidentialite.cadans@gmail.com';

// Miroir de apps/api/src/contracts/cadans-identity.ts, qui fait autorité : c'est lui qui
// alimente les contrats générés. Le site ne peut pas importer depuis l'API — même convention
// assumée que pour la validation et les libellés d'habilitation. Toute modification là-bas
// doit être répercutée ici, et les deux doivent dire exactement la même chose.
//
// ⚠️ Valeurs FICTIVES : la société n'est pas immatriculée. SIRET et RCS sont des suites de
// zéros plutôt que des numéros plausibles — un identifiant inventé mais bien formé est
// vérifiable au registre du commerce, et s'y révéler faux fait pire effet.
const CADANS = {
  denomination: 'CADANS SAS',
  formeJuridique: 'Société par actions simplifiée au capital de 10 000 €',
  siret: '000 000 000 00000 (fictif — projet pédagogique)',
  rcs: 'Pontoise B 000 000 000 (fictif)',
  adresse: '12 rue de la Logistique, 95700 Roissy-en-France',
  retraiteComplementaire: 'Agirc-Arrco',
  prevoyance: 'Organisme de prévoyance — à confirmer',
  signataireNom: 'Kemil Saadouni',
  signataireQualite: 'Président',
};
const DERNIERE_MISE_A_JOUR = '22 septembre 2026';

export const metadata: Metadata = {
  title: 'Mentions légales',
  description:
    'Éditeur, hébergeur, statut d’entreprise de travail temporaire et propriété ' +
    'intellectuelle du site CADANS.',
};

export default function MentionsLegalesPage() {
  return (
    <main className="page-legale">
      <div className="conteneur page-legale__contenu">
        <h1>Mentions légales</h1>
        <p className="page-legale__date">Dernière mise à jour : {DERNIERE_MISE_A_JOUR}</p>

        {/* Dit d'emblée, et pas en note de bas de page : les identifiants ci-dessous sont des
            emplacements réservés. Les remplir avec des numéros inventés serait pire que de
            les laisser vides — ce sont des informations qu'un visiteur est censé pouvoir
            vérifier au registre du commerce. */}
        <div className="toast toast--danger" role="note">
          <p className="toast__texte">
            <strong>CADANS est un projet pédagogique</strong> réalisé dans le cadre du cursus
            Epitech (D-WEB-901). La société n’est pas immatriculée : les identifiants d’entreprise
            ci-dessous sont <strong>fictifs</strong>, et le SIRET comme le RCS sont volontairement
            des suites de zéros — un numéro inventé mais bien formé serait vérifiable au registre du
            commerce.
          </p>
        </div>

        <h2>1. Éditeur du site</h2>
        <ul>
          <li>
            <strong>Dénomination sociale</strong> : {CADANS.denomination}
          </li>
          <li>
            <strong>Forme juridique</strong> : {CADANS.formeJuridique}
          </li>
          <li>
            <strong>Siège social</strong> : {CADANS.adresse}
          </li>
          <li>
            <strong>SIRET</strong> : {CADANS.siret}
          </li>
          <li>
            <strong>RCS</strong> : {CADANS.rcs}
          </li>
          <li>
            <strong>Numéro de TVA intracommunautaire</strong> : à compléter
          </li>
          <li>
            <strong>Contact</strong> : <a href={`mailto:${CONTACT}`}>{CONTACT}</a>
          </li>
          <li>
            <strong>Directeur de la publication</strong> : {CADANS.signataireNom},{' '}
            {CADANS.signataireQualite.toLowerCase()}
          </li>
        </ul>

        <h2>2. Activité : entreprise de travail temporaire</h2>
        <p>
          CADANS exerce l’activité d’<strong>entreprise de travail temporaire</strong> au sens des
          articles L. 1251-1 et suivants du Code du travail, spécialisée dans la logistique
          d’entrepôt.
        </p>
        <p>
          CADANS est l’<strong>employeur de l’intérimaire</strong> : elle l’embauche, le rémunère,
          et le met à disposition d’entreprises clientes pour l’exécution de missions. Deux contrats
          encadrent chaque mission :
        </p>
        <ul>
          <li>
            le <strong>contrat de mission</strong>, entre CADANS et l’intérimaire (art. L. 1251-16)
            ;
          </li>
          <li>
            le <strong>contrat de mise à disposition</strong>, entre CADANS et l’entreprise
            utilisatrice (art. L. 1251-43).
          </li>
        </ul>
        <p>
          L’exercice de cette activité est subordonné à une <strong>déclaration préalable</strong>{' '}
          auprès de l’administration et à la justification d’une{' '}
          <strong>garantie financière</strong> (art. L. 1251-45 et L. 1251-49 du Code du travail).
          Ces éléments sont à compléter avant toute exploitation réelle.
        </p>
        <p>Organismes sociaux dont relève CADANS, mentionnés sur les contrats de mission :</p>
        <ul>
          <li>
            <strong>Retraite complémentaire</strong> : {CADANS.retraiteComplementaire}
          </li>
          <li>
            <strong>Prévoyance</strong> : {CADANS.prevoyance}
          </li>
        </ul>

        <h2>3. Hébergement</h2>
        <ul>
          <li>
            <strong>Application et API</strong> : Render Services, Inc. — 525 Brannan Street, Suite
            300, San Francisco, CA 94107, États-Unis.
          </li>
          <li>
            <strong>Base de données relationnelle</strong> : Neon, Inc., États-Unis.
          </li>
          <li>
            <strong>Base de données documentaire</strong> : MongoDB Atlas (MongoDB, Inc.),
            États-Unis.
          </li>
        </ul>
        <p>
          Les conséquences de cet hébergement sur vos données personnelles sont détaillées dans la{' '}
          <Link href="/politique-de-confidentialite">politique de confidentialité</Link>.
        </p>

        <h2>4. Propriété intellectuelle</h2>
        <p>
          La structure du site, ses textes, son identité visuelle et son code source sont la
          propriété de CADANS, sauf mention contraire. Toute reproduction ou représentation, totale
          ou partielle, sans autorisation écrite, est interdite.
        </p>
        <p>
          Les <strong>données métier du référentiel ROME</strong> — intitulés de postes et de
          compétences — proviennent de <strong>France Travail</strong> et restent soumises à leurs
          conditions de réutilisation. Les trois familles de caractères utilisées par le site
          (Crimson Text, DM Sans, Roboto Mono) sont diffusées sous{' '}
          <em>SIL Open Font License 1.1</em> ; les licences sont jointes au code source.
        </p>

        <h2>5. Données personnelles et cookies</h2>
        <p>
          CADANS est <strong>responsable du traitement</strong> des données personnelles collectées
          sur ce site. Les finalités, durées de conservation, destinataires et modalités d’exercice
          de vos droits sont décrits dans la{' '}
          <Link href="/politique-de-confidentialite">politique de confidentialité</Link>.
        </p>
        <p>
          Le site dépose un <strong>unique cookie</strong>, strictement nécessaire au maintien de
          votre session. Aucun traceur publicitaire ni outil de mesure d’audience n’est utilisé :
          aucun consentement ne vous est donc demandé.
        </p>

        <h2>6. Accessibilité</h2>
        <p>
          Le site est conçu selon le <strong>RGAA 4.1</strong> : contrastes vérifiés, navigation au
          clavier, structure sémantique, alternatives textuelles. Si vous rencontrez une difficulté
          d’accès à un contenu, écrivez-nous à <a href={`mailto:${CONTACT}`}>{CONTACT}</a> et nous
          vous transmettrons l’information par un autre moyen.
        </p>

        <h2>7. Signalement</h2>
        <p>
          Pour signaler un contenu illicite, une offre frauduleuse ou un manquement à la
          réglementation du travail temporaire, écrivez à{' '}
          <a href={`mailto:${CONTACT}`}>{CONTACT}</a>. Nous accusons réception sous quarante-huit
          heures ouvrées.
        </p>
      </div>
    </main>
  );
}
