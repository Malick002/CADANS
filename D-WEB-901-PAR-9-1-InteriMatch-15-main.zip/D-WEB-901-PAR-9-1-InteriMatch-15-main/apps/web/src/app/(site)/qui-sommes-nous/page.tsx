import type { Metadata } from 'next';
import Link from 'next/link';

// Même boîte que les mentions légales et la politique de confidentialité : une seule adresse
// à maintenir pour tout le site.
const CONTACT = 'confidentialite.cadans@gmail.com';

export const metadata: Metadata = {
  title: 'Qui sommes-nous',
  description:
    'CADANS est une agence d’intérim en ligne spécialisée dans la logistique d’entrepôt : ' +
    'missions proches, habilitations vérifiées, mise en relation automatisée.',
};

const ETAPES = [
  {
    numero: '1',
    titre: 'L’entreprise publie',
    texte:
      'Poste, dates, lieu, rémunération et habilitations exigées. Les métiers proposés viennent du référentiel public de France Travail, pour que tout le monde parle des mêmes postes.',
  },
  {
    numero: '2',
    titre: 'L’intérimaire se décrit',
    texte:
      'Compétences, disponibilités, zone géographique, et ses CACES avec leur date de validité.',
  },
  {
    numero: '3',
    titre: 'Le rapprochement est automatique',
    texte: 'Chacun reçoit les propositions qui lui correspondent vraiment, et l’entreprise décide.',
  },
];

const ENGAGEMENTS = [
  {
    titre: 'Aucune mission sans l’habilitation requise',
    texte:
      'Un profil qui n’a pas le CACES exigé n’est jamais proposé, quel que soit le reste de son dossier. Ce n’est pas un réglage : conduire un chariot sans habilitation est interdit et dangereux.',
  },
  {
    titre: 'Des habilitations vérifiées',
    texte:
      'Un agent CADANS contrôle les justificatifs déposés, et une habilitation arrivée à expiration est signalée à qui doit agir.',
  },
  {
    titre: 'Des documents chiffrés',
    texte:
      'Pièces d’identité, certificats et contrats sont chiffrés avant d’être enregistrés : ils restent illisibles pour qui accéderait directement à la base.',
  },
  {
    titre: 'Des données qui ne sont ni vendues ni cédées',
    texte:
      'Nous ne collectons que ce qui sert à la mise en relation, et chaque durée de conservation est écrite noir sur blanc.',
  },
];

export default function QuiSommesNousPage() {
  return (
    <main className="accueil">
      <section className="hero conteneur">
        <p className="sur-titre">Qui sommes-nous</p>
        <h1 className="display hero__titre">L’intérim d’entrepôt, et rien d’autre.</h1>
        <p className="accroche hero__accroche">
          CADANS est une agence d’intérim en ligne spécialisée dans la logistique d’entrepôt :
          préparation de commandes, conduite de chariots, manutention, gestion de stock et de quai.
          Nous mettons en relation les entrepôts en tension de personnel et les intérimaires
          qualifiés qui habitent à côté.
        </p>
        <p className="hero__cta">
          <Link href="/missions" className="bouton bouton--principal">
            Voir les missions
          </Link>
          <Link href="/inscription" className="bouton bouton--secondaire">
            Créer un compte
          </Link>
        </p>
      </section>

      <section className="section conteneur">
        <h2>Ce que nous faisons</h2>
        <p className="accroche">
          CADANS est une <strong>entreprise de travail temporaire</strong>, et non une place de
          marché : nous sommes <strong>l’employeur de l’intérimaire</strong>. Nous le mettons à
          disposition d’une entreprise cliente et nous signons les deux contrats que la loi impose —
          le contrat de mission avec l’intérimaire, le contrat de mise à disposition avec
          l’entreprise.
        </p>
        <p className="carte__texte">
          Cette différence change tout : elle fait de nous une partie aux contrats, le responsable
          de vos données, et le destinataire des obligations du Code du travail sur le travail
          temporaire.
        </p>
      </section>

      <section className="section conteneur">
        <h2>Pourquoi l’entrepôt, et rien d’autre</h2>
        <p className="accroche">
          Les agences généralistes couvrent des dizaines de secteurs à la fois. Nous avons fait
          l’inverse.
        </p>
        <p className="carte__texte">
          La logistique d’entrepôt a ses propres règles : des besoins urgents, parfois pour le
          lendemain, et surtout des <strong>habilitations obligatoires</strong> — les CACES, qui
          autorisent la conduite des chariots et des gerbeurs. En nous concentrant sur ce seul
          secteur, nous pouvons vérifier ces habilitations sérieusement et proposer un rapprochement
          fondé sur le métier réel, pas sur un intitulé de poste approximatif.
        </p>
      </section>

      <section className="section conteneur">
        <h2>Comment ça marche</h2>
        <ol className="etapes__liste">
          {ETAPES.map((etape) => (
            <li key={etape.numero} className="carte etape">
              <span className="etape__numero mono" aria-hidden="true">
                {etape.numero}
              </span>
              <h3>{etape.titre}</h3>
              <p className="carte__texte">{etape.texte}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="section conteneur">
        <h2>Nos engagements</h2>
        <ul className="grille-benefices">
          {ENGAGEMENTS.map((engagement) => (
            <li key={engagement.titre} className="carte">
              <h3>{engagement.titre}</h3>
              <p className="carte__texte">{engagement.texte}</p>
            </li>
          ))}
        </ul>
        <p className="carte__texte">
          Le détail de ce que nous collectons, pourquoi, et pour combien de temps :{' '}
          <Link href="/politique-de-confidentialite">notre politique de confidentialité</Link>.
        </p>
      </section>

      <section className="section conteneur">
        <h2>Un projet pédagogique</h2>
        <p className="carte__texte">
          CADANS est réalisé par une équipe de cinq étudiants dans le cadre du cursus Epitech
          (D-WEB-901), qui se partagent le site, l’API, les données publiques, les automatisations
          et le déploiement. <strong>La société n’est pas immatriculée</strong> et le service n’est
          pas commercialisé : les identifiants d’entreprise affichés dans les{' '}
          <Link href="/mentions-legales">mentions légales</Link> sont fictifs et signalés comme
          tels.
        </p>
      </section>

      <section className="cta-final conteneur">
        <h2>Une question ?</h2>
        <p className="accroche">
          Sur le service, sur vos données ou sur une mission, écrivez-nous à{' '}
          <a href={`mailto:${CONTACT}`}>{CONTACT}</a>.
        </p>
        <p className="hero__cta">
          <Link href="/inscription?profil=entreprise" className="bouton bouton--principal">
            Je recrute
          </Link>
          <Link href="/inscription?profil=interimaire" className="bouton bouton--secondaire">
            Je cherche une mission
          </Link>
        </p>
      </section>
    </main>
  );
}
