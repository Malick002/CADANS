import type { Metadata } from 'next';
import { LoginForm } from '../../../components/auth/LoginForm';
import { Logo } from '../../../components/Logo';

export const metadata: Metadata = {
  title: 'Connexion',
  description:
    'Connectez-vous à votre compte CADANS : entreprise de logistique d’entrepôt ou intérimaire ' +
    'cariste, préparateur de commandes ou manutentionnaire.',
};

// Page rendue côté serveur ; seul le formulaire est interactif (composant client).
export default function ConnexionPage() {
  return (
    <main className="page-auth">
      <div className="page-auth__fond">
        <div className="page-auth__carte">
          <p className="page-auth__logo">
            <Logo taille={1.125} />
          </p>

          <h1>Connexion</h1>
          <p className="accroche">
            Entreprise ou intérimaire, vous vous connectez avec la même adresse email.
          </p>

          <LoginForm />
        </div>
      </div>
    </main>
  );
}
