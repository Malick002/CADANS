import type { Metadata } from 'next';
import Link from 'next/link';
import type { ReactNode } from 'react';
import { ResetPasswordForm } from '../../../components/auth/ResetPasswordForm';
import { Logo } from '../../../components/Logo';

export const metadata: Metadata = {
  title: 'Choisir un nouveau mot de passe',
  description: 'Choisissez un nouveau mot de passe pour votre compte CADANS.',
  // L'URL porte un jeton personnel : cette page n'a rien à faire dans un index.
  robots: { index: false, follow: false },
};

// Même traitement en carte que les autres écrans d'authentification.
function CarteAuth({ children }: { children: ReactNode }) {
  return (
    <main className="page-auth">
      <div className="page-auth__fond">
        <div className="page-auth__carte">
          <p className="page-auth__logo">
            <Logo taille={1.125} />
          </p>
          {children}
        </div>
      </div>
    </main>
  );
}

// Le jeton arrive en paramètre d'URL, depuis le lien reçu par email. Dans l'App Router,
// searchParams est une promesse : la page est donc asynchrone.
export default async function ReinitialiserMotDePassePage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>;
}) {
  const { token } = await searchParams;

  if (!token) {
    return (
      <CarteAuth>
        <h1>Lien incomplet</h1>
        <p className="accroche">
          Ce lien ne contient pas de jeton de réinitialisation. Il a peut-être été coupé par votre
          logiciel de messagerie : copiez-le en entier, ou demandez-en un nouveau.
        </p>
        <p>
          <Link href="/mot-de-passe-oublie" className="bouton bouton--principal">
            Demander un nouveau lien
          </Link>
        </p>
      </CarteAuth>
    );
  }

  return (
    <CarteAuth>
      <h1>Choisir un nouveau mot de passe</h1>
      <p className="accroche">
        Ce lien ne peut servir qu’une fois. Une fois le mot de passe enregistré, il faudra vous
        reconnecter.
      </p>
      <ResetPasswordForm token={token} />
    </CarteAuth>
  );
}
