import type { MetadataRoute } from 'next';

// Base publique du site. En local, le défaut suffit ; sur Render, WEB_URL est déjà une des
// variables à définir (docs/deploiement.md).
const SITE = (process.env.WEB_URL ?? 'http://localhost:3000').replace(/\/$/, '');

// Pages statiques indexables. La connexion, l'espace entreprise et l'espace intérimaire n'y
// sont pas : ils exigent une session, les y mettre enverrait les moteurs sur une redirection.
const PAGES = [
  '',
  '/missions',
  '/qui-sommes-nous',
  '/inscription',
  '/politique-de-confidentialite',
  '/mentions-legales',
];

interface MissionOuverte {
  id: string;
  updatedAt?: string;
}

// Seules les missions OUVERTES. La fiche d'une mission pourvue reste servie (200) pour ne pas
// casser une URL déjà indexée ou partagée, mais elle porte un `noindex` et sort d'ici : la
// proposer dans les résultats de recherche ferait perdre son temps au candidat.
async function missionsOuvertes(): Promise<MissionOuverte[]> {
  const base = process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? '';
  try {
    const response = await fetch(`${base}/missions/ouvertes`, { next: { revalidate: 300 } });
    return response.ok ? ((await response.json()) as MissionOuverte[]) : [];
  } catch {
    // Un sitemap amputé vaut mieux qu'une page 500 : si l'API ne répond pas, on sert au
    // moins les pages statiques.
    return [];
  }
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const missions = await missionsOuvertes();

  return [
    ...PAGES.map((chemin) => ({
      url: `${SITE}${chemin}`,
      lastModified: new Date(),
      changeFrequency: 'weekly' as const,
      priority: chemin === '' ? 1 : 0.7,
    })),
    ...missions.map((mission) => ({
      url: `${SITE}/missions/${mission.id}`,
      lastModified: mission.updatedAt ? new Date(mission.updatedAt) : new Date(),
      changeFrequency: 'daily' as const,
      priority: 0.8,
    })),
  ];
}
