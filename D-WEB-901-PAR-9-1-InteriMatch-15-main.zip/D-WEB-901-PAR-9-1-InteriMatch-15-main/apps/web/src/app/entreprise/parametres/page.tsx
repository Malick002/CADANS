import type { Metadata } from 'next';
import { CompanyParamsForm } from '../../../components/parametres/CompanyParamsForm';
import { CompteForm } from '../../../components/parametres/CompteForm';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Paramètres',
  robots: { index: false, follow: false },
};

interface CompanyProfile {
  legalName: string;
  siret: string;
  nafCode: string;
  contactFirstName: string;
  contactLastName: string;
  phone: string | null;
  addressLine: string;
  postalCode: string;
  city: string;
}

export default async function ParametresEntreprisePage() {
  // Deux lectures indépendantes : les coordonnées vivent sur le profil entreprise, les
  // identifiants de connexion sur le compte — le même modèle que pour un intérimaire.
  const [profile, compte] = await Promise.all([
    serverGetOrRedirect<CompanyProfile>('/companies/me'),
    serverGetOrRedirect<{ email: string }>('/account/me'),
  ]);

  return (
    <main>
      <h1>Paramètres</h1>
      <p className="accroche">
        Coordonnées de l’entreprise, visibles sur vos missions, et identifiants de connexion.
      </p>

      <CompanyParamsForm profile={profile} />
      <CompteForm email={compte.email} />
    </main>
  );
}
