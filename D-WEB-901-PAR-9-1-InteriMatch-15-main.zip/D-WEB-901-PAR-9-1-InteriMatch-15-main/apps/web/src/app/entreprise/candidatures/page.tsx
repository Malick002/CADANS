import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { serverGet } from '../../../lib/session';
import Link from 'next/link';
import { RetenirCandidat } from '../../../components/candidatures/RetenirCandidat';
import { certificationLabel } from '../../../lib/certifications';
import { shiftLabel } from '../../../lib/shifts';

export const metadata: Metadata = {
  title: 'Candidatures',
  robots: { index: false, follow: false },
};

interface MissionRow {
  id: string;
  posteLabel: string;
  siteLabel: string;
  status: 'OUVERTE' | 'POURVUE' | 'TERMINEE';
  shift: string;
  // Compétences souhaitées à la création de la mission : elles servent à mettre en évidence
  // celles que le candidat déclare, et à dire lesquelles lui manquent.
  competenceCodes: string[];
}

// Ce que l'API consent à dire du candidat (CandidatView, apps/api/src/candidatures) : de quoi
// décider, rien de plus. Ni email ni téléphone : la prise de contact passe par la plateforme.
interface CandidatRow {
  workerId: string;
  firstName: string;
  lastName: string;
  city: string;
  postalCode: string;
  competences: { code: string; label: string }[];
  shifts: string[];
  score: number;
  detail: {
    competences: { points: number; max: number };
    zone: { points: number; max: number };
  };
  certifications: string[];
  certificationsVerifiees: string[];
}

interface CandidatureRow {
  id: string;
  status: string;
  createdAt: string;
  candidat: CandidatRow;
}

const STATUT_LABEL: Record<string, string> = {
  ENVOYEE: 'Envoyée',
};

const STATUT_MISSION: Record<string, string> = {
  POURVUE: 'pourvue',
  TERMINEE: 'terminée',
};

export default async function CandidaturesEntreprisePage() {
  let avecCandidatures: { mission: MissionRow; candidatures: CandidatureRow[] }[];
  try {
    const missions = await serverGet<MissionRow[]>('/missions');
    const parMission = await Promise.all(
      missions.map(async (mission) => ({
        mission,
        candidatures: await serverGet<CandidatureRow[]>(`/missions/${mission.id}/candidatures`),
      })),
    );
    avecCandidatures = parMission.filter(({ candidatures }) => candidatures.length > 0);
  } catch {
    // Session expirée entre le layout et cette page (cas limite) : même geste que le layout.
    redirect('/connexion');
  }

  return (
    <main>
      <h1>Candidatures</h1>
      <p className="accroche">Candidatures reçues sur vos missions.</p>

      {avecCandidatures.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>Aucune candidature reçue.</strong>
          </p>
          <p className="etat-vide__texte">
            Les intérimaires habilités voient vos missions ouvertes dans leurs matches. Les
            candidatures apparaîtront ici.
          </p>
          <Link href="/entreprise/missions" className="bouton bouton--secondaire">
            Voir mes missions
          </Link>
        </div>
      ) : (
        avecCandidatures.map(({ mission, candidatures }) => (
          <section key={mission.id} className="section-candidatures">
            <h2>
              {mission.posteLabel} · {mission.siteLabel}
            </h2>
            <p className="champ__indication">
              {candidatures.length} candidature{candidatures.length > 1 ? 's' : ''}
              {mission.status !== 'OUVERTE' && ` · mission ${STATUT_MISSION[mission.status]}`}
              {' · créneau '}
              {shiftLabel(mission.shift)}
              {mission.competenceCodes.length > 0 &&
                ` · ${mission.competenceCodes.length} compétence${mission.competenceCodes.length > 1 ? 's' : ''} souhaitée${mission.competenceCodes.length > 1 ? 's' : ''}`}
            </p>
            <ul className="liste-candidatures">
              {candidatures.map((candidature) => {
                const declarees = new Set(
                  candidature.candidat.competences.map((competence) => competence.code),
                );
                const manquantes = mission.competenceCodes.filter((code) => !declarees.has(code));

                return (
                  <li key={candidature.id} className="candidature-recue">
                    <div className="candidature-recue__entete">
                      <p className="candidature-recue__nom">
                        {candidature.candidat.firstName} {candidature.candidat.lastName}
                      </p>
                      <span className="badge">
                        {STATUT_LABEL[candidature.status] ?? candidature.status}
                      </span>
                    </div>

                    <dl className="candidature-recue__details">
                      <dt>Zone</dt>
                      <dd>
                        {candidature.candidat.city} ({candidature.candidat.postalCode})
                      </dd>

                      {/* Le score que la plateforme calcule, et que l'intérimaire voit déjà sur
                        ses matches. Le cacher à la partie qui DÉCIDE était difficile à tenir.
                        Il est donné avec sa ventilation : un score sans explication est pire
                        qu'aucun score — on ne peut ni le comprendre ni le contester. */}
                      <dt>Correspondance</dt>
                      <dd>
                        <strong>{candidature.candidat.score} / 100</strong>
                        <span className="candidature-recue__ventilation">
                          compétences {candidature.candidat.detail.competences.points}/
                          {candidature.candidat.detail.competences.max} · zone{' '}
                          {candidature.candidat.detail.zone.points}/
                          {candidature.candidat.detail.zone.max}
                        </span>
                      </dd>

                      <dt>Créneaux acceptés</dt>
                      <dd>
                        {candidature.candidat.shifts.length === 0
                          ? 'Tous les créneaux'
                          : candidature.candidat.shifts.map(shiftLabel).join(', ')}
                      </dd>

                      <dt>Habilitations valides</dt>
                      <dd>
                        {candidature.candidat.certifications.length === 0 ? (
                          // Écrit en toutes lettres plutôt que signalé par une couleur seule
                          // (RGAA 4.1). Un candidat sans habilitation n'est pas disqualifié :
                          // la mission n'en exigeait aucune, sinon il n'aurait pas pu postuler.
                          <span className="candidature-recue__aucune">Aucune renseignée</span>
                        ) : (
                          <ul className="candidature-recue__habilitations">
                            {candidature.candidat.certifications.map((certification) => {
                              // « Vérifié » signifie qu'un agent CADANS a examiné le
                              // justificatif. Le mot est écrit, jamais porté par la seule
                              // couleur, et le justificatif lui-même ne quitte pas CADANS.
                              const verifiee =
                                candidature.candidat.certificationsVerifiees.includes(
                                  certification,
                                );
                              return (
                                <li
                                  key={certification}
                                  className={verifiee ? 'badge badge--verifie' : 'badge'}
                                >
                                  {certificationLabel(certification)}
                                  {verifiee ? ' · vérifié' : ' · déclaré'}
                                </li>
                              );
                            })}
                          </ul>
                        )}
                      </dd>
                      {/* Elles pèsent 60 % du score, et n'étaient pas affichées : l'entreprise
                        ne jugeait que sur les CACES, qui sont un filtre d'accès valant zéro
                        point. Déclaratif, jamais vérifié — contrairement aux habilitations,
                        qui passent devant un agent. Le mot « déclarées » le dit. */}
                      <dt>Compétences déclarées</dt>
                      <dd>
                        {candidature.candidat.competences.length === 0 ? (
                          <span className="candidature-recue__aucune">Aucune renseignée</span>
                        ) : (
                          <ul className="candidature-recue__competences">
                            {candidature.candidat.competences.map((competence) => {
                              const demandee = mission.competenceCodes.includes(competence.code);
                              return (
                                <li
                                  key={competence.code}
                                  className={demandee ? 'badge badge--verifie' : 'badge'}
                                >
                                  {competence.label}
                                  {/* Écrit, jamais porté par la seule couleur (RGAA 4.1). */}
                                  {demandee ? ' · demandée' : ''}
                                </li>
                              );
                            })}
                          </ul>
                        )}
                      </dd>

                      {manquantes.length > 0 && (
                        <>
                          {/* Ce que la mission demandait et que le candidat ne déclare pas.
                            C'est l'information qui explique le score, et celle qui manque
                            le plus pour comparer deux candidats. */}
                          <dt>Compétences demandées non déclarées</dt>
                          <dd>
                            <span className="candidature-recue__aucune">
                              {manquantes.length} sur {mission.competenceCodes.length}
                            </span>
                          </dd>
                        </>
                      )}
                    </dl>

                    <p className="candidature-recue__date">
                      Reçue le{' '}
                      <time dateTime={candidature.createdAt}>
                        {new Date(candidature.createdAt).toLocaleDateString('fr-FR')}
                      </time>
                    </p>

                    {/* L'action n'apparaît que tant que la mission est à pourvoir : une mission
                      déjà pourvue n'a plus de candidat à retenir, et le proposer quand même
                      aboutirait à un refus de l'API après un clic engageant. */}
                    {mission.status === 'OUVERTE' && (
                      <RetenirCandidat
                        missionId={mission.id}
                        workerId={candidature.candidat.workerId}
                        candidat={`${candidature.candidat.firstName} ${candidature.candidat.lastName}`}
                      />
                    )}
                  </li>
                );
              })}
            </ul>
          </section>
        ))
      )}
    </main>
  );
}
