import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { PageSignature } from '../../../../../components/contrats/PageSignature';
import { getSessionAccount } from '../../../../../lib/session';

export const metadata: Metadata = {
  title: 'Signer le contrat',
  robots: { index: false, follow: false },
};

export default async function SignerContratEntreprisePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const [{ id }, compte] = await Promise.all([params, getSessionAccount()]);
  if (!compte?.company) {
    redirect('/connexion');
  }

  return (
    <PageSignature
      contratId={id}
      // Le signataire est le contact du compte : c'est lui que l'API attend, et c'est son nom
      // qui figurera sur la page de signatures du document final.
      nomAttendu={`${compte.company.contactFirstName} ${compte.company.contactLastName}`}
      retour="/entreprise/contrats"
    />
  );
}
