import type { Metadata } from 'next';
import Link from 'next/link';
import { ContratRow, ListeContrats } from '../../../components/contrats/ListeContrats';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Contrats',
  robots: { index: false, follow: false },
};

export default async function ContratsEntreprisePage() {
  const contrats = await serverGetOrRedirect<ContratRow[]>('/contrats');

  return (
    <main>
      <h1>Contrats</h1>
      <p className="accroche">
        Le contrat de mise à disposition vous lie à <strong>CADANS</strong>, l’employeur de
        l’intérimaire. Il est établi dès qu’une de vos missions est pourvue. Le contrat de mission,
        conclu entre CADANS et l’intérimaire, ne vous est pas communiqué : il porte son état civil,
        et vous n’y êtes pas partie.
      </p>

      {contrats.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>Aucun contrat pour le moment.</strong>
          </p>
          <p className="etat-vide__texte">
            Un contrat de mise à disposition est établi automatiquement dès qu’une mission passe au
            statut « Pourvue » et qu’un intérimaire y est retenu.
          </p>
          <Link href="/entreprise/missions" className="bouton bouton--principal">
            Voir mes missions
          </Link>
        </div>
      ) : (
        <ListeContrats contrats={contrats} basePath="/entreprise/contrats" />
      )}
    </main>
  );
}
