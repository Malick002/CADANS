import { redirect } from 'next/navigation';
import type { ReactNode } from 'react';
import { BoutonDeconnexion } from '../../components/BoutonDeconnexion';
import { BarreLaterale } from '../../components/tableau-bord/BarreLaterale';
import { getSessionAccount } from '../../lib/session';

// Espace entreprise : protégé ici une seule fois (Server Component), plutôt que sur chaque
// page — un compte non connecté ou du mauvais rôle ne voit jamais le contenu.
export default async function EntrepriseLayout({ children }: { children: ReactNode }) {
  const account = await getSessionAccount();
  if (!account || account.role !== 'COMPANY') {
    redirect('/connexion');
  }

  return (
    <div className="tableau-bord">
      <BarreLaterale
        label="Espace entreprise"
        entrees={[
          { href: '/entreprise/missions', label: 'Missions' },
          { href: '/entreprise/candidatures', label: 'Candidatures' },
          { href: '/entreprise/contrats', label: 'Contrats' },
          { href: '/entreprise/parametres', label: 'Paramètres' },
        ]}
      >
        <div className="tableau-bord__compte">
          <p className="tableau-bord__compte-nom">{account.company?.legalName}</p>
          <BoutonDeconnexion />
        </div>
      </BarreLaterale>

      <div className="tableau-bord__contenu">{children}</div>
    </div>
  );
}
