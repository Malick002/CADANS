import type { Metadata } from 'next';
import Link from 'next/link';
import { PosteOption } from '../../../../components/missions/MissionForm';
import { SourceMission } from '../../../../components/missions/SourceMission';

export const metadata: Metadata = {
  title: 'Publier une mission',
  robots: { index: false, follow: false },
};

function apiBase(): string {
  return process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? '';
}

// GET /referentiel/postes est public et mis en cache une heure côté API (RGESN) : un appel
// serveur suffit, pas besoin de session pour cette partie du formulaire.
async function getPostes(): Promise<PosteOption[]> {
  const response = await fetch(`${apiBase()}/referentiel/postes`, {
    next: { revalidate: 3600 },
  });
  if (!response.ok) {
    return [];
  }
  return response.json();
}

// Le serveur a-t-il les identifiants France Travail ? Sans eux, l'entrée « Partir d'une
// offre » n'est pas affichée du tout — une entrée qui échouerait à tous les coups vaut moins
// qu'une entrée absente. La route est publique, pour la même raison que celle des postes :
// cette page est rendue côté serveur, sans session.
//
// Pas de cache : la réponse dépend de la configuration du serveur d'API, qui peut changer
// d'un déploiement à l'autre sans que cette page soit reconstruite. L'appel est trivial.
async function offresDisponibles(): Promise<boolean> {
  try {
    const response = await fetch(`${apiBase()}/missions/prefill/disponibilite`, {
      cache: 'no-store',
    });
    if (!response.ok) {
      return false;
    }
    const { disponible } = (await response.json()) as { disponible?: boolean };
    return disponible === true;
  } catch {
    // API injoignable au rendu : le formulaire vierge, lui, fonctionne toujours.
    return false;
  }
}

export default async function NouvelleMissionPage() {
  const [postes, offres] = await Promise.all([getPostes(), offresDisponibles()]);

  return (
    <main>
      <p className="fil-retour">
        <Link href="/entreprise/missions">Missions</Link> › Nouvelle mission
      </p>
      <h1>Publier une mission</h1>
      <p className="accroche">Deux minutes. La mission part au matching dès l’enregistrement.</p>

      <SourceMission postes={postes} offresDisponibles={offres} />
    </main>
  );
}
