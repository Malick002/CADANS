import type { Metadata } from 'next';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { serverGet } from '../../../lib/session';
import { certificationLabel } from '../../../lib/certifications';

export const metadata: Metadata = {
  title: 'Mes missions',
  robots: { index: false, follow: false },
};

interface MissionRow {
  id: string;
  posteLabel: string;
  siteLabel: string;
  postalCode: string;
  startDate: string;
  endDate: string;
  hourlyRate: string;
  status: 'OUVERTE' | 'POURVUE' | 'TERMINEE';
  requiredCertifications: string[];
}

const ONGLETS = [
  { status: undefined, label: 'Toutes' },
  { status: 'OUVERTE', label: 'Ouvertes' },
  { status: 'POURVUE', label: 'Pourvues' },
  { status: 'TERMINEE', label: 'Terminées' },
] as const;

const STATUT_LABEL: Record<MissionRow['status'], string> = {
  OUVERTE: 'Ouverte',
  POURVUE: 'Pourvue',
  TERMINEE: 'Terminée',
};

function formatDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
  });
}

// Page rendue côté serveur : le filtre par statut vient de l'URL (?status=), sans JavaScript
// nécessaire pour changer d'onglet.
export default async function MissionsEntreprisePage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const { status } = await searchParams;
  let missions: MissionRow[];
  let toutes: MissionRow[];
  try {
    [missions, toutes] = await Promise.all([
      serverGet<MissionRow[]>('/missions', status ? { status } : undefined),
      serverGet<MissionRow[]>('/missions'),
    ]);
  } catch {
    // Session expirée entre le layout et cette page (cas limite) : même geste que le layout.
    redirect('/connexion');
  }

  const compte = (s: (typeof ONGLETS)[number]['status']) =>
    s ? toutes.filter((m) => m.status === s).length : toutes.length;

  return (
    <main>
      <div className="missions__entete">
        <div>
          <h1>Mes missions</h1>
        </div>
        <Link href="/entreprise/missions/nouvelle" className="bouton bouton--principal">
          + Nouvelle mission
        </Link>
      </div>

      <dl className="cartes-stats">
        <div className="carte-stat">
          <dt>Ouvertes</dt>
          <dd>{compte('OUVERTE')}</dd>
        </div>
        <div className="carte-stat">
          <dt>Pourvues</dt>
          <dd>{compte('POURVUE')}</dd>
        </div>
        <div className="carte-stat">
          <dt>Terminées</dt>
          <dd>{compte('TERMINEE')}</dd>
        </div>
      </dl>

      <nav className="onglets-statut" aria-label="Filtrer par statut">
        {ONGLETS.map((onglet) => {
          const active = (status ?? undefined) === onglet.status;
          const href = onglet.status
            ? `/entreprise/missions?status=${onglet.status}`
            : '/entreprise/missions';
          return (
            <Link
              key={onglet.label}
              href={href}
              aria-current={active ? 'page' : undefined}
              className={`onglets-statut__lien${active ? ' onglets-statut__lien--actif' : ''}`}
            >
              {onglet.label} ({compte(onglet.status)})
            </Link>
          );
        })}
      </nav>

      {missions.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>{status ? 'Aucune mission avec ce statut.' : 'Aucune mission publiée.'}</strong>
          </p>
          <p className="etat-vide__texte">
            {status
              ? 'Changez de filtre pour voir les autres missions.'
              : 'Publiez une mission : les profils habilités et disponibles dans la zone remontent aussitôt.'}
          </p>
          {!status && (
            <Link href="/entreprise/missions/nouvelle" className="bouton bouton--principal">
              Publier une mission
            </Link>
          )}
        </div>
      ) : (
        /* Une liste de cartes et non un tableau : la comparaison d'une mission à l'autre est
           déjà portée par les compteurs et les onglets de statut au-dessus. Ça évite aussi
           de réimposer à la main les rôles ARIA qu'un passage en cartes sous 800 px aurait
           retirés — `display: block` supprime la sémantique de tableau. */
        <ul className="cartes-mission-entreprise">
          {missions.map((mission) => (
            <li key={mission.id} className="carte">
              <div className="carte__entete">
                <h2 className="carte-mission-entreprise__titre">{mission.posteLabel}</h2>
                <span className={`statut statut--${mission.status.toLowerCase()}`}>
                  <span className="statut__pastille" aria-hidden="true" />
                  {STATUT_LABEL[mission.status]}
                </span>
              </div>
              <p className="carte-mission-entreprise__lieu">
                {mission.siteLabel} · {mission.postalCode}
              </p>
              <dl className="carte-mission__details">
                <div>
                  <dt className="mono">Dates</dt>
                  <dd>
                    {formatDate(mission.startDate)} → {formatDate(mission.endDate)}
                  </dd>
                </div>
              </dl>
              {mission.requiredCertifications.length > 0 ? (
                <ul className="carte-mission-entreprise__caces">
                  {mission.requiredCertifications.map((certification) => (
                    <li key={certification} className="badge">
                      {certificationLabel(certification)}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="champ__indication">Aucune habilitation exigée.</p>
              )}
              {/* Plan d'accès, consignes de sécurité, fiche de poste : ce que le contrat ne
                  porte pas et que l'intérimaire retenu doit avoir avant d'arriver. */}
              <p className="carte-mission-entreprise__annexes">
                <Link href={`/entreprise/missions/${mission.id}/annexes`}>Documents joints</Link>
              </p>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
