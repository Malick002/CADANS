import type { Metadata } from 'next';
import Link from 'next/link';
import { AnnexeRow, ListeAnnexes } from '../../../../../components/annexes/ListeAnnexes';
import { FormulaireAnnexe } from '../../../../../components/annexes/FormulaireAnnexe';
import { serverGetOrRedirect } from '../../../../../lib/session';

export const metadata: Metadata = {
  title: 'Documents joints',
  robots: { index: false, follow: false },
};

interface MissionRow {
  posteLabel: string;
  siteLabel: string;
  status: 'OUVERTE' | 'POURVUE' | 'TERMINEE';
}

interface ContratRow {
  missionId: string;
  signe: boolean;
}

export default async function AnnexesMissionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  // L'API refuse la liste à qui n'est pas destinataire : inutile de recontrôler ici, une
  // mission d'une autre entreprise fait échouer l'appel et `serverGetOrRedirect` reprend la
  // main. La fiche, elle, est publique — c'est le titre de la page.
  const [annexes, mission, contrats] = await Promise.all([
    serverGetOrRedirect<AnnexeRow[]>(`/missions/${id}/annexes`),
    serverGetOrRedirect<MissionRow>(`/missions/${id}`),
    serverGetOrRedirect<ContratRow[]>('/contrats'),
  ]);

  // Un contrat signé fige les annexes : elles font partie de ce sur quoi l'intérimaire s'est
  // engagé. L'API refuse la suppression en 409 ; l'écran ne propose donc pas un bouton qui
  // serait refusé, et dit pourquoi.
  const fige = contrats.some((contrat) => contrat.missionId === id && contrat.signe);

  return (
    <main>
      <h1>Documents joints</h1>
      <p className="accroche">
        Mission <strong>{mission.posteLabel}</strong> — {mission.siteLabel}. Plan d’accès, consignes
        de sécurité du site, fiche de poste détaillée : ce que le contrat ne porte pas et que
        l’intérimaire doit avoir avant d’arriver.
      </p>

      <section className="section-annexes">
        <h2>Documents déjà joints</h2>
        {annexes.length === 0 ? (
          <p className="champ__indication">
            Aucun document pour le moment. Ceux que vous déposez ici ne sont lisibles que par vous
            et par l’intérimaire retenu sur cette mission — jamais par les candidats.
          </p>
        ) : (
          <>
            <ListeAnnexes annexes={annexes} supprimable={!fige} />
            {fige && (
              <p className="champ__indication">
                Un contrat de cette mission est signé : ses documents joints ne peuvent plus être
                retirés. Ils font partie de ce que l’intérimaire a accepté en signant.
              </p>
            )}
          </>
        )}
      </section>

      <section className="section-annexes">
        <h2>Joindre un document</h2>
        <FormulaireAnnexe missionId={id} />
      </section>

      <p className="carte-contrat__actions">
        <Link href="/entreprise/missions">Revenir à mes missions</Link>
      </p>
    </main>
  );
}
