import type { MetadataRoute } from 'next';

const SITE = (process.env.WEB_URL ?? 'http://localhost:3000').replace(/\/$/, '');

// Sans robots.txt, le sitemap n'est découvert que si on le déclare à la main dans chaque
// outil pour webmasters. Les espaces connectés sont exclus : ils redirigent vers la
// connexion, les explorer ne produit rien d'indexable.
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: '*', allow: '/', disallow: ['/entreprise/', '/interimaire/'] }],
    sitemap: `${SITE}/sitemap.xml`,
  };
}
