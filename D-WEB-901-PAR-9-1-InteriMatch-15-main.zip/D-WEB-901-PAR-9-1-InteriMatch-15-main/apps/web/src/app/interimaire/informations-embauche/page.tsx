import type { Metadata } from 'next';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import {
  InformationsEmbauche,
  InformationsEmbaucheForm,
} from '../../../components/profil/InformationsEmbaucheForm';
import { getSessionAccount, serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Informations d’embauche',
  robots: { index: false, follow: false },
};

export default async function InformationsEmbauchePage() {
  const [informations, compte] = await Promise.all([
    serverGetOrRedirect<InformationsEmbauche>('/workers/me/informations-embauche'),
    getSessionAccount(),
  ]);

  if (!compte?.worker) {
    redirect('/connexion');
  }

  return (
    <main>
      <h1>Informations d’embauche</h1>
      <p className="accroche">
        CADANS est votre <strong>employeur</strong> : ces informations sont celles que la loi impose
        de faire figurer à votre contrat de mission et à votre bulletin de paie. Elles ne vous sont
        demandées qu’une fois, au moment où vous êtes retenu sur une mission.
      </p>

      <InformationsEmbaucheForm
        informations={informations}
        domicile={{ postalCode: compte.worker.postalCode, city: compte.worker.city }}
      />

      <p className="mention-donnees">
        Base légale : l’exécution de votre contrat de travail et les obligations légales qui pèsent
        sur une entreprise de travail temporaire. Durées de conservation et exercice de vos droits :{' '}
        <Link href="/politique-de-confidentialite">politique de confidentialité</Link>.
      </p>
    </main>
  );
}
