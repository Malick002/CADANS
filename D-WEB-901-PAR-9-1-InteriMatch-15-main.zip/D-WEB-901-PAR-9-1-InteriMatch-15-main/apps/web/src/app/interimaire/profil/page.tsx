import type { Metadata } from 'next';
import { HabilitationRow, Habilitations } from '../../../components/profil/Habilitations';
import { ProfilMatchingForm, RomeOption } from '../../../components/profil/ProfilMatchingForm';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Mon profil',
  robots: { index: false, follow: false },
};

interface ProfilMatching {
  shifts: string[];
  competences: { code: string; label: string }[];
}

interface PosteApi {
  rome: { code: string; label: string };
}

// Les métiers proposés au filtre viennent des postes exposés (mêmes 3 codes ROME que le
// formulaire de mission), sans dupliquer une liste à la main.
async function getRomes(): Promise<RomeOption[]> {
  const base = process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? '';
  // revalidate court et non une heure : après un `prisma migrate reset`, le référentiel est
  // vide le temps de rejouer `npm run import:rome`. Avec un cache d'une heure, Next figeait
  // cette liste vide et le sélecteur de métiers restait désespérément vide bien après
  // l'import — sans rien afficher qui l'explique.
  const response = await fetch(`${base}/referentiel/postes`, { next: { revalidate: 60 } });
  if (!response.ok) {
    return [];
  }
  const postes: PosteApi[] = await response.json();
  const parCode = new Map<string, RomeOption>();
  for (const poste of postes) {
    parCode.set(poste.rome.code, poste.rome);
  }
  return [...parCode.values()].sort((a, b) => a.label.localeCompare(b.label, 'fr'));
}

export default async function ProfilInterimairePage() {
  const [profil, romes, habilitations] = await Promise.all([
    serverGetOrRedirect<ProfilMatching>('/workers/me/profil-matching'),
    getRomes(),
    serverGetOrRedirect<HabilitationRow[]>('/workers/me/certifications'),
  ]);

  return (
    <main>
      <h1>Mon profil</h1>
      <p className="accroche">
        Créneaux et compétences servent au matching : plus ils sont à jour, plus vous êtes proposé
        sur des missions qui vous correspondent.
      </p>

      <ProfilMatchingForm profil={profil} romes={romes} />

      <Habilitations habilitations={habilitations} />
    </main>
  );
}
