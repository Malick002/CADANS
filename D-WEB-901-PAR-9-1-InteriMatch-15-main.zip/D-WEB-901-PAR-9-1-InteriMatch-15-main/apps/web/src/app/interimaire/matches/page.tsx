import type { Metadata } from 'next';
import Link from 'next/link';
import { PostulerButton } from '../../../components/candidatures/PostulerButton';
import { certificationLabel } from '../../../lib/certifications';
import { serverGetOrRedirect } from '../../../lib/session';
import { shiftLabel } from '../../../lib/shifts';
import { tauxHoraire } from '../../../lib/montants';

export const metadata: Metadata = {
  title: 'Mes matches',
  robots: { index: false, follow: false },
};

interface MatchRow {
  missionId: string;
  posteLabel: string;
  companyName: string;
  siteLabel: string;
  postalCode: string;
  startDate: string;
  endDate: string;
  shift: string;
  hourlyRate: string;
  score: number;
  // Ventilation calculée par l'API (MatchScoreDetail). Les maxima (60 et 40) viennent d'elle
  // aussi : les réécrire ici dupliquerait les poids du matching dans l'écran.
  detail: {
    competences: { points: number; max: number };
    zone: { points: number; max: number };
  };
  // Candidature deja deposee : le bouton le sait des le rendu serveur.
  applied: boolean;
}

// Les missions exigeant une habilitation absente du profil ne sont pas renvoyées (filtrage
// bloquant, MatchingService). Seul leur nombre l'est : il alimente l'incitation ci-dessous,
// sans laisser croire qu'on pourrait y postuler.
interface MatchesResponse {
  matches: MatchRow[];
  masqueesFauteHabilitation: { missions: number; certifications: string[] };
}

function formatDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
  });
}

export default async function MatchesPage() {
  // serverGetOrRedirect et non serverGet : porte depuis version-khadija, il renvoie vers la
  // connexion quand la session ne correspond pas au role attendu, au lieu de planter.
  const { matches, masqueesFauteHabilitation: masquees } =
    await serverGetOrRedirect<MatchesResponse>('/matches');

  return (
    <main>
      <h1>Mes matches</h1>
      {/* « Habilitations et créneau » plutôt que « votre profil » : c'est exactement ce que
          filtre le calcul, et c'est ce qui explique l'écart avec la liste publique. Dire
          « correspondent à votre profil » laissait croire à un classement flou. */}
      <p className="accroche">
        {matches.length > 0
          ? `${matches.length} mission${matches.length > 1 ? 's' : ''} pour ${matches.length > 1 ? 'lesquelles' : 'laquelle'} vous avez les habilitations et le créneau, les mieux notées d’abord.`
          : 'Aucune mission ne correspond à vos habilitations et à vos créneaux pour le moment.'}
      </p>

      {masquees.missions > 0 && (
        <p className="avis-caces">
          <span className="avis-caces__pastille" aria-hidden="true" />
          {masquees.missions} mission{masquees.missions > 1 ? 's' : ''} supplémentaire
          {masquees.missions > 1 ? 's' : ''} exige
          {masquees.missions > 1 ? 'nt' : ''} une habilitation absente de votre profil (
          {masquees.certifications.map(certificationLabel).join(', ')}).{' '}
          <Link href="/interimaire/profil">Ajoutez-la pour les voir apparaître.</Link>
        </p>
      )}

      {matches.length === 0 ? (
        <p className="champ__indication">
          Complétez votre <Link href="/interimaire/profil">profil</Link> (compétences, créneaux)
          pour être proposé sur davantage de missions.
        </p>
      ) : (
        <ul className="cartes-match">
          {matches.map((match) => (
            <li key={match.missionId} className="carte-match">
              <div className="carte-match__entete">
                <span className="carte-match__score">Match {match.score}%</span>
                <span className="statut statut--ouverte">Ouverte</span>
              </div>

              {/* Le détail du score, sous le pourcentage : l'intérimaire voit ce qui lui
                  rapporte des points et ce qu'il lui manque. Chasse fixe, comme le score :
                  les deux colonnes de chiffres s'alignent d'une carte à l'autre. */}
              <p className="carte-match__detail">
                <span>
                  Compétences{' '}
                  <strong>
                    {match.detail.competences.points}/{match.detail.competences.max}
                  </strong>
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  Zone{' '}
                  <strong>
                    {match.detail.zone.points}/{match.detail.zone.max}
                  </strong>
                </span>
              </p>

              <h2 className="carte-match__titre">{match.posteLabel}</h2>
              <p className="carte-match__lieu">
                {match.companyName} · {match.siteLabel}
              </p>

              <dl className="carte-mission__details">
                <div>
                  <dt>Dates</dt>
                  <dd>
                    {formatDate(match.startDate)} → {formatDate(match.endDate)}
                  </dd>
                </div>
                <div>
                  <dt>Créneau</dt>
                  <dd>{shiftLabel(match.shift)}</dd>
                </div>
                <div>
                  <dt>Rémunération</dt>
                  <dd>{tauxHoraire(match.hourlyRate)} €/h</dd>
                </div>
              </dl>

              {/* Plus de branche « bloquee » : une mission dont l'habilitation manque n'est
                  plus renvoyee du tout. Tout ce qui est affiche ici est candidatable. */}
              <PostulerButton missionId={match.missionId} initiallyApplied={match.applied} />
            </li>
          ))}
        </ul>
      )}

      {/* Le chemin inverse du rappel posé sur /missions : d'ici, on peut aller voir tout ce
          qui est ouvert. C'est aussi ce qui donne envie d'ajouter une habilitation — le
          compteur de missions masquées ci-dessus dit combien, celui-ci dit où les voir. */}
      <p className="renvoi-offres">
        <Link href="/missions">
          Voir toutes les offres ouvertes, y compris celles hors de votre portée aujourd’hui
        </Link>
      </p>
    </main>
  );
}
