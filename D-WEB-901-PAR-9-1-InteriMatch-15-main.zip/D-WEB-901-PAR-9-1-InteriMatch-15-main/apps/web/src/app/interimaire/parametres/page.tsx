import type { Metadata } from 'next';
import { CompteForm } from '../../../components/parametres/CompteForm';
import { WorkerIdentity, WorkerParamsForm } from '../../../components/parametres/WorkerParamsForm';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Paramètres',
  robots: { index: false, follow: false },
};

export default async function ParametresInterimairePage() {
  // Deux lectures indépendantes : les coordonnées vivent sur le profil intérimaire, les
  // identifiants de connexion sur le compte — et ce compte est le même modèle pour une
  // entreprise. En parallèle : elles ne dépendent pas l'une de l'autre.
  const [identity, compte] = await Promise.all([
    serverGetOrRedirect<WorkerIdentity>('/workers/me/identite'),
    serverGetOrRedirect<{ email: string }>('/account/me'),
  ]);

  return (
    <main>
      <h1>Paramètres</h1>
      <p className="accroche">Vos coordonnées et vos identifiants de connexion.</p>

      <WorkerParamsForm identity={identity} />
      <CompteForm email={compte.email} />
    </main>
  );
}
