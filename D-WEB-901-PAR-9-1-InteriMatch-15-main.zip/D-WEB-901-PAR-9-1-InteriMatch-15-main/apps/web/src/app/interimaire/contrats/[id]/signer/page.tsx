import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { PageSignature } from '../../../../../components/contrats/PageSignature';
import { getSessionAccount } from '../../../../../lib/session';

export const metadata: Metadata = {
  title: 'Signer mon contrat',
  robots: { index: false, follow: false },
};

export default async function SignerContratInterimairePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const [{ id }, compte] = await Promise.all([params, getSessionAccount()]);
  if (!compte?.worker) {
    redirect('/connexion');
  }

  return (
    <PageSignature
      contratId={id}
      nomAttendu={`${compte.worker.firstName} ${compte.worker.lastName}`}
      retour="/interimaire/contrats"
    />
  );
}
