import type { Metadata } from 'next';
import Link from 'next/link';
import { AnnexesMission } from '../../../components/annexes/AnnexesMission';
import { ContratRow, ListeContrats } from '../../../components/contrats/ListeContrats';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Mes contrats',
  robots: { index: false, follow: false },
};

interface EtatEmbauche {
  complet: boolean;
  requis: boolean;
  missionsRetenues: number;
}

export default async function ContratsInterimairePage() {
  const [contrats, embauche] = await Promise.all([
    serverGetOrRedirect<ContratRow[]>('/contrats'),
    serverGetOrRedirect<EtatEmbauche>('/workers/me/informations-embauche'),
  ]);

  // Le cas exact que la tâche demande de traiter : retenu sur une mission, contrat de mission
  // impossible faute d'informations d'embauche. Un écran vide sans explication laisserait
  // croire à une panne.
  const enAttente = embauche.requis && !embauche.complet;

  return (
    <main>
      <h1>Mes contrats</h1>
      <p className="accroche">
        Le contrat de mission vous lie à <strong>CADANS</strong>, votre employeur. Le contrat de
        mise à disposition, qui lie CADANS à l’entreprise qui vous accueille, ne vous est pas
        communiqué : vous n’y êtes pas partie.
      </p>

      {enAttente && (
        /* Variante discrète, et non le bandeau d'encre : celui du layout est déjà à l'écran
           juste au-dessus sur cette page. Deux aplats sombres empilés se disputeraient
           l'attention et rendraient les deux moins lisibles. */
        <div className="bandeau-embauche bandeau-embauche--discret" role="status">
          <p className="bandeau-embauche__titre">Contrat en attente</p>
          <p className="bandeau-embauche__texte">
            Votre contrat de mission ne peut pas être établi tant que vos informations d’embauche
            sont incomplètes : la loi impose d’y faire figurer votre état civil, votre adresse et
            votre numéro de sécurité sociale. Il sera généré dès que vous les aurez renseignées.
          </p>
          <Link href="/interimaire/informations-embauche" className="bouton bouton--secondaire">
            Compléter mes informations
          </Link>
        </div>
      )}

      {contrats.length === 0 ? (
        !enAttente && (
          <div className="etat-vide">
            <p className="etat-vide__titre">
              <strong>Aucun contrat pour le moment.</strong>
            </p>
            <p className="etat-vide__texte">
              Votre contrat de mission est établi dès qu’une entreprise vous retient sur une
              mission. Postulez depuis vos matches pour vous faire connaître.
            </p>
            <Link href="/interimaire/matches" className="bouton bouton--principal">
              Voir mes matches
            </Link>
          </div>
        )
      ) : (
        <ListeContrats contrats={contrats} basePath="/interimaire/contrats" />
      )}

      {/* Hors du `else` : les annexes ne dépendent pas des contrats. Un intérimaire retenu
          dont le contrat de mission attend ses informations d'embauche n'a aucun contrat à
          l'écran, et doit pourtant recevoir le plan d'accès et les consignes du site. */}
      <AnnexesMission />
    </main>
  );
}
