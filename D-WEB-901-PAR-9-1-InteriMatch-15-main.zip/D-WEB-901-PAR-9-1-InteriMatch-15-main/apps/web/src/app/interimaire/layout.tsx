import { redirect } from 'next/navigation';
import type { ReactNode } from 'react';
import { BoutonDeconnexion } from '../../components/BoutonDeconnexion';
import { BandeauInformationsEmbauche } from '../../components/interimaire/BandeauInformationsEmbauche';
import { BarreLaterale } from '../../components/tableau-bord/BarreLaterale';
import { getSessionAccount } from '../../lib/session';

// Espace intérimaire : protégé ici une seule fois (Server Component), même principe que
// apps/web/src/app/entreprise/layout.tsx.
export default async function InterimaireLayout({ children }: { children: ReactNode }) {
  const account = await getSessionAccount();
  if (!account || account.role !== 'WORKER') {
    redirect('/connexion');
  }

  return (
    <div className="tableau-bord">
      <BarreLaterale
        label="Espace intérimaire"
        entrees={[
          { href: '/interimaire/matches', label: 'Matches' },
          { href: '/interimaire/mes-missions', label: 'Mes missions' },
          { href: '/interimaire/contrats', label: 'Contrats' },
          { href: '/interimaire/profil', label: 'Profil' },
          { href: '/interimaire/informations-embauche', label: 'Informations d’embauche' },
          { href: '/interimaire/parametres', label: 'Paramètres' },
        ]}
      >
        <div className="tableau-bord__compte">
          <p className="tableau-bord__compte-nom">{account.worker?.firstName}</p>
          <BoutonDeconnexion />
        </div>
      </BarreLaterale>

      <div className="tableau-bord__contenu">
        {/* Rendu ici et non dans chaque page : l'intérimaire retenu sur une mission doit
            lire ce rappel où qu'il se trouve dans son espace. Le composant ne rend rien
            quand il n'a rien à dire. */}
        <BandeauInformationsEmbauche />
        {children}
      </div>
    </div>
  );
}
