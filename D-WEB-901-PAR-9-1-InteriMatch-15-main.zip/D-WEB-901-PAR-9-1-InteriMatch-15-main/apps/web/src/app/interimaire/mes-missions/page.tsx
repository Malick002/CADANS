import type { Metadata } from 'next';
import Link from 'next/link';
import { serverGetOrRedirect } from '../../../lib/session';

export const metadata: Metadata = {
  title: 'Mes missions',
  robots: { index: false, follow: false },
};

interface CandidatureRow {
  id: string;
  status: string;
  createdAt: string;
  missionId: string;
  posteLabel: string;
  siteLabel: string;
  companyName: string;
  startDate: string;
  endDate: string;
}

const STATUT_LABEL: Record<string, string> = {
  ENVOYEE: 'Envoyée',
};

function formatDate(iso: string): string {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
  });
}

export default async function MesMissionsPage() {
  const candidatures = await serverGetOrRedirect<CandidatureRow[]>('/workers/me/candidatures');

  return (
    <main>
      <h1>Mes missions</h1>
      <p className="accroche">Missions auxquelles vous avez postulé.</p>

      {candidatures.length === 0 ? (
        <div className="etat-vide">
          <p className="etat-vide__titre">
            <strong>Aucune candidature envoyée.</strong>
          </p>
          <p className="etat-vide__texte">
            Les missions qui correspondent à votre profil sont dans vos matches. Postuler depuis
            cette page les fera apparaître ici.
          </p>
          <Link href="/interimaire/matches" className="bouton bouton--principal">
            Voir mes matches
          </Link>
        </div>
      ) : (
        /* Une liste de cartes et non un tableau : quatre champs par candidature, qu'on ne
           compare pas d'une ligne à l'autre. Un <table> n'apporterait rien ici, et il aurait
           fallu lui réimposer ses rôles ARIA à la main pour survivre au passage en cartes
           sous 800 px — `display: block` retire la sémantique de tableau.
           Chaque champ est un couple dt/dd : l'intitulé reste lu, à toutes les largeurs. */
        <ul className="cartes-candidature">
          {candidatures.map((candidature) => (
            <li key={candidature.id} className="carte carte-candidature">
              <div className="carte__entete">
                <h2 className="carte-candidature__titre">{candidature.posteLabel}</h2>
                <span className="badge">
                  {STATUT_LABEL[candidature.status] ?? candidature.status}
                </span>
              </div>
              <dl className="carte-candidature__details">
                <div>
                  <dt className="mono">Entreprise</dt>
                  <dd>
                    {candidature.companyName} · {candidature.siteLabel}
                  </dd>
                </div>
                <div>
                  <dt className="mono">Dates</dt>
                  <dd>
                    {formatDate(candidature.startDate)} → {formatDate(candidature.endDate)}
                  </dd>
                </div>
              </dl>
              <p className="carte-candidature__lien">
                <Link href={`/missions/${candidature.missionId}`}>Voir la mission</Link>
              </p>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
