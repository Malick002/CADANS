import localFont from 'next/font/local';

// Trois familles, servies depuis nos propres fichiers plutôt que depuis Google Fonts :
// aucune requête vers un tiers au chargement (RGPD, et trois requêtes de moins par visite —
// RGESN), et aucun accès réseau au moment du build, donc rien qui puisse faire échouer un
// déploiement Render.
//
// Un seul sous-ensemble par famille, « latin » : il couvre tout le français, œ et Œ compris
// (U+0152-0153) ainsi que l'euro. 65 Ko à trois. Licences à côté de ce fichier.

// Titres. Une serif de labeur, dessinée pour le texte long : elle tient les très grandes
// tailles du display sans paraître décorative.
export const policeTitre = localFont({
  src: [{ path: './crimson-text-400-latin.woff2', weight: '400', style: 'normal' }],
  variable: '--police-titre',
  display: 'swap',
  fallback: ['Iowan Old Style', 'Palatino', 'Georgia', 'serif'],
});

// Texte courant et interface. Fichier variable : une seule requête couvre 400, 500 et 700,
// là où trois fichiers statiques pèseraient plus lourd à eux seuls.
export const police = localFont({
  src: [{ path: './dm-sans-variable-latin.woff2', weight: '400 700', style: 'normal' }],
  variable: '--police',
  display: 'swap',
  fallback: ['system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
});

// Sur-titres, codes CACES, scores, dates. Une chasse fixe aligne les chiffres en colonne,
// ce qu'aucune graisse de DM Sans ne fait.
export const policeMono = localFont({
  src: [{ path: './roboto-mono-400-latin.woff2', weight: '400', style: 'normal' }],
  variable: '--police-mono',
  display: 'swap',
  fallback: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
});
