import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // Les pages publiques (annonces, listing de missions) doivent rester rendues
  // côté serveur : c'est la contrainte SEO du sujet. Pas d'export statique.
  poweredByHeader: false,
};

export default nextConfig;
